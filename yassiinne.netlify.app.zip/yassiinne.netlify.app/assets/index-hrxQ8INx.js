(function() {
    const e = document.createElement("link").relList;
    if (e && e.supports && e.supports("modulepreload")) return;
    for (const l of document.querySelectorAll('link[rel="modulepreload"]')) s(l);
    new MutationObserver(l => {
        for (const o of l)
            if (o.type === "childList")
                for (const c of o.addedNodes) c.tagName === "LINK" && c.rel === "modulepreload" && s(c)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function a(l) {
        const o = {};
        return l.integrity && (o.integrity = l.integrity), l.referrerPolicy && (o.referrerPolicy = l.referrerPolicy), l.crossOrigin === "use-credentials" ? o.credentials = "include" : l.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o
    }

    function s(l) {
        if (l.ep) return;
        l.ep = !0;
        const o = a(l);
        fetch(l.href, o)
    }
})();

function vu(n) {
    return n && n.__esModule && Object.prototype.hasOwnProperty.call(n, "default") ? n.default : n
}
var Hf = {
        exports: {}
    },
    Nr = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var h1;

function IT() {
    if (h1) return Nr;
    h1 = 1;
    var n = Symbol.for("react.transitional.element"),
        e = Symbol.for("react.fragment");

    function a(s, l, o) {
        var c = null;
        if (o !== void 0 && (c = "" + o), l.key !== void 0 && (c = "" + l.key), "key" in l) {
            o = {};
            for (var h in l) h !== "key" && (o[h] = l[h])
        } else o = l;
        return l = o.ref, {
            $$typeof: n,
            type: s,
            key: c,
            ref: l !== void 0 ? l : null,
            props: o
        }
    }
    return Nr.Fragment = e, Nr.jsx = a, Nr.jsxs = a, Nr
}
var m1;

function $T() {
    return m1 || (m1 = 1, Hf.exports = IT()), Hf.exports
}
var A = $T(),
    Gf = {
        exports: {}
    },
    me = {};
/**
 * @license React
 * react.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var p1;

function WT() {
    if (p1) return me;
    p1 = 1;
    var n = Symbol.for("react.transitional.element"),
        e = Symbol.for("react.portal"),
        a = Symbol.for("react.fragment"),
        s = Symbol.for("react.strict_mode"),
        l = Symbol.for("react.profiler"),
        o = Symbol.for("react.consumer"),
        c = Symbol.for("react.context"),
        h = Symbol.for("react.forward_ref"),
        f = Symbol.for("react.suspense"),
        m = Symbol.for("react.memo"),
        p = Symbol.for("react.lazy"),
        v = Symbol.iterator;

    function b(z) {
        return z === null || typeof z != "object" ? null : (z = v && z[v] || z["@@iterator"], typeof z == "function" ? z : null)
    }
    var y = {
            isMounted: function() {
                return !1
            },
            enqueueForceUpdate: function() {},
            enqueueReplaceState: function() {},
            enqueueSetState: function() {}
        },
        T = Object.assign,
        S = {};

    function M(z, Z, ne) {
        this.props = z, this.context = Z, this.refs = S, this.updater = ne || y
    }
    M.prototype.isReactComponent = {}, M.prototype.setState = function(z, Z) {
        if (typeof z != "object" && typeof z != "function" && z != null) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
        this.updater.enqueueSetState(this, z, Z, "setState")
    }, M.prototype.forceUpdate = function(z) {
        this.updater.enqueueForceUpdate(this, z, "forceUpdate")
    };

    function _() {}
    _.prototype = M.prototype;

    function w(z, Z, ne) {
        this.props = z, this.context = Z, this.refs = S, this.updater = ne || y
    }
    var C = w.prototype = new _;
    C.constructor = w, T(C, M.prototype), C.isPureReactComponent = !0;
    var L = Array.isArray,
        O = {
            H: null,
            A: null,
            T: null,
            S: null,
            V: null
        },
        V = Object.prototype.hasOwnProperty;

    function k(z, Z, ne, ie, le, pe) {
        return ne = pe.ref, {
            $$typeof: n,
            type: z,
            key: Z,
            ref: ne !== void 0 ? ne : null,
            props: pe
        }
    }

    function D(z, Z) {
        return k(z.type, Z, void 0, void 0, void 0, z.props)
    }

    function H(z) {
        return typeof z == "object" && z !== null && z.$$typeof === n
    }

    function F(z) {
        var Z = {
            "=": "=0",
            ":": "=2"
        };
        return "$" + z.replace(/[=:]/g, function(ne) {
            return Z[ne]
        })
    }
    var I = /\/+/g;

    function W(z, Z) {
        return typeof z == "object" && z !== null && z.key != null ? F("" + z.key) : Z.toString(36)
    }

    function ee() {}

    function ae(z) {
        switch (z.status) {
            case "fulfilled":
                return z.value;
            case "rejected":
                throw z.reason;
            default:
                switch (typeof z.status == "string" ? z.then(ee, ee) : (z.status = "pending", z.then(function(Z) {
                    z.status === "pending" && (z.status = "fulfilled", z.value = Z)
                }, function(Z) {
                    z.status === "pending" && (z.status = "rejected", z.reason = Z)
                })), z.status) {
                    case "fulfilled":
                        return z.value;
                    case "rejected":
                        throw z.reason
                }
        }
        throw z
    }

    function se(z, Z, ne, ie, le) {
        var pe = typeof z;
        (pe === "undefined" || pe === "boolean") && (z = null);
        var he = !1;
        if (z === null) he = !0;
        else switch (pe) {
            case "bigint":
            case "string":
            case "number":
                he = !0;
                break;
            case "object":
                switch (z.$$typeof) {
                    case n:
                    case e:
                        he = !0;
                        break;
                    case p:
                        return he = z._init, se(he(z._payload), Z, ne, ie, le)
                }
        }
        if (he) return le = le(z), he = ie === "" ? "." + W(z, 0) : ie, L(le) ? (ne = "", he != null && (ne = he.replace(I, "$&/") + "/"), se(le, Z, ne, "", function(ri) {
            return ri
        })) : le != null && (H(le) && (le = D(le, ne + (le.key == null || z && z.key === le.key ? "" : ("" + le.key).replace(I, "$&/") + "/") + he)), Z.push(le)), 1;
        he = 0;
        var kt = ie === "" ? "." : ie + ":";
        if (L(z))
            for (var Ne = 0; Ne < z.length; Ne++) ie = z[Ne], pe = kt + W(ie, Ne), he += se(ie, Z, ne, pe, le);
        else if (Ne = b(z), typeof Ne == "function")
            for (z = Ne.call(z), Ne = 0; !(ie = z.next()).done;) ie = ie.value, pe = kt + W(ie, Ne++), he += se(ie, Z, ne, pe, le);
        else if (pe === "object") {
            if (typeof z.then == "function") return se(ae(z), Z, ne, ie, le);
            throw Z = String(z), Error("Objects are not valid as a React child (found: " + (Z === "[object Object]" ? "object with keys {" + Object.keys(z).join(", ") + "}" : Z) + "). If you meant to render a collection of children, use an array instead.")
        }
        return he
    }

    function P(z, Z, ne) {
        if (z == null) return z;
        var ie = [],
            le = 0;
        return se(z, ie, "", "", function(pe) {
            return Z.call(ne, pe, le++)
        }), ie
    }

    function G(z) {
        if (z._status === -1) {
            var Z = z._result;
            Z = Z(), Z.then(function(ne) {
                (z._status === 0 || z._status === -1) && (z._status = 1, z._result = ne)
            }, function(ne) {
                (z._status === 0 || z._status === -1) && (z._status = 2, z._result = ne)
            }), z._status === -1 && (z._status = 0, z._result = Z)
        }
        if (z._status === 1) return z._result.default;
        throw z._result
    }
    var X = typeof reportError == "function" ? reportError : function(z) {
        if (typeof window == "object" && typeof window.ErrorEvent == "function") {
            var Z = new window.ErrorEvent("error", {
                bubbles: !0,
                cancelable: !0,
                message: typeof z == "object" && z !== null && typeof z.message == "string" ? String(z.message) : String(z),
                error: z
            });
            if (!window.dispatchEvent(Z)) return
        } else if (typeof process == "object" && typeof process.emit == "function") {
            process.emit("uncaughtException", z);
            return
        }
        console.error(z)
    };

    function te() {}
    return me.Children = {
        map: P,
        forEach: function(z, Z, ne) {
            P(z, function() {
                Z.apply(this, arguments)
            }, ne)
        },
        count: function(z) {
            var Z = 0;
            return P(z, function() {
                Z++
            }), Z
        },
        toArray: function(z) {
            return P(z, function(Z) {
                return Z
            }) || []
        },
        only: function(z) {
            if (!H(z)) throw Error("React.Children.only expected to receive a single React element child.");
            return z
        }
    }, me.Component = M, me.Fragment = a, me.Profiler = l, me.PureComponent = w, me.StrictMode = s, me.Suspense = f, me.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = O, me.__COMPILER_RUNTIME = {
        __proto__: null,
        c: function(z) {
            return O.H.useMemoCache(z)
        }
    }, me.cache = function(z) {
        return function() {
            return z.apply(null, arguments)
        }
    }, me.cloneElement = function(z, Z, ne) {
        if (z == null) throw Error("The argument must be a React element, but you passed " + z + ".");
        var ie = T({}, z.props),
            le = z.key,
            pe = void 0;
        if (Z != null)
            for (he in Z.ref !== void 0 && (pe = void 0), Z.key !== void 0 && (le = "" + Z.key), Z) !V.call(Z, he) || he === "key" || he === "__self" || he === "__source" || he === "ref" && Z.ref === void 0 || (ie[he] = Z[he]);
        var he = arguments.length - 2;
        if (he === 1) ie.children = ne;
        else if (1 < he) {
            for (var kt = Array(he), Ne = 0; Ne < he; Ne++) kt[Ne] = arguments[Ne + 2];
            ie.children = kt
        }
        return k(z.type, le, void 0, void 0, pe, ie)
    }, me.createContext = function(z) {
        return z = {
            $$typeof: c,
            _currentValue: z,
            _currentValue2: z,
            _threadCount: 0,
            Provider: null,
            Consumer: null
        }, z.Provider = z, z.Consumer = {
            $$typeof: o,
            _context: z
        }, z
    }, me.createElement = function(z, Z, ne) {
        var ie, le = {},
            pe = null;
        if (Z != null)
            for (ie in Z.key !== void 0 && (pe = "" + Z.key), Z) V.call(Z, ie) && ie !== "key" && ie !== "__self" && ie !== "__source" && (le[ie] = Z[ie]);
        var he = arguments.length - 2;
        if (he === 1) le.children = ne;
        else if (1 < he) {
            for (var kt = Array(he), Ne = 0; Ne < he; Ne++) kt[Ne] = arguments[Ne + 2];
            le.children = kt
        }
        if (z && z.defaultProps)
            for (ie in he = z.defaultProps, he) le[ie] === void 0 && (le[ie] = he[ie]);
        return k(z, pe, void 0, void 0, null, le)
    }, me.createRef = function() {
        return {
            current: null
        }
    }, me.forwardRef = function(z) {
        return {
            $$typeof: h,
            render: z
        }
    }, me.isValidElement = H, me.lazy = function(z) {
        return {
            $$typeof: p,
            _payload: {
                _status: -1,
                _result: z
            },
            _init: G
        }
    }, me.memo = function(z, Z) {
        return {
            $$typeof: m,
            type: z,
            compare: Z === void 0 ? null : Z
        }
    }, me.startTransition = function(z) {
        var Z = O.T,
            ne = {};
        O.T = ne;
        try {
            var ie = z(),
                le = O.S;
            le !== null && le(ne, ie), typeof ie == "object" && ie !== null && typeof ie.then == "function" && ie.then(te, X)
        } catch (pe) {
            X(pe)
        } finally {
            O.T = Z
        }
    }, me.unstable_useCacheRefresh = function() {
        return O.H.useCacheRefresh()
    }, me.use = function(z) {
        return O.H.use(z)
    }, me.useActionState = function(z, Z, ne) {
        return O.H.useActionState(z, Z, ne)
    }, me.useCallback = function(z, Z) {
        return O.H.useCallback(z, Z)
    }, me.useContext = function(z) {
        return O.H.useContext(z)
    }, me.useDebugValue = function() {}, me.useDeferredValue = function(z, Z) {
        return O.H.useDeferredValue(z, Z)
    }, me.useEffect = function(z, Z, ne) {
        var ie = O.H;
        if (typeof ne == "function") throw Error("useEffect CRUD overload is not enabled in this build of React.");
        return ie.useEffect(z, Z)
    }, me.useId = function() {
        return O.H.useId()
    }, me.useImperativeHandle = function(z, Z, ne) {
        return O.H.useImperativeHandle(z, Z, ne)
    }, me.useInsertionEffect = function(z, Z) {
        return O.H.useInsertionEffect(z, Z)
    }, me.useLayoutEffect = function(z, Z) {
        return O.H.useLayoutEffect(z, Z)
    }, me.useMemo = function(z, Z) {
        return O.H.useMemo(z, Z)
    }, me.useOptimistic = function(z, Z) {
        return O.H.useOptimistic(z, Z)
    }, me.useReducer = function(z, Z, ne) {
        return O.H.useReducer(z, Z, ne)
    }, me.useRef = function(z) {
        return O.H.useRef(z)
    }, me.useState = function(z) {
        return O.H.useState(z)
    }, me.useSyncExternalStore = function(z, Z, ne) {
        return O.H.useSyncExternalStore(z, Z, ne)
    }, me.useTransition = function() {
        return O.H.useTransition()
    }, me.version = "19.1.1", me
}
var g1;

function vh() {
    return g1 || (g1 = 1, Gf.exports = WT()), Gf.exports
}
var J = vh();
const xe = vu(J);
var qf = {
        exports: {}
    },
    Vr = {},
    Yf = {
        exports: {}
    },
    Xf = {};
/**
 * @license React
 * scheduler.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var v1;

function JT() {
    return v1 || (v1 = 1, (function(n) {
        function e(P, G) {
            var X = P.length;
            P.push(G);
            e: for (; 0 < X;) {
                var te = X - 1 >>> 1,
                    z = P[te];
                if (0 < l(z, G)) P[te] = G, P[X] = z, X = te;
                else break e
            }
        }

        function a(P) {
            return P.length === 0 ? null : P[0]
        }

        function s(P) {
            if (P.length === 0) return null;
            var G = P[0],
                X = P.pop();
            if (X !== G) {
                P[0] = X;
                e: for (var te = 0, z = P.length, Z = z >>> 1; te < Z;) {
                    var ne = 2 * (te + 1) - 1,
                        ie = P[ne],
                        le = ne + 1,
                        pe = P[le];
                    if (0 > l(ie, X)) le < z && 0 > l(pe, ie) ? (P[te] = pe, P[le] = X, te = le) : (P[te] = ie, P[ne] = X, te = ne);
                    else if (le < z && 0 > l(pe, X)) P[te] = pe, P[le] = X, te = le;
                    else break e
                }
            }
            return G
        }

        function l(P, G) {
            var X = P.sortIndex - G.sortIndex;
            return X !== 0 ? X : P.id - G.id
        }
        if (n.unstable_now = void 0, typeof performance == "object" && typeof performance.now == "function") {
            var o = performance;
            n.unstable_now = function() {
                return o.now()
            }
        } else {
            var c = Date,
                h = c.now();
            n.unstable_now = function() {
                return c.now() - h
            }
        }
        var f = [],
            m = [],
            p = 1,
            v = null,
            b = 3,
            y = !1,
            T = !1,
            S = !1,
            M = !1,
            _ = typeof setTimeout == "function" ? setTimeout : null,
            w = typeof clearTimeout == "function" ? clearTimeout : null,
            C = typeof setImmediate < "u" ? setImmediate : null;

        function L(P) {
            for (var G = a(m); G !== null;) {
                if (G.callback === null) s(m);
                else if (G.startTime <= P) s(m), G.sortIndex = G.expirationTime, e(f, G);
                else break;
                G = a(m)
            }
        }

        function O(P) {
            if (S = !1, L(P), !T)
                if (a(f) !== null) T = !0, V || (V = !0, W());
                else {
                    var G = a(m);
                    G !== null && se(O, G.startTime - P)
                }
        }
        var V = !1,
            k = -1,
            D = 5,
            H = -1;

        function F() {
            return M ? !0 : !(n.unstable_now() - H < D)
        }

        function I() {
            if (M = !1, V) {
                var P = n.unstable_now();
                H = P;
                var G = !0;
                try {
                    e: {
                        T = !1,
                        S && (S = !1, w(k), k = -1),
                        y = !0;
                        var X = b;
                        try {
                            t: {
                                for (L(P), v = a(f); v !== null && !(v.expirationTime > P && F());) {
                                    var te = v.callback;
                                    if (typeof te == "function") {
                                        v.callback = null, b = v.priorityLevel;
                                        var z = te(v.expirationTime <= P);
                                        if (P = n.unstable_now(), typeof z == "function") {
                                            v.callback = z, L(P), G = !0;
                                            break t
                                        }
                                        v === a(f) && s(f), L(P)
                                    } else s(f);
                                    v = a(f)
                                }
                                if (v !== null) G = !0;
                                else {
                                    var Z = a(m);
                                    Z !== null && se(O, Z.startTime - P), G = !1
                                }
                            }
                            break e
                        }
                        finally {
                            v = null, b = X, y = !1
                        }
                        G = void 0
                    }
                }
                finally {
                    G ? W() : V = !1
                }
            }
        }
        var W;
        if (typeof C == "function") W = function() {
            C(I)
        };
        else if (typeof MessageChannel < "u") {
            var ee = new MessageChannel,
                ae = ee.port2;
            ee.port1.onmessage = I, W = function() {
                ae.postMessage(null)
            }
        } else W = function() {
            _(I, 0)
        };

        function se(P, G) {
            k = _(function() {
                P(n.unstable_now())
            }, G)
        }
        n.unstable_IdlePriority = 5, n.unstable_ImmediatePriority = 1, n.unstable_LowPriority = 4, n.unstable_NormalPriority = 3, n.unstable_Profiling = null, n.unstable_UserBlockingPriority = 2, n.unstable_cancelCallback = function(P) {
            P.callback = null
        }, n.unstable_forceFrameRate = function(P) {
            0 > P || 125 < P ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : D = 0 < P ? Math.floor(1e3 / P) : 5
        }, n.unstable_getCurrentPriorityLevel = function() {
            return b
        }, n.unstable_next = function(P) {
            switch (b) {
                case 1:
                case 2:
                case 3:
                    var G = 3;
                    break;
                default:
                    G = b
            }
            var X = b;
            b = G;
            try {
                return P()
            } finally {
                b = X
            }
        }, n.unstable_requestPaint = function() {
            M = !0
        }, n.unstable_runWithPriority = function(P, G) {
            switch (P) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    P = 3
            }
            var X = b;
            b = P;
            try {
                return G()
            } finally {
                b = X
            }
        }, n.unstable_scheduleCallback = function(P, G, X) {
            var te = n.unstable_now();
            switch (typeof X == "object" && X !== null ? (X = X.delay, X = typeof X == "number" && 0 < X ? te + X : te) : X = te, P) {
                case 1:
                    var z = -1;
                    break;
                case 2:
                    z = 250;
                    break;
                case 5:
                    z = 1073741823;
                    break;
                case 4:
                    z = 1e4;
                    break;
                default:
                    z = 5e3
            }
            return z = X + z, P = {
                id: p++,
                callback: G,
                priorityLevel: P,
                startTime: X,
                expirationTime: z,
                sortIndex: -1
            }, X > te ? (P.sortIndex = X, e(m, P), a(f) === null && P === a(m) && (S ? (w(k), k = -1) : S = !0, se(O, X - te))) : (P.sortIndex = z, e(f, P), T || y || (T = !0, V || (V = !0, W()))), P
        }, n.unstable_shouldYield = F, n.unstable_wrapCallback = function(P) {
            var G = b;
            return function() {
                var X = b;
                b = G;
                try {
                    return P.apply(this, arguments)
                } finally {
                    b = X
                }
            }
        }
    })(Xf)), Xf
}
var y1;

function e_() {
    return y1 || (y1 = 1, Yf.exports = JT()), Yf.exports
}
var Ff = {
        exports: {}
    },
    yt = {};
/**
 * @license React
 * react-dom.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var b1;

function t_() {
    if (b1) return yt;
    b1 = 1;
    var n = vh();

    function e(f) {
        var m = "https://react.dev/errors/" + f;
        if (1 < arguments.length) {
            m += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var p = 2; p < arguments.length; p++) m += "&args[]=" + encodeURIComponent(arguments[p])
        }
        return "Minified React error #" + f + "; visit " + m + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function a() {}
    var s = {
            d: {
                f: a,
                r: function() {
                    throw Error(e(522))
                },
                D: a,
                C: a,
                L: a,
                m: a,
                X: a,
                S: a,
                M: a
            },
            p: 0,
            findDOMNode: null
        },
        l = Symbol.for("react.portal");

    function o(f, m, p) {
        var v = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
        return {
            $$typeof: l,
            key: v == null ? null : "" + v,
            children: f,
            containerInfo: m,
            implementation: p
        }
    }
    var c = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

    function h(f, m) {
        if (f === "font") return "";
        if (typeof m == "string") return m === "use-credentials" ? m : ""
    }
    return yt.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = s, yt.createPortal = function(f, m) {
        var p = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
        if (!m || m.nodeType !== 1 && m.nodeType !== 9 && m.nodeType !== 11) throw Error(e(299));
        return o(f, m, null, p)
    }, yt.flushSync = function(f) {
        var m = c.T,
            p = s.p;
        try {
            if (c.T = null, s.p = 2, f) return f()
        } finally {
            c.T = m, s.p = p, s.d.f()
        }
    }, yt.preconnect = function(f, m) {
        typeof f == "string" && (m ? (m = m.crossOrigin, m = typeof m == "string" ? m === "use-credentials" ? m : "" : void 0) : m = null, s.d.C(f, m))
    }, yt.prefetchDNS = function(f) {
        typeof f == "string" && s.d.D(f)
    }, yt.preinit = function(f, m) {
        if (typeof f == "string" && m && typeof m.as == "string") {
            var p = m.as,
                v = h(p, m.crossOrigin),
                b = typeof m.integrity == "string" ? m.integrity : void 0,
                y = typeof m.fetchPriority == "string" ? m.fetchPriority : void 0;
            p === "style" ? s.d.S(f, typeof m.precedence == "string" ? m.precedence : void 0, {
                crossOrigin: v,
                integrity: b,
                fetchPriority: y
            }) : p === "script" && s.d.X(f, {
                crossOrigin: v,
                integrity: b,
                fetchPriority: y,
                nonce: typeof m.nonce == "string" ? m.nonce : void 0
            })
        }
    }, yt.preinitModule = function(f, m) {
        if (typeof f == "string")
            if (typeof m == "object" && m !== null) {
                if (m.as == null || m.as === "script") {
                    var p = h(m.as, m.crossOrigin);
                    s.d.M(f, {
                        crossOrigin: p,
                        integrity: typeof m.integrity == "string" ? m.integrity : void 0,
                        nonce: typeof m.nonce == "string" ? m.nonce : void 0
                    })
                }
            } else m == null && s.d.M(f)
    }, yt.preload = function(f, m) {
        if (typeof f == "string" && typeof m == "object" && m !== null && typeof m.as == "string") {
            var p = m.as,
                v = h(p, m.crossOrigin);
            s.d.L(f, p, {
                crossOrigin: v,
                integrity: typeof m.integrity == "string" ? m.integrity : void 0,
                nonce: typeof m.nonce == "string" ? m.nonce : void 0,
                type: typeof m.type == "string" ? m.type : void 0,
                fetchPriority: typeof m.fetchPriority == "string" ? m.fetchPriority : void 0,
                referrerPolicy: typeof m.referrerPolicy == "string" ? m.referrerPolicy : void 0,
                imageSrcSet: typeof m.imageSrcSet == "string" ? m.imageSrcSet : void 0,
                imageSizes: typeof m.imageSizes == "string" ? m.imageSizes : void 0,
                media: typeof m.media == "string" ? m.media : void 0
            })
        }
    }, yt.preloadModule = function(f, m) {
        if (typeof f == "string")
            if (m) {
                var p = h(m.as, m.crossOrigin);
                s.d.m(f, {
                    as: typeof m.as == "string" && m.as !== "script" ? m.as : void 0,
                    crossOrigin: p,
                    integrity: typeof m.integrity == "string" ? m.integrity : void 0
                })
            } else s.d.m(f)
    }, yt.requestFormReset = function(f) {
        s.d.r(f)
    }, yt.unstable_batchedUpdates = function(f, m) {
        return f(m)
    }, yt.useFormState = function(f, m, p) {
        return c.H.useFormState(f, m, p)
    }, yt.useFormStatus = function() {
        return c.H.useHostTransitionStatus()
    }, yt.version = "19.1.1", yt
}
var x1;

function n_() {
    if (x1) return Ff.exports;
    x1 = 1;

    function n() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
        } catch (e) {
            console.error(e)
        }
    }
    return n(), Ff.exports = t_(), Ff.exports
}
/**
 * @license React
 * react-dom-client.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var S1;

function i_() {
    if (S1) return Vr;
    S1 = 1;
    var n = e_(),
        e = vh(),
        a = n_();

    function s(t) {
        var i = "https://react.dev/errors/" + t;
        if (1 < arguments.length) {
            i += "?args[]=" + encodeURIComponent(arguments[1]);
            for (var r = 2; r < arguments.length; r++) i += "&args[]=" + encodeURIComponent(arguments[r])
        }
        return "Minified React error #" + t + "; visit " + i + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
    }

    function l(t) {
        return !(!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11)
    }

    function o(t) {
        var i = t,
            r = t;
        if (t.alternate)
            for (; i.return;) i = i.return;
        else {
            t = i;
            do i = t, (i.flags & 4098) !== 0 && (r = i.return), t = i.return; while (t)
        }
        return i.tag === 3 ? r : null
    }

    function c(t) {
        if (t.tag === 13) {
            var i = t.memoizedState;
            if (i === null && (t = t.alternate, t !== null && (i = t.memoizedState)), i !== null) return i.dehydrated
        }
        return null
    }

    function h(t) {
        if (o(t) !== t) throw Error(s(188))
    }

    function f(t) {
        var i = t.alternate;
        if (!i) {
            if (i = o(t), i === null) throw Error(s(188));
            return i !== t ? null : t
        }
        for (var r = t, u = i;;) {
            var d = r.return;
            if (d === null) break;
            var g = d.alternate;
            if (g === null) {
                if (u = d.return, u !== null) {
                    r = u;
                    continue
                }
                break
            }
            if (d.child === g.child) {
                for (g = d.child; g;) {
                    if (g === r) return h(d), t;
                    if (g === u) return h(d), i;
                    g = g.sibling
                }
                throw Error(s(188))
            }
            if (r.return !== u.return) r = d, u = g;
            else {
                for (var x = !1, E = d.child; E;) {
                    if (E === r) {
                        x = !0, r = d, u = g;
                        break
                    }
                    if (E === u) {
                        x = !0, u = d, r = g;
                        break
                    }
                    E = E.sibling
                }
                if (!x) {
                    for (E = g.child; E;) {
                        if (E === r) {
                            x = !0, r = g, u = d;
                            break
                        }
                        if (E === u) {
                            x = !0, u = g, r = d;
                            break
                        }
                        E = E.sibling
                    }
                    if (!x) throw Error(s(189))
                }
            }
            if (r.alternate !== u) throw Error(s(190))
        }
        if (r.tag !== 3) throw Error(s(188));
        return r.stateNode.current === r ? t : i
    }

    function m(t) {
        var i = t.tag;
        if (i === 5 || i === 26 || i === 27 || i === 6) return t;
        for (t = t.child; t !== null;) {
            if (i = m(t), i !== null) return i;
            t = t.sibling
        }
        return null
    }
    var p = Object.assign,
        v = Symbol.for("react.element"),
        b = Symbol.for("react.transitional.element"),
        y = Symbol.for("react.portal"),
        T = Symbol.for("react.fragment"),
        S = Symbol.for("react.strict_mode"),
        M = Symbol.for("react.profiler"),
        _ = Symbol.for("react.provider"),
        w = Symbol.for("react.consumer"),
        C = Symbol.for("react.context"),
        L = Symbol.for("react.forward_ref"),
        O = Symbol.for("react.suspense"),
        V = Symbol.for("react.suspense_list"),
        k = Symbol.for("react.memo"),
        D = Symbol.for("react.lazy"),
        H = Symbol.for("react.activity"),
        F = Symbol.for("react.memo_cache_sentinel"),
        I = Symbol.iterator;

    function W(t) {
        return t === null || typeof t != "object" ? null : (t = I && t[I] || t["@@iterator"], typeof t == "function" ? t : null)
    }
    var ee = Symbol.for("react.client.reference");

    function ae(t) {
        if (t == null) return null;
        if (typeof t == "function") return t.$$typeof === ee ? null : t.displayName || t.name || null;
        if (typeof t == "string") return t;
        switch (t) {
            case T:
                return "Fragment";
            case M:
                return "Profiler";
            case S:
                return "StrictMode";
            case O:
                return "Suspense";
            case V:
                return "SuspenseList";
            case H:
                return "Activity"
        }
        if (typeof t == "object") switch (t.$$typeof) {
            case y:
                return "Portal";
            case C:
                return (t.displayName || "Context") + ".Provider";
            case w:
                return (t._context.displayName || "Context") + ".Consumer";
            case L:
                var i = t.render;
                return t = t.displayName, t || (t = i.displayName || i.name || "", t = t !== "" ? "ForwardRef(" + t + ")" : "ForwardRef"), t;
            case k:
                return i = t.displayName || null, i !== null ? i : ae(t.type) || "Memo";
            case D:
                i = t._payload, t = t._init;
                try {
                    return ae(t(i))
                } catch {}
        }
        return null
    }
    var se = Array.isArray,
        P = e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        G = a.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
        X = {
            pending: !1,
            data: null,
            method: null,
            action: null
        },
        te = [],
        z = -1;

    function Z(t) {
        return {
            current: t
        }
    }

    function ne(t) {
        0 > z || (t.current = te[z], te[z] = null, z--)
    }

    function ie(t, i) {
        z++, te[z] = t.current, t.current = i
    }
    var le = Z(null),
        pe = Z(null),
        he = Z(null),
        kt = Z(null);

    function Ne(t, i) {
        switch (ie(he, i), ie(pe, t), ie(le, null), i.nodeType) {
            case 9:
            case 11:
                t = (t = i.documentElement) && (t = t.namespaceURI) ? Hg(t) : 0;
                break;
            default:
                if (t = i.tagName, i = i.namespaceURI) i = Hg(i), t = Gg(i, t);
                else switch (t) {
                    case "svg":
                        t = 1;
                        break;
                    case "math":
                        t = 2;
                        break;
                    default:
                        t = 0
                }
        }
        ne(le), ie(le, t)
    }

    function ri() {
        ne(le), ne(pe), ne(he)
    }

    function wu(t) {
        t.memoizedState !== null && ie(kt, t);
        var i = le.current,
            r = Gg(i, t.type);
        i !== r && (ie(pe, t), ie(le, r))
    }

    function Sl(t) {
        pe.current === t && (ne(le), ne(pe)), kt.current === t && (ne(kt), Dr._currentValue = X)
    }
    var Mu = Object.prototype.hasOwnProperty,
        Au = n.unstable_scheduleCallback,
        Cu = n.unstable_cancelCallback,
        Cx = n.unstable_shouldYield,
        Ox = n.unstable_requestPaint,
        En = n.unstable_now,
        Dx = n.unstable_getCurrentPriorityLevel,
        Sm = n.unstable_ImmediatePriority,
        Tm = n.unstable_UserBlockingPriority,
        Tl = n.unstable_NormalPriority,
        zx = n.unstable_LowPriority,
        _m = n.unstable_IdlePriority,
        Rx = n.log,
        Lx = n.unstable_setDisableYieldValue,
        Bs = null,
        Bt = null;

    function li(t) {
        if (typeof Rx == "function" && Lx(t), Bt && typeof Bt.setStrictMode == "function") try {
            Bt.setStrictMode(Bs, t)
        } catch {}
    }
    var Pt = Math.clz32 ? Math.clz32 : Vx,
        jx = Math.log,
        Nx = Math.LN2;

    function Vx(t) {
        return t >>>= 0, t === 0 ? 32 : 31 - (jx(t) / Nx | 0) | 0
    }
    var _l = 256,
        El = 4194304;

    function Xi(t) {
        var i = t & 42;
        if (i !== 0) return i;
        switch (t & -t) {
            case 1:
                return 1;
            case 2:
                return 2;
            case 4:
                return 4;
            case 8:
                return 8;
            case 16:
                return 16;
            case 32:
                return 32;
            case 64:
                return 64;
            case 128:
                return 128;
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return t & 4194048;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                return t & 62914560;
            case 67108864:
                return 67108864;
            case 134217728:
                return 134217728;
            case 268435456:
                return 268435456;
            case 536870912:
                return 536870912;
            case 1073741824:
                return 0;
            default:
                return t
        }
    }

    function wl(t, i, r) {
        var u = t.pendingLanes;
        if (u === 0) return 0;
        var d = 0,
            g = t.suspendedLanes,
            x = t.pingedLanes;
        t = t.warmLanes;
        var E = u & 134217727;
        return E !== 0 ? (u = E & ~g, u !== 0 ? d = Xi(u) : (x &= E, x !== 0 ? d = Xi(x) : r || (r = E & ~t, r !== 0 && (d = Xi(r))))) : (E = u & ~g, E !== 0 ? d = Xi(E) : x !== 0 ? d = Xi(x) : r || (r = u & ~t, r !== 0 && (d = Xi(r)))), d === 0 ? 0 : i !== 0 && i !== d && (i & g) === 0 && (g = d & -d, r = i & -i, g >= r || g === 32 && (r & 4194048) !== 0) ? i : d
    }

    function Ps(t, i) {
        return (t.pendingLanes & ~(t.suspendedLanes & ~t.pingedLanes) & i) === 0
    }

    function kx(t, i) {
        switch (t) {
            case 1:
            case 2:
            case 4:
            case 8:
            case 64:
                return i + 250;
            case 16:
            case 32:
            case 128:
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
                return i + 5e3;
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                return -1;
            case 67108864:
            case 134217728:
            case 268435456:
            case 536870912:
            case 1073741824:
                return -1;
            default:
                return -1
        }
    }

    function Em() {
        var t = _l;
        return _l <<= 1, (_l & 4194048) === 0 && (_l = 256), t
    }

    function wm() {
        var t = El;
        return El <<= 1, (El & 62914560) === 0 && (El = 4194304), t
    }

    function Ou(t) {
        for (var i = [], r = 0; 31 > r; r++) i.push(t);
        return i
    }

    function Us(t, i) {
        t.pendingLanes |= i, i !== 268435456 && (t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0)
    }

    function Bx(t, i, r, u, d, g) {
        var x = t.pendingLanes;
        t.pendingLanes = r, t.suspendedLanes = 0, t.pingedLanes = 0, t.warmLanes = 0, t.expiredLanes &= r, t.entangledLanes &= r, t.errorRecoveryDisabledLanes &= r, t.shellSuspendCounter = 0;
        var E = t.entanglements,
            R = t.expirationTimes,
            U = t.hiddenUpdates;
        for (r = x & ~r; 0 < r;) {
            var K = 31 - Pt(r),
                $ = 1 << K;
            E[K] = 0, R[K] = -1;
            var q = U[K];
            if (q !== null)
                for (U[K] = null, K = 0; K < q.length; K++) {
                    var Y = q[K];
                    Y !== null && (Y.lane &= -536870913)
                }
            r &= ~$
        }
        u !== 0 && Mm(t, u, 0), g !== 0 && d === 0 && t.tag !== 0 && (t.suspendedLanes |= g & ~(x & ~i))
    }

    function Mm(t, i, r) {
        t.pendingLanes |= i, t.suspendedLanes &= ~i;
        var u = 31 - Pt(i);
        t.entangledLanes |= i, t.entanglements[u] = t.entanglements[u] | 1073741824 | r & 4194090
    }

    function Am(t, i) {
        var r = t.entangledLanes |= i;
        for (t = t.entanglements; r;) {
            var u = 31 - Pt(r),
                d = 1 << u;
            d & i | t[u] & i && (t[u] |= i), r &= ~d
        }
    }

    function Du(t) {
        switch (t) {
            case 2:
                t = 1;
                break;
            case 8:
                t = 4;
                break;
            case 32:
                t = 16;
                break;
            case 256:
            case 512:
            case 1024:
            case 2048:
            case 4096:
            case 8192:
            case 16384:
            case 32768:
            case 65536:
            case 131072:
            case 262144:
            case 524288:
            case 1048576:
            case 2097152:
            case 4194304:
            case 8388608:
            case 16777216:
            case 33554432:
                t = 128;
                break;
            case 268435456:
                t = 134217728;
                break;
            default:
                t = 0
        }
        return t
    }

    function zu(t) {
        return t &= -t, 2 < t ? 8 < t ? (t & 134217727) !== 0 ? 32 : 268435456 : 8 : 2
    }

    function Cm() {
        var t = G.p;
        return t !== 0 ? t : (t = window.event, t === void 0 ? 32 : l1(t.type))
    }

    function Px(t, i) {
        var r = G.p;
        try {
            return G.p = t, i()
        } finally {
            G.p = r
        }
    }
    var oi = Math.random().toString(36).slice(2),
        gt = "__reactFiber$" + oi,
        Mt = "__reactProps$" + oi,
        wa = "__reactContainer$" + oi,
        Ru = "__reactEvents$" + oi,
        Ux = "__reactListeners$" + oi,
        Hx = "__reactHandles$" + oi,
        Om = "__reactResources$" + oi,
        Hs = "__reactMarker$" + oi;

    function Lu(t) {
        delete t[gt], delete t[Mt], delete t[Ru], delete t[Ux], delete t[Hx]
    }

    function Ma(t) {
        var i = t[gt];
        if (i) return i;
        for (var r = t.parentNode; r;) {
            if (i = r[wa] || r[gt]) {
                if (r = i.alternate, i.child !== null || r !== null && r.child !== null)
                    for (t = Fg(t); t !== null;) {
                        if (r = t[gt]) return r;
                        t = Fg(t)
                    }
                return i
            }
            t = r, r = t.parentNode
        }
        return null
    }

    function Aa(t) {
        if (t = t[gt] || t[wa]) {
            var i = t.tag;
            if (i === 5 || i === 6 || i === 13 || i === 26 || i === 27 || i === 3) return t
        }
        return null
    }

    function Gs(t) {
        var i = t.tag;
        if (i === 5 || i === 26 || i === 27 || i === 6) return t.stateNode;
        throw Error(s(33))
    }

    function Ca(t) {
        var i = t[Om];
        return i || (i = t[Om] = {
            hoistableStyles: new Map,
            hoistableScripts: new Map
        }), i
    }

    function st(t) {
        t[Hs] = !0
    }
    var Dm = new Set,
        zm = {};

    function Fi(t, i) {
        Oa(t, i), Oa(t + "Capture", i)
    }

    function Oa(t, i) {
        for (zm[t] = i, t = 0; t < i.length; t++) Dm.add(i[t])
    }
    var Gx = RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),
        Rm = {},
        Lm = {};

    function qx(t) {
        return Mu.call(Lm, t) ? !0 : Mu.call(Rm, t) ? !1 : Gx.test(t) ? Lm[t] = !0 : (Rm[t] = !0, !1)
    }

    function Ml(t, i, r) {
        if (qx(i))
            if (r === null) t.removeAttribute(i);
            else {
                switch (typeof r) {
                    case "undefined":
                    case "function":
                    case "symbol":
                        t.removeAttribute(i);
                        return;
                    case "boolean":
                        var u = i.toLowerCase().slice(0, 5);
                        if (u !== "data-" && u !== "aria-") {
                            t.removeAttribute(i);
                            return
                        }
                }
                t.setAttribute(i, "" + r)
            }
    }

    function Al(t, i, r) {
        if (r === null) t.removeAttribute(i);
        else {
            switch (typeof r) {
                case "undefined":
                case "function":
                case "symbol":
                case "boolean":
                    t.removeAttribute(i);
                    return
            }
            t.setAttribute(i, "" + r)
        }
    }

    function Bn(t, i, r, u) {
        if (u === null) t.removeAttribute(r);
        else {
            switch (typeof u) {
                case "undefined":
                case "function":
                case "symbol":
                case "boolean":
                    t.removeAttribute(r);
                    return
            }
            t.setAttributeNS(i, r, "" + u)
        }
    }
    var ju, jm;

    function Da(t) {
        if (ju === void 0) try {
            throw Error()
        } catch (r) {
            var i = r.stack.trim().match(/\n( *(at )?)/);
            ju = i && i[1] || "", jm = -1 < r.stack.indexOf(`
    at`) ? " (<anonymous>)" : -1 < r.stack.indexOf("@") ? "@unknown:0:0" : ""
        }
        return `
` + ju + t + jm
    }
    var Nu = !1;

    function Vu(t, i) {
        if (!t || Nu) return "";
        Nu = !0;
        var r = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        try {
            var u = {
                DetermineComponentFrameRoot: function() {
                    try {
                        if (i) {
                            var $ = function() {
                                throw Error()
                            };
                            if (Object.defineProperty($.prototype, "props", {
                                    set: function() {
                                        throw Error()
                                    }
                                }), typeof Reflect == "object" && Reflect.construct) {
                                try {
                                    Reflect.construct($, [])
                                } catch (Y) {
                                    var q = Y
                                }
                                Reflect.construct(t, [], $)
                            } else {
                                try {
                                    $.call()
                                } catch (Y) {
                                    q = Y
                                }
                                t.call($.prototype)
                            }
                        } else {
                            try {
                                throw Error()
                            } catch (Y) {
                                q = Y
                            }($ = t()) && typeof $.catch == "function" && $.catch(function() {})
                        }
                    } catch (Y) {
                        if (Y && q && typeof Y.stack == "string") return [Y.stack, q.stack]
                    }
                    return [null, null]
                }
            };
            u.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
            var d = Object.getOwnPropertyDescriptor(u.DetermineComponentFrameRoot, "name");
            d && d.configurable && Object.defineProperty(u.DetermineComponentFrameRoot, "name", {
                value: "DetermineComponentFrameRoot"
            });
            var g = u.DetermineComponentFrameRoot(),
                x = g[0],
                E = g[1];
            if (x && E) {
                var R = x.split(`
`),
                    U = E.split(`
`);
                for (d = u = 0; u < R.length && !R[u].includes("DetermineComponentFrameRoot");) u++;
                for (; d < U.length && !U[d].includes("DetermineComponentFrameRoot");) d++;
                if (u === R.length || d === U.length)
                    for (u = R.length - 1, d = U.length - 1; 1 <= u && 0 <= d && R[u] !== U[d];) d--;
                for (; 1 <= u && 0 <= d; u--, d--)
                    if (R[u] !== U[d]) {
                        if (u !== 1 || d !== 1)
                            do
                                if (u--, d--, 0 > d || R[u] !== U[d]) {
                                    var K = `
` + R[u].replace(" at new ", " at ");
                                    return t.displayName && K.includes("<anonymous>") && (K = K.replace("<anonymous>", t.displayName)), K
                                }
                        while (1 <= u && 0 <= d);
                        break
                    }
            }
        } finally {
            Nu = !1, Error.prepareStackTrace = r
        }
        return (r = t ? t.displayName || t.name : "") ? Da(r) : ""
    }

    function Yx(t) {
        switch (t.tag) {
            case 26:
            case 27:
            case 5:
                return Da(t.type);
            case 16:
                return Da("Lazy");
            case 13:
                return Da("Suspense");
            case 19:
                return Da("SuspenseList");
            case 0:
            case 15:
                return Vu(t.type, !1);
            case 11:
                return Vu(t.type.render, !1);
            case 1:
                return Vu(t.type, !0);
            case 31:
                return Da("Activity");
            default:
                return ""
        }
    }

    function Nm(t) {
        try {
            var i = "";
            do i += Yx(t), t = t.return; while (t);
            return i
        } catch (r) {
            return `
Error generating stack: ` + r.message + `
` + r.stack
        }
    }

    function tn(t) {
        switch (typeof t) {
            case "bigint":
            case "boolean":
            case "number":
            case "string":
            case "undefined":
                return t;
            case "object":
                return t;
            default:
                return ""
        }
    }

    function Vm(t) {
        var i = t.type;
        return (t = t.nodeName) && t.toLowerCase() === "input" && (i === "checkbox" || i === "radio")
    }

    function Xx(t) {
        var i = Vm(t) ? "checked" : "value",
            r = Object.getOwnPropertyDescriptor(t.constructor.prototype, i),
            u = "" + t[i];
        if (!t.hasOwnProperty(i) && typeof r < "u" && typeof r.get == "function" && typeof r.set == "function") {
            var d = r.get,
                g = r.set;
            return Object.defineProperty(t, i, {
                configurable: !0,
                get: function() {
                    return d.call(this)
                },
                set: function(x) {
                    u = "" + x, g.call(this, x)
                }
            }), Object.defineProperty(t, i, {
                enumerable: r.enumerable
            }), {
                getValue: function() {
                    return u
                },
                setValue: function(x) {
                    u = "" + x
                },
                stopTracking: function() {
                    t._valueTracker = null, delete t[i]
                }
            }
        }
    }

    function Cl(t) {
        t._valueTracker || (t._valueTracker = Xx(t))
    }

    function km(t) {
        if (!t) return !1;
        var i = t._valueTracker;
        if (!i) return !0;
        var r = i.getValue(),
            u = "";
        return t && (u = Vm(t) ? t.checked ? "true" : "false" : t.value), t = u, t !== r ? (i.setValue(t), !0) : !1
    }

    function Ol(t) {
        if (t = t || (typeof document < "u" ? document : void 0), typeof t > "u") return null;
        try {
            return t.activeElement || t.body
        } catch {
            return t.body
        }
    }
    var Fx = /[\n"\\]/g;

    function nn(t) {
        return t.replace(Fx, function(i) {
            return "\\" + i.charCodeAt(0).toString(16) + " "
        })
    }

    function ku(t, i, r, u, d, g, x, E) {
        t.name = "", x != null && typeof x != "function" && typeof x != "symbol" && typeof x != "boolean" ? t.type = x : t.removeAttribute("type"), i != null ? x === "number" ? (i === 0 && t.value === "" || t.value != i) && (t.value = "" + tn(i)) : t.value !== "" + tn(i) && (t.value = "" + tn(i)) : x !== "submit" && x !== "reset" || t.removeAttribute("value"), i != null ? Bu(t, x, tn(i)) : r != null ? Bu(t, x, tn(r)) : u != null && t.removeAttribute("value"), d == null && g != null && (t.defaultChecked = !!g), d != null && (t.checked = d && typeof d != "function" && typeof d != "symbol"), E != null && typeof E != "function" && typeof E != "symbol" && typeof E != "boolean" ? t.name = "" + tn(E) : t.removeAttribute("name")
    }

    function Bm(t, i, r, u, d, g, x, E) {
        if (g != null && typeof g != "function" && typeof g != "symbol" && typeof g != "boolean" && (t.type = g), i != null || r != null) {
            if (!(g !== "submit" && g !== "reset" || i != null)) return;
            r = r != null ? "" + tn(r) : "", i = i != null ? "" + tn(i) : r, E || i === t.value || (t.value = i), t.defaultValue = i
        }
        u = u ? ? d, u = typeof u != "function" && typeof u != "symbol" && !!u, t.checked = E ? t.checked : !!u, t.defaultChecked = !!u, x != null && typeof x != "function" && typeof x != "symbol" && typeof x != "boolean" && (t.name = x)
    }

    function Bu(t, i, r) {
        i === "number" && Ol(t.ownerDocument) === t || t.defaultValue === "" + r || (t.defaultValue = "" + r)
    }

    function za(t, i, r, u) {
        if (t = t.options, i) {
            i = {};
            for (var d = 0; d < r.length; d++) i["$" + r[d]] = !0;
            for (r = 0; r < t.length; r++) d = i.hasOwnProperty("$" + t[r].value), t[r].selected !== d && (t[r].selected = d), d && u && (t[r].defaultSelected = !0)
        } else {
            for (r = "" + tn(r), i = null, d = 0; d < t.length; d++) {
                if (t[d].value === r) {
                    t[d].selected = !0, u && (t[d].defaultSelected = !0);
                    return
                }
                i !== null || t[d].disabled || (i = t[d])
            }
            i !== null && (i.selected = !0)
        }
    }

    function Pm(t, i, r) {
        if (i != null && (i = "" + tn(i), i !== t.value && (t.value = i), r == null)) {
            t.defaultValue !== i && (t.defaultValue = i);
            return
        }
        t.defaultValue = r != null ? "" + tn(r) : ""
    }

    function Um(t, i, r, u) {
        if (i == null) {
            if (u != null) {
                if (r != null) throw Error(s(92));
                if (se(u)) {
                    if (1 < u.length) throw Error(s(93));
                    u = u[0]
                }
                r = u
            }
            r == null && (r = ""), i = r
        }
        r = tn(i), t.defaultValue = r, u = t.textContent, u === r && u !== "" && u !== null && (t.value = u)
    }

    function Ra(t, i) {
        if (i) {
            var r = t.firstChild;
            if (r && r === t.lastChild && r.nodeType === 3) {
                r.nodeValue = i;
                return
            }
        }
        t.textContent = i
    }
    var Kx = new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));

    function Hm(t, i, r) {
        var u = i.indexOf("--") === 0;
        r == null || typeof r == "boolean" || r === "" ? u ? t.setProperty(i, "") : i === "float" ? t.cssFloat = "" : t[i] = "" : u ? t.setProperty(i, r) : typeof r != "number" || r === 0 || Kx.has(i) ? i === "float" ? t.cssFloat = r : t[i] = ("" + r).trim() : t[i] = r + "px"
    }

    function Gm(t, i, r) {
        if (i != null && typeof i != "object") throw Error(s(62));
        if (t = t.style, r != null) {
            for (var u in r) !r.hasOwnProperty(u) || i != null && i.hasOwnProperty(u) || (u.indexOf("--") === 0 ? t.setProperty(u, "") : u === "float" ? t.cssFloat = "" : t[u] = "");
            for (var d in i) u = i[d], i.hasOwnProperty(d) && r[d] !== u && Hm(t, d, u)
        } else
            for (var g in i) i.hasOwnProperty(g) && Hm(t, g, i[g])
    }

    function Pu(t) {
        if (t.indexOf("-") === -1) return !1;
        switch (t) {
            case "annotation-xml":
            case "color-profile":
            case "font-face":
            case "font-face-src":
            case "font-face-uri":
            case "font-face-format":
            case "font-face-name":
            case "missing-glyph":
                return !1;
            default:
                return !0
        }
    }
    var Zx = new Map([
            ["acceptCharset", "accept-charset"],
            ["htmlFor", "for"],
            ["httpEquiv", "http-equiv"],
            ["crossOrigin", "crossorigin"],
            ["accentHeight", "accent-height"],
            ["alignmentBaseline", "alignment-baseline"],
            ["arabicForm", "arabic-form"],
            ["baselineShift", "baseline-shift"],
            ["capHeight", "cap-height"],
            ["clipPath", "clip-path"],
            ["clipRule", "clip-rule"],
            ["colorInterpolation", "color-interpolation"],
            ["colorInterpolationFilters", "color-interpolation-filters"],
            ["colorProfile", "color-profile"],
            ["colorRendering", "color-rendering"],
            ["dominantBaseline", "dominant-baseline"],
            ["enableBackground", "enable-background"],
            ["fillOpacity", "fill-opacity"],
            ["fillRule", "fill-rule"],
            ["floodColor", "flood-color"],
            ["floodOpacity", "flood-opacity"],
            ["fontFamily", "font-family"],
            ["fontSize", "font-size"],
            ["fontSizeAdjust", "font-size-adjust"],
            ["fontStretch", "font-stretch"],
            ["fontStyle", "font-style"],
            ["fontVariant", "font-variant"],
            ["fontWeight", "font-weight"],
            ["glyphName", "glyph-name"],
            ["glyphOrientationHorizontal", "glyph-orientation-horizontal"],
            ["glyphOrientationVertical", "glyph-orientation-vertical"],
            ["horizAdvX", "horiz-adv-x"],
            ["horizOriginX", "horiz-origin-x"],
            ["imageRendering", "image-rendering"],
            ["letterSpacing", "letter-spacing"],
            ["lightingColor", "lighting-color"],
            ["markerEnd", "marker-end"],
            ["markerMid", "marker-mid"],
            ["markerStart", "marker-start"],
            ["overlinePosition", "overline-position"],
            ["overlineThickness", "overline-thickness"],
            ["paintOrder", "paint-order"],
            ["panose-1", "panose-1"],
            ["pointerEvents", "pointer-events"],
            ["renderingIntent", "rendering-intent"],
            ["shapeRendering", "shape-rendering"],
            ["stopColor", "stop-color"],
            ["stopOpacity", "stop-opacity"],
            ["strikethroughPosition", "strikethrough-position"],
            ["strikethroughThickness", "strikethrough-thickness"],
            ["strokeDasharray", "stroke-dasharray"],
            ["strokeDashoffset", "stroke-dashoffset"],
            ["strokeLinecap", "stroke-linecap"],
            ["strokeLinejoin", "stroke-linejoin"],
            ["strokeMiterlimit", "stroke-miterlimit"],
            ["strokeOpacity", "stroke-opacity"],
            ["strokeWidth", "stroke-width"],
            ["textAnchor", "text-anchor"],
            ["textDecoration", "text-decoration"],
            ["textRendering", "text-rendering"],
            ["transformOrigin", "transform-origin"],
            ["underlinePosition", "underline-position"],
            ["underlineThickness", "underline-thickness"],
            ["unicodeBidi", "unicode-bidi"],
            ["unicodeRange", "unicode-range"],
            ["unitsPerEm", "units-per-em"],
            ["vAlphabetic", "v-alphabetic"],
            ["vHanging", "v-hanging"],
            ["vIdeographic", "v-ideographic"],
            ["vMathematical", "v-mathematical"],
            ["vectorEffect", "vector-effect"],
            ["vertAdvY", "vert-adv-y"],
            ["vertOriginX", "vert-origin-x"],
            ["vertOriginY", "vert-origin-y"],
            ["wordSpacing", "word-spacing"],
            ["writingMode", "writing-mode"],
            ["xmlnsXlink", "xmlns:xlink"],
            ["xHeight", "x-height"]
        ]),
        Qx = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

    function Dl(t) {
        return Qx.test("" + t) ? "javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')" : t
    }
    var Uu = null;

    function Hu(t) {
        return t = t.target || t.srcElement || window, t.correspondingUseElement && (t = t.correspondingUseElement), t.nodeType === 3 ? t.parentNode : t
    }
    var La = null,
        ja = null;

    function qm(t) {
        var i = Aa(t);
        if (i && (t = i.stateNode)) {
            var r = t[Mt] || null;
            e: switch (t = i.stateNode, i.type) {
                case "input":
                    if (ku(t, r.value, r.defaultValue, r.defaultValue, r.checked, r.defaultChecked, r.type, r.name), i = r.name, r.type === "radio" && i != null) {
                        for (r = t; r.parentNode;) r = r.parentNode;
                        for (r = r.querySelectorAll('input[name="' + nn("" + i) + '"][type="radio"]'), i = 0; i < r.length; i++) {
                            var u = r[i];
                            if (u !== t && u.form === t.form) {
                                var d = u[Mt] || null;
                                if (!d) throw Error(s(90));
                                ku(u, d.value, d.defaultValue, d.defaultValue, d.checked, d.defaultChecked, d.type, d.name)
                            }
                        }
                        for (i = 0; i < r.length; i++) u = r[i], u.form === t.form && km(u)
                    }
                    break e;
                case "textarea":
                    Pm(t, r.value, r.defaultValue);
                    break e;
                case "select":
                    i = r.value, i != null && za(t, !!r.multiple, i, !1)
            }
        }
    }
    var Gu = !1;

    function Ym(t, i, r) {
        if (Gu) return t(i, r);
        Gu = !0;
        try {
            var u = t(i);
            return u
        } finally {
            if (Gu = !1, (La !== null || ja !== null) && (go(), La && (i = La, t = ja, ja = La = null, qm(i), t)))
                for (i = 0; i < t.length; i++) qm(t[i])
        }
    }

    function qs(t, i) {
        var r = t.stateNode;
        if (r === null) return null;
        var u = r[Mt] || null;
        if (u === null) return null;
        r = u[i];
        e: switch (i) {
            case "onClick":
            case "onClickCapture":
            case "onDoubleClick":
            case "onDoubleClickCapture":
            case "onMouseDown":
            case "onMouseDownCapture":
            case "onMouseMove":
            case "onMouseMoveCapture":
            case "onMouseUp":
            case "onMouseUpCapture":
            case "onMouseEnter":
                (u = !u.disabled) || (t = t.type, u = !(t === "button" || t === "input" || t === "select" || t === "textarea")), t = !u;
                break e;
            default:
                t = !1
        }
        if (t) return null;
        if (r && typeof r != "function") throw Error(s(231, i, typeof r));
        return r
    }
    var Pn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
        qu = !1;
    if (Pn) try {
        var Ys = {};
        Object.defineProperty(Ys, "passive", {
            get: function() {
                qu = !0
            }
        }), window.addEventListener("test", Ys, Ys), window.removeEventListener("test", Ys, Ys)
    } catch {
        qu = !1
    }
    var ui = null,
        Yu = null,
        zl = null;

    function Xm() {
        if (zl) return zl;
        var t, i = Yu,
            r = i.length,
            u, d = "value" in ui ? ui.value : ui.textContent,
            g = d.length;
        for (t = 0; t < r && i[t] === d[t]; t++);
        var x = r - t;
        for (u = 1; u <= x && i[r - u] === d[g - u]; u++);
        return zl = d.slice(t, 1 < u ? 1 - u : void 0)
    }

    function Rl(t) {
        var i = t.keyCode;
        return "charCode" in t ? (t = t.charCode, t === 0 && i === 13 && (t = 13)) : t = i, t === 10 && (t = 13), 32 <= t || t === 13 ? t : 0
    }

    function Ll() {
        return !0
    }

    function Fm() {
        return !1
    }

    function At(t) {
        function i(r, u, d, g, x) {
            this._reactName = r, this._targetInst = d, this.type = u, this.nativeEvent = g, this.target = x, this.currentTarget = null;
            for (var E in t) t.hasOwnProperty(E) && (r = t[E], this[E] = r ? r(g) : g[E]);
            return this.isDefaultPrevented = (g.defaultPrevented != null ? g.defaultPrevented : g.returnValue === !1) ? Ll : Fm, this.isPropagationStopped = Fm, this
        }
        return p(i.prototype, {
            preventDefault: function() {
                this.defaultPrevented = !0;
                var r = this.nativeEvent;
                r && (r.preventDefault ? r.preventDefault() : typeof r.returnValue != "unknown" && (r.returnValue = !1), this.isDefaultPrevented = Ll)
            },
            stopPropagation: function() {
                var r = this.nativeEvent;
                r && (r.stopPropagation ? r.stopPropagation() : typeof r.cancelBubble != "unknown" && (r.cancelBubble = !0), this.isPropagationStopped = Ll)
            },
            persist: function() {},
            isPersistent: Ll
        }), i
    }
    var Ki = {
            eventPhase: 0,
            bubbles: 0,
            cancelable: 0,
            timeStamp: function(t) {
                return t.timeStamp || Date.now()
            },
            defaultPrevented: 0,
            isTrusted: 0
        },
        jl = At(Ki),
        Xs = p({}, Ki, {
            view: 0,
            detail: 0
        }),
        Ix = At(Xs),
        Xu, Fu, Fs, Nl = p({}, Xs, {
            screenX: 0,
            screenY: 0,
            clientX: 0,
            clientY: 0,
            pageX: 0,
            pageY: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            getModifierState: Zu,
            button: 0,
            buttons: 0,
            relatedTarget: function(t) {
                return t.relatedTarget === void 0 ? t.fromElement === t.srcElement ? t.toElement : t.fromElement : t.relatedTarget
            },
            movementX: function(t) {
                return "movementX" in t ? t.movementX : (t !== Fs && (Fs && t.type === "mousemove" ? (Xu = t.screenX - Fs.screenX, Fu = t.screenY - Fs.screenY) : Fu = Xu = 0, Fs = t), Xu)
            },
            movementY: function(t) {
                return "movementY" in t ? t.movementY : Fu
            }
        }),
        Km = At(Nl),
        $x = p({}, Nl, {
            dataTransfer: 0
        }),
        Wx = At($x),
        Jx = p({}, Xs, {
            relatedTarget: 0
        }),
        Ku = At(Jx),
        eS = p({}, Ki, {
            animationName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        tS = At(eS),
        nS = p({}, Ki, {
            clipboardData: function(t) {
                return "clipboardData" in t ? t.clipboardData : window.clipboardData
            }
        }),
        iS = At(nS),
        aS = p({}, Ki, {
            data: 0
        }),
        Zm = At(aS),
        sS = {
            Esc: "Escape",
            Spacebar: " ",
            Left: "ArrowLeft",
            Up: "ArrowUp",
            Right: "ArrowRight",
            Down: "ArrowDown",
            Del: "Delete",
            Win: "OS",
            Menu: "ContextMenu",
            Apps: "ContextMenu",
            Scroll: "ScrollLock",
            MozPrintableKey: "Unidentified"
        },
        rS = {
            8: "Backspace",
            9: "Tab",
            12: "Clear",
            13: "Enter",
            16: "Shift",
            17: "Control",
            18: "Alt",
            19: "Pause",
            20: "CapsLock",
            27: "Escape",
            32: " ",
            33: "PageUp",
            34: "PageDown",
            35: "End",
            36: "Home",
            37: "ArrowLeft",
            38: "ArrowUp",
            39: "ArrowRight",
            40: "ArrowDown",
            45: "Insert",
            46: "Delete",
            112: "F1",
            113: "F2",
            114: "F3",
            115: "F4",
            116: "F5",
            117: "F6",
            118: "F7",
            119: "F8",
            120: "F9",
            121: "F10",
            122: "F11",
            123: "F12",
            144: "NumLock",
            145: "ScrollLock",
            224: "Meta"
        },
        lS = {
            Alt: "altKey",
            Control: "ctrlKey",
            Meta: "metaKey",
            Shift: "shiftKey"
        };

    function oS(t) {
        var i = this.nativeEvent;
        return i.getModifierState ? i.getModifierState(t) : (t = lS[t]) ? !!i[t] : !1
    }

    function Zu() {
        return oS
    }
    var uS = p({}, Xs, {
            key: function(t) {
                if (t.key) {
                    var i = sS[t.key] || t.key;
                    if (i !== "Unidentified") return i
                }
                return t.type === "keypress" ? (t = Rl(t), t === 13 ? "Enter" : String.fromCharCode(t)) : t.type === "keydown" || t.type === "keyup" ? rS[t.keyCode] || "Unidentified" : ""
            },
            code: 0,
            location: 0,
            ctrlKey: 0,
            shiftKey: 0,
            altKey: 0,
            metaKey: 0,
            repeat: 0,
            locale: 0,
            getModifierState: Zu,
            charCode: function(t) {
                return t.type === "keypress" ? Rl(t) : 0
            },
            keyCode: function(t) {
                return t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0
            },
            which: function(t) {
                return t.type === "keypress" ? Rl(t) : t.type === "keydown" || t.type === "keyup" ? t.keyCode : 0
            }
        }),
        cS = At(uS),
        fS = p({}, Nl, {
            pointerId: 0,
            width: 0,
            height: 0,
            pressure: 0,
            tangentialPressure: 0,
            tiltX: 0,
            tiltY: 0,
            twist: 0,
            pointerType: 0,
            isPrimary: 0
        }),
        Qm = At(fS),
        dS = p({}, Xs, {
            touches: 0,
            targetTouches: 0,
            changedTouches: 0,
            altKey: 0,
            metaKey: 0,
            ctrlKey: 0,
            shiftKey: 0,
            getModifierState: Zu
        }),
        hS = At(dS),
        mS = p({}, Ki, {
            propertyName: 0,
            elapsedTime: 0,
            pseudoElement: 0
        }),
        pS = At(mS),
        gS = p({}, Nl, {
            deltaX: function(t) {
                return "deltaX" in t ? t.deltaX : "wheelDeltaX" in t ? -t.wheelDeltaX : 0
            },
            deltaY: function(t) {
                return "deltaY" in t ? t.deltaY : "wheelDeltaY" in t ? -t.wheelDeltaY : "wheelDelta" in t ? -t.wheelDelta : 0
            },
            deltaZ: 0,
            deltaMode: 0
        }),
        vS = At(gS),
        yS = p({}, Ki, {
            newState: 0,
            oldState: 0
        }),
        bS = At(yS),
        xS = [9, 13, 27, 32],
        Qu = Pn && "CompositionEvent" in window,
        Ks = null;
    Pn && "documentMode" in document && (Ks = document.documentMode);
    var SS = Pn && "TextEvent" in window && !Ks,
        Im = Pn && (!Qu || Ks && 8 < Ks && 11 >= Ks),
        $m = " ",
        Wm = !1;

    function Jm(t, i) {
        switch (t) {
            case "keyup":
                return xS.indexOf(i.keyCode) !== -1;
            case "keydown":
                return i.keyCode !== 229;
            case "keypress":
            case "mousedown":
            case "focusout":
                return !0;
            default:
                return !1
        }
    }

    function ep(t) {
        return t = t.detail, typeof t == "object" && "data" in t ? t.data : null
    }
    var Na = !1;

    function TS(t, i) {
        switch (t) {
            case "compositionend":
                return ep(i);
            case "keypress":
                return i.which !== 32 ? null : (Wm = !0, $m);
            case "textInput":
                return t = i.data, t === $m && Wm ? null : t;
            default:
                return null
        }
    }

    function _S(t, i) {
        if (Na) return t === "compositionend" || !Qu && Jm(t, i) ? (t = Xm(), zl = Yu = ui = null, Na = !1, t) : null;
        switch (t) {
            case "paste":
                return null;
            case "keypress":
                if (!(i.ctrlKey || i.altKey || i.metaKey) || i.ctrlKey && i.altKey) {
                    if (i.char && 1 < i.char.length) return i.char;
                    if (i.which) return String.fromCharCode(i.which)
                }
                return null;
            case "compositionend":
                return Im && i.locale !== "ko" ? null : i.data;
            default:
                return null
        }
    }
    var ES = {
        color: !0,
        date: !0,
        datetime: !0,
        "datetime-local": !0,
        email: !0,
        month: !0,
        number: !0,
        password: !0,
        range: !0,
        search: !0,
        tel: !0,
        text: !0,
        time: !0,
        url: !0,
        week: !0
    };

    function tp(t) {
        var i = t && t.nodeName && t.nodeName.toLowerCase();
        return i === "input" ? !!ES[t.type] : i === "textarea"
    }

    function np(t, i, r, u) {
        La ? ja ? ja.push(u) : ja = [u] : La = u, i = To(i, "onChange"), 0 < i.length && (r = new jl("onChange", "change", null, r, u), t.push({
            event: r,
            listeners: i
        }))
    }
    var Zs = null,
        Qs = null;

    function wS(t) {
        Vg(t, 0)
    }

    function Vl(t) {
        var i = Gs(t);
        if (km(i)) return t
    }

    function ip(t, i) {
        if (t === "change") return i
    }
    var ap = !1;
    if (Pn) {
        var Iu;
        if (Pn) {
            var $u = "oninput" in document;
            if (!$u) {
                var sp = document.createElement("div");
                sp.setAttribute("oninput", "return;"), $u = typeof sp.oninput == "function"
            }
            Iu = $u
        } else Iu = !1;
        ap = Iu && (!document.documentMode || 9 < document.documentMode)
    }

    function rp() {
        Zs && (Zs.detachEvent("onpropertychange", lp), Qs = Zs = null)
    }

    function lp(t) {
        if (t.propertyName === "value" && Vl(Qs)) {
            var i = [];
            np(i, Qs, t, Hu(t)), Ym(wS, i)
        }
    }

    function MS(t, i, r) {
        t === "focusin" ? (rp(), Zs = i, Qs = r, Zs.attachEvent("onpropertychange", lp)) : t === "focusout" && rp()
    }

    function AS(t) {
        if (t === "selectionchange" || t === "keyup" || t === "keydown") return Vl(Qs)
    }

    function CS(t, i) {
        if (t === "click") return Vl(i)
    }

    function OS(t, i) {
        if (t === "input" || t === "change") return Vl(i)
    }

    function DS(t, i) {
        return t === i && (t !== 0 || 1 / t === 1 / i) || t !== t && i !== i
    }
    var Ut = typeof Object.is == "function" ? Object.is : DS;

    function Is(t, i) {
        if (Ut(t, i)) return !0;
        if (typeof t != "object" || t === null || typeof i != "object" || i === null) return !1;
        var r = Object.keys(t),
            u = Object.keys(i);
        if (r.length !== u.length) return !1;
        for (u = 0; u < r.length; u++) {
            var d = r[u];
            if (!Mu.call(i, d) || !Ut(t[d], i[d])) return !1
        }
        return !0
    }

    function op(t) {
        for (; t && t.firstChild;) t = t.firstChild;
        return t
    }

    function up(t, i) {
        var r = op(t);
        t = 0;
        for (var u; r;) {
            if (r.nodeType === 3) {
                if (u = t + r.textContent.length, t <= i && u >= i) return {
                    node: r,
                    offset: i - t
                };
                t = u
            }
            e: {
                for (; r;) {
                    if (r.nextSibling) {
                        r = r.nextSibling;
                        break e
                    }
                    r = r.parentNode
                }
                r = void 0
            }
            r = op(r)
        }
    }

    function cp(t, i) {
        return t && i ? t === i ? !0 : t && t.nodeType === 3 ? !1 : i && i.nodeType === 3 ? cp(t, i.parentNode) : "contains" in t ? t.contains(i) : t.compareDocumentPosition ? !!(t.compareDocumentPosition(i) & 16) : !1 : !1
    }

    function fp(t) {
        t = t != null && t.ownerDocument != null && t.ownerDocument.defaultView != null ? t.ownerDocument.defaultView : window;
        for (var i = Ol(t.document); i instanceof t.HTMLIFrameElement;) {
            try {
                var r = typeof i.contentWindow.location.href == "string"
            } catch {
                r = !1
            }
            if (r) t = i.contentWindow;
            else break;
            i = Ol(t.document)
        }
        return i
    }

    function Wu(t) {
        var i = t && t.nodeName && t.nodeName.toLowerCase();
        return i && (i === "input" && (t.type === "text" || t.type === "search" || t.type === "tel" || t.type === "url" || t.type === "password") || i === "textarea" || t.contentEditable === "true")
    }
    var zS = Pn && "documentMode" in document && 11 >= document.documentMode,
        Va = null,
        Ju = null,
        $s = null,
        ec = !1;

    function dp(t, i, r) {
        var u = r.window === r ? r.document : r.nodeType === 9 ? r : r.ownerDocument;
        ec || Va == null || Va !== Ol(u) || (u = Va, "selectionStart" in u && Wu(u) ? u = {
            start: u.selectionStart,
            end: u.selectionEnd
        } : (u = (u.ownerDocument && u.ownerDocument.defaultView || window).getSelection(), u = {
            anchorNode: u.anchorNode,
            anchorOffset: u.anchorOffset,
            focusNode: u.focusNode,
            focusOffset: u.focusOffset
        }), $s && Is($s, u) || ($s = u, u = To(Ju, "onSelect"), 0 < u.length && (i = new jl("onSelect", "select", null, i, r), t.push({
            event: i,
            listeners: u
        }), i.target = Va)))
    }

    function Zi(t, i) {
        var r = {};
        return r[t.toLowerCase()] = i.toLowerCase(), r["Webkit" + t] = "webkit" + i, r["Moz" + t] = "moz" + i, r
    }
    var ka = {
            animationend: Zi("Animation", "AnimationEnd"),
            animationiteration: Zi("Animation", "AnimationIteration"),
            animationstart: Zi("Animation", "AnimationStart"),
            transitionrun: Zi("Transition", "TransitionRun"),
            transitionstart: Zi("Transition", "TransitionStart"),
            transitioncancel: Zi("Transition", "TransitionCancel"),
            transitionend: Zi("Transition", "TransitionEnd")
        },
        tc = {},
        hp = {};
    Pn && (hp = document.createElement("div").style, "AnimationEvent" in window || (delete ka.animationend.animation, delete ka.animationiteration.animation, delete ka.animationstart.animation), "TransitionEvent" in window || delete ka.transitionend.transition);

    function Qi(t) {
        if (tc[t]) return tc[t];
        if (!ka[t]) return t;
        var i = ka[t],
            r;
        for (r in i)
            if (i.hasOwnProperty(r) && r in hp) return tc[t] = i[r];
        return t
    }
    var mp = Qi("animationend"),
        pp = Qi("animationiteration"),
        gp = Qi("animationstart"),
        RS = Qi("transitionrun"),
        LS = Qi("transitionstart"),
        jS = Qi("transitioncancel"),
        vp = Qi("transitionend"),
        yp = new Map,
        nc = "abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
    nc.push("scrollEnd");

    function bn(t, i) {
        yp.set(t, i), Fi(i, [t])
    }
    var bp = new WeakMap;

    function an(t, i) {
        if (typeof t == "object" && t !== null) {
            var r = bp.get(t);
            return r !== void 0 ? r : (i = {
                value: t,
                source: i,
                stack: Nm(i)
            }, bp.set(t, i), i)
        }
        return {
            value: t,
            source: i,
            stack: Nm(i)
        }
    }
    var sn = [],
        Ba = 0,
        ic = 0;

    function kl() {
        for (var t = Ba, i = ic = Ba = 0; i < t;) {
            var r = sn[i];
            sn[i++] = null;
            var u = sn[i];
            sn[i++] = null;
            var d = sn[i];
            sn[i++] = null;
            var g = sn[i];
            if (sn[i++] = null, u !== null && d !== null) {
                var x = u.pending;
                x === null ? d.next = d : (d.next = x.next, x.next = d), u.pending = d
            }
            g !== 0 && xp(r, d, g)
        }
    }

    function Bl(t, i, r, u) {
        sn[Ba++] = t, sn[Ba++] = i, sn[Ba++] = r, sn[Ba++] = u, ic |= u, t.lanes |= u, t = t.alternate, t !== null && (t.lanes |= u)
    }

    function ac(t, i, r, u) {
        return Bl(t, i, r, u), Pl(t)
    }

    function Pa(t, i) {
        return Bl(t, null, null, i), Pl(t)
    }

    function xp(t, i, r) {
        t.lanes |= r;
        var u = t.alternate;
        u !== null && (u.lanes |= r);
        for (var d = !1, g = t.return; g !== null;) g.childLanes |= r, u = g.alternate, u !== null && (u.childLanes |= r), g.tag === 22 && (t = g.stateNode, t === null || t._visibility & 1 || (d = !0)), t = g, g = g.return;
        return t.tag === 3 ? (g = t.stateNode, d && i !== null && (d = 31 - Pt(r), t = g.hiddenUpdates, u = t[d], u === null ? t[d] = [i] : u.push(i), i.lane = r | 536870912), g) : null
    }

    function Pl(t) {
        if (50 < Tr) throw Tr = 0, ff = null, Error(s(185));
        for (var i = t.return; i !== null;) t = i, i = t.return;
        return t.tag === 3 ? t.stateNode : null
    }
    var Ua = {};

    function NS(t, i, r, u) {
        this.tag = t, this.key = r, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = i, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = u, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
    }

    function Ht(t, i, r, u) {
        return new NS(t, i, r, u)
    }

    function sc(t) {
        return t = t.prototype, !(!t || !t.isReactComponent)
    }

    function Un(t, i) {
        var r = t.alternate;
        return r === null ? (r = Ht(t.tag, i, t.key, t.mode), r.elementType = t.elementType, r.type = t.type, r.stateNode = t.stateNode, r.alternate = t, t.alternate = r) : (r.pendingProps = i, r.type = t.type, r.flags = 0, r.subtreeFlags = 0, r.deletions = null), r.flags = t.flags & 65011712, r.childLanes = t.childLanes, r.lanes = t.lanes, r.child = t.child, r.memoizedProps = t.memoizedProps, r.memoizedState = t.memoizedState, r.updateQueue = t.updateQueue, i = t.dependencies, r.dependencies = i === null ? null : {
            lanes: i.lanes,
            firstContext: i.firstContext
        }, r.sibling = t.sibling, r.index = t.index, r.ref = t.ref, r.refCleanup = t.refCleanup, r
    }

    function Sp(t, i) {
        t.flags &= 65011714;
        var r = t.alternate;
        return r === null ? (t.childLanes = 0, t.lanes = i, t.child = null, t.subtreeFlags = 0, t.memoizedProps = null, t.memoizedState = null, t.updateQueue = null, t.dependencies = null, t.stateNode = null) : (t.childLanes = r.childLanes, t.lanes = r.lanes, t.child = r.child, t.subtreeFlags = 0, t.deletions = null, t.memoizedProps = r.memoizedProps, t.memoizedState = r.memoizedState, t.updateQueue = r.updateQueue, t.type = r.type, i = r.dependencies, t.dependencies = i === null ? null : {
            lanes: i.lanes,
            firstContext: i.firstContext
        }), t
    }

    function Ul(t, i, r, u, d, g) {
        var x = 0;
        if (u = t, typeof t == "function") sc(t) && (x = 1);
        else if (typeof t == "string") x = kT(t, r, le.current) ? 26 : t === "html" || t === "head" || t === "body" ? 27 : 5;
        else e: switch (t) {
            case H:
                return t = Ht(31, r, i, d), t.elementType = H, t.lanes = g, t;
            case T:
                return Ii(r.children, d, g, i);
            case S:
                x = 8, d |= 24;
                break;
            case M:
                return t = Ht(12, r, i, d | 2), t.elementType = M, t.lanes = g, t;
            case O:
                return t = Ht(13, r, i, d), t.elementType = O, t.lanes = g, t;
            case V:
                return t = Ht(19, r, i, d), t.elementType = V, t.lanes = g, t;
            default:
                if (typeof t == "object" && t !== null) switch (t.$$typeof) {
                    case _:
                    case C:
                        x = 10;
                        break e;
                    case w:
                        x = 9;
                        break e;
                    case L:
                        x = 11;
                        break e;
                    case k:
                        x = 14;
                        break e;
                    case D:
                        x = 16, u = null;
                        break e
                }
                x = 29, r = Error(s(130, t === null ? "null" : typeof t, "")), u = null
        }
        return i = Ht(x, r, i, d), i.elementType = t, i.type = u, i.lanes = g, i
    }

    function Ii(t, i, r, u) {
        return t = Ht(7, t, u, i), t.lanes = r, t
    }

    function rc(t, i, r) {
        return t = Ht(6, t, null, i), t.lanes = r, t
    }

    function lc(t, i, r) {
        return i = Ht(4, t.children !== null ? t.children : [], t.key, i), i.lanes = r, i.stateNode = {
            containerInfo: t.containerInfo,
            pendingChildren: null,
            implementation: t.implementation
        }, i
    }
    var Ha = [],
        Ga = 0,
        Hl = null,
        Gl = 0,
        rn = [],
        ln = 0,
        $i = null,
        Hn = 1,
        Gn = "";

    function Wi(t, i) {
        Ha[Ga++] = Gl, Ha[Ga++] = Hl, Hl = t, Gl = i
    }

    function Tp(t, i, r) {
        rn[ln++] = Hn, rn[ln++] = Gn, rn[ln++] = $i, $i = t;
        var u = Hn;
        t = Gn;
        var d = 32 - Pt(u) - 1;
        u &= ~(1 << d), r += 1;
        var g = 32 - Pt(i) + d;
        if (30 < g) {
            var x = d - d % 5;
            g = (u & (1 << x) - 1).toString(32), u >>= x, d -= x, Hn = 1 << 32 - Pt(i) + d | r << d | u, Gn = g + t
        } else Hn = 1 << g | r << d | u, Gn = t
    }

    function oc(t) {
        t.return !== null && (Wi(t, 1), Tp(t, 1, 0))
    }

    function uc(t) {
        for (; t === Hl;) Hl = Ha[--Ga], Ha[Ga] = null, Gl = Ha[--Ga], Ha[Ga] = null;
        for (; t === $i;) $i = rn[--ln], rn[ln] = null, Gn = rn[--ln], rn[ln] = null, Hn = rn[--ln], rn[ln] = null
    }
    var Tt = null,
        Xe = null,
        Ee = !1,
        Ji = null,
        wn = !1,
        cc = Error(s(519));

    function ea(t) {
        var i = Error(s(418, ""));
        throw er(an(i, t)), cc
    }

    function _p(t) {
        var i = t.stateNode,
            r = t.type,
            u = t.memoizedProps;
        switch (i[gt] = t, i[Mt] = u, r) {
            case "dialog":
                be("cancel", i), be("close", i);
                break;
            case "iframe":
            case "object":
            case "embed":
                be("load", i);
                break;
            case "video":
            case "audio":
                for (r = 0; r < Er.length; r++) be(Er[r], i);
                break;
            case "source":
                be("error", i);
                break;
            case "img":
            case "image":
            case "link":
                be("error", i), be("load", i);
                break;
            case "details":
                be("toggle", i);
                break;
            case "input":
                be("invalid", i), Bm(i, u.value, u.defaultValue, u.checked, u.defaultChecked, u.type, u.name, !0), Cl(i);
                break;
            case "select":
                be("invalid", i);
                break;
            case "textarea":
                be("invalid", i), Um(i, u.value, u.defaultValue, u.children), Cl(i)
        }
        r = u.children, typeof r != "string" && typeof r != "number" && typeof r != "bigint" || i.textContent === "" + r || u.suppressHydrationWarning === !0 || Ug(i.textContent, r) ? (u.popover != null && (be("beforetoggle", i), be("toggle", i)), u.onScroll != null && be("scroll", i), u.onScrollEnd != null && be("scrollend", i), u.onClick != null && (i.onclick = _o), i = !0) : i = !1, i || ea(t)
    }

    function Ep(t) {
        for (Tt = t.return; Tt;) switch (Tt.tag) {
            case 5:
            case 13:
                wn = !1;
                return;
            case 27:
            case 3:
                wn = !0;
                return;
            default:
                Tt = Tt.return
        }
    }

    function Ws(t) {
        if (t !== Tt) return !1;
        if (!Ee) return Ep(t), Ee = !0, !1;
        var i = t.tag,
            r;
        if ((r = i !== 3 && i !== 27) && ((r = i === 5) && (r = t.type, r = !(r !== "form" && r !== "button") || Af(t.type, t.memoizedProps)), r = !r), r && Xe && ea(t), Ep(t), i === 13) {
            if (t = t.memoizedState, t = t !== null ? t.dehydrated : null, !t) throw Error(s(317));
            e: {
                for (t = t.nextSibling, i = 0; t;) {
                    if (t.nodeType === 8)
                        if (r = t.data, r === "/$") {
                            if (i === 0) {
                                Xe = Sn(t.nextSibling);
                                break e
                            }
                            i--
                        } else r !== "$" && r !== "$!" && r !== "$?" || i++;
                    t = t.nextSibling
                }
                Xe = null
            }
        } else i === 27 ? (i = Xe, wi(t.type) ? (t = zf, zf = null, Xe = t) : Xe = i) : Xe = Tt ? Sn(t.stateNode.nextSibling) : null;
        return !0
    }

    function Js() {
        Xe = Tt = null, Ee = !1
    }

    function wp() {
        var t = Ji;
        return t !== null && (Dt === null ? Dt = t : Dt.push.apply(Dt, t), Ji = null), t
    }

    function er(t) {
        Ji === null ? Ji = [t] : Ji.push(t)
    }
    var fc = Z(null),
        ta = null,
        qn = null;

    function ci(t, i, r) {
        ie(fc, i._currentValue), i._currentValue = r
    }

    function Yn(t) {
        t._currentValue = fc.current, ne(fc)
    }

    function dc(t, i, r) {
        for (; t !== null;) {
            var u = t.alternate;
            if ((t.childLanes & i) !== i ? (t.childLanes |= i, u !== null && (u.childLanes |= i)) : u !== null && (u.childLanes & i) !== i && (u.childLanes |= i), t === r) break;
            t = t.return
        }
    }

    function hc(t, i, r, u) {
        var d = t.child;
        for (d !== null && (d.return = t); d !== null;) {
            var g = d.dependencies;
            if (g !== null) {
                var x = d.child;
                g = g.firstContext;
                e: for (; g !== null;) {
                    var E = g;
                    g = d;
                    for (var R = 0; R < i.length; R++)
                        if (E.context === i[R]) {
                            g.lanes |= r, E = g.alternate, E !== null && (E.lanes |= r), dc(g.return, r, t), u || (x = null);
                            break e
                        }
                    g = E.next
                }
            } else if (d.tag === 18) {
                if (x = d.return, x === null) throw Error(s(341));
                x.lanes |= r, g = x.alternate, g !== null && (g.lanes |= r), dc(x, r, t), x = null
            } else x = d.child;
            if (x !== null) x.return = d;
            else
                for (x = d; x !== null;) {
                    if (x === t) {
                        x = null;
                        break
                    }
                    if (d = x.sibling, d !== null) {
                        d.return = x.return, x = d;
                        break
                    }
                    x = x.return
                }
            d = x
        }
    }

    function tr(t, i, r, u) {
        t = null;
        for (var d = i, g = !1; d !== null;) {
            if (!g) {
                if ((d.flags & 524288) !== 0) g = !0;
                else if ((d.flags & 262144) !== 0) break
            }
            if (d.tag === 10) {
                var x = d.alternate;
                if (x === null) throw Error(s(387));
                if (x = x.memoizedProps, x !== null) {
                    var E = d.type;
                    Ut(d.pendingProps.value, x.value) || (t !== null ? t.push(E) : t = [E])
                }
            } else if (d === kt.current) {
                if (x = d.alternate, x === null) throw Error(s(387));
                x.memoizedState.memoizedState !== d.memoizedState.memoizedState && (t !== null ? t.push(Dr) : t = [Dr])
            }
            d = d.return
        }
        t !== null && hc(i, t, r, u), i.flags |= 262144
    }

    function ql(t) {
        for (t = t.firstContext; t !== null;) {
            if (!Ut(t.context._currentValue, t.memoizedValue)) return !0;
            t = t.next
        }
        return !1
    }

    function na(t) {
        ta = t, qn = null, t = t.dependencies, t !== null && (t.firstContext = null)
    }

    function vt(t) {
        return Mp(ta, t)
    }

    function Yl(t, i) {
        return ta === null && na(t), Mp(t, i)
    }

    function Mp(t, i) {
        var r = i._currentValue;
        if (i = {
                context: i,
                memoizedValue: r,
                next: null
            }, qn === null) {
            if (t === null) throw Error(s(308));
            qn = i, t.dependencies = {
                lanes: 0,
                firstContext: i
            }, t.flags |= 524288
        } else qn = qn.next = i;
        return r
    }
    var VS = typeof AbortController < "u" ? AbortController : function() {
            var t = [],
                i = this.signal = {
                    aborted: !1,
                    addEventListener: function(r, u) {
                        t.push(u)
                    }
                };
            this.abort = function() {
                i.aborted = !0, t.forEach(function(r) {
                    return r()
                })
            }
        },
        kS = n.unstable_scheduleCallback,
        BS = n.unstable_NormalPriority,
        it = {
            $$typeof: C,
            Consumer: null,
            Provider: null,
            _currentValue: null,
            _currentValue2: null,
            _threadCount: 0
        };

    function mc() {
        return {
            controller: new VS,
            data: new Map,
            refCount: 0
        }
    }

    function nr(t) {
        t.refCount--, t.refCount === 0 && kS(BS, function() {
            t.controller.abort()
        })
    }
    var ir = null,
        pc = 0,
        qa = 0,
        Ya = null;

    function PS(t, i) {
        if (ir === null) {
            var r = ir = [];
            pc = 0, qa = yf(), Ya = {
                status: "pending",
                value: void 0,
                then: function(u) {
                    r.push(u)
                }
            }
        }
        return pc++, i.then(Ap, Ap), i
    }

    function Ap() {
        if (--pc === 0 && ir !== null) {
            Ya !== null && (Ya.status = "fulfilled");
            var t = ir;
            ir = null, qa = 0, Ya = null;
            for (var i = 0; i < t.length; i++)(0, t[i])()
        }
    }

    function US(t, i) {
        var r = [],
            u = {
                status: "pending",
                value: null,
                reason: null,
                then: function(d) {
                    r.push(d)
                }
            };
        return t.then(function() {
            u.status = "fulfilled", u.value = i;
            for (var d = 0; d < r.length; d++)(0, r[d])(i)
        }, function(d) {
            for (u.status = "rejected", u.reason = d, d = 0; d < r.length; d++)(0, r[d])(void 0)
        }), u
    }
    var Cp = P.S;
    P.S = function(t, i) {
        typeof i == "object" && i !== null && typeof i.then == "function" && PS(t, i), Cp !== null && Cp(t, i)
    };
    var ia = Z(null);

    function gc() {
        var t = ia.current;
        return t !== null ? t : je.pooledCache
    }

    function Xl(t, i) {
        i === null ? ie(ia, ia.current) : ie(ia, i.pool)
    }

    function Op() {
        var t = gc();
        return t === null ? null : {
            parent: it._currentValue,
            pool: t
        }
    }
    var ar = Error(s(460)),
        Dp = Error(s(474)),
        Fl = Error(s(542)),
        vc = {
            then: function() {}
        };

    function zp(t) {
        return t = t.status, t === "fulfilled" || t === "rejected"
    }

    function Kl() {}

    function Rp(t, i, r) {
        switch (r = t[r], r === void 0 ? t.push(i) : r !== i && (i.then(Kl, Kl), i = r), i.status) {
            case "fulfilled":
                return i.value;
            case "rejected":
                throw t = i.reason, jp(t), t;
            default:
                if (typeof i.status == "string") i.then(Kl, Kl);
                else {
                    if (t = je, t !== null && 100 < t.shellSuspendCounter) throw Error(s(482));
                    t = i, t.status = "pending", t.then(function(u) {
                        if (i.status === "pending") {
                            var d = i;
                            d.status = "fulfilled", d.value = u
                        }
                    }, function(u) {
                        if (i.status === "pending") {
                            var d = i;
                            d.status = "rejected", d.reason = u
                        }
                    })
                }
                switch (i.status) {
                    case "fulfilled":
                        return i.value;
                    case "rejected":
                        throw t = i.reason, jp(t), t
                }
                throw sr = i, ar
        }
    }
    var sr = null;

    function Lp() {
        if (sr === null) throw Error(s(459));
        var t = sr;
        return sr = null, t
    }

    function jp(t) {
        if (t === ar || t === Fl) throw Error(s(483))
    }
    var fi = !1;

    function yc(t) {
        t.updateQueue = {
            baseState: t.memoizedState,
            firstBaseUpdate: null,
            lastBaseUpdate: null,
            shared: {
                pending: null,
                lanes: 0,
                hiddenCallbacks: null
            },
            callbacks: null
        }
    }

    function bc(t, i) {
        t = t.updateQueue, i.updateQueue === t && (i.updateQueue = {
            baseState: t.baseState,
            firstBaseUpdate: t.firstBaseUpdate,
            lastBaseUpdate: t.lastBaseUpdate,
            shared: t.shared,
            callbacks: null
        })
    }

    function di(t) {
        return {
            lane: t,
            tag: 0,
            payload: null,
            callback: null,
            next: null
        }
    }

    function hi(t, i, r) {
        var u = t.updateQueue;
        if (u === null) return null;
        if (u = u.shared, (Me & 2) !== 0) {
            var d = u.pending;
            return d === null ? i.next = i : (i.next = d.next, d.next = i), u.pending = i, i = Pl(t), xp(t, null, r), i
        }
        return Bl(t, u, i, r), Pl(t)
    }

    function rr(t, i, r) {
        if (i = i.updateQueue, i !== null && (i = i.shared, (r & 4194048) !== 0)) {
            var u = i.lanes;
            u &= t.pendingLanes, r |= u, i.lanes = r, Am(t, r)
        }
    }

    function xc(t, i) {
        var r = t.updateQueue,
            u = t.alternate;
        if (u !== null && (u = u.updateQueue, r === u)) {
            var d = null,
                g = null;
            if (r = r.firstBaseUpdate, r !== null) {
                do {
                    var x = {
                        lane: r.lane,
                        tag: r.tag,
                        payload: r.payload,
                        callback: null,
                        next: null
                    };
                    g === null ? d = g = x : g = g.next = x, r = r.next
                } while (r !== null);
                g === null ? d = g = i : g = g.next = i
            } else d = g = i;
            r = {
                baseState: u.baseState,
                firstBaseUpdate: d,
                lastBaseUpdate: g,
                shared: u.shared,
                callbacks: u.callbacks
            }, t.updateQueue = r;
            return
        }
        t = r.lastBaseUpdate, t === null ? r.firstBaseUpdate = i : t.next = i, r.lastBaseUpdate = i
    }
    var Sc = !1;

    function lr() {
        if (Sc) {
            var t = Ya;
            if (t !== null) throw t
        }
    }

    function or(t, i, r, u) {
        Sc = !1;
        var d = t.updateQueue;
        fi = !1;
        var g = d.firstBaseUpdate,
            x = d.lastBaseUpdate,
            E = d.shared.pending;
        if (E !== null) {
            d.shared.pending = null;
            var R = E,
                U = R.next;
            R.next = null, x === null ? g = U : x.next = U, x = R;
            var K = t.alternate;
            K !== null && (K = K.updateQueue, E = K.lastBaseUpdate, E !== x && (E === null ? K.firstBaseUpdate = U : E.next = U, K.lastBaseUpdate = R))
        }
        if (g !== null) {
            var $ = d.baseState;
            x = 0, K = U = R = null, E = g;
            do {
                var q = E.lane & -536870913,
                    Y = q !== E.lane;
                if (Y ? (Te & q) === q : (u & q) === q) {
                    q !== 0 && q === qa && (Sc = !0), K !== null && (K = K.next = {
                        lane: 0,
                        tag: E.tag,
                        payload: E.payload,
                        callback: null,
                        next: null
                    });
                    e: {
                        var fe = t,
                            ue = E;q = i;
                        var De = r;
                        switch (ue.tag) {
                            case 1:
                                if (fe = ue.payload, typeof fe == "function") {
                                    $ = fe.call(De, $, q);
                                    break e
                                }
                                $ = fe;
                                break e;
                            case 3:
                                fe.flags = fe.flags & -65537 | 128;
                            case 0:
                                if (fe = ue.payload, q = typeof fe == "function" ? fe.call(De, $, q) : fe, q == null) break e;
                                $ = p({}, $, q);
                                break e;
                            case 2:
                                fi = !0
                        }
                    }
                    q = E.callback, q !== null && (t.flags |= 64, Y && (t.flags |= 8192), Y = d.callbacks, Y === null ? d.callbacks = [q] : Y.push(q))
                } else Y = {
                    lane: q,
                    tag: E.tag,
                    payload: E.payload,
                    callback: E.callback,
                    next: null
                }, K === null ? (U = K = Y, R = $) : K = K.next = Y, x |= q;
                if (E = E.next, E === null) {
                    if (E = d.shared.pending, E === null) break;
                    Y = E, E = Y.next, Y.next = null, d.lastBaseUpdate = Y, d.shared.pending = null
                }
            } while (!0);
            K === null && (R = $), d.baseState = R, d.firstBaseUpdate = U, d.lastBaseUpdate = K, g === null && (d.shared.lanes = 0), Si |= x, t.lanes = x, t.memoizedState = $
        }
    }

    function Np(t, i) {
        if (typeof t != "function") throw Error(s(191, t));
        t.call(i)
    }

    function Vp(t, i) {
        var r = t.callbacks;
        if (r !== null)
            for (t.callbacks = null, t = 0; t < r.length; t++) Np(r[t], i)
    }
    var Xa = Z(null),
        Zl = Z(0);

    function kp(t, i) {
        t = $n, ie(Zl, t), ie(Xa, i), $n = t | i.baseLanes
    }

    function Tc() {
        ie(Zl, $n), ie(Xa, Xa.current)
    }

    function _c() {
        $n = Zl.current, ne(Xa), ne(Zl)
    }
    var mi = 0,
        ge = null,
        Ce = null,
        Je = null,
        Ql = !1,
        Fa = !1,
        aa = !1,
        Il = 0,
        ur = 0,
        Ka = null,
        HS = 0;

    function Qe() {
        throw Error(s(321))
    }

    function Ec(t, i) {
        if (i === null) return !1;
        for (var r = 0; r < i.length && r < t.length; r++)
            if (!Ut(t[r], i[r])) return !1;
        return !0
    }

    function wc(t, i, r, u, d, g) {
        return mi = g, ge = i, i.memoizedState = null, i.updateQueue = null, i.lanes = 0, P.H = t === null || t.memoizedState === null ? x0 : S0, aa = !1, g = r(u, d), aa = !1, Fa && (g = Pp(i, r, u, d)), Bp(t), g
    }

    function Bp(t) {
        P.H = no;
        var i = Ce !== null && Ce.next !== null;
        if (mi = 0, Je = Ce = ge = null, Ql = !1, ur = 0, Ka = null, i) throw Error(s(300));
        t === null || rt || (t = t.dependencies, t !== null && ql(t) && (rt = !0))
    }

    function Pp(t, i, r, u) {
        ge = t;
        var d = 0;
        do {
            if (Fa && (Ka = null), ur = 0, Fa = !1, 25 <= d) throw Error(s(301));
            if (d += 1, Je = Ce = null, t.updateQueue != null) {
                var g = t.updateQueue;
                g.lastEffect = null, g.events = null, g.stores = null, g.memoCache != null && (g.memoCache.index = 0)
            }
            P.H = ZS, g = i(r, u)
        } while (Fa);
        return g
    }

    function GS() {
        var t = P.H,
            i = t.useState()[0];
        return i = typeof i.then == "function" ? cr(i) : i, t = t.useState()[0], (Ce !== null ? Ce.memoizedState : null) !== t && (ge.flags |= 1024), i
    }

    function Mc() {
        var t = Il !== 0;
        return Il = 0, t
    }

    function Ac(t, i, r) {
        i.updateQueue = t.updateQueue, i.flags &= -2053, t.lanes &= ~r
    }

    function Cc(t) {
        if (Ql) {
            for (t = t.memoizedState; t !== null;) {
                var i = t.queue;
                i !== null && (i.pending = null), t = t.next
            }
            Ql = !1
        }
        mi = 0, Je = Ce = ge = null, Fa = !1, ur = Il = 0, Ka = null
    }

    function Ct() {
        var t = {
            memoizedState: null,
            baseState: null,
            baseQueue: null,
            queue: null,
            next: null
        };
        return Je === null ? ge.memoizedState = Je = t : Je = Je.next = t, Je
    }

    function et() {
        if (Ce === null) {
            var t = ge.alternate;
            t = t !== null ? t.memoizedState : null
        } else t = Ce.next;
        var i = Je === null ? ge.memoizedState : Je.next;
        if (i !== null) Je = i, Ce = t;
        else {
            if (t === null) throw ge.alternate === null ? Error(s(467)) : Error(s(310));
            Ce = t, t = {
                memoizedState: Ce.memoizedState,
                baseState: Ce.baseState,
                baseQueue: Ce.baseQueue,
                queue: Ce.queue,
                next: null
            }, Je === null ? ge.memoizedState = Je = t : Je = Je.next = t
        }
        return Je
    }

    function Oc() {
        return {
            lastEffect: null,
            events: null,
            stores: null,
            memoCache: null
        }
    }

    function cr(t) {
        var i = ur;
        return ur += 1, Ka === null && (Ka = []), t = Rp(Ka, t, i), i = ge, (Je === null ? i.memoizedState : Je.next) === null && (i = i.alternate, P.H = i === null || i.memoizedState === null ? x0 : S0), t
    }

    function $l(t) {
        if (t !== null && typeof t == "object") {
            if (typeof t.then == "function") return cr(t);
            if (t.$$typeof === C) return vt(t)
        }
        throw Error(s(438, String(t)))
    }

    function Dc(t) {
        var i = null,
            r = ge.updateQueue;
        if (r !== null && (i = r.memoCache), i == null) {
            var u = ge.alternate;
            u !== null && (u = u.updateQueue, u !== null && (u = u.memoCache, u != null && (i = {
                data: u.data.map(function(d) {
                    return d.slice()
                }),
                index: 0
            })))
        }
        if (i == null && (i = {
                data: [],
                index: 0
            }), r === null && (r = Oc(), ge.updateQueue = r), r.memoCache = i, r = i.data[i.index], r === void 0)
            for (r = i.data[i.index] = Array(t), u = 0; u < t; u++) r[u] = F;
        return i.index++, r
    }

    function Xn(t, i) {
        return typeof i == "function" ? i(t) : i
    }

    function Wl(t) {
        var i = et();
        return zc(i, Ce, t)
    }

    function zc(t, i, r) {
        var u = t.queue;
        if (u === null) throw Error(s(311));
        u.lastRenderedReducer = r;
        var d = t.baseQueue,
            g = u.pending;
        if (g !== null) {
            if (d !== null) {
                var x = d.next;
                d.next = g.next, g.next = x
            }
            i.baseQueue = d = g, u.pending = null
        }
        if (g = t.baseState, d === null) t.memoizedState = g;
        else {
            i = d.next;
            var E = x = null,
                R = null,
                U = i,
                K = !1;
            do {
                var $ = U.lane & -536870913;
                if ($ !== U.lane ? (Te & $) === $ : (mi & $) === $) {
                    var q = U.revertLane;
                    if (q === 0) R !== null && (R = R.next = {
                        lane: 0,
                        revertLane: 0,
                        action: U.action,
                        hasEagerState: U.hasEagerState,
                        eagerState: U.eagerState,
                        next: null
                    }), $ === qa && (K = !0);
                    else if ((mi & q) === q) {
                        U = U.next, q === qa && (K = !0);
                        continue
                    } else $ = {
                        lane: 0,
                        revertLane: U.revertLane,
                        action: U.action,
                        hasEagerState: U.hasEagerState,
                        eagerState: U.eagerState,
                        next: null
                    }, R === null ? (E = R = $, x = g) : R = R.next = $, ge.lanes |= q, Si |= q;
                    $ = U.action, aa && r(g, $), g = U.hasEagerState ? U.eagerState : r(g, $)
                } else q = {
                    lane: $,
                    revertLane: U.revertLane,
                    action: U.action,
                    hasEagerState: U.hasEagerState,
                    eagerState: U.eagerState,
                    next: null
                }, R === null ? (E = R = q, x = g) : R = R.next = q, ge.lanes |= $, Si |= $;
                U = U.next
            } while (U !== null && U !== i);
            if (R === null ? x = g : R.next = E, !Ut(g, t.memoizedState) && (rt = !0, K && (r = Ya, r !== null))) throw r;
            t.memoizedState = g, t.baseState = x, t.baseQueue = R, u.lastRenderedState = g
        }
        return d === null && (u.lanes = 0), [t.memoizedState, u.dispatch]
    }

    function Rc(t) {
        var i = et(),
            r = i.queue;
        if (r === null) throw Error(s(311));
        r.lastRenderedReducer = t;
        var u = r.dispatch,
            d = r.pending,
            g = i.memoizedState;
        if (d !== null) {
            r.pending = null;
            var x = d = d.next;
            do g = t(g, x.action), x = x.next; while (x !== d);
            Ut(g, i.memoizedState) || (rt = !0), i.memoizedState = g, i.baseQueue === null && (i.baseState = g), r.lastRenderedState = g
        }
        return [g, u]
    }

    function Up(t, i, r) {
        var u = ge,
            d = et(),
            g = Ee;
        if (g) {
            if (r === void 0) throw Error(s(407));
            r = r()
        } else r = i();
        var x = !Ut((Ce || d).memoizedState, r);
        x && (d.memoizedState = r, rt = !0), d = d.queue;
        var E = qp.bind(null, u, d, t);
        if (fr(2048, 8, E, [t]), d.getSnapshot !== i || x || Je !== null && Je.memoizedState.tag & 1) {
            if (u.flags |= 2048, Za(9, Jl(), Gp.bind(null, u, d, r, i), null), je === null) throw Error(s(349));
            g || (mi & 124) !== 0 || Hp(u, i, r)
        }
        return r
    }

    function Hp(t, i, r) {
        t.flags |= 16384, t = {
            getSnapshot: i,
            value: r
        }, i = ge.updateQueue, i === null ? (i = Oc(), ge.updateQueue = i, i.stores = [t]) : (r = i.stores, r === null ? i.stores = [t] : r.push(t))
    }

    function Gp(t, i, r, u) {
        i.value = r, i.getSnapshot = u, Yp(i) && Xp(t)
    }

    function qp(t, i, r) {
        return r(function() {
            Yp(i) && Xp(t)
        })
    }

    function Yp(t) {
        var i = t.getSnapshot;
        t = t.value;
        try {
            var r = i();
            return !Ut(t, r)
        } catch {
            return !0
        }
    }

    function Xp(t) {
        var i = Pa(t, 2);
        i !== null && Ft(i, t, 2)
    }

    function Lc(t) {
        var i = Ct();
        if (typeof t == "function") {
            var r = t;
            if (t = r(), aa) {
                li(!0);
                try {
                    r()
                } finally {
                    li(!1)
                }
            }
        }
        return i.memoizedState = i.baseState = t, i.queue = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: Xn,
            lastRenderedState: t
        }, i
    }

    function Fp(t, i, r, u) {
        return t.baseState = r, zc(t, Ce, typeof u == "function" ? u : Xn)
    }

    function qS(t, i, r, u, d) {
        if (to(t)) throw Error(s(485));
        if (t = i.action, t !== null) {
            var g = {
                payload: d,
                action: t,
                next: null,
                isTransition: !0,
                status: "pending",
                value: null,
                reason: null,
                listeners: [],
                then: function(x) {
                    g.listeners.push(x)
                }
            };
            P.T !== null ? r(!0) : g.isTransition = !1, u(g), r = i.pending, r === null ? (g.next = i.pending = g, Kp(i, g)) : (g.next = r.next, i.pending = r.next = g)
        }
    }

    function Kp(t, i) {
        var r = i.action,
            u = i.payload,
            d = t.state;
        if (i.isTransition) {
            var g = P.T,
                x = {};
            P.T = x;
            try {
                var E = r(d, u),
                    R = P.S;
                R !== null && R(x, E), Zp(t, i, E)
            } catch (U) {
                jc(t, i, U)
            } finally {
                P.T = g
            }
        } else try {
            g = r(d, u), Zp(t, i, g)
        } catch (U) {
            jc(t, i, U)
        }
    }

    function Zp(t, i, r) {
        r !== null && typeof r == "object" && typeof r.then == "function" ? r.then(function(u) {
            Qp(t, i, u)
        }, function(u) {
            return jc(t, i, u)
        }) : Qp(t, i, r)
    }

    function Qp(t, i, r) {
        i.status = "fulfilled", i.value = r, Ip(i), t.state = r, i = t.pending, i !== null && (r = i.next, r === i ? t.pending = null : (r = r.next, i.next = r, Kp(t, r)))
    }

    function jc(t, i, r) {
        var u = t.pending;
        if (t.pending = null, u !== null) {
            u = u.next;
            do i.status = "rejected", i.reason = r, Ip(i), i = i.next; while (i !== u)
        }
        t.action = null
    }

    function Ip(t) {
        t = t.listeners;
        for (var i = 0; i < t.length; i++)(0, t[i])()
    }

    function $p(t, i) {
        return i
    }

    function Wp(t, i) {
        if (Ee) {
            var r = je.formState;
            if (r !== null) {
                e: {
                    var u = ge;
                    if (Ee) {
                        if (Xe) {
                            t: {
                                for (var d = Xe, g = wn; d.nodeType !== 8;) {
                                    if (!g) {
                                        d = null;
                                        break t
                                    }
                                    if (d = Sn(d.nextSibling), d === null) {
                                        d = null;
                                        break t
                                    }
                                }
                                g = d.data,
                                d = g === "F!" || g === "F" ? d : null
                            }
                            if (d) {
                                Xe = Sn(d.nextSibling), u = d.data === "F!";
                                break e
                            }
                        }
                        ea(u)
                    }
                    u = !1
                }
                u && (i = r[0])
            }
        }
        return r = Ct(), r.memoizedState = r.baseState = i, u = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: $p,
            lastRenderedState: i
        }, r.queue = u, r = v0.bind(null, ge, u), u.dispatch = r, u = Lc(!1), g = Pc.bind(null, ge, !1, u.queue), u = Ct(), d = {
            state: i,
            dispatch: null,
            action: t,
            pending: null
        }, u.queue = d, r = qS.bind(null, ge, d, g, r), d.dispatch = r, u.memoizedState = t, [i, r, !1]
    }

    function Jp(t) {
        var i = et();
        return e0(i, Ce, t)
    }

    function e0(t, i, r) {
        if (i = zc(t, i, $p)[0], t = Wl(Xn)[0], typeof i == "object" && i !== null && typeof i.then == "function") try {
            var u = cr(i)
        } catch (x) {
            throw x === ar ? Fl : x
        } else u = i;
        i = et();
        var d = i.queue,
            g = d.dispatch;
        return r !== i.memoizedState && (ge.flags |= 2048, Za(9, Jl(), YS.bind(null, d, r), null)), [u, g, t]
    }

    function YS(t, i) {
        t.action = i
    }

    function t0(t) {
        var i = et(),
            r = Ce;
        if (r !== null) return e0(i, r, t);
        et(), i = i.memoizedState, r = et();
        var u = r.queue.dispatch;
        return r.memoizedState = t, [i, u, !1]
    }

    function Za(t, i, r, u) {
        return t = {
            tag: t,
            create: r,
            deps: u,
            inst: i,
            next: null
        }, i = ge.updateQueue, i === null && (i = Oc(), ge.updateQueue = i), r = i.lastEffect, r === null ? i.lastEffect = t.next = t : (u = r.next, r.next = t, t.next = u, i.lastEffect = t), t
    }

    function Jl() {
        return {
            destroy: void 0,
            resource: void 0
        }
    }

    function n0() {
        return et().memoizedState
    }

    function eo(t, i, r, u) {
        var d = Ct();
        u = u === void 0 ? null : u, ge.flags |= t, d.memoizedState = Za(1 | i, Jl(), r, u)
    }

    function fr(t, i, r, u) {
        var d = et();
        u = u === void 0 ? null : u;
        var g = d.memoizedState.inst;
        Ce !== null && u !== null && Ec(u, Ce.memoizedState.deps) ? d.memoizedState = Za(i, g, r, u) : (ge.flags |= t, d.memoizedState = Za(1 | i, g, r, u))
    }

    function i0(t, i) {
        eo(8390656, 8, t, i)
    }

    function a0(t, i) {
        fr(2048, 8, t, i)
    }

    function s0(t, i) {
        return fr(4, 2, t, i)
    }

    function r0(t, i) {
        return fr(4, 4, t, i)
    }

    function l0(t, i) {
        if (typeof i == "function") {
            t = t();
            var r = i(t);
            return function() {
                typeof r == "function" ? r() : i(null)
            }
        }
        if (i != null) return t = t(), i.current = t,
            function() {
                i.current = null
            }
    }

    function o0(t, i, r) {
        r = r != null ? r.concat([t]) : null, fr(4, 4, l0.bind(null, i, t), r)
    }

    function Nc() {}

    function u0(t, i) {
        var r = et();
        i = i === void 0 ? null : i;
        var u = r.memoizedState;
        return i !== null && Ec(i, u[1]) ? u[0] : (r.memoizedState = [t, i], t)
    }

    function c0(t, i) {
        var r = et();
        i = i === void 0 ? null : i;
        var u = r.memoizedState;
        if (i !== null && Ec(i, u[1])) return u[0];
        if (u = t(), aa) {
            li(!0);
            try {
                t()
            } finally {
                li(!1)
            }
        }
        return r.memoizedState = [u, i], u
    }

    function Vc(t, i, r) {
        return r === void 0 || (mi & 1073741824) !== 0 ? t.memoizedState = i : (t.memoizedState = r, t = hg(), ge.lanes |= t, Si |= t, r)
    }

    function f0(t, i, r, u) {
        return Ut(r, i) ? r : Xa.current !== null ? (t = Vc(t, r, u), Ut(t, i) || (rt = !0), t) : (mi & 42) === 0 ? (rt = !0, t.memoizedState = r) : (t = hg(), ge.lanes |= t, Si |= t, i)
    }

    function d0(t, i, r, u, d) {
        var g = G.p;
        G.p = g !== 0 && 8 > g ? g : 8;
        var x = P.T,
            E = {};
        P.T = E, Pc(t, !1, i, r);
        try {
            var R = d(),
                U = P.S;
            if (U !== null && U(E, R), R !== null && typeof R == "object" && typeof R.then == "function") {
                var K = US(R, u);
                dr(t, i, K, Xt(t))
            } else dr(t, i, u, Xt(t))
        } catch ($) {
            dr(t, i, {
                then: function() {},
                status: "rejected",
                reason: $
            }, Xt())
        } finally {
            G.p = g, P.T = x
        }
    }

    function XS() {}

    function kc(t, i, r, u) {
        if (t.tag !== 5) throw Error(s(476));
        var d = h0(t).queue;
        d0(t, d, i, X, r === null ? XS : function() {
            return m0(t), r(u)
        })
    }

    function h0(t) {
        var i = t.memoizedState;
        if (i !== null) return i;
        i = {
            memoizedState: X,
            baseState: X,
            baseQueue: null,
            queue: {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: Xn,
                lastRenderedState: X
            },
            next: null
        };
        var r = {};
        return i.next = {
            memoizedState: r,
            baseState: r,
            baseQueue: null,
            queue: {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: Xn,
                lastRenderedState: r
            },
            next: null
        }, t.memoizedState = i, t = t.alternate, t !== null && (t.memoizedState = i), i
    }

    function m0(t) {
        var i = h0(t).next.queue;
        dr(t, i, {}, Xt())
    }

    function Bc() {
        return vt(Dr)
    }

    function p0() {
        return et().memoizedState
    }

    function g0() {
        return et().memoizedState
    }

    function FS(t) {
        for (var i = t.return; i !== null;) {
            switch (i.tag) {
                case 24:
                case 3:
                    var r = Xt();
                    t = di(r);
                    var u = hi(i, t, r);
                    u !== null && (Ft(u, i, r), rr(u, i, r)), i = {
                        cache: mc()
                    }, t.payload = i;
                    return
            }
            i = i.return
        }
    }

    function KS(t, i, r) {
        var u = Xt();
        r = {
            lane: u,
            revertLane: 0,
            action: r,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, to(t) ? y0(i, r) : (r = ac(t, i, r, u), r !== null && (Ft(r, t, u), b0(r, i, u)))
    }

    function v0(t, i, r) {
        var u = Xt();
        dr(t, i, r, u)
    }

    function dr(t, i, r, u) {
        var d = {
            lane: u,
            revertLane: 0,
            action: r,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
        if (to(t)) y0(i, d);
        else {
            var g = t.alternate;
            if (t.lanes === 0 && (g === null || g.lanes === 0) && (g = i.lastRenderedReducer, g !== null)) try {
                var x = i.lastRenderedState,
                    E = g(x, r);
                if (d.hasEagerState = !0, d.eagerState = E, Ut(E, x)) return Bl(t, i, d, 0), je === null && kl(), !1
            } catch {} finally {}
            if (r = ac(t, i, d, u), r !== null) return Ft(r, t, u), b0(r, i, u), !0
        }
        return !1
    }

    function Pc(t, i, r, u) {
        if (u = {
                lane: 2,
                revertLane: yf(),
                action: u,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, to(t)) {
            if (i) throw Error(s(479))
        } else i = ac(t, r, u, 2), i !== null && Ft(i, t, 2)
    }

    function to(t) {
        var i = t.alternate;
        return t === ge || i !== null && i === ge
    }

    function y0(t, i) {
        Fa = Ql = !0;
        var r = t.pending;
        r === null ? i.next = i : (i.next = r.next, r.next = i), t.pending = i
    }

    function b0(t, i, r) {
        if ((r & 4194048) !== 0) {
            var u = i.lanes;
            u &= t.pendingLanes, r |= u, i.lanes = r, Am(t, r)
        }
    }
    var no = {
            readContext: vt,
            use: $l,
            useCallback: Qe,
            useContext: Qe,
            useEffect: Qe,
            useImperativeHandle: Qe,
            useLayoutEffect: Qe,
            useInsertionEffect: Qe,
            useMemo: Qe,
            useReducer: Qe,
            useRef: Qe,
            useState: Qe,
            useDebugValue: Qe,
            useDeferredValue: Qe,
            useTransition: Qe,
            useSyncExternalStore: Qe,
            useId: Qe,
            useHostTransitionStatus: Qe,
            useFormState: Qe,
            useActionState: Qe,
            useOptimistic: Qe,
            useMemoCache: Qe,
            useCacheRefresh: Qe
        },
        x0 = {
            readContext: vt,
            use: $l,
            useCallback: function(t, i) {
                return Ct().memoizedState = [t, i === void 0 ? null : i], t
            },
            useContext: vt,
            useEffect: i0,
            useImperativeHandle: function(t, i, r) {
                r = r != null ? r.concat([t]) : null, eo(4194308, 4, l0.bind(null, i, t), r)
            },
            useLayoutEffect: function(t, i) {
                return eo(4194308, 4, t, i)
            },
            useInsertionEffect: function(t, i) {
                eo(4, 2, t, i)
            },
            useMemo: function(t, i) {
                var r = Ct();
                i = i === void 0 ? null : i;
                var u = t();
                if (aa) {
                    li(!0);
                    try {
                        t()
                    } finally {
                        li(!1)
                    }
                }
                return r.memoizedState = [u, i], u
            },
            useReducer: function(t, i, r) {
                var u = Ct();
                if (r !== void 0) {
                    var d = r(i);
                    if (aa) {
                        li(!0);
                        try {
                            r(i)
                        } finally {
                            li(!1)
                        }
                    }
                } else d = i;
                return u.memoizedState = u.baseState = d, t = {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: t,
                    lastRenderedState: d
                }, u.queue = t, t = t.dispatch = KS.bind(null, ge, t), [u.memoizedState, t]
            },
            useRef: function(t) {
                var i = Ct();
                return t = {
                    current: t
                }, i.memoizedState = t
            },
            useState: function(t) {
                t = Lc(t);
                var i = t.queue,
                    r = v0.bind(null, ge, i);
                return i.dispatch = r, [t.memoizedState, r]
            },
            useDebugValue: Nc,
            useDeferredValue: function(t, i) {
                var r = Ct();
                return Vc(r, t, i)
            },
            useTransition: function() {
                var t = Lc(!1);
                return t = d0.bind(null, ge, t.queue, !0, !1), Ct().memoizedState = t, [!1, t]
            },
            useSyncExternalStore: function(t, i, r) {
                var u = ge,
                    d = Ct();
                if (Ee) {
                    if (r === void 0) throw Error(s(407));
                    r = r()
                } else {
                    if (r = i(), je === null) throw Error(s(349));
                    (Te & 124) !== 0 || Hp(u, i, r)
                }
                d.memoizedState = r;
                var g = {
                    value: r,
                    getSnapshot: i
                };
                return d.queue = g, i0(qp.bind(null, u, g, t), [t]), u.flags |= 2048, Za(9, Jl(), Gp.bind(null, u, g, r, i), null), r
            },
            useId: function() {
                var t = Ct(),
                    i = je.identifierPrefix;
                if (Ee) {
                    var r = Gn,
                        u = Hn;
                    r = (u & ~(1 << 32 - Pt(u) - 1)).toString(32) + r, i = "«" + i + "R" + r, r = Il++, 0 < r && (i += "H" + r.toString(32)), i += "»"
                } else r = HS++, i = "«" + i + "r" + r.toString(32) + "»";
                return t.memoizedState = i
            },
            useHostTransitionStatus: Bc,
            useFormState: Wp,
            useActionState: Wp,
            useOptimistic: function(t) {
                var i = Ct();
                i.memoizedState = i.baseState = t;
                var r = {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: null,
                    lastRenderedState: null
                };
                return i.queue = r, i = Pc.bind(null, ge, !0, r), r.dispatch = i, [t, i]
            },
            useMemoCache: Dc,
            useCacheRefresh: function() {
                return Ct().memoizedState = FS.bind(null, ge)
            }
        },
        S0 = {
            readContext: vt,
            use: $l,
            useCallback: u0,
            useContext: vt,
            useEffect: a0,
            useImperativeHandle: o0,
            useInsertionEffect: s0,
            useLayoutEffect: r0,
            useMemo: c0,
            useReducer: Wl,
            useRef: n0,
            useState: function() {
                return Wl(Xn)
            },
            useDebugValue: Nc,
            useDeferredValue: function(t, i) {
                var r = et();
                return f0(r, Ce.memoizedState, t, i)
            },
            useTransition: function() {
                var t = Wl(Xn)[0],
                    i = et().memoizedState;
                return [typeof t == "boolean" ? t : cr(t), i]
            },
            useSyncExternalStore: Up,
            useId: p0,
            useHostTransitionStatus: Bc,
            useFormState: Jp,
            useActionState: Jp,
            useOptimistic: function(t, i) {
                var r = et();
                return Fp(r, Ce, t, i)
            },
            useMemoCache: Dc,
            useCacheRefresh: g0
        },
        ZS = {
            readContext: vt,
            use: $l,
            useCallback: u0,
            useContext: vt,
            useEffect: a0,
            useImperativeHandle: o0,
            useInsertionEffect: s0,
            useLayoutEffect: r0,
            useMemo: c0,
            useReducer: Rc,
            useRef: n0,
            useState: function() {
                return Rc(Xn)
            },
            useDebugValue: Nc,
            useDeferredValue: function(t, i) {
                var r = et();
                return Ce === null ? Vc(r, t, i) : f0(r, Ce.memoizedState, t, i)
            },
            useTransition: function() {
                var t = Rc(Xn)[0],
                    i = et().memoizedState;
                return [typeof t == "boolean" ? t : cr(t), i]
            },
            useSyncExternalStore: Up,
            useId: p0,
            useHostTransitionStatus: Bc,
            useFormState: t0,
            useActionState: t0,
            useOptimistic: function(t, i) {
                var r = et();
                return Ce !== null ? Fp(r, Ce, t, i) : (r.baseState = t, [t, r.queue.dispatch])
            },
            useMemoCache: Dc,
            useCacheRefresh: g0
        },
        Qa = null,
        hr = 0;

    function io(t) {
        var i = hr;
        return hr += 1, Qa === null && (Qa = []), Rp(Qa, t, i)
    }

    function mr(t, i) {
        i = i.props.ref, t.ref = i !== void 0 ? i : null
    }

    function ao(t, i) {
        throw i.$$typeof === v ? Error(s(525)) : (t = Object.prototype.toString.call(i), Error(s(31, t === "[object Object]" ? "object with keys {" + Object.keys(i).join(", ") + "}" : t)))
    }

    function T0(t) {
        var i = t._init;
        return i(t._payload)
    }

    function _0(t) {
        function i(N, j) {
            if (t) {
                var B = N.deletions;
                B === null ? (N.deletions = [j], N.flags |= 16) : B.push(j)
            }
        }

        function r(N, j) {
            if (!t) return null;
            for (; j !== null;) i(N, j), j = j.sibling;
            return null
        }

        function u(N) {
            for (var j = new Map; N !== null;) N.key !== null ? j.set(N.key, N) : j.set(N.index, N), N = N.sibling;
            return j
        }

        function d(N, j) {
            return N = Un(N, j), N.index = 0, N.sibling = null, N
        }

        function g(N, j, B) {
            return N.index = B, t ? (B = N.alternate, B !== null ? (B = B.index, B < j ? (N.flags |= 67108866, j) : B) : (N.flags |= 67108866, j)) : (N.flags |= 1048576, j)
        }

        function x(N) {
            return t && N.alternate === null && (N.flags |= 67108866), N
        }

        function E(N, j, B, Q) {
            return j === null || j.tag !== 6 ? (j = rc(B, N.mode, Q), j.return = N, j) : (j = d(j, B), j.return = N, j)
        }

        function R(N, j, B, Q) {
            var re = B.type;
            return re === T ? K(N, j, B.props.children, Q, B.key) : j !== null && (j.elementType === re || typeof re == "object" && re !== null && re.$$typeof === D && T0(re) === j.type) ? (j = d(j, B.props), mr(j, B), j.return = N, j) : (j = Ul(B.type, B.key, B.props, null, N.mode, Q), mr(j, B), j.return = N, j)
        }

        function U(N, j, B, Q) {
            return j === null || j.tag !== 4 || j.stateNode.containerInfo !== B.containerInfo || j.stateNode.implementation !== B.implementation ? (j = lc(B, N.mode, Q), j.return = N, j) : (j = d(j, B.children || []), j.return = N, j)
        }

        function K(N, j, B, Q, re) {
            return j === null || j.tag !== 7 ? (j = Ii(B, N.mode, Q, re), j.return = N, j) : (j = d(j, B), j.return = N, j)
        }

        function $(N, j, B) {
            if (typeof j == "string" && j !== "" || typeof j == "number" || typeof j == "bigint") return j = rc("" + j, N.mode, B), j.return = N, j;
            if (typeof j == "object" && j !== null) {
                switch (j.$$typeof) {
                    case b:
                        return B = Ul(j.type, j.key, j.props, null, N.mode, B), mr(B, j), B.return = N, B;
                    case y:
                        return j = lc(j, N.mode, B), j.return = N, j;
                    case D:
                        var Q = j._init;
                        return j = Q(j._payload), $(N, j, B)
                }
                if (se(j) || W(j)) return j = Ii(j, N.mode, B, null), j.return = N, j;
                if (typeof j.then == "function") return $(N, io(j), B);
                if (j.$$typeof === C) return $(N, Yl(N, j), B);
                ao(N, j)
            }
            return null
        }

        function q(N, j, B, Q) {
            var re = j !== null ? j.key : null;
            if (typeof B == "string" && B !== "" || typeof B == "number" || typeof B == "bigint") return re !== null ? null : E(N, j, "" + B, Q);
            if (typeof B == "object" && B !== null) {
                switch (B.$$typeof) {
                    case b:
                        return B.key === re ? R(N, j, B, Q) : null;
                    case y:
                        return B.key === re ? U(N, j, B, Q) : null;
                    case D:
                        return re = B._init, B = re(B._payload), q(N, j, B, Q)
                }
                if (se(B) || W(B)) return re !== null ? null : K(N, j, B, Q, null);
                if (typeof B.then == "function") return q(N, j, io(B), Q);
                if (B.$$typeof === C) return q(N, j, Yl(N, B), Q);
                ao(N, B)
            }
            return null
        }

        function Y(N, j, B, Q, re) {
            if (typeof Q == "string" && Q !== "" || typeof Q == "number" || typeof Q == "bigint") return N = N.get(B) || null, E(j, N, "" + Q, re);
            if (typeof Q == "object" && Q !== null) {
                switch (Q.$$typeof) {
                    case b:
                        return N = N.get(Q.key === null ? B : Q.key) || null, R(j, N, Q, re);
                    case y:
                        return N = N.get(Q.key === null ? B : Q.key) || null, U(j, N, Q, re);
                    case D:
                        var ve = Q._init;
                        return Q = ve(Q._payload), Y(N, j, B, Q, re)
                }
                if (se(Q) || W(Q)) return N = N.get(B) || null, K(j, N, Q, re, null);
                if (typeof Q.then == "function") return Y(N, j, B, io(Q), re);
                if (Q.$$typeof === C) return Y(N, j, B, Yl(j, Q), re);
                ao(j, Q)
            }
            return null
        }

        function fe(N, j, B, Q) {
            for (var re = null, ve = null, oe = j, ce = j = 0, ot = null; oe !== null && ce < B.length; ce++) {
                oe.index > ce ? (ot = oe, oe = null) : ot = oe.sibling;
                var _e = q(N, oe, B[ce], Q);
                if (_e === null) {
                    oe === null && (oe = ot);
                    break
                }
                t && oe && _e.alternate === null && i(N, oe), j = g(_e, j, ce), ve === null ? re = _e : ve.sibling = _e, ve = _e, oe = ot
            }
            if (ce === B.length) return r(N, oe), Ee && Wi(N, ce), re;
            if (oe === null) {
                for (; ce < B.length; ce++) oe = $(N, B[ce], Q), oe !== null && (j = g(oe, j, ce), ve === null ? re = oe : ve.sibling = oe, ve = oe);
                return Ee && Wi(N, ce), re
            }
            for (oe = u(oe); ce < B.length; ce++) ot = Y(oe, N, ce, B[ce], Q), ot !== null && (t && ot.alternate !== null && oe.delete(ot.key === null ? ce : ot.key), j = g(ot, j, ce), ve === null ? re = ot : ve.sibling = ot, ve = ot);
            return t && oe.forEach(function(Di) {
                return i(N, Di)
            }), Ee && Wi(N, ce), re
        }

        function ue(N, j, B, Q) {
            if (B == null) throw Error(s(151));
            for (var re = null, ve = null, oe = j, ce = j = 0, ot = null, _e = B.next(); oe !== null && !_e.done; ce++, _e = B.next()) {
                oe.index > ce ? (ot = oe, oe = null) : ot = oe.sibling;
                var Di = q(N, oe, _e.value, Q);
                if (Di === null) {
                    oe === null && (oe = ot);
                    break
                }
                t && oe && Di.alternate === null && i(N, oe), j = g(Di, j, ce), ve === null ? re = Di : ve.sibling = Di, ve = Di, oe = ot
            }
            if (_e.done) return r(N, oe), Ee && Wi(N, ce), re;
            if (oe === null) {
                for (; !_e.done; ce++, _e = B.next()) _e = $(N, _e.value, Q), _e !== null && (j = g(_e, j, ce), ve === null ? re = _e : ve.sibling = _e, ve = _e);
                return Ee && Wi(N, ce), re
            }
            for (oe = u(oe); !_e.done; ce++, _e = B.next()) _e = Y(oe, N, ce, _e.value, Q), _e !== null && (t && _e.alternate !== null && oe.delete(_e.key === null ? ce : _e.key), j = g(_e, j, ce), ve === null ? re = _e : ve.sibling = _e, ve = _e);
            return t && oe.forEach(function(QT) {
                return i(N, QT)
            }), Ee && Wi(N, ce), re
        }

        function De(N, j, B, Q) {
            if (typeof B == "object" && B !== null && B.type === T && B.key === null && (B = B.props.children), typeof B == "object" && B !== null) {
                switch (B.$$typeof) {
                    case b:
                        e: {
                            for (var re = B.key; j !== null;) {
                                if (j.key === re) {
                                    if (re = B.type, re === T) {
                                        if (j.tag === 7) {
                                            r(N, j.sibling), Q = d(j, B.props.children), Q.return = N, N = Q;
                                            break e
                                        }
                                    } else if (j.elementType === re || typeof re == "object" && re !== null && re.$$typeof === D && T0(re) === j.type) {
                                        r(N, j.sibling), Q = d(j, B.props), mr(Q, B), Q.return = N, N = Q;
                                        break e
                                    }
                                    r(N, j);
                                    break
                                } else i(N, j);
                                j = j.sibling
                            }
                            B.type === T ? (Q = Ii(B.props.children, N.mode, Q, B.key), Q.return = N, N = Q) : (Q = Ul(B.type, B.key, B.props, null, N.mode, Q), mr(Q, B), Q.return = N, N = Q)
                        }
                        return x(N);
                    case y:
                        e: {
                            for (re = B.key; j !== null;) {
                                if (j.key === re)
                                    if (j.tag === 4 && j.stateNode.containerInfo === B.containerInfo && j.stateNode.implementation === B.implementation) {
                                        r(N, j.sibling), Q = d(j, B.children || []), Q.return = N, N = Q;
                                        break e
                                    } else {
                                        r(N, j);
                                        break
                                    }
                                else i(N, j);
                                j = j.sibling
                            }
                            Q = lc(B, N.mode, Q),
                            Q.return = N,
                            N = Q
                        }
                        return x(N);
                    case D:
                        return re = B._init, B = re(B._payload), De(N, j, B, Q)
                }
                if (se(B)) return fe(N, j, B, Q);
                if (W(B)) {
                    if (re = W(B), typeof re != "function") throw Error(s(150));
                    return B = re.call(B), ue(N, j, B, Q)
                }
                if (typeof B.then == "function") return De(N, j, io(B), Q);
                if (B.$$typeof === C) return De(N, j, Yl(N, B), Q);
                ao(N, B)
            }
            return typeof B == "string" && B !== "" || typeof B == "number" || typeof B == "bigint" ? (B = "" + B, j !== null && j.tag === 6 ? (r(N, j.sibling), Q = d(j, B), Q.return = N, N = Q) : (r(N, j), Q = rc(B, N.mode, Q), Q.return = N, N = Q), x(N)) : r(N, j)
        }
        return function(N, j, B, Q) {
            try {
                hr = 0;
                var re = De(N, j, B, Q);
                return Qa = null, re
            } catch (oe) {
                if (oe === ar || oe === Fl) throw oe;
                var ve = Ht(29, oe, null, N.mode);
                return ve.lanes = Q, ve.return = N, ve
            } finally {}
        }
    }
    var Ia = _0(!0),
        E0 = _0(!1),
        on = Z(null),
        Mn = null;

    function pi(t) {
        var i = t.alternate;
        ie(at, at.current & 1), ie(on, t), Mn === null && (i === null || Xa.current !== null || i.memoizedState !== null) && (Mn = t)
    }

    function w0(t) {
        if (t.tag === 22) {
            if (ie(at, at.current), ie(on, t), Mn === null) {
                var i = t.alternate;
                i !== null && i.memoizedState !== null && (Mn = t)
            }
        } else gi()
    }

    function gi() {
        ie(at, at.current), ie(on, on.current)
    }

    function Fn(t) {
        ne(on), Mn === t && (Mn = null), ne(at)
    }
    var at = Z(0);

    function so(t) {
        for (var i = t; i !== null;) {
            if (i.tag === 13) {
                var r = i.memoizedState;
                if (r !== null && (r = r.dehydrated, r === null || r.data === "$?" || Df(r))) return i
            } else if (i.tag === 19 && i.memoizedProps.revealOrder !== void 0) {
                if ((i.flags & 128) !== 0) return i
            } else if (i.child !== null) {
                i.child.return = i, i = i.child;
                continue
            }
            if (i === t) break;
            for (; i.sibling === null;) {
                if (i.return === null || i.return === t) return null;
                i = i.return
            }
            i.sibling.return = i.return, i = i.sibling
        }
        return null
    }

    function Uc(t, i, r, u) {
        i = t.memoizedState, r = r(u, i), r = r == null ? i : p({}, i, r), t.memoizedState = r, t.lanes === 0 && (t.updateQueue.baseState = r)
    }
    var Hc = {
        enqueueSetState: function(t, i, r) {
            t = t._reactInternals;
            var u = Xt(),
                d = di(u);
            d.payload = i, r != null && (d.callback = r), i = hi(t, d, u), i !== null && (Ft(i, t, u), rr(i, t, u))
        },
        enqueueReplaceState: function(t, i, r) {
            t = t._reactInternals;
            var u = Xt(),
                d = di(u);
            d.tag = 1, d.payload = i, r != null && (d.callback = r), i = hi(t, d, u), i !== null && (Ft(i, t, u), rr(i, t, u))
        },
        enqueueForceUpdate: function(t, i) {
            t = t._reactInternals;
            var r = Xt(),
                u = di(r);
            u.tag = 2, i != null && (u.callback = i), i = hi(t, u, r), i !== null && (Ft(i, t, r), rr(i, t, r))
        }
    };

    function M0(t, i, r, u, d, g, x) {
        return t = t.stateNode, typeof t.shouldComponentUpdate == "function" ? t.shouldComponentUpdate(u, g, x) : i.prototype && i.prototype.isPureReactComponent ? !Is(r, u) || !Is(d, g) : !0
    }

    function A0(t, i, r, u) {
        t = i.state, typeof i.componentWillReceiveProps == "function" && i.componentWillReceiveProps(r, u), typeof i.UNSAFE_componentWillReceiveProps == "function" && i.UNSAFE_componentWillReceiveProps(r, u), i.state !== t && Hc.enqueueReplaceState(i, i.state, null)
    }

    function sa(t, i) {
        var r = i;
        if ("ref" in i) {
            r = {};
            for (var u in i) u !== "ref" && (r[u] = i[u])
        }
        if (t = t.defaultProps) {
            r === i && (r = p({}, r));
            for (var d in t) r[d] === void 0 && (r[d] = t[d])
        }
        return r
    }
    var ro = typeof reportError == "function" ? reportError : function(t) {
        if (typeof window == "object" && typeof window.ErrorEvent == "function") {
            var i = new window.ErrorEvent("error", {
                bubbles: !0,
                cancelable: !0,
                message: typeof t == "object" && t !== null && typeof t.message == "string" ? String(t.message) : String(t),
                error: t
            });
            if (!window.dispatchEvent(i)) return
        } else if (typeof process == "object" && typeof process.emit == "function") {
            process.emit("uncaughtException", t);
            return
        }
        console.error(t)
    };

    function C0(t) {
        ro(t)
    }

    function O0(t) {
        console.error(t)
    }

    function D0(t) {
        ro(t)
    }

    function lo(t, i) {
        try {
            var r = t.onUncaughtError;
            r(i.value, {
                componentStack: i.stack
            })
        } catch (u) {
            setTimeout(function() {
                throw u
            })
        }
    }

    function z0(t, i, r) {
        try {
            var u = t.onCaughtError;
            u(r.value, {
                componentStack: r.stack,
                errorBoundary: i.tag === 1 ? i.stateNode : null
            })
        } catch (d) {
            setTimeout(function() {
                throw d
            })
        }
    }

    function Gc(t, i, r) {
        return r = di(r), r.tag = 3, r.payload = {
            element: null
        }, r.callback = function() {
            lo(t, i)
        }, r
    }

    function R0(t) {
        return t = di(t), t.tag = 3, t
    }

    function L0(t, i, r, u) {
        var d = r.type.getDerivedStateFromError;
        if (typeof d == "function") {
            var g = u.value;
            t.payload = function() {
                return d(g)
            }, t.callback = function() {
                z0(i, r, u)
            }
        }
        var x = r.stateNode;
        x !== null && typeof x.componentDidCatch == "function" && (t.callback = function() {
            z0(i, r, u), typeof d != "function" && (Ti === null ? Ti = new Set([this]) : Ti.add(this));
            var E = u.stack;
            this.componentDidCatch(u.value, {
                componentStack: E !== null ? E : ""
            })
        })
    }

    function QS(t, i, r, u, d) {
        if (r.flags |= 32768, u !== null && typeof u == "object" && typeof u.then == "function") {
            if (i = r.alternate, i !== null && tr(i, r, d, !0), r = on.current, r !== null) {
                switch (r.tag) {
                    case 13:
                        return Mn === null ? hf() : r.alternate === null && Fe === 0 && (Fe = 3), r.flags &= -257, r.flags |= 65536, r.lanes = d, u === vc ? r.flags |= 16384 : (i = r.updateQueue, i === null ? r.updateQueue = new Set([u]) : i.add(u), pf(t, u, d)), !1;
                    case 22:
                        return r.flags |= 65536, u === vc ? r.flags |= 16384 : (i = r.updateQueue, i === null ? (i = {
                            transitions: null,
                            markerInstances: null,
                            retryQueue: new Set([u])
                        }, r.updateQueue = i) : (r = i.retryQueue, r === null ? i.retryQueue = new Set([u]) : r.add(u)), pf(t, u, d)), !1
                }
                throw Error(s(435, r.tag))
            }
            return pf(t, u, d), hf(), !1
        }
        if (Ee) return i = on.current, i !== null ? ((i.flags & 65536) === 0 && (i.flags |= 256), i.flags |= 65536, i.lanes = d, u !== cc && (t = Error(s(422), {
            cause: u
        }), er(an(t, r)))) : (u !== cc && (i = Error(s(423), {
            cause: u
        }), er(an(i, r))), t = t.current.alternate, t.flags |= 65536, d &= -d, t.lanes |= d, u = an(u, r), d = Gc(t.stateNode, u, d), xc(t, d), Fe !== 4 && (Fe = 2)), !1;
        var g = Error(s(520), {
            cause: u
        });
        if (g = an(g, r), Sr === null ? Sr = [g] : Sr.push(g), Fe !== 4 && (Fe = 2), i === null) return !0;
        u = an(u, r), r = i;
        do {
            switch (r.tag) {
                case 3:
                    return r.flags |= 65536, t = d & -d, r.lanes |= t, t = Gc(r.stateNode, u, t), xc(r, t), !1;
                case 1:
                    if (i = r.type, g = r.stateNode, (r.flags & 128) === 0 && (typeof i.getDerivedStateFromError == "function" || g !== null && typeof g.componentDidCatch == "function" && (Ti === null || !Ti.has(g)))) return r.flags |= 65536, d &= -d, r.lanes |= d, d = R0(d), L0(d, t, r, u), xc(r, d), !1
            }
            r = r.return
        } while (r !== null);
        return !1
    }
    var j0 = Error(s(461)),
        rt = !1;

    function ft(t, i, r, u) {
        i.child = t === null ? E0(i, null, r, u) : Ia(i, t.child, r, u)
    }

    function N0(t, i, r, u, d) {
        r = r.render;
        var g = i.ref;
        if ("ref" in u) {
            var x = {};
            for (var E in u) E !== "ref" && (x[E] = u[E])
        } else x = u;
        return na(i), u = wc(t, i, r, x, g, d), E = Mc(), t !== null && !rt ? (Ac(t, i, d), Kn(t, i, d)) : (Ee && E && oc(i), i.flags |= 1, ft(t, i, u, d), i.child)
    }

    function V0(t, i, r, u, d) {
        if (t === null) {
            var g = r.type;
            return typeof g == "function" && !sc(g) && g.defaultProps === void 0 && r.compare === null ? (i.tag = 15, i.type = g, k0(t, i, g, u, d)) : (t = Ul(r.type, null, u, i, i.mode, d), t.ref = i.ref, t.return = i, i.child = t)
        }
        if (g = t.child, !Ic(t, d)) {
            var x = g.memoizedProps;
            if (r = r.compare, r = r !== null ? r : Is, r(x, u) && t.ref === i.ref) return Kn(t, i, d)
        }
        return i.flags |= 1, t = Un(g, u), t.ref = i.ref, t.return = i, i.child = t
    }

    function k0(t, i, r, u, d) {
        if (t !== null) {
            var g = t.memoizedProps;
            if (Is(g, u) && t.ref === i.ref)
                if (rt = !1, i.pendingProps = u = g, Ic(t, d))(t.flags & 131072) !== 0 && (rt = !0);
                else return i.lanes = t.lanes, Kn(t, i, d)
        }
        return qc(t, i, r, u, d)
    }

    function B0(t, i, r) {
        var u = i.pendingProps,
            d = u.children,
            g = t !== null ? t.memoizedState : null;
        if (u.mode === "hidden") {
            if ((i.flags & 128) !== 0) {
                if (u = g !== null ? g.baseLanes | r : r, t !== null) {
                    for (d = i.child = t.child, g = 0; d !== null;) g = g | d.lanes | d.childLanes, d = d.sibling;
                    i.childLanes = g & ~u
                } else i.childLanes = 0, i.child = null;
                return P0(t, i, u, r)
            }
            if ((r & 536870912) !== 0) i.memoizedState = {
                baseLanes: 0,
                cachePool: null
            }, t !== null && Xl(i, g !== null ? g.cachePool : null), g !== null ? kp(i, g) : Tc(), w0(i);
            else return i.lanes = i.childLanes = 536870912, P0(t, i, g !== null ? g.baseLanes | r : r, r)
        } else g !== null ? (Xl(i, g.cachePool), kp(i, g), gi(), i.memoizedState = null) : (t !== null && Xl(i, null), Tc(), gi());
        return ft(t, i, d, r), i.child
    }

    function P0(t, i, r, u) {
        var d = gc();
        return d = d === null ? null : {
            parent: it._currentValue,
            pool: d
        }, i.memoizedState = {
            baseLanes: r,
            cachePool: d
        }, t !== null && Xl(i, null), Tc(), w0(i), t !== null && tr(t, i, u, !0), null
    }

    function oo(t, i) {
        var r = i.ref;
        if (r === null) t !== null && t.ref !== null && (i.flags |= 4194816);
        else {
            if (typeof r != "function" && typeof r != "object") throw Error(s(284));
            (t === null || t.ref !== r) && (i.flags |= 4194816)
        }
    }

    function qc(t, i, r, u, d) {
        return na(i), r = wc(t, i, r, u, void 0, d), u = Mc(), t !== null && !rt ? (Ac(t, i, d), Kn(t, i, d)) : (Ee && u && oc(i), i.flags |= 1, ft(t, i, r, d), i.child)
    }

    function U0(t, i, r, u, d, g) {
        return na(i), i.updateQueue = null, r = Pp(i, u, r, d), Bp(t), u = Mc(), t !== null && !rt ? (Ac(t, i, g), Kn(t, i, g)) : (Ee && u && oc(i), i.flags |= 1, ft(t, i, r, g), i.child)
    }

    function H0(t, i, r, u, d) {
        if (na(i), i.stateNode === null) {
            var g = Ua,
                x = r.contextType;
            typeof x == "object" && x !== null && (g = vt(x)), g = new r(u, g), i.memoizedState = g.state !== null && g.state !== void 0 ? g.state : null, g.updater = Hc, i.stateNode = g, g._reactInternals = i, g = i.stateNode, g.props = u, g.state = i.memoizedState, g.refs = {}, yc(i), x = r.contextType, g.context = typeof x == "object" && x !== null ? vt(x) : Ua, g.state = i.memoizedState, x = r.getDerivedStateFromProps, typeof x == "function" && (Uc(i, r, x, u), g.state = i.memoizedState), typeof r.getDerivedStateFromProps == "function" || typeof g.getSnapshotBeforeUpdate == "function" || typeof g.UNSAFE_componentWillMount != "function" && typeof g.componentWillMount != "function" || (x = g.state, typeof g.componentWillMount == "function" && g.componentWillMount(), typeof g.UNSAFE_componentWillMount == "function" && g.UNSAFE_componentWillMount(), x !== g.state && Hc.enqueueReplaceState(g, g.state, null), or(i, u, g, d), lr(), g.state = i.memoizedState), typeof g.componentDidMount == "function" && (i.flags |= 4194308), u = !0
        } else if (t === null) {
            g = i.stateNode;
            var E = i.memoizedProps,
                R = sa(r, E);
            g.props = R;
            var U = g.context,
                K = r.contextType;
            x = Ua, typeof K == "object" && K !== null && (x = vt(K));
            var $ = r.getDerivedStateFromProps;
            K = typeof $ == "function" || typeof g.getSnapshotBeforeUpdate == "function", E = i.pendingProps !== E, K || typeof g.UNSAFE_componentWillReceiveProps != "function" && typeof g.componentWillReceiveProps != "function" || (E || U !== x) && A0(i, g, u, x), fi = !1;
            var q = i.memoizedState;
            g.state = q, or(i, u, g, d), lr(), U = i.memoizedState, E || q !== U || fi ? (typeof $ == "function" && (Uc(i, r, $, u), U = i.memoizedState), (R = fi || M0(i, r, R, u, q, U, x)) ? (K || typeof g.UNSAFE_componentWillMount != "function" && typeof g.componentWillMount != "function" || (typeof g.componentWillMount == "function" && g.componentWillMount(), typeof g.UNSAFE_componentWillMount == "function" && g.UNSAFE_componentWillMount()), typeof g.componentDidMount == "function" && (i.flags |= 4194308)) : (typeof g.componentDidMount == "function" && (i.flags |= 4194308), i.memoizedProps = u, i.memoizedState = U), g.props = u, g.state = U, g.context = x, u = R) : (typeof g.componentDidMount == "function" && (i.flags |= 4194308), u = !1)
        } else {
            g = i.stateNode, bc(t, i), x = i.memoizedProps, K = sa(r, x), g.props = K, $ = i.pendingProps, q = g.context, U = r.contextType, R = Ua, typeof U == "object" && U !== null && (R = vt(U)), E = r.getDerivedStateFromProps, (U = typeof E == "function" || typeof g.getSnapshotBeforeUpdate == "function") || typeof g.UNSAFE_componentWillReceiveProps != "function" && typeof g.componentWillReceiveProps != "function" || (x !== $ || q !== R) && A0(i, g, u, R), fi = !1, q = i.memoizedState, g.state = q, or(i, u, g, d), lr();
            var Y = i.memoizedState;
            x !== $ || q !== Y || fi || t !== null && t.dependencies !== null && ql(t.dependencies) ? (typeof E == "function" && (Uc(i, r, E, u), Y = i.memoizedState), (K = fi || M0(i, r, K, u, q, Y, R) || t !== null && t.dependencies !== null && ql(t.dependencies)) ? (U || typeof g.UNSAFE_componentWillUpdate != "function" && typeof g.componentWillUpdate != "function" || (typeof g.componentWillUpdate == "function" && g.componentWillUpdate(u, Y, R), typeof g.UNSAFE_componentWillUpdate == "function" && g.UNSAFE_componentWillUpdate(u, Y, R)), typeof g.componentDidUpdate == "function" && (i.flags |= 4), typeof g.getSnapshotBeforeUpdate == "function" && (i.flags |= 1024)) : (typeof g.componentDidUpdate != "function" || x === t.memoizedProps && q === t.memoizedState || (i.flags |= 4), typeof g.getSnapshotBeforeUpdate != "function" || x === t.memoizedProps && q === t.memoizedState || (i.flags |= 1024), i.memoizedProps = u, i.memoizedState = Y), g.props = u, g.state = Y, g.context = R, u = K) : (typeof g.componentDidUpdate != "function" || x === t.memoizedProps && q === t.memoizedState || (i.flags |= 4), typeof g.getSnapshotBeforeUpdate != "function" || x === t.memoizedProps && q === t.memoizedState || (i.flags |= 1024), u = !1)
        }
        return g = u, oo(t, i), u = (i.flags & 128) !== 0, g || u ? (g = i.stateNode, r = u && typeof r.getDerivedStateFromError != "function" ? null : g.render(), i.flags |= 1, t !== null && u ? (i.child = Ia(i, t.child, null, d), i.child = Ia(i, null, r, d)) : ft(t, i, r, d), i.memoizedState = g.state, t = i.child) : t = Kn(t, i, d), t
    }

    function G0(t, i, r, u) {
        return Js(), i.flags |= 256, ft(t, i, r, u), i.child
    }
    var Yc = {
        dehydrated: null,
        treeContext: null,
        retryLane: 0,
        hydrationErrors: null
    };

    function Xc(t) {
        return {
            baseLanes: t,
            cachePool: Op()
        }
    }

    function Fc(t, i, r) {
        return t = t !== null ? t.childLanes & ~r : 0, i && (t |= un), t
    }

    function q0(t, i, r) {
        var u = i.pendingProps,
            d = !1,
            g = (i.flags & 128) !== 0,
            x;
        if ((x = g) || (x = t !== null && t.memoizedState === null ? !1 : (at.current & 2) !== 0), x && (d = !0, i.flags &= -129), x = (i.flags & 32) !== 0, i.flags &= -33, t === null) {
            if (Ee) {
                if (d ? pi(i) : gi(), Ee) {
                    var E = Xe,
                        R;
                    if (R = E) {
                        e: {
                            for (R = E, E = wn; R.nodeType !== 8;) {
                                if (!E) {
                                    E = null;
                                    break e
                                }
                                if (R = Sn(R.nextSibling), R === null) {
                                    E = null;
                                    break e
                                }
                            }
                            E = R
                        }
                        E !== null ? (i.memoizedState = {
                            dehydrated: E,
                            treeContext: $i !== null ? {
                                id: Hn,
                                overflow: Gn
                            } : null,
                            retryLane: 536870912,
                            hydrationErrors: null
                        }, R = Ht(18, null, null, 0), R.stateNode = E, R.return = i, i.child = R, Tt = i, Xe = null, R = !0) : R = !1
                    }
                    R || ea(i)
                }
                if (E = i.memoizedState, E !== null && (E = E.dehydrated, E !== null)) return Df(E) ? i.lanes = 32 : i.lanes = 536870912, null;
                Fn(i)
            }
            return E = u.children, u = u.fallback, d ? (gi(), d = i.mode, E = uo({
                mode: "hidden",
                children: E
            }, d), u = Ii(u, d, r, null), E.return = i, u.return = i, E.sibling = u, i.child = E, d = i.child, d.memoizedState = Xc(r), d.childLanes = Fc(t, x, r), i.memoizedState = Yc, u) : (pi(i), Kc(i, E))
        }
        if (R = t.memoizedState, R !== null && (E = R.dehydrated, E !== null)) {
            if (g) i.flags & 256 ? (pi(i), i.flags &= -257, i = Zc(t, i, r)) : i.memoizedState !== null ? (gi(), i.child = t.child, i.flags |= 128, i = null) : (gi(), d = u.fallback, E = i.mode, u = uo({
                mode: "visible",
                children: u.children
            }, E), d = Ii(d, E, r, null), d.flags |= 2, u.return = i, d.return = i, u.sibling = d, i.child = u, Ia(i, t.child, null, r), u = i.child, u.memoizedState = Xc(r), u.childLanes = Fc(t, x, r), i.memoizedState = Yc, i = d);
            else if (pi(i), Df(E)) {
                if (x = E.nextSibling && E.nextSibling.dataset, x) var U = x.dgst;
                x = U, u = Error(s(419)), u.stack = "", u.digest = x, er({
                    value: u,
                    source: null,
                    stack: null
                }), i = Zc(t, i, r)
            } else if (rt || tr(t, i, r, !1), x = (r & t.childLanes) !== 0, rt || x) {
                if (x = je, x !== null && (u = r & -r, u = (u & 42) !== 0 ? 1 : Du(u), u = (u & (x.suspendedLanes | r)) !== 0 ? 0 : u, u !== 0 && u !== R.retryLane)) throw R.retryLane = u, Pa(t, u), Ft(x, t, u), j0;
                E.data === "$?" || hf(), i = Zc(t, i, r)
            } else E.data === "$?" ? (i.flags |= 192, i.child = t.child, i = null) : (t = R.treeContext, Xe = Sn(E.nextSibling), Tt = i, Ee = !0, Ji = null, wn = !1, t !== null && (rn[ln++] = Hn, rn[ln++] = Gn, rn[ln++] = $i, Hn = t.id, Gn = t.overflow, $i = i), i = Kc(i, u.children), i.flags |= 4096);
            return i
        }
        return d ? (gi(), d = u.fallback, E = i.mode, R = t.child, U = R.sibling, u = Un(R, {
            mode: "hidden",
            children: u.children
        }), u.subtreeFlags = R.subtreeFlags & 65011712, U !== null ? d = Un(U, d) : (d = Ii(d, E, r, null), d.flags |= 2), d.return = i, u.return = i, u.sibling = d, i.child = u, u = d, d = i.child, E = t.child.memoizedState, E === null ? E = Xc(r) : (R = E.cachePool, R !== null ? (U = it._currentValue, R = R.parent !== U ? {
            parent: U,
            pool: U
        } : R) : R = Op(), E = {
            baseLanes: E.baseLanes | r,
            cachePool: R
        }), d.memoizedState = E, d.childLanes = Fc(t, x, r), i.memoizedState = Yc, u) : (pi(i), r = t.child, t = r.sibling, r = Un(r, {
            mode: "visible",
            children: u.children
        }), r.return = i, r.sibling = null, t !== null && (x = i.deletions, x === null ? (i.deletions = [t], i.flags |= 16) : x.push(t)), i.child = r, i.memoizedState = null, r)
    }

    function Kc(t, i) {
        return i = uo({
            mode: "visible",
            children: i
        }, t.mode), i.return = t, t.child = i
    }

    function uo(t, i) {
        return t = Ht(22, t, null, i), t.lanes = 0, t.stateNode = {
            _visibility: 1,
            _pendingMarkers: null,
            _retryCache: null,
            _transitions: null
        }, t
    }

    function Zc(t, i, r) {
        return Ia(i, t.child, null, r), t = Kc(i, i.pendingProps.children), t.flags |= 2, i.memoizedState = null, t
    }

    function Y0(t, i, r) {
        t.lanes |= i;
        var u = t.alternate;
        u !== null && (u.lanes |= i), dc(t.return, i, r)
    }

    function Qc(t, i, r, u, d) {
        var g = t.memoizedState;
        g === null ? t.memoizedState = {
            isBackwards: i,
            rendering: null,
            renderingStartTime: 0,
            last: u,
            tail: r,
            tailMode: d
        } : (g.isBackwards = i, g.rendering = null, g.renderingStartTime = 0, g.last = u, g.tail = r, g.tailMode = d)
    }

    function X0(t, i, r) {
        var u = i.pendingProps,
            d = u.revealOrder,
            g = u.tail;
        if (ft(t, i, u.children, r), u = at.current, (u & 2) !== 0) u = u & 1 | 2, i.flags |= 128;
        else {
            if (t !== null && (t.flags & 128) !== 0) e: for (t = i.child; t !== null;) {
                if (t.tag === 13) t.memoizedState !== null && Y0(t, r, i);
                else if (t.tag === 19) Y0(t, r, i);
                else if (t.child !== null) {
                    t.child.return = t, t = t.child;
                    continue
                }
                if (t === i) break e;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === i) break e;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
            u &= 1
        }
        switch (ie(at, u), d) {
            case "forwards":
                for (r = i.child, d = null; r !== null;) t = r.alternate, t !== null && so(t) === null && (d = r), r = r.sibling;
                r = d, r === null ? (d = i.child, i.child = null) : (d = r.sibling, r.sibling = null), Qc(i, !1, d, r, g);
                break;
            case "backwards":
                for (r = null, d = i.child, i.child = null; d !== null;) {
                    if (t = d.alternate, t !== null && so(t) === null) {
                        i.child = d;
                        break
                    }
                    t = d.sibling, d.sibling = r, r = d, d = t
                }
                Qc(i, !0, r, null, g);
                break;
            case "together":
                Qc(i, !1, null, null, void 0);
                break;
            default:
                i.memoizedState = null
        }
        return i.child
    }

    function Kn(t, i, r) {
        if (t !== null && (i.dependencies = t.dependencies), Si |= i.lanes, (r & i.childLanes) === 0)
            if (t !== null) {
                if (tr(t, i, r, !1), (r & i.childLanes) === 0) return null
            } else return null;
        if (t !== null && i.child !== t.child) throw Error(s(153));
        if (i.child !== null) {
            for (t = i.child, r = Un(t, t.pendingProps), i.child = r, r.return = i; t.sibling !== null;) t = t.sibling, r = r.sibling = Un(t, t.pendingProps), r.return = i;
            r.sibling = null
        }
        return i.child
    }

    function Ic(t, i) {
        return (t.lanes & i) !== 0 ? !0 : (t = t.dependencies, !!(t !== null && ql(t)))
    }

    function IS(t, i, r) {
        switch (i.tag) {
            case 3:
                Ne(i, i.stateNode.containerInfo), ci(i, it, t.memoizedState.cache), Js();
                break;
            case 27:
            case 5:
                wu(i);
                break;
            case 4:
                Ne(i, i.stateNode.containerInfo);
                break;
            case 10:
                ci(i, i.type, i.memoizedProps.value);
                break;
            case 13:
                var u = i.memoizedState;
                if (u !== null) return u.dehydrated !== null ? (pi(i), i.flags |= 128, null) : (r & i.child.childLanes) !== 0 ? q0(t, i, r) : (pi(i), t = Kn(t, i, r), t !== null ? t.sibling : null);
                pi(i);
                break;
            case 19:
                var d = (t.flags & 128) !== 0;
                if (u = (r & i.childLanes) !== 0, u || (tr(t, i, r, !1), u = (r & i.childLanes) !== 0), d) {
                    if (u) return X0(t, i, r);
                    i.flags |= 128
                }
                if (d = i.memoizedState, d !== null && (d.rendering = null, d.tail = null, d.lastEffect = null), ie(at, at.current), u) break;
                return null;
            case 22:
            case 23:
                return i.lanes = 0, B0(t, i, r);
            case 24:
                ci(i, it, t.memoizedState.cache)
        }
        return Kn(t, i, r)
    }

    function F0(t, i, r) {
        if (t !== null)
            if (t.memoizedProps !== i.pendingProps) rt = !0;
            else {
                if (!Ic(t, r) && (i.flags & 128) === 0) return rt = !1, IS(t, i, r);
                rt = (t.flags & 131072) !== 0
            }
        else rt = !1, Ee && (i.flags & 1048576) !== 0 && Tp(i, Gl, i.index);
        switch (i.lanes = 0, i.tag) {
            case 16:
                e: {
                    t = i.pendingProps;
                    var u = i.elementType,
                        d = u._init;
                    if (u = d(u._payload), i.type = u, typeof u == "function") sc(u) ? (t = sa(u, t), i.tag = 1, i = H0(null, i, u, t, r)) : (i.tag = 0, i = qc(null, i, u, t, r));
                    else {
                        if (u != null) {
                            if (d = u.$$typeof, d === L) {
                                i.tag = 11, i = N0(null, i, u, t, r);
                                break e
                            } else if (d === k) {
                                i.tag = 14, i = V0(null, i, u, t, r);
                                break e
                            }
                        }
                        throw i = ae(u) || u, Error(s(306, i, ""))
                    }
                }
                return i;
            case 0:
                return qc(t, i, i.type, i.pendingProps, r);
            case 1:
                return u = i.type, d = sa(u, i.pendingProps), H0(t, i, u, d, r);
            case 3:
                e: {
                    if (Ne(i, i.stateNode.containerInfo), t === null) throw Error(s(387));u = i.pendingProps;
                    var g = i.memoizedState;d = g.element,
                    bc(t, i),
                    or(i, u, null, r);
                    var x = i.memoizedState;
                    if (u = x.cache, ci(i, it, u), u !== g.cache && hc(i, [it], r, !0), lr(), u = x.element, g.isDehydrated)
                        if (g = {
                                element: u,
                                isDehydrated: !1,
                                cache: x.cache
                            }, i.updateQueue.baseState = g, i.memoizedState = g, i.flags & 256) {
                            i = G0(t, i, u, r);
                            break e
                        } else if (u !== d) {
                        d = an(Error(s(424)), i), er(d), i = G0(t, i, u, r);
                        break e
                    } else {
                        switch (t = i.stateNode.containerInfo, t.nodeType) {
                            case 9:
                                t = t.body;
                                break;
                            default:
                                t = t.nodeName === "HTML" ? t.ownerDocument.body : t
                        }
                        for (Xe = Sn(t.firstChild), Tt = i, Ee = !0, Ji = null, wn = !0, r = E0(i, null, u, r), i.child = r; r;) r.flags = r.flags & -3 | 4096, r = r.sibling
                    } else {
                        if (Js(), u === d) {
                            i = Kn(t, i, r);
                            break e
                        }
                        ft(t, i, u, r)
                    }
                    i = i.child
                }
                return i;
            case 26:
                return oo(t, i), t === null ? (r = Ig(i.type, null, i.pendingProps, null)) ? i.memoizedState = r : Ee || (r = i.type, t = i.pendingProps, u = Eo(he.current).createElement(r), u[gt] = i, u[Mt] = t, ht(u, r, t), st(u), i.stateNode = u) : i.memoizedState = Ig(i.type, t.memoizedProps, i.pendingProps, t.memoizedState), null;
            case 27:
                return wu(i), t === null && Ee && (u = i.stateNode = Kg(i.type, i.pendingProps, he.current), Tt = i, wn = !0, d = Xe, wi(i.type) ? (zf = d, Xe = Sn(u.firstChild)) : Xe = d), ft(t, i, i.pendingProps.children, r), oo(t, i), t === null && (i.flags |= 4194304), i.child;
            case 5:
                return t === null && Ee && ((d = u = Xe) && (u = ET(u, i.type, i.pendingProps, wn), u !== null ? (i.stateNode = u, Tt = i, Xe = Sn(u.firstChild), wn = !1, d = !0) : d = !1), d || ea(i)), wu(i), d = i.type, g = i.pendingProps, x = t !== null ? t.memoizedProps : null, u = g.children, Af(d, g) ? u = null : x !== null && Af(d, x) && (i.flags |= 32), i.memoizedState !== null && (d = wc(t, i, GS, null, null, r), Dr._currentValue = d), oo(t, i), ft(t, i, u, r), i.child;
            case 6:
                return t === null && Ee && ((t = r = Xe) && (r = wT(r, i.pendingProps, wn), r !== null ? (i.stateNode = r, Tt = i, Xe = null, t = !0) : t = !1), t || ea(i)), null;
            case 13:
                return q0(t, i, r);
            case 4:
                return Ne(i, i.stateNode.containerInfo), u = i.pendingProps, t === null ? i.child = Ia(i, null, u, r) : ft(t, i, u, r), i.child;
            case 11:
                return N0(t, i, i.type, i.pendingProps, r);
            case 7:
                return ft(t, i, i.pendingProps, r), i.child;
            case 8:
                return ft(t, i, i.pendingProps.children, r), i.child;
            case 12:
                return ft(t, i, i.pendingProps.children, r), i.child;
            case 10:
                return u = i.pendingProps, ci(i, i.type, u.value), ft(t, i, u.children, r), i.child;
            case 9:
                return d = i.type._context, u = i.pendingProps.children, na(i), d = vt(d), u = u(d), i.flags |= 1, ft(t, i, u, r), i.child;
            case 14:
                return V0(t, i, i.type, i.pendingProps, r);
            case 15:
                return k0(t, i, i.type, i.pendingProps, r);
            case 19:
                return X0(t, i, r);
            case 31:
                return u = i.pendingProps, r = i.mode, u = {
                    mode: u.mode,
                    children: u.children
                }, t === null ? (r = uo(u, r), r.ref = i.ref, i.child = r, r.return = i, i = r) : (r = Un(t.child, u), r.ref = i.ref, i.child = r, r.return = i, i = r), i;
            case 22:
                return B0(t, i, r);
            case 24:
                return na(i), u = vt(it), t === null ? (d = gc(), d === null && (d = je, g = mc(), d.pooledCache = g, g.refCount++, g !== null && (d.pooledCacheLanes |= r), d = g), i.memoizedState = {
                    parent: u,
                    cache: d
                }, yc(i), ci(i, it, d)) : ((t.lanes & r) !== 0 && (bc(t, i), or(i, null, null, r), lr()), d = t.memoizedState, g = i.memoizedState, d.parent !== u ? (d = {
                    parent: u,
                    cache: u
                }, i.memoizedState = d, i.lanes === 0 && (i.memoizedState = i.updateQueue.baseState = d), ci(i, it, u)) : (u = g.cache, ci(i, it, u), u !== d.cache && hc(i, [it], r, !0))), ft(t, i, i.pendingProps.children, r), i.child;
            case 29:
                throw i.pendingProps
        }
        throw Error(s(156, i.tag))
    }

    function Zn(t) {
        t.flags |= 4
    }

    function K0(t, i) {
        if (i.type !== "stylesheet" || (i.state.loading & 4) !== 0) t.flags &= -16777217;
        else if (t.flags |= 16777216, !t1(i)) {
            if (i = on.current, i !== null && ((Te & 4194048) === Te ? Mn !== null : (Te & 62914560) !== Te && (Te & 536870912) === 0 || i !== Mn)) throw sr = vc, Dp;
            t.flags |= 8192
        }
    }

    function co(t, i) {
        i !== null && (t.flags |= 4), t.flags & 16384 && (i = t.tag !== 22 ? wm() : 536870912, t.lanes |= i, es |= i)
    }

    function pr(t, i) {
        if (!Ee) switch (t.tailMode) {
            case "hidden":
                i = t.tail;
                for (var r = null; i !== null;) i.alternate !== null && (r = i), i = i.sibling;
                r === null ? t.tail = null : r.sibling = null;
                break;
            case "collapsed":
                r = t.tail;
                for (var u = null; r !== null;) r.alternate !== null && (u = r), r = r.sibling;
                u === null ? i || t.tail === null ? t.tail = null : t.tail.sibling = null : u.sibling = null
        }
    }

    function Ue(t) {
        var i = t.alternate !== null && t.alternate.child === t.child,
            r = 0,
            u = 0;
        if (i)
            for (var d = t.child; d !== null;) r |= d.lanes | d.childLanes, u |= d.subtreeFlags & 65011712, u |= d.flags & 65011712, d.return = t, d = d.sibling;
        else
            for (d = t.child; d !== null;) r |= d.lanes | d.childLanes, u |= d.subtreeFlags, u |= d.flags, d.return = t, d = d.sibling;
        return t.subtreeFlags |= u, t.childLanes = r, i
    }

    function $S(t, i, r) {
        var u = i.pendingProps;
        switch (uc(i), i.tag) {
            case 31:
            case 16:
            case 15:
            case 0:
            case 11:
            case 7:
            case 8:
            case 12:
            case 9:
            case 14:
                return Ue(i), null;
            case 1:
                return Ue(i), null;
            case 3:
                return r = i.stateNode, u = null, t !== null && (u = t.memoizedState.cache), i.memoizedState.cache !== u && (i.flags |= 2048), Yn(it), ri(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (t === null || t.child === null) && (Ws(i) ? Zn(i) : t === null || t.memoizedState.isDehydrated && (i.flags & 256) === 0 || (i.flags |= 1024, wp())), Ue(i), null;
            case 26:
                return r = i.memoizedState, t === null ? (Zn(i), r !== null ? (Ue(i), K0(i, r)) : (Ue(i), i.flags &= -16777217)) : r ? r !== t.memoizedState ? (Zn(i), Ue(i), K0(i, r)) : (Ue(i), i.flags &= -16777217) : (t.memoizedProps !== u && Zn(i), Ue(i), i.flags &= -16777217), null;
            case 27:
                Sl(i), r = he.current;
                var d = i.type;
                if (t !== null && i.stateNode != null) t.memoizedProps !== u && Zn(i);
                else {
                    if (!u) {
                        if (i.stateNode === null) throw Error(s(166));
                        return Ue(i), null
                    }
                    t = le.current, Ws(i) ? _p(i) : (t = Kg(d, u, r), i.stateNode = t, Zn(i))
                }
                return Ue(i), null;
            case 5:
                if (Sl(i), r = i.type, t !== null && i.stateNode != null) t.memoizedProps !== u && Zn(i);
                else {
                    if (!u) {
                        if (i.stateNode === null) throw Error(s(166));
                        return Ue(i), null
                    }
                    if (t = le.current, Ws(i)) _p(i);
                    else {
                        switch (d = Eo(he.current), t) {
                            case 1:
                                t = d.createElementNS("http://www.w3.org/2000/svg", r);
                                break;
                            case 2:
                                t = d.createElementNS("http://www.w3.org/1998/Math/MathML", r);
                                break;
                            default:
                                switch (r) {
                                    case "svg":
                                        t = d.createElementNS("http://www.w3.org/2000/svg", r);
                                        break;
                                    case "math":
                                        t = d.createElementNS("http://www.w3.org/1998/Math/MathML", r);
                                        break;
                                    case "script":
                                        t = d.createElement("div"), t.innerHTML = "<script><\/script>", t = t.removeChild(t.firstChild);
                                        break;
                                    case "select":
                                        t = typeof u.is == "string" ? d.createElement("select", {
                                            is: u.is
                                        }) : d.createElement("select"), u.multiple ? t.multiple = !0 : u.size && (t.size = u.size);
                                        break;
                                    default:
                                        t = typeof u.is == "string" ? d.createElement(r, {
                                            is: u.is
                                        }) : d.createElement(r)
                                }
                        }
                        t[gt] = i, t[Mt] = u;
                        e: for (d = i.child; d !== null;) {
                            if (d.tag === 5 || d.tag === 6) t.appendChild(d.stateNode);
                            else if (d.tag !== 4 && d.tag !== 27 && d.child !== null) {
                                d.child.return = d, d = d.child;
                                continue
                            }
                            if (d === i) break e;
                            for (; d.sibling === null;) {
                                if (d.return === null || d.return === i) break e;
                                d = d.return
                            }
                            d.sibling.return = d.return, d = d.sibling
                        }
                        i.stateNode = t;
                        e: switch (ht(t, r, u), r) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                t = !!u.autoFocus;
                                break e;
                            case "img":
                                t = !0;
                                break e;
                            default:
                                t = !1
                        }
                        t && Zn(i)
                    }
                }
                return Ue(i), i.flags &= -16777217, null;
            case 6:
                if (t && i.stateNode != null) t.memoizedProps !== u && Zn(i);
                else {
                    if (typeof u != "string" && i.stateNode === null) throw Error(s(166));
                    if (t = he.current, Ws(i)) {
                        if (t = i.stateNode, r = i.memoizedProps, u = null, d = Tt, d !== null) switch (d.tag) {
                            case 27:
                            case 5:
                                u = d.memoizedProps
                        }
                        t[gt] = i, t = !!(t.nodeValue === r || u !== null && u.suppressHydrationWarning === !0 || Ug(t.nodeValue, r)), t || ea(i)
                    } else t = Eo(t).createTextNode(u), t[gt] = i, i.stateNode = t
                }
                return Ue(i), null;
            case 13:
                if (u = i.memoizedState, t === null || t.memoizedState !== null && t.memoizedState.dehydrated !== null) {
                    if (d = Ws(i), u !== null && u.dehydrated !== null) {
                        if (t === null) {
                            if (!d) throw Error(s(318));
                            if (d = i.memoizedState, d = d !== null ? d.dehydrated : null, !d) throw Error(s(317));
                            d[gt] = i
                        } else Js(), (i.flags & 128) === 0 && (i.memoizedState = null), i.flags |= 4;
                        Ue(i), d = !1
                    } else d = wp(), t !== null && t.memoizedState !== null && (t.memoizedState.hydrationErrors = d), d = !0;
                    if (!d) return i.flags & 256 ? (Fn(i), i) : (Fn(i), null)
                }
                if (Fn(i), (i.flags & 128) !== 0) return i.lanes = r, i;
                if (r = u !== null, t = t !== null && t.memoizedState !== null, r) {
                    u = i.child, d = null, u.alternate !== null && u.alternate.memoizedState !== null && u.alternate.memoizedState.cachePool !== null && (d = u.alternate.memoizedState.cachePool.pool);
                    var g = null;
                    u.memoizedState !== null && u.memoizedState.cachePool !== null && (g = u.memoizedState.cachePool.pool), g !== d && (u.flags |= 2048)
                }
                return r !== t && r && (i.child.flags |= 8192), co(i, i.updateQueue), Ue(i), null;
            case 4:
                return ri(), t === null && Tf(i.stateNode.containerInfo), Ue(i), null;
            case 10:
                return Yn(i.type), Ue(i), null;
            case 19:
                if (ne(at), d = i.memoizedState, d === null) return Ue(i), null;
                if (u = (i.flags & 128) !== 0, g = d.rendering, g === null)
                    if (u) pr(d, !1);
                    else {
                        if (Fe !== 0 || t !== null && (t.flags & 128) !== 0)
                            for (t = i.child; t !== null;) {
                                if (g = so(t), g !== null) {
                                    for (i.flags |= 128, pr(d, !1), t = g.updateQueue, i.updateQueue = t, co(i, t), i.subtreeFlags = 0, t = r, r = i.child; r !== null;) Sp(r, t), r = r.sibling;
                                    return ie(at, at.current & 1 | 2), i.child
                                }
                                t = t.sibling
                            }
                        d.tail !== null && En() > mo && (i.flags |= 128, u = !0, pr(d, !1), i.lanes = 4194304)
                    }
                else {
                    if (!u)
                        if (t = so(g), t !== null) {
                            if (i.flags |= 128, u = !0, t = t.updateQueue, i.updateQueue = t, co(i, t), pr(d, !0), d.tail === null && d.tailMode === "hidden" && !g.alternate && !Ee) return Ue(i), null
                        } else 2 * En() - d.renderingStartTime > mo && r !== 536870912 && (i.flags |= 128, u = !0, pr(d, !1), i.lanes = 4194304);
                    d.isBackwards ? (g.sibling = i.child, i.child = g) : (t = d.last, t !== null ? t.sibling = g : i.child = g, d.last = g)
                }
                return d.tail !== null ? (i = d.tail, d.rendering = i, d.tail = i.sibling, d.renderingStartTime = En(), i.sibling = null, t = at.current, ie(at, u ? t & 1 | 2 : t & 1), i) : (Ue(i), null);
            case 22:
            case 23:
                return Fn(i), _c(), u = i.memoizedState !== null, t !== null ? t.memoizedState !== null !== u && (i.flags |= 8192) : u && (i.flags |= 8192), u ? (r & 536870912) !== 0 && (i.flags & 128) === 0 && (Ue(i), i.subtreeFlags & 6 && (i.flags |= 8192)) : Ue(i), r = i.updateQueue, r !== null && co(i, r.retryQueue), r = null, t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (r = t.memoizedState.cachePool.pool), u = null, i.memoizedState !== null && i.memoizedState.cachePool !== null && (u = i.memoizedState.cachePool.pool), u !== r && (i.flags |= 2048), t !== null && ne(ia), null;
            case 24:
                return r = null, t !== null && (r = t.memoizedState.cache), i.memoizedState.cache !== r && (i.flags |= 2048), Yn(it), Ue(i), null;
            case 25:
                return null;
            case 30:
                return null
        }
        throw Error(s(156, i.tag))
    }

    function WS(t, i) {
        switch (uc(i), i.tag) {
            case 1:
                return t = i.flags, t & 65536 ? (i.flags = t & -65537 | 128, i) : null;
            case 3:
                return Yn(it), ri(), t = i.flags, (t & 65536) !== 0 && (t & 128) === 0 ? (i.flags = t & -65537 | 128, i) : null;
            case 26:
            case 27:
            case 5:
                return Sl(i), null;
            case 13:
                if (Fn(i), t = i.memoizedState, t !== null && t.dehydrated !== null) {
                    if (i.alternate === null) throw Error(s(340));
                    Js()
                }
                return t = i.flags, t & 65536 ? (i.flags = t & -65537 | 128, i) : null;
            case 19:
                return ne(at), null;
            case 4:
                return ri(), null;
            case 10:
                return Yn(i.type), null;
            case 22:
            case 23:
                return Fn(i), _c(), t !== null && ne(ia), t = i.flags, t & 65536 ? (i.flags = t & -65537 | 128, i) : null;
            case 24:
                return Yn(it), null;
            case 25:
                return null;
            default:
                return null
        }
    }

    function Z0(t, i) {
        switch (uc(i), i.tag) {
            case 3:
                Yn(it), ri();
                break;
            case 26:
            case 27:
            case 5:
                Sl(i);
                break;
            case 4:
                ri();
                break;
            case 13:
                Fn(i);
                break;
            case 19:
                ne(at);
                break;
            case 10:
                Yn(i.type);
                break;
            case 22:
            case 23:
                Fn(i), _c(), t !== null && ne(ia);
                break;
            case 24:
                Yn(it)
        }
    }

    function gr(t, i) {
        try {
            var r = i.updateQueue,
                u = r !== null ? r.lastEffect : null;
            if (u !== null) {
                var d = u.next;
                r = d;
                do {
                    if ((r.tag & t) === t) {
                        u = void 0;
                        var g = r.create,
                            x = r.inst;
                        u = g(), x.destroy = u
                    }
                    r = r.next
                } while (r !== d)
            }
        } catch (E) {
            ze(i, i.return, E)
        }
    }

    function vi(t, i, r) {
        try {
            var u = i.updateQueue,
                d = u !== null ? u.lastEffect : null;
            if (d !== null) {
                var g = d.next;
                u = g;
                do {
                    if ((u.tag & t) === t) {
                        var x = u.inst,
                            E = x.destroy;
                        if (E !== void 0) {
                            x.destroy = void 0, d = i;
                            var R = r,
                                U = E;
                            try {
                                U()
                            } catch (K) {
                                ze(d, R, K)
                            }
                        }
                    }
                    u = u.next
                } while (u !== g)
            }
        } catch (K) {
            ze(i, i.return, K)
        }
    }

    function Q0(t) {
        var i = t.updateQueue;
        if (i !== null) {
            var r = t.stateNode;
            try {
                Vp(i, r)
            } catch (u) {
                ze(t, t.return, u)
            }
        }
    }

    function I0(t, i, r) {
        r.props = sa(t.type, t.memoizedProps), r.state = t.memoizedState;
        try {
            r.componentWillUnmount()
        } catch (u) {
            ze(t, i, u)
        }
    }

    function vr(t, i) {
        try {
            var r = t.ref;
            if (r !== null) {
                switch (t.tag) {
                    case 26:
                    case 27:
                    case 5:
                        var u = t.stateNode;
                        break;
                    case 30:
                        u = t.stateNode;
                        break;
                    default:
                        u = t.stateNode
                }
                typeof r == "function" ? t.refCleanup = r(u) : r.current = u
            }
        } catch (d) {
            ze(t, i, d)
        }
    }

    function An(t, i) {
        var r = t.ref,
            u = t.refCleanup;
        if (r !== null)
            if (typeof u == "function") try {
                u()
            } catch (d) {
                ze(t, i, d)
            } finally {
                t.refCleanup = null, t = t.alternate, t != null && (t.refCleanup = null)
            } else if (typeof r == "function") try {
                r(null)
            } catch (d) {
                ze(t, i, d)
            } else r.current = null
    }

    function $0(t) {
        var i = t.type,
            r = t.memoizedProps,
            u = t.stateNode;
        try {
            e: switch (i) {
                case "button":
                case "input":
                case "select":
                case "textarea":
                    r.autoFocus && u.focus();
                    break e;
                case "img":
                    r.src ? u.src = r.src : r.srcSet && (u.srcset = r.srcSet)
            }
        }
        catch (d) {
            ze(t, t.return, d)
        }
    }

    function $c(t, i, r) {
        try {
            var u = t.stateNode;
            bT(u, t.type, r, i), u[Mt] = i
        } catch (d) {
            ze(t, t.return, d)
        }
    }

    function W0(t) {
        return t.tag === 5 || t.tag === 3 || t.tag === 26 || t.tag === 27 && wi(t.type) || t.tag === 4
    }

    function Wc(t) {
        e: for (;;) {
            for (; t.sibling === null;) {
                if (t.return === null || W0(t.return)) return null;
                t = t.return
            }
            for (t.sibling.return = t.return, t = t.sibling; t.tag !== 5 && t.tag !== 6 && t.tag !== 18;) {
                if (t.tag === 27 && wi(t.type) || t.flags & 2 || t.child === null || t.tag === 4) continue e;
                t.child.return = t, t = t.child
            }
            if (!(t.flags & 2)) return t.stateNode
        }
    }

    function Jc(t, i, r) {
        var u = t.tag;
        if (u === 5 || u === 6) t = t.stateNode, i ? (r.nodeType === 9 ? r.body : r.nodeName === "HTML" ? r.ownerDocument.body : r).insertBefore(t, i) : (i = r.nodeType === 9 ? r.body : r.nodeName === "HTML" ? r.ownerDocument.body : r, i.appendChild(t), r = r._reactRootContainer, r != null || i.onclick !== null || (i.onclick = _o));
        else if (u !== 4 && (u === 27 && wi(t.type) && (r = t.stateNode, i = null), t = t.child, t !== null))
            for (Jc(t, i, r), t = t.sibling; t !== null;) Jc(t, i, r), t = t.sibling
    }

    function fo(t, i, r) {
        var u = t.tag;
        if (u === 5 || u === 6) t = t.stateNode, i ? r.insertBefore(t, i) : r.appendChild(t);
        else if (u !== 4 && (u === 27 && wi(t.type) && (r = t.stateNode), t = t.child, t !== null))
            for (fo(t, i, r), t = t.sibling; t !== null;) fo(t, i, r), t = t.sibling
    }

    function J0(t) {
        var i = t.stateNode,
            r = t.memoizedProps;
        try {
            for (var u = t.type, d = i.attributes; d.length;) i.removeAttributeNode(d[0]);
            ht(i, u, r), i[gt] = t, i[Mt] = r
        } catch (g) {
            ze(t, t.return, g)
        }
    }
    var Qn = !1,
        Ie = !1,
        ef = !1,
        eg = typeof WeakSet == "function" ? WeakSet : Set,
        lt = null;

    function JS(t, i) {
        if (t = t.containerInfo, wf = Do, t = fp(t), Wu(t)) {
            if ("selectionStart" in t) var r = {
                start: t.selectionStart,
                end: t.selectionEnd
            };
            else e: {
                r = (r = t.ownerDocument) && r.defaultView || window;
                var u = r.getSelection && r.getSelection();
                if (u && u.rangeCount !== 0) {
                    r = u.anchorNode;
                    var d = u.anchorOffset,
                        g = u.focusNode;
                    u = u.focusOffset;
                    try {
                        r.nodeType, g.nodeType
                    } catch {
                        r = null;
                        break e
                    }
                    var x = 0,
                        E = -1,
                        R = -1,
                        U = 0,
                        K = 0,
                        $ = t,
                        q = null;
                    t: for (;;) {
                        for (var Y; $ !== r || d !== 0 && $.nodeType !== 3 || (E = x + d), $ !== g || u !== 0 && $.nodeType !== 3 || (R = x + u), $.nodeType === 3 && (x += $.nodeValue.length), (Y = $.firstChild) !== null;) q = $, $ = Y;
                        for (;;) {
                            if ($ === t) break t;
                            if (q === r && ++U === d && (E = x), q === g && ++K === u && (R = x), (Y = $.nextSibling) !== null) break;
                            $ = q, q = $.parentNode
                        }
                        $ = Y
                    }
                    r = E === -1 || R === -1 ? null : {
                        start: E,
                        end: R
                    }
                } else r = null
            }
            r = r || {
                start: 0,
                end: 0
            }
        } else r = null;
        for (Mf = {
                focusedElem: t,
                selectionRange: r
            }, Do = !1, lt = i; lt !== null;)
            if (i = lt, t = i.child, (i.subtreeFlags & 1024) !== 0 && t !== null) t.return = i, lt = t;
            else
                for (; lt !== null;) {
                    switch (i = lt, g = i.alternate, t = i.flags, i.tag) {
                        case 0:
                            break;
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if ((t & 1024) !== 0 && g !== null) {
                                t = void 0, r = i, d = g.memoizedProps, g = g.memoizedState, u = r.stateNode;
                                try {
                                    var fe = sa(r.type, d, r.elementType === r.type);
                                    t = u.getSnapshotBeforeUpdate(fe, g), u.__reactInternalSnapshotBeforeUpdate = t
                                } catch (ue) {
                                    ze(r, r.return, ue)
                                }
                            }
                            break;
                        case 3:
                            if ((t & 1024) !== 0) {
                                if (t = i.stateNode.containerInfo, r = t.nodeType, r === 9) Of(t);
                                else if (r === 1) switch (t.nodeName) {
                                    case "HEAD":
                                    case "HTML":
                                    case "BODY":
                                        Of(t);
                                        break;
                                    default:
                                        t.textContent = ""
                                }
                            }
                            break;
                        case 5:
                        case 26:
                        case 27:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            if ((t & 1024) !== 0) throw Error(s(163))
                    }
                    if (t = i.sibling, t !== null) {
                        t.return = i.return, lt = t;
                        break
                    }
                    lt = i.return
                }
    }

    function tg(t, i, r) {
        var u = r.flags;
        switch (r.tag) {
            case 0:
            case 11:
            case 15:
                yi(t, r), u & 4 && gr(5, r);
                break;
            case 1:
                if (yi(t, r), u & 4)
                    if (t = r.stateNode, i === null) try {
                        t.componentDidMount()
                    } catch (x) {
                        ze(r, r.return, x)
                    } else {
                        var d = sa(r.type, i.memoizedProps);
                        i = i.memoizedState;
                        try {
                            t.componentDidUpdate(d, i, t.__reactInternalSnapshotBeforeUpdate)
                        } catch (x) {
                            ze(r, r.return, x)
                        }
                    }
                u & 64 && Q0(r), u & 512 && vr(r, r.return);
                break;
            case 3:
                if (yi(t, r), u & 64 && (t = r.updateQueue, t !== null)) {
                    if (i = null, r.child !== null) switch (r.child.tag) {
                        case 27:
                        case 5:
                            i = r.child.stateNode;
                            break;
                        case 1:
                            i = r.child.stateNode
                    }
                    try {
                        Vp(t, i)
                    } catch (x) {
                        ze(r, r.return, x)
                    }
                }
                break;
            case 27:
                i === null && u & 4 && J0(r);
            case 26:
            case 5:
                yi(t, r), i === null && u & 4 && $0(r), u & 512 && vr(r, r.return);
                break;
            case 12:
                yi(t, r);
                break;
            case 13:
                yi(t, r), u & 4 && ag(t, r), u & 64 && (t = r.memoizedState, t !== null && (t = t.dehydrated, t !== null && (r = oT.bind(null, r), MT(t, r))));
                break;
            case 22:
                if (u = r.memoizedState !== null || Qn, !u) {
                    i = i !== null && i.memoizedState !== null || Ie, d = Qn;
                    var g = Ie;
                    Qn = u, (Ie = i) && !g ? bi(t, r, (r.subtreeFlags & 8772) !== 0) : yi(t, r), Qn = d, Ie = g
                }
                break;
            case 30:
                break;
            default:
                yi(t, r)
        }
    }

    function ng(t) {
        var i = t.alternate;
        i !== null && (t.alternate = null, ng(i)), t.child = null, t.deletions = null, t.sibling = null, t.tag === 5 && (i = t.stateNode, i !== null && Lu(i)), t.stateNode = null, t.return = null, t.dependencies = null, t.memoizedProps = null, t.memoizedState = null, t.pendingProps = null, t.stateNode = null, t.updateQueue = null
    }
    var Ve = null,
        Ot = !1;

    function In(t, i, r) {
        for (r = r.child; r !== null;) ig(t, i, r), r = r.sibling
    }

    function ig(t, i, r) {
        if (Bt && typeof Bt.onCommitFiberUnmount == "function") try {
            Bt.onCommitFiberUnmount(Bs, r)
        } catch {}
        switch (r.tag) {
            case 26:
                Ie || An(r, i), In(t, i, r), r.memoizedState ? r.memoizedState.count-- : r.stateNode && (r = r.stateNode, r.parentNode.removeChild(r));
                break;
            case 27:
                Ie || An(r, i);
                var u = Ve,
                    d = Ot;
                wi(r.type) && (Ve = r.stateNode, Ot = !1), In(t, i, r), Mr(r.stateNode), Ve = u, Ot = d;
                break;
            case 5:
                Ie || An(r, i);
            case 6:
                if (u = Ve, d = Ot, Ve = null, In(t, i, r), Ve = u, Ot = d, Ve !== null)
                    if (Ot) try {
                        (Ve.nodeType === 9 ? Ve.body : Ve.nodeName === "HTML" ? Ve.ownerDocument.body : Ve).removeChild(r.stateNode)
                    } catch (g) {
                        ze(r, i, g)
                    } else try {
                        Ve.removeChild(r.stateNode)
                    } catch (g) {
                        ze(r, i, g)
                    }
                break;
            case 18:
                Ve !== null && (Ot ? (t = Ve, Xg(t.nodeType === 9 ? t.body : t.nodeName === "HTML" ? t.ownerDocument.body : t, r.stateNode), jr(t)) : Xg(Ve, r.stateNode));
                break;
            case 4:
                u = Ve, d = Ot, Ve = r.stateNode.containerInfo, Ot = !0, In(t, i, r), Ve = u, Ot = d;
                break;
            case 0:
            case 11:
            case 14:
            case 15:
                Ie || vi(2, r, i), Ie || vi(4, r, i), In(t, i, r);
                break;
            case 1:
                Ie || (An(r, i), u = r.stateNode, typeof u.componentWillUnmount == "function" && I0(r, i, u)), In(t, i, r);
                break;
            case 21:
                In(t, i, r);
                break;
            case 22:
                Ie = (u = Ie) || r.memoizedState !== null, In(t, i, r), Ie = u;
                break;
            default:
                In(t, i, r)
        }
    }

    function ag(t, i) {
        if (i.memoizedState === null && (t = i.alternate, t !== null && (t = t.memoizedState, t !== null && (t = t.dehydrated, t !== null)))) try {
            jr(t)
        } catch (r) {
            ze(i, i.return, r)
        }
    }

    function eT(t) {
        switch (t.tag) {
            case 13:
            case 19:
                var i = t.stateNode;
                return i === null && (i = t.stateNode = new eg), i;
            case 22:
                return t = t.stateNode, i = t._retryCache, i === null && (i = t._retryCache = new eg), i;
            default:
                throw Error(s(435, t.tag))
        }
    }

    function tf(t, i) {
        var r = eT(t);
        i.forEach(function(u) {
            var d = uT.bind(null, t, u);
            r.has(u) || (r.add(u), u.then(d, d))
        })
    }

    function Gt(t, i) {
        var r = i.deletions;
        if (r !== null)
            for (var u = 0; u < r.length; u++) {
                var d = r[u],
                    g = t,
                    x = i,
                    E = x;
                e: for (; E !== null;) {
                    switch (E.tag) {
                        case 27:
                            if (wi(E.type)) {
                                Ve = E.stateNode, Ot = !1;
                                break e
                            }
                            break;
                        case 5:
                            Ve = E.stateNode, Ot = !1;
                            break e;
                        case 3:
                        case 4:
                            Ve = E.stateNode.containerInfo, Ot = !0;
                            break e
                    }
                    E = E.return
                }
                if (Ve === null) throw Error(s(160));
                ig(g, x, d), Ve = null, Ot = !1, g = d.alternate, g !== null && (g.return = null), d.return = null
            }
        if (i.subtreeFlags & 13878)
            for (i = i.child; i !== null;) sg(i, t), i = i.sibling
    }
    var xn = null;

    function sg(t, i) {
        var r = t.alternate,
            u = t.flags;
        switch (t.tag) {
            case 0:
            case 11:
            case 14:
            case 15:
                Gt(i, t), qt(t), u & 4 && (vi(3, t, t.return), gr(3, t), vi(5, t, t.return));
                break;
            case 1:
                Gt(i, t), qt(t), u & 512 && (Ie || r === null || An(r, r.return)), u & 64 && Qn && (t = t.updateQueue, t !== null && (u = t.callbacks, u !== null && (r = t.shared.hiddenCallbacks, t.shared.hiddenCallbacks = r === null ? u : r.concat(u))));
                break;
            case 26:
                var d = xn;
                if (Gt(i, t), qt(t), u & 512 && (Ie || r === null || An(r, r.return)), u & 4) {
                    var g = r !== null ? r.memoizedState : null;
                    if (u = t.memoizedState, r === null)
                        if (u === null)
                            if (t.stateNode === null) {
                                e: {
                                    u = t.type,
                                    r = t.memoizedProps,
                                    d = d.ownerDocument || d;t: switch (u) {
                                        case "title":
                                            g = d.getElementsByTagName("title")[0], (!g || g[Hs] || g[gt] || g.namespaceURI === "http://www.w3.org/2000/svg" || g.hasAttribute("itemprop")) && (g = d.createElement(u), d.head.insertBefore(g, d.querySelector("head > title"))), ht(g, u, r), g[gt] = t, st(g), u = g;
                                            break e;
                                        case "link":
                                            var x = Jg("link", "href", d).get(u + (r.href || ""));
                                            if (x) {
                                                for (var E = 0; E < x.length; E++)
                                                    if (g = x[E], g.getAttribute("href") === (r.href == null || r.href === "" ? null : r.href) && g.getAttribute("rel") === (r.rel == null ? null : r.rel) && g.getAttribute("title") === (r.title == null ? null : r.title) && g.getAttribute("crossorigin") === (r.crossOrigin == null ? null : r.crossOrigin)) {
                                                        x.splice(E, 1);
                                                        break t
                                                    }
                                            }
                                            g = d.createElement(u), ht(g, u, r), d.head.appendChild(g);
                                            break;
                                        case "meta":
                                            if (x = Jg("meta", "content", d).get(u + (r.content || ""))) {
                                                for (E = 0; E < x.length; E++)
                                                    if (g = x[E], g.getAttribute("content") === (r.content == null ? null : "" + r.content) && g.getAttribute("name") === (r.name == null ? null : r.name) && g.getAttribute("property") === (r.property == null ? null : r.property) && g.getAttribute("http-equiv") === (r.httpEquiv == null ? null : r.httpEquiv) && g.getAttribute("charset") === (r.charSet == null ? null : r.charSet)) {
                                                        x.splice(E, 1);
                                                        break t
                                                    }
                                            }
                                            g = d.createElement(u), ht(g, u, r), d.head.appendChild(g);
                                            break;
                                        default:
                                            throw Error(s(468, u))
                                    }
                                    g[gt] = t,
                                    st(g),
                                    u = g
                                }
                                t.stateNode = u
                            }
                    else e1(d, t.type, t.stateNode);
                    else t.stateNode = Wg(d, u, t.memoizedProps);
                    else g !== u ? (g === null ? r.stateNode !== null && (r = r.stateNode, r.parentNode.removeChild(r)) : g.count--, u === null ? e1(d, t.type, t.stateNode) : Wg(d, u, t.memoizedProps)) : u === null && t.stateNode !== null && $c(t, t.memoizedProps, r.memoizedProps)
                }
                break;
            case 27:
                Gt(i, t), qt(t), u & 512 && (Ie || r === null || An(r, r.return)), r !== null && u & 4 && $c(t, t.memoizedProps, r.memoizedProps);
                break;
            case 5:
                if (Gt(i, t), qt(t), u & 512 && (Ie || r === null || An(r, r.return)), t.flags & 32) {
                    d = t.stateNode;
                    try {
                        Ra(d, "")
                    } catch (Y) {
                        ze(t, t.return, Y)
                    }
                }
                u & 4 && t.stateNode != null && (d = t.memoizedProps, $c(t, d, r !== null ? r.memoizedProps : d)), u & 1024 && (ef = !0);
                break;
            case 6:
                if (Gt(i, t), qt(t), u & 4) {
                    if (t.stateNode === null) throw Error(s(162));
                    u = t.memoizedProps, r = t.stateNode;
                    try {
                        r.nodeValue = u
                    } catch (Y) {
                        ze(t, t.return, Y)
                    }
                }
                break;
            case 3:
                if (Ao = null, d = xn, xn = wo(i.containerInfo), Gt(i, t), xn = d, qt(t), u & 4 && r !== null && r.memoizedState.isDehydrated) try {
                    jr(i.containerInfo)
                } catch (Y) {
                    ze(t, t.return, Y)
                }
                ef && (ef = !1, rg(t));
                break;
            case 4:
                u = xn, xn = wo(t.stateNode.containerInfo), Gt(i, t), qt(t), xn = u;
                break;
            case 12:
                Gt(i, t), qt(t);
                break;
            case 13:
                Gt(i, t), qt(t), t.child.flags & 8192 && t.memoizedState !== null != (r !== null && r.memoizedState !== null) && ( of = En()), u & 4 && (u = t.updateQueue, u !== null && (t.updateQueue = null, tf(t, u)));
                break;
            case 22:
                d = t.memoizedState !== null;
                var R = r !== null && r.memoizedState !== null,
                    U = Qn,
                    K = Ie;
                if (Qn = U || d, Ie = K || R, Gt(i, t), Ie = K, Qn = U, qt(t), u & 8192) e: for (i = t.stateNode, i._visibility = d ? i._visibility & -2 : i._visibility | 1, d && (r === null || R || Qn || Ie || ra(t)), r = null, i = t;;) {
                    if (i.tag === 5 || i.tag === 26) {
                        if (r === null) {
                            R = r = i;
                            try {
                                if (g = R.stateNode, d) x = g.style, typeof x.setProperty == "function" ? x.setProperty("display", "none", "important") : x.display = "none";
                                else {
                                    E = R.stateNode;
                                    var $ = R.memoizedProps.style,
                                        q = $ != null && $.hasOwnProperty("display") ? $.display : null;
                                    E.style.display = q == null || typeof q == "boolean" ? "" : ("" + q).trim()
                                }
                            } catch (Y) {
                                ze(R, R.return, Y)
                            }
                        }
                    } else if (i.tag === 6) {
                        if (r === null) {
                            R = i;
                            try {
                                R.stateNode.nodeValue = d ? "" : R.memoizedProps
                            } catch (Y) {
                                ze(R, R.return, Y)
                            }
                        }
                    } else if ((i.tag !== 22 && i.tag !== 23 || i.memoizedState === null || i === t) && i.child !== null) {
                        i.child.return = i, i = i.child;
                        continue
                    }
                    if (i === t) break e;
                    for (; i.sibling === null;) {
                        if (i.return === null || i.return === t) break e;
                        r === i && (r = null), i = i.return
                    }
                    r === i && (r = null), i.sibling.return = i.return, i = i.sibling
                }
                u & 4 && (u = t.updateQueue, u !== null && (r = u.retryQueue, r !== null && (u.retryQueue = null, tf(t, r))));
                break;
            case 19:
                Gt(i, t), qt(t), u & 4 && (u = t.updateQueue, u !== null && (t.updateQueue = null, tf(t, u)));
                break;
            case 30:
                break;
            case 21:
                break;
            default:
                Gt(i, t), qt(t)
        }
    }

    function qt(t) {
        var i = t.flags;
        if (i & 2) {
            try {
                for (var r, u = t.return; u !== null;) {
                    if (W0(u)) {
                        r = u;
                        break
                    }
                    u = u.return
                }
                if (r == null) throw Error(s(160));
                switch (r.tag) {
                    case 27:
                        var d = r.stateNode,
                            g = Wc(t);
                        fo(t, g, d);
                        break;
                    case 5:
                        var x = r.stateNode;
                        r.flags & 32 && (Ra(x, ""), r.flags &= -33);
                        var E = Wc(t);
                        fo(t, E, x);
                        break;
                    case 3:
                    case 4:
                        var R = r.stateNode.containerInfo,
                            U = Wc(t);
                        Jc(t, U, R);
                        break;
                    default:
                        throw Error(s(161))
                }
            } catch (K) {
                ze(t, t.return, K)
            }
            t.flags &= -3
        }
        i & 4096 && (t.flags &= -4097)
    }

    function rg(t) {
        if (t.subtreeFlags & 1024)
            for (t = t.child; t !== null;) {
                var i = t;
                rg(i), i.tag === 5 && i.flags & 1024 && i.stateNode.reset(), t = t.sibling
            }
    }

    function yi(t, i) {
        if (i.subtreeFlags & 8772)
            for (i = i.child; i !== null;) tg(t, i.alternate, i), i = i.sibling
    }

    function ra(t) {
        for (t = t.child; t !== null;) {
            var i = t;
            switch (i.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    vi(4, i, i.return), ra(i);
                    break;
                case 1:
                    An(i, i.return);
                    var r = i.stateNode;
                    typeof r.componentWillUnmount == "function" && I0(i, i.return, r), ra(i);
                    break;
                case 27:
                    Mr(i.stateNode);
                case 26:
                case 5:
                    An(i, i.return), ra(i);
                    break;
                case 22:
                    i.memoizedState === null && ra(i);
                    break;
                case 30:
                    ra(i);
                    break;
                default:
                    ra(i)
            }
            t = t.sibling
        }
    }

    function bi(t, i, r) {
        for (r = r && (i.subtreeFlags & 8772) !== 0, i = i.child; i !== null;) {
            var u = i.alternate,
                d = t,
                g = i,
                x = g.flags;
            switch (g.tag) {
                case 0:
                case 11:
                case 15:
                    bi(d, g, r), gr(4, g);
                    break;
                case 1:
                    if (bi(d, g, r), u = g, d = u.stateNode, typeof d.componentDidMount == "function") try {
                        d.componentDidMount()
                    } catch (U) {
                        ze(u, u.return, U)
                    }
                    if (u = g, d = u.updateQueue, d !== null) {
                        var E = u.stateNode;
                        try {
                            var R = d.shared.hiddenCallbacks;
                            if (R !== null)
                                for (d.shared.hiddenCallbacks = null, d = 0; d < R.length; d++) Np(R[d], E)
                        } catch (U) {
                            ze(u, u.return, U)
                        }
                    }
                    r && x & 64 && Q0(g), vr(g, g.return);
                    break;
                case 27:
                    J0(g);
                case 26:
                case 5:
                    bi(d, g, r), r && u === null && x & 4 && $0(g), vr(g, g.return);
                    break;
                case 12:
                    bi(d, g, r);
                    break;
                case 13:
                    bi(d, g, r), r && x & 4 && ag(d, g);
                    break;
                case 22:
                    g.memoizedState === null && bi(d, g, r), vr(g, g.return);
                    break;
                case 30:
                    break;
                default:
                    bi(d, g, r)
            }
            i = i.sibling
        }
    }

    function nf(t, i) {
        var r = null;
        t !== null && t.memoizedState !== null && t.memoizedState.cachePool !== null && (r = t.memoizedState.cachePool.pool), t = null, i.memoizedState !== null && i.memoizedState.cachePool !== null && (t = i.memoizedState.cachePool.pool), t !== r && (t != null && t.refCount++, r != null && nr(r))
    }

    function af(t, i) {
        t = null, i.alternate !== null && (t = i.alternate.memoizedState.cache), i = i.memoizedState.cache, i !== t && (i.refCount++, t != null && nr(t))
    }

    function Cn(t, i, r, u) {
        if (i.subtreeFlags & 10256)
            for (i = i.child; i !== null;) lg(t, i, r, u), i = i.sibling
    }

    function lg(t, i, r, u) {
        var d = i.flags;
        switch (i.tag) {
            case 0:
            case 11:
            case 15:
                Cn(t, i, r, u), d & 2048 && gr(9, i);
                break;
            case 1:
                Cn(t, i, r, u);
                break;
            case 3:
                Cn(t, i, r, u), d & 2048 && (t = null, i.alternate !== null && (t = i.alternate.memoizedState.cache), i = i.memoizedState.cache, i !== t && (i.refCount++, t != null && nr(t)));
                break;
            case 12:
                if (d & 2048) {
                    Cn(t, i, r, u), t = i.stateNode;
                    try {
                        var g = i.memoizedProps,
                            x = g.id,
                            E = g.onPostCommit;
                        typeof E == "function" && E(x, i.alternate === null ? "mount" : "update", t.passiveEffectDuration, -0)
                    } catch (R) {
                        ze(i, i.return, R)
                    }
                } else Cn(t, i, r, u);
                break;
            case 13:
                Cn(t, i, r, u);
                break;
            case 23:
                break;
            case 22:
                g = i.stateNode, x = i.alternate, i.memoizedState !== null ? g._visibility & 2 ? Cn(t, i, r, u) : yr(t, i) : g._visibility & 2 ? Cn(t, i, r, u) : (g._visibility |= 2, $a(t, i, r, u, (i.subtreeFlags & 10256) !== 0)), d & 2048 && nf(x, i);
                break;
            case 24:
                Cn(t, i, r, u), d & 2048 && af(i.alternate, i);
                break;
            default:
                Cn(t, i, r, u)
        }
    }

    function $a(t, i, r, u, d) {
        for (d = d && (i.subtreeFlags & 10256) !== 0, i = i.child; i !== null;) {
            var g = t,
                x = i,
                E = r,
                R = u,
                U = x.flags;
            switch (x.tag) {
                case 0:
                case 11:
                case 15:
                    $a(g, x, E, R, d), gr(8, x);
                    break;
                case 23:
                    break;
                case 22:
                    var K = x.stateNode;
                    x.memoizedState !== null ? K._visibility & 2 ? $a(g, x, E, R, d) : yr(g, x) : (K._visibility |= 2, $a(g, x, E, R, d)), d && U & 2048 && nf(x.alternate, x);
                    break;
                case 24:
                    $a(g, x, E, R, d), d && U & 2048 && af(x.alternate, x);
                    break;
                default:
                    $a(g, x, E, R, d)
            }
            i = i.sibling
        }
    }

    function yr(t, i) {
        if (i.subtreeFlags & 10256)
            for (i = i.child; i !== null;) {
                var r = t,
                    u = i,
                    d = u.flags;
                switch (u.tag) {
                    case 22:
                        yr(r, u), d & 2048 && nf(u.alternate, u);
                        break;
                    case 24:
                        yr(r, u), d & 2048 && af(u.alternate, u);
                        break;
                    default:
                        yr(r, u)
                }
                i = i.sibling
            }
    }
    var br = 8192;

    function Wa(t) {
        if (t.subtreeFlags & br)
            for (t = t.child; t !== null;) og(t), t = t.sibling
    }

    function og(t) {
        switch (t.tag) {
            case 26:
                Wa(t), t.flags & br && t.memoizedState !== null && PT(xn, t.memoizedState, t.memoizedProps);
                break;
            case 5:
                Wa(t);
                break;
            case 3:
            case 4:
                var i = xn;
                xn = wo(t.stateNode.containerInfo), Wa(t), xn = i;
                break;
            case 22:
                t.memoizedState === null && (i = t.alternate, i !== null && i.memoizedState !== null ? (i = br, br = 16777216, Wa(t), br = i) : Wa(t));
                break;
            default:
                Wa(t)
        }
    }

    function ug(t) {
        var i = t.alternate;
        if (i !== null && (t = i.child, t !== null)) {
            i.child = null;
            do i = t.sibling, t.sibling = null, t = i; while (t !== null)
        }
    }

    function xr(t) {
        var i = t.deletions;
        if ((t.flags & 16) !== 0) {
            if (i !== null)
                for (var r = 0; r < i.length; r++) {
                    var u = i[r];
                    lt = u, fg(u, t)
                }
            ug(t)
        }
        if (t.subtreeFlags & 10256)
            for (t = t.child; t !== null;) cg(t), t = t.sibling
    }

    function cg(t) {
        switch (t.tag) {
            case 0:
            case 11:
            case 15:
                xr(t), t.flags & 2048 && vi(9, t, t.return);
                break;
            case 3:
                xr(t);
                break;
            case 12:
                xr(t);
                break;
            case 22:
                var i = t.stateNode;
                t.memoizedState !== null && i._visibility & 2 && (t.return === null || t.return.tag !== 13) ? (i._visibility &= -3, ho(t)) : xr(t);
                break;
            default:
                xr(t)
        }
    }

    function ho(t) {
        var i = t.deletions;
        if ((t.flags & 16) !== 0) {
            if (i !== null)
                for (var r = 0; r < i.length; r++) {
                    var u = i[r];
                    lt = u, fg(u, t)
                }
            ug(t)
        }
        for (t = t.child; t !== null;) {
            switch (i = t, i.tag) {
                case 0:
                case 11:
                case 15:
                    vi(8, i, i.return), ho(i);
                    break;
                case 22:
                    r = i.stateNode, r._visibility & 2 && (r._visibility &= -3, ho(i));
                    break;
                default:
                    ho(i)
            }
            t = t.sibling
        }
    }

    function fg(t, i) {
        for (; lt !== null;) {
            var r = lt;
            switch (r.tag) {
                case 0:
                case 11:
                case 15:
                    vi(8, r, i);
                    break;
                case 23:
                case 22:
                    if (r.memoizedState !== null && r.memoizedState.cachePool !== null) {
                        var u = r.memoizedState.cachePool.pool;
                        u != null && u.refCount++
                    }
                    break;
                case 24:
                    nr(r.memoizedState.cache)
            }
            if (u = r.child, u !== null) u.return = r, lt = u;
            else e: for (r = t; lt !== null;) {
                u = lt;
                var d = u.sibling,
                    g = u.return;
                if (ng(u), u === r) {
                    lt = null;
                    break e
                }
                if (d !== null) {
                    d.return = g, lt = d;
                    break e
                }
                lt = g
            }
        }
    }
    var tT = {
            getCacheForType: function(t) {
                var i = vt(it),
                    r = i.data.get(t);
                return r === void 0 && (r = t(), i.data.set(t, r)), r
            }
        },
        nT = typeof WeakMap == "function" ? WeakMap : Map,
        Me = 0,
        je = null,
        ye = null,
        Te = 0,
        Ae = 0,
        Yt = null,
        xi = !1,
        Ja = !1,
        sf = !1,
        $n = 0,
        Fe = 0,
        Si = 0,
        la = 0,
        rf = 0,
        un = 0,
        es = 0,
        Sr = null,
        Dt = null,
        lf = !1,
        of = 0,
        mo = 1 / 0,
        po = null,
        Ti = null,
        dt = 0,
        _i = null,
        ts = null,
        ns = 0,
        uf = 0,
        cf = null,
        dg = null,
        Tr = 0,
        ff = null;

    function Xt() {
        if ((Me & 2) !== 0 && Te !== 0) return Te & -Te;
        if (P.T !== null) {
            var t = qa;
            return t !== 0 ? t : yf()
        }
        return Cm()
    }

    function hg() {
        un === 0 && (un = (Te & 536870912) === 0 || Ee ? Em() : 536870912);
        var t = on.current;
        return t !== null && (t.flags |= 32), un
    }

    function Ft(t, i, r) {
        (t === je && (Ae === 2 || Ae === 9) || t.cancelPendingCommit !== null) && (is(t, 0), Ei(t, Te, un, !1)), Us(t, r), ((Me & 2) === 0 || t !== je) && (t === je && ((Me & 2) === 0 && (la |= r), Fe === 4 && Ei(t, Te, un, !1)), On(t))
    }

    function mg(t, i, r) {
        if ((Me & 6) !== 0) throw Error(s(327));
        var u = !r && (i & 124) === 0 && (i & t.expiredLanes) === 0 || Ps(t, i),
            d = u ? sT(t, i) : mf(t, i, !0),
            g = u;
        do {
            if (d === 0) {
                Ja && !u && Ei(t, i, 0, !1);
                break
            } else {
                if (r = t.current.alternate, g && !iT(r)) {
                    d = mf(t, i, !1), g = !1;
                    continue
                }
                if (d === 2) {
                    if (g = i, t.errorRecoveryDisabledLanes & g) var x = 0;
                    else x = t.pendingLanes & -536870913, x = x !== 0 ? x : x & 536870912 ? 536870912 : 0;
                    if (x !== 0) {
                        i = x;
                        e: {
                            var E = t;d = Sr;
                            var R = E.current.memoizedState.isDehydrated;
                            if (R && (is(E, x).flags |= 256), x = mf(E, x, !1), x !== 2) {
                                if (sf && !R) {
                                    E.errorRecoveryDisabledLanes |= g, la |= g, d = 4;
                                    break e
                                }
                                g = Dt, Dt = d, g !== null && (Dt === null ? Dt = g : Dt.push.apply(Dt, g))
                            }
                            d = x
                        }
                        if (g = !1, d !== 2) continue
                    }
                }
                if (d === 1) {
                    is(t, 0), Ei(t, i, 0, !0);
                    break
                }
                e: {
                    switch (u = t, g = d, g) {
                        case 0:
                        case 1:
                            throw Error(s(345));
                        case 4:
                            if ((i & 4194048) !== i) break;
                        case 6:
                            Ei(u, i, un, !xi);
                            break e;
                        case 2:
                            Dt = null;
                            break;
                        case 3:
                        case 5:
                            break;
                        default:
                            throw Error(s(329))
                    }
                    if ((i & 62914560) === i && (d = of +300 - En(), 10 < d)) {
                        if (Ei(u, i, un, !xi), wl(u, 0, !0) !== 0) break e;
                        u.timeoutHandle = qg(pg.bind(null, u, r, Dt, po, lf, i, un, la, es, xi, g, 2, -0, 0), d);
                        break e
                    }
                    pg(u, r, Dt, po, lf, i, un, la, es, xi, g, 0, -0, 0)
                }
            }
            break
        } while (!0);
        On(t)
    }

    function pg(t, i, r, u, d, g, x, E, R, U, K, $, q, Y) {
        if (t.timeoutHandle = -1, $ = i.subtreeFlags, ($ & 8192 || ($ & 16785408) === 16785408) && (Or = {
                stylesheets: null,
                count: 0,
                unsuspend: BT
            }, og(i), $ = UT(), $ !== null)) {
            t.cancelPendingCommit = $(Tg.bind(null, t, i, g, r, u, d, x, E, R, K, 1, q, Y)), Ei(t, g, x, !U);
            return
        }
        Tg(t, i, g, r, u, d, x, E, R)
    }

    function iT(t) {
        for (var i = t;;) {
            var r = i.tag;
            if ((r === 0 || r === 11 || r === 15) && i.flags & 16384 && (r = i.updateQueue, r !== null && (r = r.stores, r !== null)))
                for (var u = 0; u < r.length; u++) {
                    var d = r[u],
                        g = d.getSnapshot;
                    d = d.value;
                    try {
                        if (!Ut(g(), d)) return !1
                    } catch {
                        return !1
                    }
                }
            if (r = i.child, i.subtreeFlags & 16384 && r !== null) r.return = i, i = r;
            else {
                if (i === t) break;
                for (; i.sibling === null;) {
                    if (i.return === null || i.return === t) return !0;
                    i = i.return
                }
                i.sibling.return = i.return, i = i.sibling
            }
        }
        return !0
    }

    function Ei(t, i, r, u) {
        i &= ~rf, i &= ~la, t.suspendedLanes |= i, t.pingedLanes &= ~i, u && (t.warmLanes |= i), u = t.expirationTimes;
        for (var d = i; 0 < d;) {
            var g = 31 - Pt(d),
                x = 1 << g;
            u[g] = -1, d &= ~x
        }
        r !== 0 && Mm(t, r, i)
    }

    function go() {
        return (Me & 6) === 0 ? (_r(0), !1) : !0
    }

    function df() {
        if (ye !== null) {
            if (Ae === 0) var t = ye.return;
            else t = ye, qn = ta = null, Cc(t), Qa = null, hr = 0, t = ye;
            for (; t !== null;) Z0(t.alternate, t), t = t.return;
            ye = null
        }
    }

    function is(t, i) {
        var r = t.timeoutHandle;
        r !== -1 && (t.timeoutHandle = -1, ST(r)), r = t.cancelPendingCommit, r !== null && (t.cancelPendingCommit = null, r()), df(), je = t, ye = r = Un(t.current, null), Te = i, Ae = 0, Yt = null, xi = !1, Ja = Ps(t, i), sf = !1, es = un = rf = la = Si = Fe = 0, Dt = Sr = null, lf = !1, (i & 8) !== 0 && (i |= i & 32);
        var u = t.entangledLanes;
        if (u !== 0)
            for (t = t.entanglements, u &= i; 0 < u;) {
                var d = 31 - Pt(u),
                    g = 1 << d;
                i |= t[d], u &= ~g
            }
        return $n = i, kl(), r
    }

    function gg(t, i) {
        ge = null, P.H = no, i === ar || i === Fl ? (i = Lp(), Ae = 3) : i === Dp ? (i = Lp(), Ae = 4) : Ae = i === j0 ? 8 : i !== null && typeof i == "object" && typeof i.then == "function" ? 6 : 1, Yt = i, ye === null && (Fe = 1, lo(t, an(i, t.current)))
    }

    function vg() {
        var t = P.H;
        return P.H = no, t === null ? no : t
    }

    function yg() {
        var t = P.A;
        return P.A = tT, t
    }

    function hf() {
        Fe = 4, xi || (Te & 4194048) !== Te && on.current !== null || (Ja = !0), (Si & 134217727) === 0 && (la & 134217727) === 0 || je === null || Ei(je, Te, un, !1)
    }

    function mf(t, i, r) {
        var u = Me;
        Me |= 2;
        var d = vg(),
            g = yg();
        (je !== t || Te !== i) && (po = null, is(t, i)), i = !1;
        var x = Fe;
        e: do try {
                if (Ae !== 0 && ye !== null) {
                    var E = ye,
                        R = Yt;
                    switch (Ae) {
                        case 8:
                            df(), x = 6;
                            break e;
                        case 3:
                        case 2:
                        case 9:
                        case 6:
                            on.current === null && (i = !0);
                            var U = Ae;
                            if (Ae = 0, Yt = null, as(t, E, R, U), r && Ja) {
                                x = 0;
                                break e
                            }
                            break;
                        default:
                            U = Ae, Ae = 0, Yt = null, as(t, E, R, U)
                    }
                }
                aT(), x = Fe;
                break
            } catch (K) {
                gg(t, K)
            }
            while (!0);
            return i && t.shellSuspendCounter++, qn = ta = null, Me = u, P.H = d, P.A = g, ye === null && (je = null, Te = 0, kl()), x
    }

    function aT() {
        for (; ye !== null;) bg(ye)
    }

    function sT(t, i) {
        var r = Me;
        Me |= 2;
        var u = vg(),
            d = yg();
        je !== t || Te !== i ? (po = null, mo = En() + 500, is(t, i)) : Ja = Ps(t, i);
        e: do try {
                if (Ae !== 0 && ye !== null) {
                    i = ye;
                    var g = Yt;
                    t: switch (Ae) {
                        case 1:
                            Ae = 0, Yt = null, as(t, i, g, 1);
                            break;
                        case 2:
                        case 9:
                            if (zp(g)) {
                                Ae = 0, Yt = null, xg(i);
                                break
                            }
                            i = function() {
                                Ae !== 2 && Ae !== 9 || je !== t || (Ae = 7), On(t)
                            }, g.then(i, i);
                            break e;
                        case 3:
                            Ae = 7;
                            break e;
                        case 4:
                            Ae = 5;
                            break e;
                        case 7:
                            zp(g) ? (Ae = 0, Yt = null, xg(i)) : (Ae = 0, Yt = null, as(t, i, g, 7));
                            break;
                        case 5:
                            var x = null;
                            switch (ye.tag) {
                                case 26:
                                    x = ye.memoizedState;
                                case 5:
                                case 27:
                                    var E = ye;
                                    if (!x || t1(x)) {
                                        Ae = 0, Yt = null;
                                        var R = E.sibling;
                                        if (R !== null) ye = R;
                                        else {
                                            var U = E.return;
                                            U !== null ? (ye = U, vo(U)) : ye = null
                                        }
                                        break t
                                    }
                            }
                            Ae = 0, Yt = null, as(t, i, g, 5);
                            break;
                        case 6:
                            Ae = 0, Yt = null, as(t, i, g, 6);
                            break;
                        case 8:
                            df(), Fe = 6;
                            break e;
                        default:
                            throw Error(s(462))
                    }
                }
                rT();
                break
            } catch (K) {
                gg(t, K)
            }
            while (!0);
            return qn = ta = null, P.H = u, P.A = d, Me = r, ye !== null ? 0 : (je = null, Te = 0, kl(), Fe)
    }

    function rT() {
        for (; ye !== null && !Cx();) bg(ye)
    }

    function bg(t) {
        var i = F0(t.alternate, t, $n);
        t.memoizedProps = t.pendingProps, i === null ? vo(t) : ye = i
    }

    function xg(t) {
        var i = t,
            r = i.alternate;
        switch (i.tag) {
            case 15:
            case 0:
                i = U0(r, i, i.pendingProps, i.type, void 0, Te);
                break;
            case 11:
                i = U0(r, i, i.pendingProps, i.type.render, i.ref, Te);
                break;
            case 5:
                Cc(i);
            default:
                Z0(r, i), i = ye = Sp(i, $n), i = F0(r, i, $n)
        }
        t.memoizedProps = t.pendingProps, i === null ? vo(t) : ye = i
    }

    function as(t, i, r, u) {
        qn = ta = null, Cc(i), Qa = null, hr = 0;
        var d = i.return;
        try {
            if (QS(t, d, i, r, Te)) {
                Fe = 1, lo(t, an(r, t.current)), ye = null;
                return
            }
        } catch (g) {
            if (d !== null) throw ye = d, g;
            Fe = 1, lo(t, an(r, t.current)), ye = null;
            return
        }
        i.flags & 32768 ? (Ee || u === 1 ? t = !0 : Ja || (Te & 536870912) !== 0 ? t = !1 : (xi = t = !0, (u === 2 || u === 9 || u === 3 || u === 6) && (u = on.current, u !== null && u.tag === 13 && (u.flags |= 16384))), Sg(i, t)) : vo(i)
    }

    function vo(t) {
        var i = t;
        do {
            if ((i.flags & 32768) !== 0) {
                Sg(i, xi);
                return
            }
            t = i.return;
            var r = $S(i.alternate, i, $n);
            if (r !== null) {
                ye = r;
                return
            }
            if (i = i.sibling, i !== null) {
                ye = i;
                return
            }
            ye = i = t
        } while (i !== null);
        Fe === 0 && (Fe = 5)
    }

    function Sg(t, i) {
        do {
            var r = WS(t.alternate, t);
            if (r !== null) {
                r.flags &= 32767, ye = r;
                return
            }
            if (r = t.return, r !== null && (r.flags |= 32768, r.subtreeFlags = 0, r.deletions = null), !i && (t = t.sibling, t !== null)) {
                ye = t;
                return
            }
            ye = t = r
        } while (t !== null);
        Fe = 6, ye = null
    }

    function Tg(t, i, r, u, d, g, x, E, R) {
        t.cancelPendingCommit = null;
        do yo(); while (dt !== 0);
        if ((Me & 6) !== 0) throw Error(s(327));
        if (i !== null) {
            if (i === t.current) throw Error(s(177));
            if (g = i.lanes | i.childLanes, g |= ic, Bx(t, r, g, x, E, R), t === je && (ye = je = null, Te = 0), ts = i, _i = t, ns = r, uf = g, cf = d, dg = u, (i.subtreeFlags & 10256) !== 0 || (i.flags & 10256) !== 0 ? (t.callbackNode = null, t.callbackPriority = 0, cT(Tl, function() {
                    return Ag(), null
                })) : (t.callbackNode = null, t.callbackPriority = 0), u = (i.flags & 13878) !== 0, (i.subtreeFlags & 13878) !== 0 || u) {
                u = P.T, P.T = null, d = G.p, G.p = 2, x = Me, Me |= 4;
                try {
                    JS(t, i, r)
                } finally {
                    Me = x, G.p = d, P.T = u
                }
            }
            dt = 1, _g(), Eg(), wg()
        }
    }

    function _g() {
        if (dt === 1) {
            dt = 0;
            var t = _i,
                i = ts,
                r = (i.flags & 13878) !== 0;
            if ((i.subtreeFlags & 13878) !== 0 || r) {
                r = P.T, P.T = null;
                var u = G.p;
                G.p = 2;
                var d = Me;
                Me |= 4;
                try {
                    sg(i, t);
                    var g = Mf,
                        x = fp(t.containerInfo),
                        E = g.focusedElem,
                        R = g.selectionRange;
                    if (x !== E && E && E.ownerDocument && cp(E.ownerDocument.documentElement, E)) {
                        if (R !== null && Wu(E)) {
                            var U = R.start,
                                K = R.end;
                            if (K === void 0 && (K = U), "selectionStart" in E) E.selectionStart = U, E.selectionEnd = Math.min(K, E.value.length);
                            else {
                                var $ = E.ownerDocument || document,
                                    q = $ && $.defaultView || window;
                                if (q.getSelection) {
                                    var Y = q.getSelection(),
                                        fe = E.textContent.length,
                                        ue = Math.min(R.start, fe),
                                        De = R.end === void 0 ? ue : Math.min(R.end, fe);
                                    !Y.extend && ue > De && (x = De, De = ue, ue = x);
                                    var N = up(E, ue),
                                        j = up(E, De);
                                    if (N && j && (Y.rangeCount !== 1 || Y.anchorNode !== N.node || Y.anchorOffset !== N.offset || Y.focusNode !== j.node || Y.focusOffset !== j.offset)) {
                                        var B = $.createRange();
                                        B.setStart(N.node, N.offset), Y.removeAllRanges(), ue > De ? (Y.addRange(B), Y.extend(j.node, j.offset)) : (B.setEnd(j.node, j.offset), Y.addRange(B))
                                    }
                                }
                            }
                        }
                        for ($ = [], Y = E; Y = Y.parentNode;) Y.nodeType === 1 && $.push({
                            element: Y,
                            left: Y.scrollLeft,
                            top: Y.scrollTop
                        });
                        for (typeof E.focus == "function" && E.focus(), E = 0; E < $.length; E++) {
                            var Q = $[E];
                            Q.element.scrollLeft = Q.left, Q.element.scrollTop = Q.top
                        }
                    }
                    Do = !!wf, Mf = wf = null
                } finally {
                    Me = d, G.p = u, P.T = r
                }
            }
            t.current = i, dt = 2
        }
    }

    function Eg() {
        if (dt === 2) {
            dt = 0;
            var t = _i,
                i = ts,
                r = (i.flags & 8772) !== 0;
            if ((i.subtreeFlags & 8772) !== 0 || r) {
                r = P.T, P.T = null;
                var u = G.p;
                G.p = 2;
                var d = Me;
                Me |= 4;
                try {
                    tg(t, i.alternate, i)
                } finally {
                    Me = d, G.p = u, P.T = r
                }
            }
            dt = 3
        }
    }

    function wg() {
        if (dt === 4 || dt === 3) {
            dt = 0, Ox();
            var t = _i,
                i = ts,
                r = ns,
                u = dg;
            (i.subtreeFlags & 10256) !== 0 || (i.flags & 10256) !== 0 ? dt = 5 : (dt = 0, ts = _i = null, Mg(t, t.pendingLanes));
            var d = t.pendingLanes;
            if (d === 0 && (Ti = null), zu(r), i = i.stateNode, Bt && typeof Bt.onCommitFiberRoot == "function") try {
                Bt.onCommitFiberRoot(Bs, i, void 0, (i.current.flags & 128) === 128)
            } catch {}
            if (u !== null) {
                i = P.T, d = G.p, G.p = 2, P.T = null;
                try {
                    for (var g = t.onRecoverableError, x = 0; x < u.length; x++) {
                        var E = u[x];
                        g(E.value, {
                            componentStack: E.stack
                        })
                    }
                } finally {
                    P.T = i, G.p = d
                }
            }(ns & 3) !== 0 && yo(), On(t), d = t.pendingLanes, (r & 4194090) !== 0 && (d & 42) !== 0 ? t === ff ? Tr++ : (Tr = 0, ff = t) : Tr = 0, _r(0)
        }
    }

    function Mg(t, i) {
        (t.pooledCacheLanes &= i) === 0 && (i = t.pooledCache, i != null && (t.pooledCache = null, nr(i)))
    }

    function yo(t) {
        return _g(), Eg(), wg(), Ag()
    }

    function Ag() {
        if (dt !== 5) return !1;
        var t = _i,
            i = uf;
        uf = 0;
        var r = zu(ns),
            u = P.T,
            d = G.p;
        try {
            G.p = 32 > r ? 32 : r, P.T = null, r = cf, cf = null;
            var g = _i,
                x = ns;
            if (dt = 0, ts = _i = null, ns = 0, (Me & 6) !== 0) throw Error(s(331));
            var E = Me;
            if (Me |= 4, cg(g.current), lg(g, g.current, x, r), Me = E, _r(0, !1), Bt && typeof Bt.onPostCommitFiberRoot == "function") try {
                Bt.onPostCommitFiberRoot(Bs, g)
            } catch {}
            return !0
        } finally {
            G.p = d, P.T = u, Mg(t, i)
        }
    }

    function Cg(t, i, r) {
        i = an(r, i), i = Gc(t.stateNode, i, 2), t = hi(t, i, 2), t !== null && (Us(t, 2), On(t))
    }

    function ze(t, i, r) {
        if (t.tag === 3) Cg(t, t, r);
        else
            for (; i !== null;) {
                if (i.tag === 3) {
                    Cg(i, t, r);
                    break
                } else if (i.tag === 1) {
                    var u = i.stateNode;
                    if (typeof i.type.getDerivedStateFromError == "function" || typeof u.componentDidCatch == "function" && (Ti === null || !Ti.has(u))) {
                        t = an(r, t), r = R0(2), u = hi(i, r, 2), u !== null && (L0(r, u, i, t), Us(u, 2), On(u));
                        break
                    }
                }
                i = i.return
            }
    }

    function pf(t, i, r) {
        var u = t.pingCache;
        if (u === null) {
            u = t.pingCache = new nT;
            var d = new Set;
            u.set(i, d)
        } else d = u.get(i), d === void 0 && (d = new Set, u.set(i, d));
        d.has(r) || (sf = !0, d.add(r), t = lT.bind(null, t, i, r), i.then(t, t))
    }

    function lT(t, i, r) {
        var u = t.pingCache;
        u !== null && u.delete(i), t.pingedLanes |= t.suspendedLanes & r, t.warmLanes &= ~r, je === t && (Te & r) === r && (Fe === 4 || Fe === 3 && (Te & 62914560) === Te && 300 > En() - of ? (Me & 2) === 0 && is(t, 0) : rf |= r, es === Te && (es = 0)), On(t)
    }

    function Og(t, i) {
        i === 0 && (i = wm()), t = Pa(t, i), t !== null && (Us(t, i), On(t))
    }

    function oT(t) {
        var i = t.memoizedState,
            r = 0;
        i !== null && (r = i.retryLane), Og(t, r)
    }

    function uT(t, i) {
        var r = 0;
        switch (t.tag) {
            case 13:
                var u = t.stateNode,
                    d = t.memoizedState;
                d !== null && (r = d.retryLane);
                break;
            case 19:
                u = t.stateNode;
                break;
            case 22:
                u = t.stateNode._retryCache;
                break;
            default:
                throw Error(s(314))
        }
        u !== null && u.delete(i), Og(t, r)
    }

    function cT(t, i) {
        return Au(t, i)
    }
    var bo = null,
        ss = null,
        gf = !1,
        xo = !1,
        vf = !1,
        oa = 0;

    function On(t) {
        t !== ss && t.next === null && (ss === null ? bo = ss = t : ss = ss.next = t), xo = !0, gf || (gf = !0, dT())
    }

    function _r(t, i) {
        if (!vf && xo) {
            vf = !0;
            do
                for (var r = !1, u = bo; u !== null;) {
                    if (t !== 0) {
                        var d = u.pendingLanes;
                        if (d === 0) var g = 0;
                        else {
                            var x = u.suspendedLanes,
                                E = u.pingedLanes;
                            g = (1 << 31 - Pt(42 | t) + 1) - 1, g &= d & ~(x & ~E), g = g & 201326741 ? g & 201326741 | 1 : g ? g | 2 : 0
                        }
                        g !== 0 && (r = !0, Lg(u, g))
                    } else g = Te, g = wl(u, u === je ? g : 0, u.cancelPendingCommit !== null || u.timeoutHandle !== -1), (g & 3) === 0 || Ps(u, g) || (r = !0, Lg(u, g));
                    u = u.next
                }
            while (r);
            vf = !1
        }
    }

    function fT() {
        Dg()
    }

    function Dg() {
        xo = gf = !1;
        var t = 0;
        oa !== 0 && (xT() && (t = oa), oa = 0);
        for (var i = En(), r = null, u = bo; u !== null;) {
            var d = u.next,
                g = zg(u, i);
            g === 0 ? (u.next = null, r === null ? bo = d : r.next = d, d === null && (ss = r)) : (r = u, (t !== 0 || (g & 3) !== 0) && (xo = !0)), u = d
        }
        _r(t)
    }

    function zg(t, i) {
        for (var r = t.suspendedLanes, u = t.pingedLanes, d = t.expirationTimes, g = t.pendingLanes & -62914561; 0 < g;) {
            var x = 31 - Pt(g),
                E = 1 << x,
                R = d[x];
            R === -1 ? ((E & r) === 0 || (E & u) !== 0) && (d[x] = kx(E, i)) : R <= i && (t.expiredLanes |= E), g &= ~E
        }
        if (i = je, r = Te, r = wl(t, t === i ? r : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), u = t.callbackNode, r === 0 || t === i && (Ae === 2 || Ae === 9) || t.cancelPendingCommit !== null) return u !== null && u !== null && Cu(u), t.callbackNode = null, t.callbackPriority = 0;
        if ((r & 3) === 0 || Ps(t, r)) {
            if (i = r & -r, i === t.callbackPriority) return i;
            switch (u !== null && Cu(u), zu(r)) {
                case 2:
                case 8:
                    r = Tm;
                    break;
                case 32:
                    r = Tl;
                    break;
                case 268435456:
                    r = _m;
                    break;
                default:
                    r = Tl
            }
            return u = Rg.bind(null, t), r = Au(r, u), t.callbackPriority = i, t.callbackNode = r, i
        }
        return u !== null && u !== null && Cu(u), t.callbackPriority = 2, t.callbackNode = null, 2
    }

    function Rg(t, i) {
        if (dt !== 0 && dt !== 5) return t.callbackNode = null, t.callbackPriority = 0, null;
        var r = t.callbackNode;
        if (yo() && t.callbackNode !== r) return null;
        var u = Te;
        return u = wl(t, t === je ? u : 0, t.cancelPendingCommit !== null || t.timeoutHandle !== -1), u === 0 ? null : (mg(t, u, i), zg(t, En()), t.callbackNode != null && t.callbackNode === r ? Rg.bind(null, t) : null)
    }

    function Lg(t, i) {
        if (yo()) return null;
        mg(t, i, !0)
    }

    function dT() {
        TT(function() {
            (Me & 6) !== 0 ? Au(Sm, fT) : Dg()
        })
    }

    function yf() {
        return oa === 0 && (oa = Em()), oa
    }

    function jg(t) {
        return t == null || typeof t == "symbol" || typeof t == "boolean" ? null : typeof t == "function" ? t : Dl("" + t)
    }

    function Ng(t, i) {
        var r = i.ownerDocument.createElement("input");
        return r.name = i.name, r.value = i.value, t.id && r.setAttribute("form", t.id), i.parentNode.insertBefore(r, i), t = new FormData(t), r.parentNode.removeChild(r), t
    }

    function hT(t, i, r, u, d) {
        if (i === "submit" && r && r.stateNode === d) {
            var g = jg((d[Mt] || null).action),
                x = u.submitter;
            x && (i = (i = x[Mt] || null) ? jg(i.formAction) : x.getAttribute("formAction"), i !== null && (g = i, x = null));
            var E = new jl("action", "action", null, u, d);
            t.push({
                event: E,
                listeners: [{
                    instance: null,
                    listener: function() {
                        if (u.defaultPrevented) {
                            if (oa !== 0) {
                                var R = x ? Ng(d, x) : new FormData(d);
                                kc(r, {
                                    pending: !0,
                                    data: R,
                                    method: d.method,
                                    action: g
                                }, null, R)
                            }
                        } else typeof g == "function" && (E.preventDefault(), R = x ? Ng(d, x) : new FormData(d), kc(r, {
                            pending: !0,
                            data: R,
                            method: d.method,
                            action: g
                        }, g, R))
                    },
                    currentTarget: d
                }]
            })
        }
    }
    for (var bf = 0; bf < nc.length; bf++) {
        var xf = nc[bf],
            mT = xf.toLowerCase(),
            pT = xf[0].toUpperCase() + xf.slice(1);
        bn(mT, "on" + pT)
    }
    bn(mp, "onAnimationEnd"), bn(pp, "onAnimationIteration"), bn(gp, "onAnimationStart"), bn("dblclick", "onDoubleClick"), bn("focusin", "onFocus"), bn("focusout", "onBlur"), bn(RS, "onTransitionRun"), bn(LS, "onTransitionStart"), bn(jS, "onTransitionCancel"), bn(vp, "onTransitionEnd"), Oa("onMouseEnter", ["mouseout", "mouseover"]), Oa("onMouseLeave", ["mouseout", "mouseover"]), Oa("onPointerEnter", ["pointerout", "pointerover"]), Oa("onPointerLeave", ["pointerout", "pointerover"]), Fi("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" ")), Fi("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")), Fi("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]), Fi("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" ")), Fi("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" ")), Fi("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
    var Er = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
        gT = new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Er));

    function Vg(t, i) {
        i = (i & 4) !== 0;
        for (var r = 0; r < t.length; r++) {
            var u = t[r],
                d = u.event;
            u = u.listeners;
            e: {
                var g = void 0;
                if (i)
                    for (var x = u.length - 1; 0 <= x; x--) {
                        var E = u[x],
                            R = E.instance,
                            U = E.currentTarget;
                        if (E = E.listener, R !== g && d.isPropagationStopped()) break e;
                        g = E, d.currentTarget = U;
                        try {
                            g(d)
                        } catch (K) {
                            ro(K)
                        }
                        d.currentTarget = null, g = R
                    } else
                        for (x = 0; x < u.length; x++) {
                            if (E = u[x], R = E.instance, U = E.currentTarget, E = E.listener, R !== g && d.isPropagationStopped()) break e;
                            g = E, d.currentTarget = U;
                            try {
                                g(d)
                            } catch (K) {
                                ro(K)
                            }
                            d.currentTarget = null, g = R
                        }
            }
        }
    }

    function be(t, i) {
        var r = i[Ru];
        r === void 0 && (r = i[Ru] = new Set);
        var u = t + "__bubble";
        r.has(u) || (kg(i, t, 2, !1), r.add(u))
    }

    function Sf(t, i, r) {
        var u = 0;
        i && (u |= 4), kg(r, t, u, i)
    }
    var So = "_reactListening" + Math.random().toString(36).slice(2);

    function Tf(t) {
        if (!t[So]) {
            t[So] = !0, Dm.forEach(function(r) {
                r !== "selectionchange" && (gT.has(r) || Sf(r, !1, t), Sf(r, !0, t))
            });
            var i = t.nodeType === 9 ? t : t.ownerDocument;
            i === null || i[So] || (i[So] = !0, Sf("selectionchange", !1, i))
        }
    }

    function kg(t, i, r, u) {
        switch (l1(i)) {
            case 2:
                var d = qT;
                break;
            case 8:
                d = YT;
                break;
            default:
                d = Vf
        }
        r = d.bind(null, i, r, t), d = void 0, !qu || i !== "touchstart" && i !== "touchmove" && i !== "wheel" || (d = !0), u ? d !== void 0 ? t.addEventListener(i, r, {
            capture: !0,
            passive: d
        }) : t.addEventListener(i, r, !0) : d !== void 0 ? t.addEventListener(i, r, {
            passive: d
        }) : t.addEventListener(i, r, !1)
    }

    function _f(t, i, r, u, d) {
        var g = u;
        if ((i & 1) === 0 && (i & 2) === 0 && u !== null) e: for (;;) {
            if (u === null) return;
            var x = u.tag;
            if (x === 3 || x === 4) {
                var E = u.stateNode.containerInfo;
                if (E === d) break;
                if (x === 4)
                    for (x = u.return; x !== null;) {
                        var R = x.tag;
                        if ((R === 3 || R === 4) && x.stateNode.containerInfo === d) return;
                        x = x.return
                    }
                for (; E !== null;) {
                    if (x = Ma(E), x === null) return;
                    if (R = x.tag, R === 5 || R === 6 || R === 26 || R === 27) {
                        u = g = x;
                        continue e
                    }
                    E = E.parentNode
                }
            }
            u = u.return
        }
        Ym(function() {
            var U = g,
                K = Hu(r),
                $ = [];
            e: {
                var q = yp.get(t);
                if (q !== void 0) {
                    var Y = jl,
                        fe = t;
                    switch (t) {
                        case "keypress":
                            if (Rl(r) === 0) break e;
                        case "keydown":
                        case "keyup":
                            Y = cS;
                            break;
                        case "focusin":
                            fe = "focus", Y = Ku;
                            break;
                        case "focusout":
                            fe = "blur", Y = Ku;
                            break;
                        case "beforeblur":
                        case "afterblur":
                            Y = Ku;
                            break;
                        case "click":
                            if (r.button === 2) break e;
                        case "auxclick":
                        case "dblclick":
                        case "mousedown":
                        case "mousemove":
                        case "mouseup":
                        case "mouseout":
                        case "mouseover":
                        case "contextmenu":
                            Y = Km;
                            break;
                        case "drag":
                        case "dragend":
                        case "dragenter":
                        case "dragexit":
                        case "dragleave":
                        case "dragover":
                        case "dragstart":
                        case "drop":
                            Y = Wx;
                            break;
                        case "touchcancel":
                        case "touchend":
                        case "touchmove":
                        case "touchstart":
                            Y = hS;
                            break;
                        case mp:
                        case pp:
                        case gp:
                            Y = tS;
                            break;
                        case vp:
                            Y = pS;
                            break;
                        case "scroll":
                        case "scrollend":
                            Y = Ix;
                            break;
                        case "wheel":
                            Y = vS;
                            break;
                        case "copy":
                        case "cut":
                        case "paste":
                            Y = iS;
                            break;
                        case "gotpointercapture":
                        case "lostpointercapture":
                        case "pointercancel":
                        case "pointerdown":
                        case "pointermove":
                        case "pointerout":
                        case "pointerover":
                        case "pointerup":
                            Y = Qm;
                            break;
                        case "toggle":
                        case "beforetoggle":
                            Y = bS
                    }
                    var ue = (i & 4) !== 0,
                        De = !ue && (t === "scroll" || t === "scrollend"),
                        N = ue ? q !== null ? q + "Capture" : null : q;
                    ue = [];
                    for (var j = U, B; j !== null;) {
                        var Q = j;
                        if (B = Q.stateNode, Q = Q.tag, Q !== 5 && Q !== 26 && Q !== 27 || B === null || N === null || (Q = qs(j, N), Q != null && ue.push(wr(j, Q, B))), De) break;
                        j = j.return
                    }
                    0 < ue.length && (q = new Y(q, fe, null, r, K), $.push({
                        event: q,
                        listeners: ue
                    }))
                }
            }
            if ((i & 7) === 0) {
                e: {
                    if (q = t === "mouseover" || t === "pointerover", Y = t === "mouseout" || t === "pointerout", q && r !== Uu && (fe = r.relatedTarget || r.fromElement) && (Ma(fe) || fe[wa])) break e;
                    if ((Y || q) && (q = K.window === K ? K : (q = K.ownerDocument) ? q.defaultView || q.parentWindow : window, Y ? (fe = r.relatedTarget || r.toElement, Y = U, fe = fe ? Ma(fe) : null, fe !== null && (De = o(fe), ue = fe.tag, fe !== De || ue !== 5 && ue !== 27 && ue !== 6) && (fe = null)) : (Y = null, fe = U), Y !== fe)) {
                        if (ue = Km, Q = "onMouseLeave", N = "onMouseEnter", j = "mouse", (t === "pointerout" || t === "pointerover") && (ue = Qm, Q = "onPointerLeave", N = "onPointerEnter", j = "pointer"), De = Y == null ? q : Gs(Y), B = fe == null ? q : Gs(fe), q = new ue(Q, j + "leave", Y, r, K), q.target = De, q.relatedTarget = B, Q = null, Ma(K) === U && (ue = new ue(N, j + "enter", fe, r, K), ue.target = B, ue.relatedTarget = De, Q = ue), De = Q, Y && fe) t: {
                            for (ue = Y, N = fe, j = 0, B = ue; B; B = rs(B)) j++;
                            for (B = 0, Q = N; Q; Q = rs(Q)) B++;
                            for (; 0 < j - B;) ue = rs(ue),
                            j--;
                            for (; 0 < B - j;) N = rs(N),
                            B--;
                            for (; j--;) {
                                if (ue === N || N !== null && ue === N.alternate) break t;
                                ue = rs(ue), N = rs(N)
                            }
                            ue = null
                        }
                        else ue = null;
                        Y !== null && Bg($, q, Y, ue, !1), fe !== null && De !== null && Bg($, De, fe, ue, !0)
                    }
                }
                e: {
                    if (q = U ? Gs(U) : window, Y = q.nodeName && q.nodeName.toLowerCase(), Y === "select" || Y === "input" && q.type === "file") var re = ip;
                    else if (tp(q))
                        if (ap) re = OS;
                        else {
                            re = AS;
                            var ve = MS
                        }
                    else Y = q.nodeName,
                    !Y || Y.toLowerCase() !== "input" || q.type !== "checkbox" && q.type !== "radio" ? U && Pu(U.elementType) && (re = ip) : re = CS;
                    if (re && (re = re(t, U))) {
                        np($, re, r, K);
                        break e
                    }
                    ve && ve(t, q, U),
                    t === "focusout" && U && q.type === "number" && U.memoizedProps.value != null && Bu(q, "number", q.value)
                }
                switch (ve = U ? Gs(U) : window, t) {
                    case "focusin":
                        (tp(ve) || ve.contentEditable === "true") && (Va = ve, Ju = U, $s = null);
                        break;
                    case "focusout":
                        $s = Ju = Va = null;
                        break;
                    case "mousedown":
                        ec = !0;
                        break;
                    case "contextmenu":
                    case "mouseup":
                    case "dragend":
                        ec = !1, dp($, r, K);
                        break;
                    case "selectionchange":
                        if (zS) break;
                    case "keydown":
                    case "keyup":
                        dp($, r, K)
                }
                var oe;
                if (Qu) e: {
                    switch (t) {
                        case "compositionstart":
                            var ce = "onCompositionStart";
                            break e;
                        case "compositionend":
                            ce = "onCompositionEnd";
                            break e;
                        case "compositionupdate":
                            ce = "onCompositionUpdate";
                            break e
                    }
                    ce = void 0
                }
                else Na ? Jm(t, r) && (ce = "onCompositionEnd") : t === "keydown" && r.keyCode === 229 && (ce = "onCompositionStart");ce && (Im && r.locale !== "ko" && (Na || ce !== "onCompositionStart" ? ce === "onCompositionEnd" && Na && (oe = Xm()) : (ui = K, Yu = "value" in ui ? ui.value : ui.textContent, Na = !0)), ve = To(U, ce), 0 < ve.length && (ce = new Zm(ce, t, null, r, K), $.push({
                    event: ce,
                    listeners: ve
                }), oe ? ce.data = oe : (oe = ep(r), oe !== null && (ce.data = oe)))),
                (oe = SS ? TS(t, r) : _S(t, r)) && (ce = To(U, "onBeforeInput"), 0 < ce.length && (ve = new Zm("onBeforeInput", "beforeinput", null, r, K), $.push({
                    event: ve,
                    listeners: ce
                }), ve.data = oe)),
                hT($, t, U, r, K)
            }
            Vg($, i)
        })
    }

    function wr(t, i, r) {
        return {
            instance: t,
            listener: i,
            currentTarget: r
        }
    }

    function To(t, i) {
        for (var r = i + "Capture", u = []; t !== null;) {
            var d = t,
                g = d.stateNode;
            if (d = d.tag, d !== 5 && d !== 26 && d !== 27 || g === null || (d = qs(t, r), d != null && u.unshift(wr(t, d, g)), d = qs(t, i), d != null && u.push(wr(t, d, g))), t.tag === 3) return u;
            t = t.return
        }
        return []
    }

    function rs(t) {
        if (t === null) return null;
        do t = t.return; while (t && t.tag !== 5 && t.tag !== 27);
        return t || null
    }

    function Bg(t, i, r, u, d) {
        for (var g = i._reactName, x = []; r !== null && r !== u;) {
            var E = r,
                R = E.alternate,
                U = E.stateNode;
            if (E = E.tag, R !== null && R === u) break;
            E !== 5 && E !== 26 && E !== 27 || U === null || (R = U, d ? (U = qs(r, g), U != null && x.unshift(wr(r, U, R))) : d || (U = qs(r, g), U != null && x.push(wr(r, U, R)))), r = r.return
        }
        x.length !== 0 && t.push({
            event: i,
            listeners: x
        })
    }
    var vT = /\r\n?/g,
        yT = /\u0000|\uFFFD/g;

    function Pg(t) {
        return (typeof t == "string" ? t : "" + t).replace(vT, `
`).replace(yT, "")
    }

    function Ug(t, i) {
        return i = Pg(i), Pg(t) === i
    }

    function _o() {}

    function Oe(t, i, r, u, d, g) {
        switch (r) {
            case "children":
                typeof u == "string" ? i === "body" || i === "textarea" && u === "" || Ra(t, u) : (typeof u == "number" || typeof u == "bigint") && i !== "body" && Ra(t, "" + u);
                break;
            case "className":
                Al(t, "class", u);
                break;
            case "tabIndex":
                Al(t, "tabindex", u);
                break;
            case "dir":
            case "role":
            case "viewBox":
            case "width":
            case "height":
                Al(t, r, u);
                break;
            case "style":
                Gm(t, u, g);
                break;
            case "data":
                if (i !== "object") {
                    Al(t, "data", u);
                    break
                }
            case "src":
            case "href":
                if (u === "" && (i !== "a" || r !== "href")) {
                    t.removeAttribute(r);
                    break
                }
                if (u == null || typeof u == "function" || typeof u == "symbol" || typeof u == "boolean") {
                    t.removeAttribute(r);
                    break
                }
                u = Dl("" + u), t.setAttribute(r, u);
                break;
            case "action":
            case "formAction":
                if (typeof u == "function") {
                    t.setAttribute(r, "javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");
                    break
                } else typeof g == "function" && (r === "formAction" ? (i !== "input" && Oe(t, i, "name", d.name, d, null), Oe(t, i, "formEncType", d.formEncType, d, null), Oe(t, i, "formMethod", d.formMethod, d, null), Oe(t, i, "formTarget", d.formTarget, d, null)) : (Oe(t, i, "encType", d.encType, d, null), Oe(t, i, "method", d.method, d, null), Oe(t, i, "target", d.target, d, null)));
                if (u == null || typeof u == "symbol" || typeof u == "boolean") {
                    t.removeAttribute(r);
                    break
                }
                u = Dl("" + u), t.setAttribute(r, u);
                break;
            case "onClick":
                u != null && (t.onclick = _o);
                break;
            case "onScroll":
                u != null && be("scroll", t);
                break;
            case "onScrollEnd":
                u != null && be("scrollend", t);
                break;
            case "dangerouslySetInnerHTML":
                if (u != null) {
                    if (typeof u != "object" || !("__html" in u)) throw Error(s(61));
                    if (r = u.__html, r != null) {
                        if (d.children != null) throw Error(s(60));
                        t.innerHTML = r
                    }
                }
                break;
            case "multiple":
                t.multiple = u && typeof u != "function" && typeof u != "symbol";
                break;
            case "muted":
                t.muted = u && typeof u != "function" && typeof u != "symbol";
                break;
            case "suppressContentEditableWarning":
            case "suppressHydrationWarning":
            case "defaultValue":
            case "defaultChecked":
            case "innerHTML":
            case "ref":
                break;
            case "autoFocus":
                break;
            case "xlinkHref":
                if (u == null || typeof u == "function" || typeof u == "boolean" || typeof u == "symbol") {
                    t.removeAttribute("xlink:href");
                    break
                }
                r = Dl("" + u), t.setAttributeNS("http://www.w3.org/1999/xlink", "xlink:href", r);
                break;
            case "contentEditable":
            case "spellCheck":
            case "draggable":
            case "value":
            case "autoReverse":
            case "externalResourcesRequired":
            case "focusable":
            case "preserveAlpha":
                u != null && typeof u != "function" && typeof u != "symbol" ? t.setAttribute(r, "" + u) : t.removeAttribute(r);
                break;
            case "inert":
            case "allowFullScreen":
            case "async":
            case "autoPlay":
            case "controls":
            case "default":
            case "defer":
            case "disabled":
            case "disablePictureInPicture":
            case "disableRemotePlayback":
            case "formNoValidate":
            case "hidden":
            case "loop":
            case "noModule":
            case "noValidate":
            case "open":
            case "playsInline":
            case "readOnly":
            case "required":
            case "reversed":
            case "scoped":
            case "seamless":
            case "itemScope":
                u && typeof u != "function" && typeof u != "symbol" ? t.setAttribute(r, "") : t.removeAttribute(r);
                break;
            case "capture":
            case "download":
                u === !0 ? t.setAttribute(r, "") : u !== !1 && u != null && typeof u != "function" && typeof u != "symbol" ? t.setAttribute(r, u) : t.removeAttribute(r);
                break;
            case "cols":
            case "rows":
            case "size":
            case "span":
                u != null && typeof u != "function" && typeof u != "symbol" && !isNaN(u) && 1 <= u ? t.setAttribute(r, u) : t.removeAttribute(r);
                break;
            case "rowSpan":
            case "start":
                u == null || typeof u == "function" || typeof u == "symbol" || isNaN(u) ? t.removeAttribute(r) : t.setAttribute(r, u);
                break;
            case "popover":
                be("beforetoggle", t), be("toggle", t), Ml(t, "popover", u);
                break;
            case "xlinkActuate":
                Bn(t, "http://www.w3.org/1999/xlink", "xlink:actuate", u);
                break;
            case "xlinkArcrole":
                Bn(t, "http://www.w3.org/1999/xlink", "xlink:arcrole", u);
                break;
            case "xlinkRole":
                Bn(t, "http://www.w3.org/1999/xlink", "xlink:role", u);
                break;
            case "xlinkShow":
                Bn(t, "http://www.w3.org/1999/xlink", "xlink:show", u);
                break;
            case "xlinkTitle":
                Bn(t, "http://www.w3.org/1999/xlink", "xlink:title", u);
                break;
            case "xlinkType":
                Bn(t, "http://www.w3.org/1999/xlink", "xlink:type", u);
                break;
            case "xmlBase":
                Bn(t, "http://www.w3.org/XML/1998/namespace", "xml:base", u);
                break;
            case "xmlLang":
                Bn(t, "http://www.w3.org/XML/1998/namespace", "xml:lang", u);
                break;
            case "xmlSpace":
                Bn(t, "http://www.w3.org/XML/1998/namespace", "xml:space", u);
                break;
            case "is":
                Ml(t, "is", u);
                break;
            case "innerText":
            case "textContent":
                break;
            default:
                (!(2 < r.length) || r[0] !== "o" && r[0] !== "O" || r[1] !== "n" && r[1] !== "N") && (r = Zx.get(r) || r, Ml(t, r, u))
        }
    }

    function Ef(t, i, r, u, d, g) {
        switch (r) {
            case "style":
                Gm(t, u, g);
                break;
            case "dangerouslySetInnerHTML":
                if (u != null) {
                    if (typeof u != "object" || !("__html" in u)) throw Error(s(61));
                    if (r = u.__html, r != null) {
                        if (d.children != null) throw Error(s(60));
                        t.innerHTML = r
                    }
                }
                break;
            case "children":
                typeof u == "string" ? Ra(t, u) : (typeof u == "number" || typeof u == "bigint") && Ra(t, "" + u);
                break;
            case "onScroll":
                u != null && be("scroll", t);
                break;
            case "onScrollEnd":
                u != null && be("scrollend", t);
                break;
            case "onClick":
                u != null && (t.onclick = _o);
                break;
            case "suppressContentEditableWarning":
            case "suppressHydrationWarning":
            case "innerHTML":
            case "ref":
                break;
            case "innerText":
            case "textContent":
                break;
            default:
                if (!zm.hasOwnProperty(r)) e: {
                    if (r[0] === "o" && r[1] === "n" && (d = r.endsWith("Capture"), i = r.slice(2, d ? r.length - 7 : void 0), g = t[Mt] || null, g = g != null ? g[r] : null, typeof g == "function" && t.removeEventListener(i, g, d), typeof u == "function")) {
                        typeof g != "function" && g !== null && (r in t ? t[r] = null : t.hasAttribute(r) && t.removeAttribute(r)), t.addEventListener(i, u, d);
                        break e
                    }
                    r in t ? t[r] = u : u === !0 ? t.setAttribute(r, "") : Ml(t, r, u)
                }
        }
    }

    function ht(t, i, r) {
        switch (i) {
            case "div":
            case "span":
            case "svg":
            case "path":
            case "a":
            case "g":
            case "p":
            case "li":
                break;
            case "img":
                be("error", t), be("load", t);
                var u = !1,
                    d = !1,
                    g;
                for (g in r)
                    if (r.hasOwnProperty(g)) {
                        var x = r[g];
                        if (x != null) switch (g) {
                            case "src":
                                u = !0;
                                break;
                            case "srcSet":
                                d = !0;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                throw Error(s(137, i));
                            default:
                                Oe(t, i, g, x, r, null)
                        }
                    }
                d && Oe(t, i, "srcSet", r.srcSet, r, null), u && Oe(t, i, "src", r.src, r, null);
                return;
            case "input":
                be("invalid", t);
                var E = g = x = d = null,
                    R = null,
                    U = null;
                for (u in r)
                    if (r.hasOwnProperty(u)) {
                        var K = r[u];
                        if (K != null) switch (u) {
                            case "name":
                                d = K;
                                break;
                            case "type":
                                x = K;
                                break;
                            case "checked":
                                R = K;
                                break;
                            case "defaultChecked":
                                U = K;
                                break;
                            case "value":
                                g = K;
                                break;
                            case "defaultValue":
                                E = K;
                                break;
                            case "children":
                            case "dangerouslySetInnerHTML":
                                if (K != null) throw Error(s(137, i));
                                break;
                            default:
                                Oe(t, i, u, K, r, null)
                        }
                    }
                Bm(t, g, E, R, U, x, d, !1), Cl(t);
                return;
            case "select":
                be("invalid", t), u = x = g = null;
                for (d in r)
                    if (r.hasOwnProperty(d) && (E = r[d], E != null)) switch (d) {
                        case "value":
                            g = E;
                            break;
                        case "defaultValue":
                            x = E;
                            break;
                        case "multiple":
                            u = E;
                        default:
                            Oe(t, i, d, E, r, null)
                    }
                i = g, r = x, t.multiple = !!u, i != null ? za(t, !!u, i, !1) : r != null && za(t, !!u, r, !0);
                return;
            case "textarea":
                be("invalid", t), g = d = u = null;
                for (x in r)
                    if (r.hasOwnProperty(x) && (E = r[x], E != null)) switch (x) {
                        case "value":
                            u = E;
                            break;
                        case "defaultValue":
                            d = E;
                            break;
                        case "children":
                            g = E;
                            break;
                        case "dangerouslySetInnerHTML":
                            if (E != null) throw Error(s(91));
                            break;
                        default:
                            Oe(t, i, x, E, r, null)
                    }
                Um(t, u, d, g), Cl(t);
                return;
            case "option":
                for (R in r)
                    if (r.hasOwnProperty(R) && (u = r[R], u != null)) switch (R) {
                        case "selected":
                            t.selected = u && typeof u != "function" && typeof u != "symbol";
                            break;
                        default:
                            Oe(t, i, R, u, r, null)
                    }
                return;
            case "dialog":
                be("beforetoggle", t), be("toggle", t), be("cancel", t), be("close", t);
                break;
            case "iframe":
            case "object":
                be("load", t);
                break;
            case "video":
            case "audio":
                for (u = 0; u < Er.length; u++) be(Er[u], t);
                break;
            case "image":
                be("error", t), be("load", t);
                break;
            case "details":
                be("toggle", t);
                break;
            case "embed":
            case "source":
            case "link":
                be("error", t), be("load", t);
            case "area":
            case "base":
            case "br":
            case "col":
            case "hr":
            case "keygen":
            case "meta":
            case "param":
            case "track":
            case "wbr":
            case "menuitem":
                for (U in r)
                    if (r.hasOwnProperty(U) && (u = r[U], u != null)) switch (U) {
                        case "children":
                        case "dangerouslySetInnerHTML":
                            throw Error(s(137, i));
                        default:
                            Oe(t, i, U, u, r, null)
                    }
                return;
            default:
                if (Pu(i)) {
                    for (K in r) r.hasOwnProperty(K) && (u = r[K], u !== void 0 && Ef(t, i, K, u, r, void 0));
                    return
                }
        }
        for (E in r) r.hasOwnProperty(E) && (u = r[E], u != null && Oe(t, i, E, u, r, null))
    }

    function bT(t, i, r, u) {
        switch (i) {
            case "div":
            case "span":
            case "svg":
            case "path":
            case "a":
            case "g":
            case "p":
            case "li":
                break;
            case "input":
                var d = null,
                    g = null,
                    x = null,
                    E = null,
                    R = null,
                    U = null,
                    K = null;
                for (Y in r) {
                    var $ = r[Y];
                    if (r.hasOwnProperty(Y) && $ != null) switch (Y) {
                        case "checked":
                            break;
                        case "value":
                            break;
                        case "defaultValue":
                            R = $;
                        default:
                            u.hasOwnProperty(Y) || Oe(t, i, Y, null, u, $)
                    }
                }
                for (var q in u) {
                    var Y = u[q];
                    if ($ = r[q], u.hasOwnProperty(q) && (Y != null || $ != null)) switch (q) {
                        case "type":
                            g = Y;
                            break;
                        case "name":
                            d = Y;
                            break;
                        case "checked":
                            U = Y;
                            break;
                        case "defaultChecked":
                            K = Y;
                            break;
                        case "value":
                            x = Y;
                            break;
                        case "defaultValue":
                            E = Y;
                            break;
                        case "children":
                        case "dangerouslySetInnerHTML":
                            if (Y != null) throw Error(s(137, i));
                            break;
                        default:
                            Y !== $ && Oe(t, i, q, Y, u, $)
                    }
                }
                ku(t, x, E, R, U, K, g, d);
                return;
            case "select":
                Y = x = E = q = null;
                for (g in r)
                    if (R = r[g], r.hasOwnProperty(g) && R != null) switch (g) {
                        case "value":
                            break;
                        case "multiple":
                            Y = R;
                        default:
                            u.hasOwnProperty(g) || Oe(t, i, g, null, u, R)
                    }
                for (d in u)
                    if (g = u[d], R = r[d], u.hasOwnProperty(d) && (g != null || R != null)) switch (d) {
                        case "value":
                            q = g;
                            break;
                        case "defaultValue":
                            E = g;
                            break;
                        case "multiple":
                            x = g;
                        default:
                            g !== R && Oe(t, i, d, g, u, R)
                    }
                i = E, r = x, u = Y, q != null ? za(t, !!r, q, !1) : !!u != !!r && (i != null ? za(t, !!r, i, !0) : za(t, !!r, r ? [] : "", !1));
                return;
            case "textarea":
                Y = q = null;
                for (E in r)
                    if (d = r[E], r.hasOwnProperty(E) && d != null && !u.hasOwnProperty(E)) switch (E) {
                        case "value":
                            break;
                        case "children":
                            break;
                        default:
                            Oe(t, i, E, null, u, d)
                    }
                for (x in u)
                    if (d = u[x], g = r[x], u.hasOwnProperty(x) && (d != null || g != null)) switch (x) {
                        case "value":
                            q = d;
                            break;
                        case "defaultValue":
                            Y = d;
                            break;
                        case "children":
                            break;
                        case "dangerouslySetInnerHTML":
                            if (d != null) throw Error(s(91));
                            break;
                        default:
                            d !== g && Oe(t, i, x, d, u, g)
                    }
                Pm(t, q, Y);
                return;
            case "option":
                for (var fe in r)
                    if (q = r[fe], r.hasOwnProperty(fe) && q != null && !u.hasOwnProperty(fe)) switch (fe) {
                        case "selected":
                            t.selected = !1;
                            break;
                        default:
                            Oe(t, i, fe, null, u, q)
                    }
                for (R in u)
                    if (q = u[R], Y = r[R], u.hasOwnProperty(R) && q !== Y && (q != null || Y != null)) switch (R) {
                        case "selected":
                            t.selected = q && typeof q != "function" && typeof q != "symbol";
                            break;
                        default:
                            Oe(t, i, R, q, u, Y)
                    }
                return;
            case "img":
            case "link":
            case "area":
            case "base":
            case "br":
            case "col":
            case "embed":
            case "hr":
            case "keygen":
            case "meta":
            case "param":
            case "source":
            case "track":
            case "wbr":
            case "menuitem":
                for (var ue in r) q = r[ue], r.hasOwnProperty(ue) && q != null && !u.hasOwnProperty(ue) && Oe(t, i, ue, null, u, q);
                for (U in u)
                    if (q = u[U], Y = r[U], u.hasOwnProperty(U) && q !== Y && (q != null || Y != null)) switch (U) {
                        case "children":
                        case "dangerouslySetInnerHTML":
                            if (q != null) throw Error(s(137, i));
                            break;
                        default:
                            Oe(t, i, U, q, u, Y)
                    }
                return;
            default:
                if (Pu(i)) {
                    for (var De in r) q = r[De], r.hasOwnProperty(De) && q !== void 0 && !u.hasOwnProperty(De) && Ef(t, i, De, void 0, u, q);
                    for (K in u) q = u[K], Y = r[K], !u.hasOwnProperty(K) || q === Y || q === void 0 && Y === void 0 || Ef(t, i, K, q, u, Y);
                    return
                }
        }
        for (var N in r) q = r[N], r.hasOwnProperty(N) && q != null && !u.hasOwnProperty(N) && Oe(t, i, N, null, u, q);
        for ($ in u) q = u[$], Y = r[$], !u.hasOwnProperty($) || q === Y || q == null && Y == null || Oe(t, i, $, q, u, Y)
    }
    var wf = null,
        Mf = null;

    function Eo(t) {
        return t.nodeType === 9 ? t : t.ownerDocument
    }

    function Hg(t) {
        switch (t) {
            case "http://www.w3.org/2000/svg":
                return 1;
            case "http://www.w3.org/1998/Math/MathML":
                return 2;
            default:
                return 0
        }
    }

    function Gg(t, i) {
        if (t === 0) switch (i) {
            case "svg":
                return 1;
            case "math":
                return 2;
            default:
                return 0
        }
        return t === 1 && i === "foreignObject" ? 0 : t
    }

    function Af(t, i) {
        return t === "textarea" || t === "noscript" || typeof i.children == "string" || typeof i.children == "number" || typeof i.children == "bigint" || typeof i.dangerouslySetInnerHTML == "object" && i.dangerouslySetInnerHTML !== null && i.dangerouslySetInnerHTML.__html != null
    }
    var Cf = null;

    function xT() {
        var t = window.event;
        return t && t.type === "popstate" ? t === Cf ? !1 : (Cf = t, !0) : (Cf = null, !1)
    }
    var qg = typeof setTimeout == "function" ? setTimeout : void 0,
        ST = typeof clearTimeout == "function" ? clearTimeout : void 0,
        Yg = typeof Promise == "function" ? Promise : void 0,
        TT = typeof queueMicrotask == "function" ? queueMicrotask : typeof Yg < "u" ? function(t) {
            return Yg.resolve(null).then(t).catch(_T)
        } : qg;

    function _T(t) {
        setTimeout(function() {
            throw t
        })
    }

    function wi(t) {
        return t === "head"
    }

    function Xg(t, i) {
        var r = i,
            u = 0,
            d = 0;
        do {
            var g = r.nextSibling;
            if (t.removeChild(r), g && g.nodeType === 8)
                if (r = g.data, r === "/$") {
                    if (0 < u && 8 > u) {
                        r = u;
                        var x = t.ownerDocument;
                        if (r & 1 && Mr(x.documentElement), r & 2 && Mr(x.body), r & 4)
                            for (r = x.head, Mr(r), x = r.firstChild; x;) {
                                var E = x.nextSibling,
                                    R = x.nodeName;
                                x[Hs] || R === "SCRIPT" || R === "STYLE" || R === "LINK" && x.rel.toLowerCase() === "stylesheet" || r.removeChild(x), x = E
                            }
                    }
                    if (d === 0) {
                        t.removeChild(g), jr(i);
                        return
                    }
                    d--
                } else r === "$" || r === "$?" || r === "$!" ? d++ : u = r.charCodeAt(0) - 48;
            else u = 0;
            r = g
        } while (r);
        jr(i)
    }

    function Of(t) {
        var i = t.firstChild;
        for (i && i.nodeType === 10 && (i = i.nextSibling); i;) {
            var r = i;
            switch (i = i.nextSibling, r.nodeName) {
                case "HTML":
                case "HEAD":
                case "BODY":
                    Of(r), Lu(r);
                    continue;
                case "SCRIPT":
                case "STYLE":
                    continue;
                case "LINK":
                    if (r.rel.toLowerCase() === "stylesheet") continue
            }
            t.removeChild(r)
        }
    }

    function ET(t, i, r, u) {
        for (; t.nodeType === 1;) {
            var d = r;
            if (t.nodeName.toLowerCase() !== i.toLowerCase()) {
                if (!u && (t.nodeName !== "INPUT" || t.type !== "hidden")) break
            } else if (u) {
                if (!t[Hs]) switch (i) {
                    case "meta":
                        if (!t.hasAttribute("itemprop")) break;
                        return t;
                    case "link":
                        if (g = t.getAttribute("rel"), g === "stylesheet" && t.hasAttribute("data-precedence")) break;
                        if (g !== d.rel || t.getAttribute("href") !== (d.href == null || d.href === "" ? null : d.href) || t.getAttribute("crossorigin") !== (d.crossOrigin == null ? null : d.crossOrigin) || t.getAttribute("title") !== (d.title == null ? null : d.title)) break;
                        return t;
                    case "style":
                        if (t.hasAttribute("data-precedence")) break;
                        return t;
                    case "script":
                        if (g = t.getAttribute("src"), (g !== (d.src == null ? null : d.src) || t.getAttribute("type") !== (d.type == null ? null : d.type) || t.getAttribute("crossorigin") !== (d.crossOrigin == null ? null : d.crossOrigin)) && g && t.hasAttribute("async") && !t.hasAttribute("itemprop")) break;
                        return t;
                    default:
                        return t
                }
            } else if (i === "input" && t.type === "hidden") {
                var g = d.name == null ? null : "" + d.name;
                if (d.type === "hidden" && t.getAttribute("name") === g) return t
            } else return t;
            if (t = Sn(t.nextSibling), t === null) break
        }
        return null
    }

    function wT(t, i, r) {
        if (i === "") return null;
        for (; t.nodeType !== 3;)
            if ((t.nodeType !== 1 || t.nodeName !== "INPUT" || t.type !== "hidden") && !r || (t = Sn(t.nextSibling), t === null)) return null;
        return t
    }

    function Df(t) {
        return t.data === "$!" || t.data === "$?" && t.ownerDocument.readyState === "complete"
    }

    function MT(t, i) {
        var r = t.ownerDocument;
        if (t.data !== "$?" || r.readyState === "complete") i();
        else {
            var u = function() {
                i(), r.removeEventListener("DOMContentLoaded", u)
            };
            r.addEventListener("DOMContentLoaded", u), t._reactRetry = u
        }
    }

    function Sn(t) {
        for (; t != null; t = t.nextSibling) {
            var i = t.nodeType;
            if (i === 1 || i === 3) break;
            if (i === 8) {
                if (i = t.data, i === "$" || i === "$!" || i === "$?" || i === "F!" || i === "F") break;
                if (i === "/$") return null
            }
        }
        return t
    }
    var zf = null;

    function Fg(t) {
        t = t.previousSibling;
        for (var i = 0; t;) {
            if (t.nodeType === 8) {
                var r = t.data;
                if (r === "$" || r === "$!" || r === "$?") {
                    if (i === 0) return t;
                    i--
                } else r === "/$" && i++
            }
            t = t.previousSibling
        }
        return null
    }

    function Kg(t, i, r) {
        switch (i = Eo(r), t) {
            case "html":
                if (t = i.documentElement, !t) throw Error(s(452));
                return t;
            case "head":
                if (t = i.head, !t) throw Error(s(453));
                return t;
            case "body":
                if (t = i.body, !t) throw Error(s(454));
                return t;
            default:
                throw Error(s(451))
        }
    }

    function Mr(t) {
        for (var i = t.attributes; i.length;) t.removeAttributeNode(i[0]);
        Lu(t)
    }
    var cn = new Map,
        Zg = new Set;

    function wo(t) {
        return typeof t.getRootNode == "function" ? t.getRootNode() : t.nodeType === 9 ? t : t.ownerDocument
    }
    var Wn = G.d;
    G.d = {
        f: AT,
        r: CT,
        D: OT,
        C: DT,
        L: zT,
        m: RT,
        X: jT,
        S: LT,
        M: NT
    };

    function AT() {
        var t = Wn.f(),
            i = go();
        return t || i
    }

    function CT(t) {
        var i = Aa(t);
        i !== null && i.tag === 5 && i.type === "form" ? m0(i) : Wn.r(t)
    }
    var ls = typeof document > "u" ? null : document;

    function Qg(t, i, r) {
        var u = ls;
        if (u && typeof i == "string" && i) {
            var d = nn(i);
            d = 'link[rel="' + t + '"][href="' + d + '"]', typeof r == "string" && (d += '[crossorigin="' + r + '"]'), Zg.has(d) || (Zg.add(d), t = {
                rel: t,
                crossOrigin: r,
                href: i
            }, u.querySelector(d) === null && (i = u.createElement("link"), ht(i, "link", t), st(i), u.head.appendChild(i)))
        }
    }

    function OT(t) {
        Wn.D(t), Qg("dns-prefetch", t, null)
    }

    function DT(t, i) {
        Wn.C(t, i), Qg("preconnect", t, i)
    }

    function zT(t, i, r) {
        Wn.L(t, i, r);
        var u = ls;
        if (u && t && i) {
            var d = 'link[rel="preload"][as="' + nn(i) + '"]';
            i === "image" && r && r.imageSrcSet ? (d += '[imagesrcset="' + nn(r.imageSrcSet) + '"]', typeof r.imageSizes == "string" && (d += '[imagesizes="' + nn(r.imageSizes) + '"]')) : d += '[href="' + nn(t) + '"]';
            var g = d;
            switch (i) {
                case "style":
                    g = os(t);
                    break;
                case "script":
                    g = us(t)
            }
            cn.has(g) || (t = p({
                rel: "preload",
                href: i === "image" && r && r.imageSrcSet ? void 0 : t,
                as: i
            }, r), cn.set(g, t), u.querySelector(d) !== null || i === "style" && u.querySelector(Ar(g)) || i === "script" && u.querySelector(Cr(g)) || (i = u.createElement("link"), ht(i, "link", t), st(i), u.head.appendChild(i)))
        }
    }

    function RT(t, i) {
        Wn.m(t, i);
        var r = ls;
        if (r && t) {
            var u = i && typeof i.as == "string" ? i.as : "script",
                d = 'link[rel="modulepreload"][as="' + nn(u) + '"][href="' + nn(t) + '"]',
                g = d;
            switch (u) {
                case "audioworklet":
                case "paintworklet":
                case "serviceworker":
                case "sharedworker":
                case "worker":
                case "script":
                    g = us(t)
            }
            if (!cn.has(g) && (t = p({
                    rel: "modulepreload",
                    href: t
                }, i), cn.set(g, t), r.querySelector(d) === null)) {
                switch (u) {
                    case "audioworklet":
                    case "paintworklet":
                    case "serviceworker":
                    case "sharedworker":
                    case "worker":
                    case "script":
                        if (r.querySelector(Cr(g))) return
                }
                u = r.createElement("link"), ht(u, "link", t), st(u), r.head.appendChild(u)
            }
        }
    }

    function LT(t, i, r) {
        Wn.S(t, i, r);
        var u = ls;
        if (u && t) {
            var d = Ca(u).hoistableStyles,
                g = os(t);
            i = i || "default";
            var x = d.get(g);
            if (!x) {
                var E = {
                    loading: 0,
                    preload: null
                };
                if (x = u.querySelector(Ar(g))) E.loading = 5;
                else {
                    t = p({
                        rel: "stylesheet",
                        href: t,
                        "data-precedence": i
                    }, r), (r = cn.get(g)) && Rf(t, r);
                    var R = x = u.createElement("link");
                    st(R), ht(R, "link", t), R._p = new Promise(function(U, K) {
                        R.onload = U, R.onerror = K
                    }), R.addEventListener("load", function() {
                        E.loading |= 1
                    }), R.addEventListener("error", function() {
                        E.loading |= 2
                    }), E.loading |= 4, Mo(x, i, u)
                }
                x = {
                    type: "stylesheet",
                    instance: x,
                    count: 1,
                    state: E
                }, d.set(g, x)
            }
        }
    }

    function jT(t, i) {
        Wn.X(t, i);
        var r = ls;
        if (r && t) {
            var u = Ca(r).hoistableScripts,
                d = us(t),
                g = u.get(d);
            g || (g = r.querySelector(Cr(d)), g || (t = p({
                src: t,
                async: !0
            }, i), (i = cn.get(d)) && Lf(t, i), g = r.createElement("script"), st(g), ht(g, "link", t), r.head.appendChild(g)), g = {
                type: "script",
                instance: g,
                count: 1,
                state: null
            }, u.set(d, g))
        }
    }

    function NT(t, i) {
        Wn.M(t, i);
        var r = ls;
        if (r && t) {
            var u = Ca(r).hoistableScripts,
                d = us(t),
                g = u.get(d);
            g || (g = r.querySelector(Cr(d)), g || (t = p({
                src: t,
                async: !0,
                type: "module"
            }, i), (i = cn.get(d)) && Lf(t, i), g = r.createElement("script"), st(g), ht(g, "link", t), r.head.appendChild(g)), g = {
                type: "script",
                instance: g,
                count: 1,
                state: null
            }, u.set(d, g))
        }
    }

    function Ig(t, i, r, u) {
        var d = (d = he.current) ? wo(d) : null;
        if (!d) throw Error(s(446));
        switch (t) {
            case "meta":
            case "title":
                return null;
            case "style":
                return typeof r.precedence == "string" && typeof r.href == "string" ? (i = os(r.href), r = Ca(d).hoistableStyles, u = r.get(i), u || (u = {
                    type: "style",
                    instance: null,
                    count: 0,
                    state: null
                }, r.set(i, u)), u) : {
                    type: "void",
                    instance: null,
                    count: 0,
                    state: null
                };
            case "link":
                if (r.rel === "stylesheet" && typeof r.href == "string" && typeof r.precedence == "string") {
                    t = os(r.href);
                    var g = Ca(d).hoistableStyles,
                        x = g.get(t);
                    if (x || (d = d.ownerDocument || d, x = {
                            type: "stylesheet",
                            instance: null,
                            count: 0,
                            state: {
                                loading: 0,
                                preload: null
                            }
                        }, g.set(t, x), (g = d.querySelector(Ar(t))) && !g._p && (x.instance = g, x.state.loading = 5), cn.has(t) || (r = {
                            rel: "preload",
                            as: "style",
                            href: r.href,
                            crossOrigin: r.crossOrigin,
                            integrity: r.integrity,
                            media: r.media,
                            hrefLang: r.hrefLang,
                            referrerPolicy: r.referrerPolicy
                        }, cn.set(t, r), g || VT(d, t, r, x.state))), i && u === null) throw Error(s(528, ""));
                    return x
                }
                if (i && u !== null) throw Error(s(529, ""));
                return null;
            case "script":
                return i = r.async, r = r.src, typeof r == "string" && i && typeof i != "function" && typeof i != "symbol" ? (i = us(r), r = Ca(d).hoistableScripts, u = r.get(i), u || (u = {
                    type: "script",
                    instance: null,
                    count: 0,
                    state: null
                }, r.set(i, u)), u) : {
                    type: "void",
                    instance: null,
                    count: 0,
                    state: null
                };
            default:
                throw Error(s(444, t))
        }
    }

    function os(t) {
        return 'href="' + nn(t) + '"'
    }

    function Ar(t) {
        return 'link[rel="stylesheet"][' + t + "]"
    }

    function $g(t) {
        return p({}, t, {
            "data-precedence": t.precedence,
            precedence: null
        })
    }

    function VT(t, i, r, u) {
        t.querySelector('link[rel="preload"][as="style"][' + i + "]") ? u.loading = 1 : (i = t.createElement("link"), u.preload = i, i.addEventListener("load", function() {
            return u.loading |= 1
        }), i.addEventListener("error", function() {
            return u.loading |= 2
        }), ht(i, "link", r), st(i), t.head.appendChild(i))
    }

    function us(t) {
        return '[src="' + nn(t) + '"]'
    }

    function Cr(t) {
        return "script[async]" + t
    }

    function Wg(t, i, r) {
        if (i.count++, i.instance === null) switch (i.type) {
            case "style":
                var u = t.querySelector('style[data-href~="' + nn(r.href) + '"]');
                if (u) return i.instance = u, st(u), u;
                var d = p({}, r, {
                    "data-href": r.href,
                    "data-precedence": r.precedence,
                    href: null,
                    precedence: null
                });
                return u = (t.ownerDocument || t).createElement("style"), st(u), ht(u, "style", d), Mo(u, r.precedence, t), i.instance = u;
            case "stylesheet":
                d = os(r.href);
                var g = t.querySelector(Ar(d));
                if (g) return i.state.loading |= 4, i.instance = g, st(g), g;
                u = $g(r), (d = cn.get(d)) && Rf(u, d), g = (t.ownerDocument || t).createElement("link"), st(g);
                var x = g;
                return x._p = new Promise(function(E, R) {
                    x.onload = E, x.onerror = R
                }), ht(g, "link", u), i.state.loading |= 4, Mo(g, r.precedence, t), i.instance = g;
            case "script":
                return g = us(r.src), (d = t.querySelector(Cr(g))) ? (i.instance = d, st(d), d) : (u = r, (d = cn.get(g)) && (u = p({}, r), Lf(u, d)), t = t.ownerDocument || t, d = t.createElement("script"), st(d), ht(d, "link", u), t.head.appendChild(d), i.instance = d);
            case "void":
                return null;
            default:
                throw Error(s(443, i.type))
        } else i.type === "stylesheet" && (i.state.loading & 4) === 0 && (u = i.instance, i.state.loading |= 4, Mo(u, r.precedence, t));
        return i.instance
    }

    function Mo(t, i, r) {
        for (var u = r.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'), d = u.length ? u[u.length - 1] : null, g = d, x = 0; x < u.length; x++) {
            var E = u[x];
            if (E.dataset.precedence === i) g = E;
            else if (g !== d) break
        }
        g ? g.parentNode.insertBefore(t, g.nextSibling) : (i = r.nodeType === 9 ? r.head : r, i.insertBefore(t, i.firstChild))
    }

    function Rf(t, i) {
        t.crossOrigin == null && (t.crossOrigin = i.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = i.referrerPolicy), t.title == null && (t.title = i.title)
    }

    function Lf(t, i) {
        t.crossOrigin == null && (t.crossOrigin = i.crossOrigin), t.referrerPolicy == null && (t.referrerPolicy = i.referrerPolicy), t.integrity == null && (t.integrity = i.integrity)
    }
    var Ao = null;

    function Jg(t, i, r) {
        if (Ao === null) {
            var u = new Map,
                d = Ao = new Map;
            d.set(r, u)
        } else d = Ao, u = d.get(r), u || (u = new Map, d.set(r, u));
        if (u.has(t)) return u;
        for (u.set(t, null), r = r.getElementsByTagName(t), d = 0; d < r.length; d++) {
            var g = r[d];
            if (!(g[Hs] || g[gt] || t === "link" && g.getAttribute("rel") === "stylesheet") && g.namespaceURI !== "http://www.w3.org/2000/svg") {
                var x = g.getAttribute(i) || "";
                x = t + x;
                var E = u.get(x);
                E ? E.push(g) : u.set(x, [g])
            }
        }
        return u
    }

    function e1(t, i, r) {
        t = t.ownerDocument || t, t.head.insertBefore(r, i === "title" ? t.querySelector("head > title") : null)
    }

    function kT(t, i, r) {
        if (r === 1 || i.itemProp != null) return !1;
        switch (t) {
            case "meta":
            case "title":
                return !0;
            case "style":
                if (typeof i.precedence != "string" || typeof i.href != "string" || i.href === "") break;
                return !0;
            case "link":
                if (typeof i.rel != "string" || typeof i.href != "string" || i.href === "" || i.onLoad || i.onError) break;
                switch (i.rel) {
                    case "stylesheet":
                        return t = i.disabled, typeof i.precedence == "string" && t == null;
                    default:
                        return !0
                }
            case "script":
                if (i.async && typeof i.async != "function" && typeof i.async != "symbol" && !i.onLoad && !i.onError && i.src && typeof i.src == "string") return !0
        }
        return !1
    }

    function t1(t) {
        return !(t.type === "stylesheet" && (t.state.loading & 3) === 0)
    }
    var Or = null;

    function BT() {}

    function PT(t, i, r) {
        if (Or === null) throw Error(s(475));
        var u = Or;
        if (i.type === "stylesheet" && (typeof r.media != "string" || matchMedia(r.media).matches !== !1) && (i.state.loading & 4) === 0) {
            if (i.instance === null) {
                var d = os(r.href),
                    g = t.querySelector(Ar(d));
                if (g) {
                    t = g._p, t !== null && typeof t == "object" && typeof t.then == "function" && (u.count++, u = Co.bind(u), t.then(u, u)), i.state.loading |= 4, i.instance = g, st(g);
                    return
                }
                g = t.ownerDocument || t, r = $g(r), (d = cn.get(d)) && Rf(r, d), g = g.createElement("link"), st(g);
                var x = g;
                x._p = new Promise(function(E, R) {
                    x.onload = E, x.onerror = R
                }), ht(g, "link", r), i.instance = g
            }
            u.stylesheets === null && (u.stylesheets = new Map), u.stylesheets.set(i, t), (t = i.state.preload) && (i.state.loading & 3) === 0 && (u.count++, i = Co.bind(u), t.addEventListener("load", i), t.addEventListener("error", i))
        }
    }

    function UT() {
        if (Or === null) throw Error(s(475));
        var t = Or;
        return t.stylesheets && t.count === 0 && jf(t, t.stylesheets), 0 < t.count ? function(i) {
            var r = setTimeout(function() {
                if (t.stylesheets && jf(t, t.stylesheets), t.unsuspend) {
                    var u = t.unsuspend;
                    t.unsuspend = null, u()
                }
            }, 6e4);
            return t.unsuspend = i,
                function() {
                    t.unsuspend = null, clearTimeout(r)
                }
        } : null
    }

    function Co() {
        if (this.count--, this.count === 0) {
            if (this.stylesheets) jf(this, this.stylesheets);
            else if (this.unsuspend) {
                var t = this.unsuspend;
                this.unsuspend = null, t()
            }
        }
    }
    var Oo = null;

    function jf(t, i) {
        t.stylesheets = null, t.unsuspend !== null && (t.count++, Oo = new Map, i.forEach(HT, t), Oo = null, Co.call(t))
    }

    function HT(t, i) {
        if (!(i.state.loading & 4)) {
            var r = Oo.get(t);
            if (r) var u = r.get(null);
            else {
                r = new Map, Oo.set(t, r);
                for (var d = t.querySelectorAll("link[data-precedence],style[data-precedence]"), g = 0; g < d.length; g++) {
                    var x = d[g];
                    (x.nodeName === "LINK" || x.getAttribute("media") !== "not all") && (r.set(x.dataset.precedence, x), u = x)
                }
                u && r.set(null, u)
            }
            d = i.instance, x = d.getAttribute("data-precedence"), g = r.get(x) || u, g === u && r.set(null, d), r.set(x, d), this.count++, u = Co.bind(this), d.addEventListener("load", u), d.addEventListener("error", u), g ? g.parentNode.insertBefore(d, g.nextSibling) : (t = t.nodeType === 9 ? t.head : t, t.insertBefore(d, t.firstChild)), i.state.loading |= 4
        }
    }
    var Dr = {
        $$typeof: C,
        Provider: null,
        Consumer: null,
        _currentValue: X,
        _currentValue2: X,
        _threadCount: 0
    };

    function GT(t, i, r, u, d, g, x, E) {
        this.tag = 1, this.containerInfo = t, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = Ou(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Ou(0), this.hiddenUpdates = Ou(null), this.identifierPrefix = u, this.onUncaughtError = d, this.onCaughtError = g, this.onRecoverableError = x, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = E, this.incompleteTransitions = new Map
    }

    function n1(t, i, r, u, d, g, x, E, R, U, K, $) {
        return t = new GT(t, i, r, x, E, R, U, $), i = 1, g === !0 && (i |= 24), g = Ht(3, null, null, i), t.current = g, g.stateNode = t, i = mc(), i.refCount++, t.pooledCache = i, i.refCount++, g.memoizedState = {
            element: u,
            isDehydrated: r,
            cache: i
        }, yc(g), t
    }

    function i1(t) {
        return t ? (t = Ua, t) : Ua
    }

    function a1(t, i, r, u, d, g) {
        d = i1(d), u.context === null ? u.context = d : u.pendingContext = d, u = di(i), u.payload = {
            element: r
        }, g = g === void 0 ? null : g, g !== null && (u.callback = g), r = hi(t, u, i), r !== null && (Ft(r, t, i), rr(r, t, i))
    }

    function s1(t, i) {
        if (t = t.memoizedState, t !== null && t.dehydrated !== null) {
            var r = t.retryLane;
            t.retryLane = r !== 0 && r < i ? r : i
        }
    }

    function Nf(t, i) {
        s1(t, i), (t = t.alternate) && s1(t, i)
    }

    function r1(t) {
        if (t.tag === 13) {
            var i = Pa(t, 67108864);
            i !== null && Ft(i, t, 67108864), Nf(t, 67108864)
        }
    }
    var Do = !0;

    function qT(t, i, r, u) {
        var d = P.T;
        P.T = null;
        var g = G.p;
        try {
            G.p = 2, Vf(t, i, r, u)
        } finally {
            G.p = g, P.T = d
        }
    }

    function YT(t, i, r, u) {
        var d = P.T;
        P.T = null;
        var g = G.p;
        try {
            G.p = 8, Vf(t, i, r, u)
        } finally {
            G.p = g, P.T = d
        }
    }

    function Vf(t, i, r, u) {
        if (Do) {
            var d = kf(u);
            if (d === null) _f(t, i, u, zo, r), o1(t, u);
            else if (FT(d, t, i, r, u)) u.stopPropagation();
            else if (o1(t, u), i & 4 && -1 < XT.indexOf(t)) {
                for (; d !== null;) {
                    var g = Aa(d);
                    if (g !== null) switch (g.tag) {
                        case 3:
                            if (g = g.stateNode, g.current.memoizedState.isDehydrated) {
                                var x = Xi(g.pendingLanes);
                                if (x !== 0) {
                                    var E = g;
                                    for (E.pendingLanes |= 2, E.entangledLanes |= 2; x;) {
                                        var R = 1 << 31 - Pt(x);
                                        E.entanglements[1] |= R, x &= ~R
                                    }
                                    On(g), (Me & 6) === 0 && (mo = En() + 500, _r(0))
                                }
                            }
                            break;
                        case 13:
                            E = Pa(g, 2), E !== null && Ft(E, g, 2), go(), Nf(g, 2)
                    }
                    if (g = kf(u), g === null && _f(t, i, u, zo, r), g === d) break;
                    d = g
                }
                d !== null && u.stopPropagation()
            } else _f(t, i, u, null, r)
        }
    }

    function kf(t) {
        return t = Hu(t), Bf(t)
    }
    var zo = null;

    function Bf(t) {
        if (zo = null, t = Ma(t), t !== null) {
            var i = o(t);
            if (i === null) t = null;
            else {
                var r = i.tag;
                if (r === 13) {
                    if (t = c(i), t !== null) return t;
                    t = null
                } else if (r === 3) {
                    if (i.stateNode.current.memoizedState.isDehydrated) return i.tag === 3 ? i.stateNode.containerInfo : null;
                    t = null
                } else i !== t && (t = null)
            }
        }
        return zo = t, null
    }

    function l1(t) {
        switch (t) {
            case "beforetoggle":
            case "cancel":
            case "click":
            case "close":
            case "contextmenu":
            case "copy":
            case "cut":
            case "auxclick":
            case "dblclick":
            case "dragend":
            case "dragstart":
            case "drop":
            case "focusin":
            case "focusout":
            case "input":
            case "invalid":
            case "keydown":
            case "keypress":
            case "keyup":
            case "mousedown":
            case "mouseup":
            case "paste":
            case "pause":
            case "play":
            case "pointercancel":
            case "pointerdown":
            case "pointerup":
            case "ratechange":
            case "reset":
            case "resize":
            case "seeked":
            case "submit":
            case "toggle":
            case "touchcancel":
            case "touchend":
            case "touchstart":
            case "volumechange":
            case "change":
            case "selectionchange":
            case "textInput":
            case "compositionstart":
            case "compositionend":
            case "compositionupdate":
            case "beforeblur":
            case "afterblur":
            case "beforeinput":
            case "blur":
            case "fullscreenchange":
            case "focus":
            case "hashchange":
            case "popstate":
            case "select":
            case "selectstart":
                return 2;
            case "drag":
            case "dragenter":
            case "dragexit":
            case "dragleave":
            case "dragover":
            case "mousemove":
            case "mouseout":
            case "mouseover":
            case "pointermove":
            case "pointerout":
            case "pointerover":
            case "scroll":
            case "touchmove":
            case "wheel":
            case "mouseenter":
            case "mouseleave":
            case "pointerenter":
            case "pointerleave":
                return 8;
            case "message":
                switch (Dx()) {
                    case Sm:
                        return 2;
                    case Tm:
                        return 8;
                    case Tl:
                    case zx:
                        return 32;
                    case _m:
                        return 268435456;
                    default:
                        return 32
                }
            default:
                return 32
        }
    }
    var Pf = !1,
        Mi = null,
        Ai = null,
        Ci = null,
        zr = new Map,
        Rr = new Map,
        Oi = [],
        XT = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");

    function o1(t, i) {
        switch (t) {
            case "focusin":
            case "focusout":
                Mi = null;
                break;
            case "dragenter":
            case "dragleave":
                Ai = null;
                break;
            case "mouseover":
            case "mouseout":
                Ci = null;
                break;
            case "pointerover":
            case "pointerout":
                zr.delete(i.pointerId);
                break;
            case "gotpointercapture":
            case "lostpointercapture":
                Rr.delete(i.pointerId)
        }
    }

    function Lr(t, i, r, u, d, g) {
        return t === null || t.nativeEvent !== g ? (t = {
            blockedOn: i,
            domEventName: r,
            eventSystemFlags: u,
            nativeEvent: g,
            targetContainers: [d]
        }, i !== null && (i = Aa(i), i !== null && r1(i)), t) : (t.eventSystemFlags |= u, i = t.targetContainers, d !== null && i.indexOf(d) === -1 && i.push(d), t)
    }

    function FT(t, i, r, u, d) {
        switch (i) {
            case "focusin":
                return Mi = Lr(Mi, t, i, r, u, d), !0;
            case "dragenter":
                return Ai = Lr(Ai, t, i, r, u, d), !0;
            case "mouseover":
                return Ci = Lr(Ci, t, i, r, u, d), !0;
            case "pointerover":
                var g = d.pointerId;
                return zr.set(g, Lr(zr.get(g) || null, t, i, r, u, d)), !0;
            case "gotpointercapture":
                return g = d.pointerId, Rr.set(g, Lr(Rr.get(g) || null, t, i, r, u, d)), !0
        }
        return !1
    }

    function u1(t) {
        var i = Ma(t.target);
        if (i !== null) {
            var r = o(i);
            if (r !== null) {
                if (i = r.tag, i === 13) {
                    if (i = c(r), i !== null) {
                        t.blockedOn = i, Px(t.priority, function() {
                            if (r.tag === 13) {
                                var u = Xt();
                                u = Du(u);
                                var d = Pa(r, u);
                                d !== null && Ft(d, r, u), Nf(r, u)
                            }
                        });
                        return
                    }
                } else if (i === 3 && r.stateNode.current.memoizedState.isDehydrated) {
                    t.blockedOn = r.tag === 3 ? r.stateNode.containerInfo : null;
                    return
                }
            }
        }
        t.blockedOn = null
    }

    function Ro(t) {
        if (t.blockedOn !== null) return !1;
        for (var i = t.targetContainers; 0 < i.length;) {
            var r = kf(t.nativeEvent);
            if (r === null) {
                r = t.nativeEvent;
                var u = new r.constructor(r.type, r);
                Uu = u, r.target.dispatchEvent(u), Uu = null
            } else return i = Aa(r), i !== null && r1(i), t.blockedOn = r, !1;
            i.shift()
        }
        return !0
    }

    function c1(t, i, r) {
        Ro(t) && r.delete(i)
    }

    function KT() {
        Pf = !1, Mi !== null && Ro(Mi) && (Mi = null), Ai !== null && Ro(Ai) && (Ai = null), Ci !== null && Ro(Ci) && (Ci = null), zr.forEach(c1), Rr.forEach(c1)
    }

    function Lo(t, i) {
        t.blockedOn === i && (t.blockedOn = null, Pf || (Pf = !0, n.unstable_scheduleCallback(n.unstable_NormalPriority, KT)))
    }
    var jo = null;

    function f1(t) {
        jo !== t && (jo = t, n.unstable_scheduleCallback(n.unstable_NormalPriority, function() {
            jo === t && (jo = null);
            for (var i = 0; i < t.length; i += 3) {
                var r = t[i],
                    u = t[i + 1],
                    d = t[i + 2];
                if (typeof u != "function") {
                    if (Bf(u || r) === null) continue;
                    break
                }
                var g = Aa(r);
                g !== null && (t.splice(i, 3), i -= 3, kc(g, {
                    pending: !0,
                    data: d,
                    method: r.method,
                    action: u
                }, u, d))
            }
        }))
    }

    function jr(t) {
        function i(R) {
            return Lo(R, t)
        }
        Mi !== null && Lo(Mi, t), Ai !== null && Lo(Ai, t), Ci !== null && Lo(Ci, t), zr.forEach(i), Rr.forEach(i);
        for (var r = 0; r < Oi.length; r++) {
            var u = Oi[r];
            u.blockedOn === t && (u.blockedOn = null)
        }
        for (; 0 < Oi.length && (r = Oi[0], r.blockedOn === null);) u1(r), r.blockedOn === null && Oi.shift();
        if (r = (t.ownerDocument || t).$$reactFormReplay, r != null)
            for (u = 0; u < r.length; u += 3) {
                var d = r[u],
                    g = r[u + 1],
                    x = d[Mt] || null;
                if (typeof g == "function") x || f1(r);
                else if (x) {
                    var E = null;
                    if (g && g.hasAttribute("formAction")) {
                        if (d = g, x = g[Mt] || null) E = x.formAction;
                        else if (Bf(d) !== null) continue
                    } else E = x.action;
                    typeof E == "function" ? r[u + 1] = E : (r.splice(u, 3), u -= 3), f1(r)
                }
            }
    }

    function Uf(t) {
        this._internalRoot = t
    }
    No.prototype.render = Uf.prototype.render = function(t) {
        var i = this._internalRoot;
        if (i === null) throw Error(s(409));
        var r = i.current,
            u = Xt();
        a1(r, u, t, i, null, null)
    }, No.prototype.unmount = Uf.prototype.unmount = function() {
        var t = this._internalRoot;
        if (t !== null) {
            this._internalRoot = null;
            var i = t.containerInfo;
            a1(t.current, 2, null, t, null, null), go(), i[wa] = null
        }
    };

    function No(t) {
        this._internalRoot = t
    }
    No.prototype.unstable_scheduleHydration = function(t) {
        if (t) {
            var i = Cm();
            t = {
                blockedOn: null,
                target: t,
                priority: i
            };
            for (var r = 0; r < Oi.length && i !== 0 && i < Oi[r].priority; r++);
            Oi.splice(r, 0, t), r === 0 && u1(t)
        }
    };
    var d1 = e.version;
    if (d1 !== "19.1.1") throw Error(s(527, d1, "19.1.1"));
    G.findDOMNode = function(t) {
        var i = t._reactInternals;
        if (i === void 0) throw typeof t.render == "function" ? Error(s(188)) : (t = Object.keys(t).join(","), Error(s(268, t)));
        return t = f(i), t = t !== null ? m(t) : null, t = t === null ? null : t.stateNode, t
    };
    var ZT = {
        bundleType: 0,
        version: "19.1.1",
        rendererPackageName: "react-dom",
        currentDispatcherRef: P,
        reconcilerVersion: "19.1.1"
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
        var Vo = __REACT_DEVTOOLS_GLOBAL_HOOK__;
        if (!Vo.isDisabled && Vo.supportsFiber) try {
            Bs = Vo.inject(ZT), Bt = Vo
        } catch {}
    }
    return Vr.createRoot = function(t, i) {
        if (!l(t)) throw Error(s(299));
        var r = !1,
            u = "",
            d = C0,
            g = O0,
            x = D0,
            E = null;
        return i != null && (i.unstable_strictMode === !0 && (r = !0), i.identifierPrefix !== void 0 && (u = i.identifierPrefix), i.onUncaughtError !== void 0 && (d = i.onUncaughtError), i.onCaughtError !== void 0 && (g = i.onCaughtError), i.onRecoverableError !== void 0 && (x = i.onRecoverableError), i.unstable_transitionCallbacks !== void 0 && (E = i.unstable_transitionCallbacks)), i = n1(t, 1, !1, null, null, r, u, d, g, x, E, null), t[wa] = i.current, Tf(t), new Uf(i)
    }, Vr.hydrateRoot = function(t, i, r) {
        if (!l(t)) throw Error(s(299));
        var u = !1,
            d = "",
            g = C0,
            x = O0,
            E = D0,
            R = null,
            U = null;
        return r != null && (r.unstable_strictMode === !0 && (u = !0), r.identifierPrefix !== void 0 && (d = r.identifierPrefix), r.onUncaughtError !== void 0 && (g = r.onUncaughtError), r.onCaughtError !== void 0 && (x = r.onCaughtError), r.onRecoverableError !== void 0 && (E = r.onRecoverableError), r.unstable_transitionCallbacks !== void 0 && (R = r.unstable_transitionCallbacks), r.formState !== void 0 && (U = r.formState)), i = n1(t, 1, !0, i, r ? ? null, u, d, g, x, E, R, U), i.context = i1(null), r = i.current, u = Xt(), u = Du(u), d = di(u), d.callback = null, hi(r, d, u), r = u, i.current.lanes = r, Us(i, r), On(i), t[wa] = i.current, Tf(t), new No(i)
    }, Vr.version = "19.1.1", Vr
}
var T1;

function a_() {
    if (T1) return qf.exports;
    T1 = 1;

    function n() {
        if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
        } catch (e) {
            console.error(e)
        }
    }
    return n(), qf.exports = i_(), qf.exports
}
var s_ = a_();
const _1 = [{
        id: "about",
        href: "#about",
        label: "Über mich"
    }, {
        id: "nachweise",
        href: "#nachweise",
        label: "Nachweise"
    }, {
        id: "skills",
        href: "#skills",
        label: "Fähigkeiten"
    }, {
        id: "experience",
        href: "#experience",
        label: "Erfahrung"
    }, {
        id: "education",
        href: "#education",
        label: "Ausbildung"
    }, {
        id: "contact",
        href: "#contact",
        label: "Kontakt"
    }],
    r_ = () => {
        const [n, e] = J.useState(!0);
        return J.useEffect(() => {
            const s = localStorage.getItem("darkMode"),
                l = s ? JSON.parse(s) : !0;
            e(l), l && document.documentElement.classList.add("dark")
        }, []), {
            darkMode: n,
            toggleDarkMode: () => {
                e(s => {
                    const l = !s;
                    return localStorage.setItem("darkMode", JSON.stringify(l)), l ? document.documentElement.classList.add("dark") : document.documentElement.classList.remove("dark"), l
                })
            }
        }
    },
    l_ = () => {
        const {
            darkMode: n,
            toggleDarkMode: e
        } = r_();
        return A.jsxs("div", {
            className: `flex items-center space-x-1
               bg-gray-200 dark:bg-gray-800 p-1 rounded-full
               text-xs font-medium`,
            children: [A.jsx("span", {
                className: `
          rounded-full p-1.5 *:size-7
          ${n?"hover:bg-white/90 hover:text-blue-600":"bg-white ring-1 ring-blue-400 shadow-sm"}
          sm:p-0 
          cursor-pointer 
          text-gray-800 dark:text-white
        `,
                onClick: () => n && e(),
                role: "radio",
                "aria-checked": !n,
                "aria-label": "Light theme",
                tabIndex: "0",
                children: A.jsxs("svg", {
                    viewBox: "0 0 28 28",
                    fill: "none",
                    stroke: "currentColor",
                    children: [A.jsx("circle", {
                        cx: "14",
                        cy: "14",
                        r: "3.5"
                    }), A.jsx("path", {
                        d: "M14 8.5V6.5",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M17.889 10.111L19.303 8.697",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M19.5 14H21.5",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M17.889 17.888L19.303 19.302",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M14 21.5V19.5",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M8.697 19.303L10.111 17.889",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M6.5 14H8.5",
                        strokeLinecap: "round"
                    }), A.jsx("path", {
                        d: "M8.697 8.697L10.111 10.111",
                        strokeLinecap: "round"
                    })]
                })
            }), A.jsx("span", {
                className: `
          rounded-full p-1.5 *:size-7 
          ${n?"bg-gray-700 ring-1 ring-blue-600 shadow-sm inset-ring-white/10":"hover:bg-white/90 hover:text-blue-400"}
          sm:p-0
          cursor-pointer
          text-gray-800 dark:text-white
        `,
                onClick: () => !n && e(),
                role: "radio",
                "aria-checked": n,
                "aria-label": "Dark theme",
                tabIndex: "0",
                children: A.jsxs("svg", {
                    viewBox: "0 0 28 28",
                    fill: "none",
                    stroke: "currentColor",
                    children: [A.jsx("path", {
                        d: "M10.5 9.999C10.5 14.14 13.858 17.499 18 17.499C19.033 17.499 20.018 17.29 20.913 16.912C19.776 19.607 17.109 21.499 14 21.499C9.858 21.499 6.5 18.141 6.5 13.999C6.5 10.89 8.392 8.223 11.087 7.086C10.709 7.982 10.5 8.966 10.5 9.999Z",
                        strokeLinejoin: "round"
                    }), A.jsx("path", {
                        d: "M16.356 6.507L16.5 5.5L16.644 6.507C16.707 6.947 17.053 7.293 17.493 7.356L18.5 7.5L17.493 7.644C17.053 7.707 16.707 8.053 16.644 8.492L16.5 9.5L16.356 8.492C16.293 8.052 15.948 7.707 15.508 7.644L14.5 7.5L15.508 7.356C15.948 7.293 16.293 6.947 16.356 6.507Z",
                        fill: "currentColor",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }), A.jsx("path", {
                        d: "M20.356 11.507L20.5 10.5L20.644 11.507C20.707 11.947 21.053 12.293 21.493 12.356L22.5 12.5L21.493 12.644C21.053 12.707 20.707 13.053 20.644 13.492L20.5 14.5L20.356 13.492C20.293 13.052 19.948 12.707 19.508 12.644L18.5 12.5L19.508 12.356C19.948 12.293 20.293 11.947 20.356 11.507Z",
                        fill: "currentColor",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })]
                })
            })]
        })
    },
    E1 = xe.memo(l_),
    o_ = {
        site: {
            name: "Yassine El Amrani",
            title: "Professionelle Pflegefachkraft",
            description: "Engagierte Pflegefachkraft mit fundierter Erfahrung in der Patientenversorgung, medizinischen Assistenz und Gesundheitsförderung.",
            heroPhrases: ["Fachkraft für Gesundheits- und Krankenpflege", "Erfahren in der Grund- und Behandlungspflege", "Zuverlässig, empathisch und belastbar", "Bereit für neue Herausforderungen in Bayern"]
        },
        nav: {
            hero: "Inicio",
            about: "Acerca",
            skills: "Habilidades",
            projects: "Proyectos",
            experience: "Experiencia",
            education: "Educación",
            contact: "Contacto"
        },
        sections: {
            about: "Acerca de mí",
            skills: "Habilidades Técnicas",
            projects: "Proyectos",
            experience: "Experiencia",
            education: "Educación",
            contact: "Contacto"
        },
        about: {
            bio: ["Soy desarrollador full-stack con experiencia en construir aplicaciones web robustas y escalables.", "Me apasiona escribir código limpio, bien testeado y mantenible. Uso TDD y CI/CD en todos mis proyectos.", "Fuera del código, me gusta compartir conocimientos, contribuir a open source y aprender nuevas tecnologías."]
        },
        experience: {
            roles: {
                "senior-dev": "Desarrollador Senior Full-Stack",
                "dev-lead": "Líder Técnico",
                "frontend-dev": "Desarrollador Frontend",
                "backend-dev": "Desarrollador Backend"
            },
            descriptions: {
                "senior-dev": "Diseño e implemento soluciones full stack con React, Node.js y bases de datos modernas. Enfoque en rendimiento, accesibilidad y buenas prácticas.",
                "dev-lead": "Lidero equipos ágiles, defino arquitectura técnica y mentoreo a otros desarrolladores en buenas prácticas y testing.",
                "frontend-dev": "Desarrollo interfaces modernas con React, TypeScript y Tailwind CSS. Priorizo UX, accesibilidad y rendimiento.",
                "backend-dev": "Creo APIs RESTful y servicios backend con Node.js, Express y bases de datos SQL/NoSQL. Uso pruebas automatizadas en todo el flujo."
            }
        },
        education: {
            degrees: {
                "computer-science": "Ingeniería en Computación",
                "web-dev-bootcamp": "Bootcamp de Desarrollo Web",
                "tdd-course": "Curso de Test-Driven Development"
            },
            descriptions: {
                "computer-science": "Formación sólida en algoritmos, estructuras de datos, redes y desarrollo de software.",
                "web-dev-bootcamp": "Entrenamiento intensivo en tecnologías modernas: React, Node.js, MongoDB, Docker.",
                "tdd-course": "Enfoque avanzado en pruebas automatizadas, calidad de código y ciclos de desarrollo ágil."
            }
        },
        projects: {
            txtResults: "Resultados",
            buttons: {
                viewResults: "Ver resultados",
                hideResults: "Ocultar resultados",
                viewOnGithub: "Ver en GitHub"
            },
            titles: {
                "e-commerce-platform": "Plataforma de E-commerce",
                "task-manager-app": "Aplicación de Gestión de Tareas",
                "weather-dashboard": "Dashboard de Clima en Tiempo Real",
                "blog-engine": "Motor de Blog con CMS"
            },
            descriptions: {
                "e-commerce-platform": "Plataforma completa con carrito, pasarela de pago (Stripe) y panel de administración. Desarrollada con React, Node.js y MongoDB.",
                "task-manager-app": "App para gestión de tareas con autenticación, drag & drop y sincronización en tiempo real. Usé React, Firebase y Framer Motion.",
                "weather-dashboard": "Dashboard interactivo que muestra clima actual y pronóstico usando la API de OpenWeather. Diseño responsive y animaciones suaves.",
                "blog-engine": "Motor de blog con editor WYSIWYG, comentarios y SEO avanzado. Backend en Node.js con Express y base de datos PostgreSQL."
            },
            results: {
                "e-commerce-platform": ["+10,000 visitas mensuales", "Integración con Stripe exitosa", "95% de satisfacción de usuarios"],
                "task-manager-app": ["100% cubierto por pruebas unitarias", "Rendimiento optimizado (<100ms)", "Disponible en web y móvil"],
                "weather-dashboard": ["Datos en tiempo real precisos", "Soporte para +200,000 ciudades", "Diseño accesible y responsive"],
                "blog-engine": ["SEO optimizado (Lighthouse >90)", "Editor intuitivo para no técnicos", "Comentarios con moderación"]
            }
        },
        skills: {
            txtHeader: "Habilidades Técnicas",
            intro: "Mis habilidades se han desarrollado durante años construyendo aplicaciones web modernas, con enfoque en calidad, rendimiento y mantenibilidad.",
            categories: {
                frontend: "Frontend",
                backend: "Backend",
                devops: "DevOps & Cloud",
                databases: "Bases de Datos",
                testing: "Pruebas & Calidad",
                other: "Otros"
            },
            items: {
                react: "React",
                javascript: "JavaScript",
                typescript: "TypeScript",
                tailwind: "Tailwind CSS",
                nodejs: "Node.js",
                express: "Express",
                docker: "Docker",
                git: "Git & GitHub",
                postgresql: "PostgreSQL",
                mysql: "MySQL",
                mongodb: "MongoDB",
                redis: "Redis",
                jest: "Jest, Testing Library",
                playwright: "Playwright (E2E)",
                languages: "C,C++"
            }
        },
        hero: {
            btnDownload: "📄 Descargar CV",
            btnContact: "✉️ Contáctame"
        },
        contact: {
            message: "¿Tienes un proyecto en mente? ¡Hablemos!",
            form: {
                name: "Nombre",
                email: "Correo",
                message: "Mensaje",
                buttonText: "Enviar",
                sending: "Enviando...",
                error: "Hubo un error. Inténtalo más tarde.",
                success: "¡Mensaje enviado! Te responderé pronto.",
                invalidEmail: "Por favor, ingresa un email válido."
            }
        },
        footer: {
            developedBy: "Diseñado y desarrollado por",
            rights: "Todos los derechos reservados"
        },
        ats: {
            summary: "{name} es {roles} con experiencia en {skills}. Desarrollador de aplicaciones web modernas con enfoque en calidad, rendimiento y escalabilidad.",
            keyProjects: "Proyectos destacados: {projects}.",
            experience: "Experiencia profesional en {company} liderando desarrollo full stack en entornos ágiles.",
            contact: "Contacto: {email}. Disponible en {social}.",
            languages: "Idiomas: Español (nativo), Inglés (profesional).",
            keywords: "Palabras clave:"
        }
    },
    u_ = {
        site: {
            name: "Yassine El Amrani",
            title: "Professionelle Pflegefachkraft",
            description: "Engagierte Pflegefachkraft mit fundierter Erfahrung in der Patientenversorgung, medizinischen Assistenz und Gesundheitsförderung.",
            heroPhrases: ["Fachkraft für Gesundheits- und Krankenpflege", "Erfahren in der Grund- und Behandlungspflege", "Zuverlässig, empathisch und belastbar", "Bereit für neue Herausforderungen in Bayern"]
        },
        nav: {
            about: "Über mich",
            nachweise: "Nachweise",
            skills: "Fähigkeiten",
            projects: "Projekte",
            experience: "Erfahrung",
            education: "Ausbildung",
            contact: "Kontakt"
        },
        sections: {
            about: "About me",
            skills: "Technical Skills",
            experience: "Experience",
            education: "Education",
            contact: "Contact"
        },
        about: {
            title: "Über mich",
            bio: ["Engagierte Pflegefachkraft mit fundierter Ausbildung und großer Leidenschaft für die ganzheitliche Patientenversorgung.", "Mein Ziel ist es, meine fachlichen Kompetenzen und meine interkulturelle Erfahrung in das deutsche Gesundheitssystem, idealerweise in Bayern, einzubringen.", "Ich verfüge über das TELC B2 Sprachzertifikat und befinde mich aktuell im Anerkennungsverfahren für meine beruflichen Qualifikationen."],
            videoTitle: "Persönliche Vorstellung",
            videoSubtitle: "Hören Sie mich Deutsch sprechen & erfahren Sie mehr über meine Motivation."
        },
        experience: {
            roles: {
                "senior-dev": "Senior Full-Stack Developer",
                "dev-lead": "Technical Lead",
                "frontend-dev": "Frontend Developer",
                "backend-dev": "Backend Developer"
            },
            descriptions: {
                "senior-dev": "Design and implement full-stack solutions with React, Node.js, and modern databases. Focus on performance, accessibility, and best practices.",
                "dev-lead": "Lead agile teams, define technical architecture, and mentor developers in best practices and testing.",
                "frontend-dev": "Build modern UIs with React, TypeScript, and Tailwind CSS. Prioritize UX, accessibility, and performance.",
                "backend-dev": "Create RESTful APIs and backend services with Node.js, Express, and SQL/NoSQL databases. Use automated testing throughout the pipeline."
            }
        },
        education: {
            degrees: {
                "computer-science": "Computer Science Engineering",
                "web-dev-bootcamp": "Web Development Bootcamp",
                "tdd-course": "Test-Driven Development Course"
            },
            descriptions: {
                "computer-science": "Solid foundation in algorithms, data structures, networking, and software development.",
                "web-dev-bootcamp": "Intensive training in modern technologies: React, Node.js, MongoDB, Docker.",
                "tdd-course": "Advanced focus on automated testing, code quality, and agile development cycles."
            }
        },
        projects: {
            txtResults: "Results",
            buttons: {
                viewResults: "View Results",
                hideResults: "Hide Results",
                viewOnGithub: "View on GitHub"
            },
            titles: {
                "e-commerce-platform": "E-commerce Platform",
                "task-manager-app": "Task Manager App",
                "weather-dashboard": "Real-Time Weather Dashboard",
                "blog-engine": "Blog Engine with CMS"
            },
            descriptions: {
                "e-commerce-platform": "Full platform with cart, Stripe payment gateway, and admin panel. Built with React, Node.js, and MongoDB.",
                "task-manager-app": "Task management app with auth, drag & drop, and real-time sync. Used React, Firebase, and Framer Motion.",
                "weather-dashboard": "Interactive dashboard showing current weather and forecast using OpenWeather API. Responsive design with smooth animations.",
                "blog-engine": "Blog engine with WYSIWYG editor, comments, and advanced SEO. Backend in Node.js with Express and PostgreSQL."
            },
            results: {
                "e-commerce-platform": ["+10,000 monthly visits", "Successful Stripe integration", "95% user satisfaction"],
                "task-manager-app": ["100% unit test coverage", "Optimized performance (<100ms)", "Available on web and mobile"],
                "weather-dashboard": ["Accurate real-time data", "Support for 200,000+ cities", "Accessible and responsive design"],
                "blog-engine": ["SEO optimized (Lighthouse >90)", "Intuitive editor for non-tech users", "Moderated comments"]
            }
        },
        skills: {
            txtHeader: "Technical Skills",
            intro: "My skills have been developed over years building modern web applications, with a focus on quality, performance, and maintainability.",
            categories: {
                frontend: "Frontend",
                backend: "Backend",
                devops: "DevOps & Cloud",
                databases: "Databases",
                testing: "Testing & Quality",
                other: "Other"
            },
            items: {
                react: "React",
                javascript: "JavaScript",
                typescript: "TypeScript",
                tailwind: "Tailwind CSS",
                nodejs: "Node.js",
                express: "Express",
                docker: "Docker",
                git: "Git & GitHub",
                postgresql: "PostgreSQL",
                mysql: "MySQL",
                mongodb: "MongoDB",
                redis: "Redis",
                jest: "Jest, Testing Library",
                playwright: "Playwright (E2E)",
                languages: "C,C++"
            }
        },
        hero: {
            btnDownload: "📄 Download CV",
            btnContact: "✉️ Contact me"
        },
        contact: {
            message: "Have a project in mind? Let's talk!",
            form: {
                name: "Name",
                email: "Email",
                message: "Message",
                buttonText: "Send",
                sending: "Sending...",
                error: "There was an error. Please try again later.",
                success: "Message sent! I'll get back to you soon.",
                invalidEmail: "Please enter a valid email address."
            }
        },
        footer: {
            developedBy: "Designed and developed by",
            rights: "All rights reserved"
        },
        ats: {
            summary: "{name} is a {roles} with experience in {skills}. Developer of modern web applications with focus on quality, performance, and scalability.",
            keyProjects: "Key projects: {projects}.",
            experience: "Professional experience at {company} leading full-stack development in agile environments.",
            contact: "Contact: {email}. Available on {social}.",
            languages: "Languages: Spanish (native), English (professional).",
            keywords: "Keywords:"
        }
    },
    w1 = {
        es: o_,
        en: u_
    },
    by = J.createContext(),
    yu = () => {
        const n = J.useContext(by);
        if (!n) throw new Error("useTranslation must be used within a TranslationProvider");
        return n
    },
    c_ = ({
        children: n
    }) => {
        const [e, a] = J.useState("en");
        J.useEffect(() => {
            const o = localStorage.getItem("language"),
                c = navigator.language || navigator.userLanguage,
                f = o && ["es", "en"].includes(o) ? o : c.startsWith("es") ? "es" : "en";
            a(f), document.documentElement.lang = f
        }, []);
        const s = o => {
                w1[o] && (a(o), localStorage.setItem("language", o), document.documentElement.lang = o)
            },
            l = w1[e];
        return A.jsx(by.Provider, {
            value: {
                t: l,
                lang: e,
                switchLanguage: s
            },
            children: n
        })
    },
    f_ = () => {
        const [n, e] = J.useState(!1), {
            t: a,
            lang: s
        } = yu();
        return A.jsx("nav", {
            className: "fixed top-0 left-0 w-full bg-white/90 dark:bg-gray-900/90 backdrop-blur-md shadow-sm z-50",
            children: A.jsxs("div", {
                className: "container mx-auto px-6 py-4",
                children: [A.jsxs("div", {
                    className: "flex justify-between items-center",
                    children: [A.jsx("h1", {
                        className: "text-xl font-bold text-emerald-600 dark:text-emerald-400",
                        children: "Portfolio"
                    }), A.jsxs("div", {
                        className: "hidden md:flex items-center gap-6",
                        children: [_1.map(l => A.jsx("a", {
                            href: l.href,
                            className: "text-gray-700 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-colors duration-200",
                            children: a.nav[l.id]
                        }, l.id)), A.jsx(E1, {})]
                    }), A.jsxs("div", {
                        className: "flex items-center gap-4 md:hidden",
                        children: [A.jsx(E1, {}), A.jsx("button", {
                            onClick: () => e(!n),
                            className: "text-gray-700 dark:text-gray-300 focus:outline-none",
                            "aria-label": "Toggle menu",
                            children: A.jsx("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                className: "h-6 w-6",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                stroke: "currentColor",
                                children: n ? A.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M6 18L18 6M6 6l12 12"
                                }) : A.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: 2,
                                    d: "M4 6h16M4 12h16M4 18h16"
                                })
                            })
                        })]
                    })]
                }), A.jsx("div", {
                    className: `md:hidden mt-4 ${n?"block":"hidden"}`,
                    children: A.jsx("ul", {
                        className: "space-y-2 bg-white dark:bg-gray-800 p-4 rounded-lg shadow-lg",
                        children: _1.map(l => A.jsx("li", {
                            children: A.jsx("a", {
                                href: l.href,
                                onClick: () => e(!1),
                                className: "block px-4 py-2 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition",
                                children: a.nav[l.id]
                            })
                        }, l.id))
                    })
                })]
            })
        }, s)
    };
var xy = {
        color: void 0,
        size: void 0,
        className: void 0,
        style: void 0,
        attr: void 0
    },
    M1 = xe.createContext && xe.createContext(xy),
    d_ = ["attr", "size", "title"];

function h_(n, e) {
    if (n == null) return {};
    var a = m_(n, e),
        s, l;
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(n);
        for (l = 0; l < o.length; l++) s = o[l], !(e.indexOf(s) >= 0) && Object.prototype.propertyIsEnumerable.call(n, s) && (a[s] = n[s])
    }
    return a
}

function m_(n, e) {
    if (n == null) return {};
    var a = {};
    for (var s in n)
        if (Object.prototype.hasOwnProperty.call(n, s)) {
            if (e.indexOf(s) >= 0) continue;
            a[s] = n[s]
        }
    return a
}

function Jo() {
    return Jo = Object.assign ? Object.assign.bind() : function(n) {
        for (var e = 1; e < arguments.length; e++) {
            var a = arguments[e];
            for (var s in a) Object.prototype.hasOwnProperty.call(a, s) && (n[s] = a[s])
        }
        return n
    }, Jo.apply(this, arguments)
}

function A1(n, e) {
    var a = Object.keys(n);
    if (Object.getOwnPropertySymbols) {
        var s = Object.getOwnPropertySymbols(n);
        e && (s = s.filter(function(l) {
            return Object.getOwnPropertyDescriptor(n, l).enumerable
        })), a.push.apply(a, s)
    }
    return a
}

function eu(n) {
    for (var e = 1; e < arguments.length; e++) {
        var a = arguments[e] != null ? arguments[e] : {};
        e % 2 ? A1(Object(a), !0).forEach(function(s) {
            p_(n, s, a[s])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(n, Object.getOwnPropertyDescriptors(a)) : A1(Object(a)).forEach(function(s) {
            Object.defineProperty(n, s, Object.getOwnPropertyDescriptor(a, s))
        })
    }
    return n
}

function p_(n, e, a) {
    return e = g_(e), e in n ? Object.defineProperty(n, e, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : n[e] = a, n
}

function g_(n) {
    var e = v_(n, "string");
    return typeof e == "symbol" ? e : e + ""
}

function v_(n, e) {
    if (typeof n != "object" || !n) return n;
    var a = n[Symbol.toPrimitive];
    if (a !== void 0) {
        var s = a.call(n, e);
        if (typeof s != "object") return s;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(n)
}

function Sy(n) {
    return n && n.map((e, a) => xe.createElement(e.tag, eu({
        key: a
    }, e.attr), Sy(e.child)))
}

function Pe(n) {
    return e => xe.createElement(y_, Jo({
        attr: eu({}, n.attr)
    }, e), Sy(n.child))
}

function y_(n) {
    var e = a => {
        var {
            attr: s,
            size: l,
            title: o
        } = n, c = h_(n, d_), h = l || a.size || "1em", f;
        return a.className && (f = a.className), n.className && (f = (f ? f + " " : "") + n.className), xe.createElement("svg", Jo({
            stroke: "currentColor",
            fill: "currentColor",
            strokeWidth: "0"
        }, a.attr, s, c, {
            className: f,
            style: eu(eu({
                color: n.color || a.color
            }, a.style), n.style),
            height: h,
            width: h,
            xmlns: "http://www.w3.org/2000/svg"
        }), o && xe.createElement("title", null, o), n.children)
    };
    return M1 !== void 0 ? xe.createElement(M1.Consumer, null, a => e(a)) : e(xy)
}

function b_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 640 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M524.531,69.836a1.5,1.5,0,0,0-.764-.7A485.065,485.065,0,0,0,404.081,32.03a1.816,1.816,0,0,0-1.923.91,337.461,337.461,0,0,0-14.9,30.6,447.848,447.848,0,0,0-134.426,0,309.541,309.541,0,0,0-15.135-30.6,1.89,1.89,0,0,0-1.924-.91A483.689,483.689,0,0,0,116.085,69.137a1.712,1.712,0,0,0-.788.676C39.068,183.651,18.186,294.69,28.43,404.354a2.016,2.016,0,0,0,.765,1.375A487.666,487.666,0,0,0,176.02,479.918a1.9,1.9,0,0,0,2.063-.676A348.2,348.2,0,0,0,208.12,430.4a1.86,1.86,0,0,0-1.019-2.588,321.173,321.173,0,0,1-45.868-21.853,1.885,1.885,0,0,1-.185-3.126c3.082-2.309,6.166-4.711,9.109-7.137a1.819,1.819,0,0,1,1.9-.256c96.229,43.917,200.41,43.917,295.5,0a1.812,1.812,0,0,1,1.924.233c2.944,2.426,6.027,4.851,9.132,7.16a1.884,1.884,0,0,1-.162,3.126,301.407,301.407,0,0,1-45.89,21.83,1.875,1.875,0,0,0-1,2.611,391.055,391.055,0,0,0,30.014,48.815,1.864,1.864,0,0,0,2.063.7A486.048,486.048,0,0,0,610.7,405.729a1.882,1.882,0,0,0,.765-1.352C623.729,277.594,590.933,167.465,524.531,69.836ZM222.491,337.58c-28.972,0-52.844-26.587-52.844-59.239S193.056,219.1,222.491,219.1c29.665,0,53.306,26.82,52.843,59.239C275.334,310.993,251.924,337.58,222.491,337.58Zm195.38,0c-28.971,0-52.843-26.587-52.843-59.239S388.437,219.1,417.871,219.1c29.667,0,53.307,26.82,52.844,59.239C470.715,310.993,447.538,337.58,417.871,337.58Z"
            },
            child: []
        }]
    })(n)
}

function x_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 496 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M165.9 397.4c0 2-2.3 3.6-5.2 3.6-3.3.3-5.6-1.3-5.6-3.6 0-2 2.3-3.6 5.2-3.6 3-.3 5.6 1.3 5.6 3.6zm-31.1-4.5c-.7 2 1.3 4.3 4.3 4.9 2.6 1 5.6 0 6.2-2s-1.3-4.3-4.3-5.2c-2.6-.7-5.5.3-6.2 2.3zm44.2-1.7c-2.9.7-4.9 2.6-4.6 4.9.3 2 2.9 3.3 5.9 2.6 2.9-.7 4.9-2.6 4.6-4.6-.3-1.9-3-3.2-5.9-2.9zM244.8 8C106.1 8 0 113.3 0 252c0 110.9 69.8 205.8 169.5 239.2 12.8 2.3 17.3-5.6 17.3-12.1 0-6.2-.3-40.4-.3-61.4 0 0-70 15-84.7-29.8 0 0-11.4-29.1-27.8-36.6 0 0-22.9-15.7 1.6-15.4 0 0 24.9 2 38.6 25.8 21.9 38.6 58.6 27.5 72.9 20.9 2.3-16 8.8-27.1 16-33.7-55.9-6.2-112.3-14.3-112.3-110.5 0-27.5 7.6-41.3 23.6-58.9-2.6-6.5-11.1-33.3 2.6-67.9 20.9-6.5 69 27 69 27 20-5.6 41.5-8.5 62.8-8.5s42.8 2.9 62.8 8.5c0 0 48.1-33.6 69-27 13.7 34.7 5.2 61.4 2.6 67.9 16 17.7 25.8 31.5 25.8 58.9 0 96.5-58.9 104.2-114.8 110.5 9.2 7.9 17 22.9 17 46.4 0 33.7-.3 75.4-.3 83.6 0 6.5 4.6 14.4 17.3 12.1C428.2 457.8 496 362.9 496 252 496 113.3 383.5 8 244.8 8zM97.2 352.9c-1.3 1-1 3.3.7 5.2 1.6 1.6 3.9 2.3 5.2 1 1.3-1 1-3.3-.7-5.2-1.6-1.6-3.9-2.3-5.2-1zm-10.8-8.1c-.7 1.3.3 2.9 2.3 3.9 1.6 1 3.6.7 4.3-.7.7-1.3-.3-2.9-2.3-3.9-2-.6-3.6-.3-4.3.7zm32.4 35.6c-1.6 1.3-1 4.3 1.3 6.2 2.3 2.3 5.2 2.6 6.5 1 1.3-1.3.7-4.3-1.3-6.2-2.2-2.3-5.2-2.6-6.5-1zm-11.4-14.7c-1.6 1-1.6 3.6 0 5.9 1.6 2.3 4.3 3.3 5.6 2.3 1.6-1.3 1.6-3.9 0-6.2-1.4-2.3-4-3.3-5.6-2z"
            },
            child: []
        }]
    })(n)
}

function yh(n) {
    return Pe({
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M416 32H31.9C14.3 32 0 46.5 0 64.3v383.4C0 465.5 14.3 480 31.9 480H416c17.6 0 32-14.5 32-32.3V64.3c0-17.8-14.4-32.3-32-32.3zM135.4 416H69V202.2h66.5V416zm-33.2-243c-21.3 0-38.5-17.3-38.5-38.5S80.9 96 102.2 96c21.2 0 38.5 17.3 38.5 38.5 0 21.3-17.2 38.5-38.5 38.5zm282.1 243h-66.4V312c0-24.8-.5-56.7-34.5-56.7-34.6 0-39.9 27-39.9 54.9V416h-66.4V202.2h63.7v29.2h.9c8.9-16.8 30.6-34.5 62.9-34.5 67.2 0 79.7 44.3 79.7 101.9V416z"
            },
            child: []
        }]
    })(n)
}

function Ty(n) {
    return Pe({
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"
            },
            child: []
        }]
    })(n)
}

function S_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 384 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M97.12 362.63c-8.69-8.69-4.16-6.24-25.12-11.85-9.51-2.55-17.87-7.45-25.43-13.32L1.2 448.7c-4.39 10.77 3.81 22.47 15.43 22.03l52.69-2.01L105.56 507c8 8.44 22.04 5.81 26.43-4.96l52.05-127.62c-10.84 6.04-22.87 9.58-35.31 9.58-19.5 0-37.82-7.59-51.61-21.37zM382.8 448.7l-45.37-111.24c-7.56 5.88-15.92 10.77-25.43 13.32-21.07 5.64-16.45 3.18-25.12 11.85-13.79 13.78-32.12 21.37-51.62 21.37-12.44 0-24.47-3.55-35.31-9.58L252 502.04c4.39 10.77 18.44 13.4 26.43 4.96l36.25-38.28 52.69 2.01c11.62.44 19.82-11.27 15.43-22.03zM263 340c15.28-15.55 17.03-14.21 38.79-20.14 13.89-3.79 24.75-14.84 28.47-28.98 7.48-28.4 5.54-24.97 25.95-45.75 10.17-10.35 14.14-25.44 10.42-39.58-7.47-28.38-7.48-24.42 0-52.83 3.72-14.14-.25-29.23-10.42-39.58-20.41-20.78-18.47-17.36-25.95-45.75-3.72-14.14-14.58-25.19-28.47-28.98-27.88-7.61-24.52-5.62-44.95-26.41-10.17-10.35-25-14.4-38.89-10.61-27.87 7.6-23.98 7.61-51.9 0-13.89-3.79-28.72.25-38.89 10.61-20.41 20.78-17.05 18.8-44.94 26.41-13.89 3.79-24.75 14.84-28.47 28.98-7.47 28.39-5.54 24.97-25.95 45.75-10.17 10.35-14.15 25.44-10.42 39.58 7.47 28.36 7.48 24.4 0 52.82-3.72 14.14.25 29.23 10.42 39.59 20.41 20.78 18.47 17.35 25.95 45.75 3.72 14.14 14.58 25.19 28.47 28.98C104.6 325.96 106.27 325 121 340c13.23 13.47 33.84 15.88 49.74 5.82a39.676 39.676 0 0 1 42.53 0c15.89 10.06 36.5 7.65 49.73-5.82zM97.66 175.96c0-53.03 42.24-96.02 94.34-96.02s94.34 42.99 94.34 96.02-42.24 96.02-94.34 96.02-94.34-42.99-94.34-96.02z"
            },
            child: []
        }]
    })(n)
}

function T_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M448 360V24c0-13.3-10.7-24-24-24H96C43 0 0 43 0 96v320c0 53 43 96 96 96h328c13.3 0 24-10.7 24-24v-16c0-7.5-3.5-14.3-8.9-18.7-4.2-15.4-4.2-59.3 0-74.7 5.4-4.3 8.9-11.1 8.9-18.6zM128 134c0-3.3 2.7-6 6-6h212c3.3 0 6 2.7 6 6v20c0 3.3-2.7 6-6 6H134c-3.3 0-6-2.7-6-6v-20zm0 64c0-3.3 2.7-6 6-6h212c3.3 0 6 2.7 6 6v20c0 3.3-2.7 6-6 6H134c-3.3 0-6-2.7-6-6v-20zm253.4 250H96c-17.7 0-32-14.3-32-32 0-17.6 14.4-32 32-32h285.4c-1.9 17.1-1.9 46.9 0 64z"
            },
            child: []
        }]
    })(n)
}

function __(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M464 128h-80V80c0-26.5-21.5-48-48-48H176c-26.5 0-48 21.5-48 48v48H48c-26.5 0-48 21.5-48 48v288c0 26.5 21.5 48 48 48h416c26.5 0 48-21.5 48-48V176c0-26.5-21.5-48-48-48zM192 96h128v32H192V96zm160 248c0 4.4-3.6 8-8 8h-56v56c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8v-56h-56c-4.4 0-8-3.6-8-8v-48c0-4.4 3.6-8 8-8h56v-56c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v56h56c4.4 0 8 3.6 8 8v48z"
            },
            child: []
        }]
    })(n)
}

function E_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M0 464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48V192H0v272zm320-196c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12h-40c-6.6 0-12-5.4-12-12v-40zm0 128c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12h-40c-6.6 0-12-5.4-12-12v-40zM192 268c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12h-40c-6.6 0-12-5.4-12-12v-40zm0 128c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12h-40c-6.6 0-12-5.4-12-12v-40zM64 268c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12H76c-6.6 0-12-5.4-12-12v-40zm0 128c0-6.6 5.4-12 12-12h40c6.6 0 12 5.4 12 12v40c0 6.6-5.4 12-12 12H76c-6.6 0-12-5.4-12-12v-40zM400 64h-48V16c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v48H160V16c0-8.8-7.2-16-16-16h-32c-8.8 0-16 7.2-16 16v48H48C21.5 64 0 85.5 0 112v48h448v-48c0-26.5-21.5-48-48-48z"
            },
            child: []
        }]
    })(n)
}

function w_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M504 256c0 136.967-111.033 248-248 248S8 392.967 8 256 119.033 8 256 8s248 111.033 248 248zM227.314 387.314l184-184c6.248-6.248 6.248-16.379 0-22.627l-22.627-22.627c-6.248-6.249-16.379-6.249-22.628 0L216 308.118l-70.059-70.059c-6.248-6.248-16.379-6.248-22.628 0l-22.627 22.627c-6.248 6.248-6.248 16.379 0 22.627l104 104c6.249 6.249 16.379 6.249 22.628.001z"
            },
            child: []
        }]
    })(n)
}

function _y(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M505 174.8l-39.6-39.6c-9.4-9.4-24.6-9.4-33.9 0L192 374.7 80.6 263.2c-9.4-9.4-24.6-9.4-33.9 0L7 302.9c-9.4 9.4-9.4 24.6 0 34L175 505c9.4 9.4 24.6 9.4 33.9 0l296-296.2c9.4-9.5 9.4-24.7.1-34zm-324.3 106c6.2 6.3 16.4 6.3 22.6 0l208-208.2c6.2-6.3 6.2-16.4 0-22.6L366.1 4.7c-6.2-6.3-16.4-6.3-22.6 0L192 156.2l-55.4-55.5c-6.2-6.3-16.4-6.3-22.6 0L68.7 146c-6.2 6.3-6.2 16.4 0 22.6l112 112.2z"
            },
            child: []
        }]
    })(n)
}

function M_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 576 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M288 115L69.47 307.71c-1.62 1.46-3.69 2.14-5.47 3.35V496a16 16 0 0 0 16 16h416a16 16 0 0 0 16-16V311.1c-1.7-1.16-3.72-1.82-5.26-3.2zm96 261a8 8 0 0 1-8 8h-56v56a8 8 0 0 1-8 8h-48a8 8 0 0 1-8-8v-56h-56a8 8 0 0 1-8-8v-48a8 8 0 0 1 8-8h56v-56a8 8 0 0 1 8-8h48a8 8 0 0 1 8 8v56h56a8 8 0 0 1 8 8zm186.69-139.72l-255.94-226a39.85 39.85 0 0 0-53.45 0l-256 226a16 16 0 0 0-1.21 22.6L25.5 282.7a16 16 0 0 0 22.6 1.21L277.42 81.63a16 16 0 0 1 21.17 0L527.91 283.9a16 16 0 0 0 22.6-1.21l21.4-23.82a16 16 0 0 0-1.22-22.59z"
            },
            child: []
        }]
    })(n)
}

function bh(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M502.3 190.8c3.9-3.1 9.7-.2 9.7 4.7V400c0 26.5-21.5 48-48 48H48c-26.5 0-48-21.5-48-48V195.6c0-5 5.7-7.8 9.7-4.7 22.4 17.4 52.1 39.5 154.1 113.6 21.1 15.4 56.7 47.8 92.2 47.6 35.7.3 72-32.8 92.3-47.6 102-74.1 131.6-96.3 154-113.7zM256 320c23.2.4 56.6-29.2 73.4-41.4 132.7-96.3 142.8-104.7 173.4-128.7 5.8-4.5 9.2-11.5 9.2-18.9v-19c0-26.5-21.5-48-48-48H48C21.5 64 0 85.5 0 112v19c0 7.4 3.4 14.3 9.2 18.9 30.6 23.9 40.7 32.4 173.4 128.7 16.8 12.2 50.2 41.8 73.4 41.4z"
            },
            child: []
        }]
    })(n)
}

function A_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M432,320H400a16,16,0,0,0-16,16V448H64V128H208a16,16,0,0,0,16-16V80a16,16,0,0,0-16-16H48A48,48,0,0,0,0,112V464a48,48,0,0,0,48,48H400a48,48,0,0,0,48-48V336A16,16,0,0,0,432,320ZM488,0h-128c-21.37,0-32.05,25.91-17,41l35.73,35.73L135,320.37a24,24,0,0,0,0,34L157.67,377a24,24,0,0,0,34,0L435.28,133.32,471,169c15,15,41,4.5,41-17V24A24,24,0,0,0,488,0Z"
            },
            child: []
        }]
    })(n)
}

function C_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 384 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M224 136V0H24C10.7 0 0 10.7 0 24v464c0 13.3 10.7 24 24 24h336c13.3 0 24-10.7 24-24V160H248c-13.2 0-24-10.8-24-24zm76.45 211.36l-96.42 95.7c-6.65 6.61-17.39 6.61-24.04 0l-96.42-95.7C73.42 337.29 80.54 320 94.82 320H160v-80c0-8.84 7.16-16 16-16h32c8.84 0 16 7.16 16 16v80h65.18c14.28 0 21.4 17.29 11.27 27.36zM377 105L279.1 7c-4.5-4.5-10.6-7-17-7H256v128h128v-6.1c0-6.3-2.5-12.4-7-16.9z"
            },
            child: []
        }]
    })(n)
}

function O_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 496 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M248 8C111.03 8 0 119.03 0 256s111.03 248 248 248 248-111.03 248-248S384.97 8 248 8zm82.29 357.6c-3.9 3.88-7.99 7.95-11.31 11.28-2.99 3-5.1 6.7-6.17 10.71-1.51 5.66-2.73 11.38-4.77 16.87l-17.39 46.85c-13.76 3-28 4.69-42.65 4.69v-27.38c1.69-12.62-7.64-36.26-22.63-51.25-6-6-9.37-14.14-9.37-22.63v-32.01c0-11.64-6.27-22.34-16.46-27.97-14.37-7.95-34.81-19.06-48.81-26.11-11.48-5.78-22.1-13.14-31.65-21.75l-.8-.72a114.792 114.792 0 0 1-18.06-20.74c-9.38-13.77-24.66-36.42-34.59-51.14 20.47-45.5 57.36-82.04 103.2-101.89l24.01 12.01C203.48 89.74 216 82.01 216 70.11v-11.3c7.99-1.29 16.12-2.11 24.39-2.42l28.3 28.3c6.25 6.25 6.25 16.38 0 22.63L264 112l-10.34 10.34c-3.12 3.12-3.12 8.19 0 11.31l4.69 4.69c3.12 3.12 3.12 8.19 0 11.31l-8 8a8.008 8.008 0 0 1-5.66 2.34h-8.99c-2.08 0-4.08.81-5.58 2.27l-9.92 9.65a8.008 8.008 0 0 0-1.58 9.31l15.59 31.19c2.66 5.32-1.21 11.58-7.15 11.58h-5.64c-1.93 0-3.79-.7-5.24-1.96l-9.28-8.06a16.017 16.017 0 0 0-15.55-3.1l-31.17 10.39a11.95 11.95 0 0 0-8.17 11.34c0 4.53 2.56 8.66 6.61 10.69l11.08 5.54c9.41 4.71 19.79 7.16 30.31 7.16s22.59 27.29 32 32h66.75c8.49 0 16.62 3.37 22.63 9.37l13.69 13.69a30.503 30.503 0 0 1 8.93 21.57 46.536 46.536 0 0 1-13.72 32.98zM417 274.25c-5.79-1.45-10.84-5-14.15-9.97l-17.98-26.97a23.97 23.97 0 0 1 0-26.62l19.59-29.38c2.32-3.47 5.5-6.29 9.24-8.15l12.98-6.49C440.2 193.59 448 223.87 448 256c0 8.67-.74 17.16-1.82 25.54L417 274.25z"
            },
            child: []
        }]
    })(n)
}

function Ey(n) {
    return Pe({
        attr: {
            viewBox: "0 0 640 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M622.34 153.2L343.4 67.5c-15.2-4.67-31.6-4.67-46.79 0L17.66 153.2c-23.54 7.23-23.54 38.36 0 45.59l48.63 14.94c-10.67 13.19-17.23 29.28-17.88 46.9C38.78 266.15 32 276.11 32 288c0 10.78 5.68 19.85 13.86 25.65L20.33 428.53C18.11 438.52 25.71 448 35.94 448h56.11c10.24 0 17.84-9.48 15.62-19.47L82.14 313.65C90.32 307.85 96 298.78 96 288c0-11.57-6.47-21.25-15.66-26.87.76-15.02 8.44-28.3 20.69-36.72L296.6 284.5c9.06 2.78 26.44 6.25 46.79 0l278.95-85.7c23.55-7.24 23.55-38.36 0-45.6zM352.79 315.09c-28.53 8.76-52.84 3.92-65.59 0l-145.02-44.55L128 384c0 35.35 85.96 64 192 64s192-28.65 192-64l-14.18-113.47-145.03 44.56z"
            },
            child: []
        }]
    })(n)
}

function D_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 576 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M280.37 148.26L96 300.11V464a16 16 0 0 0 16 16l112.06-.29a16 16 0 0 0 15.92-16V368a16 16 0 0 1 16-16h64a16 16 0 0 1 16 16v95.64a16 16 0 0 0 16 16.05L464 480a16 16 0 0 0 16-16V300L295.67 148.26a12.19 12.19 0 0 0-15.3 0zM571.6 251.47L488 182.56V44.05a12 12 0 0 0-12-12h-56a12 12 0 0 0-12 12v72.61L318.47 43a48 48 0 0 0-61 0L4.34 251.47a12 12 0 0 0-1.6 16.9l25.5 31A12 12 0 0 0 45.15 301l235.22-193.74a12.19 12.19 0 0 1 15.3 0L530.9 301a12 12 0 0 0 16.9-1.6l25.5-31a12 12 0 0 0-1.7-16.93z"
            },
            child: []
        }]
    })(n)
}

function z_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M448 492v20H0v-20c0-6.627 5.373-12 12-12h20V120c0-13.255 10.745-24 24-24h88V24c0-13.255 10.745-24 24-24h112c13.255 0 24 10.745 24 24v72h88c13.255 0 24 10.745 24 24v360h20c6.627 0 12 5.373 12 12zM308 192h-40c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12zm-168 64h40c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-40c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12zm104 128h-40c-6.627 0-12 5.373-12 12v84h64v-84c0-6.627-5.373-12-12-12zm64-96h-40c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12zm-116 12c0-6.627-5.373-12-12-12h-40c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-40zM182 96h26v26a6 6 0 0 0 6 6h20a6 6 0 0 0 6-6V96h26a6 6 0 0 0 6-6V70a6 6 0 0 0-6-6h-26V38a6 6 0 0 0-6-6h-20a6 6 0 0 0-6 6v26h-26a6 6 0 0 0-6 6v20a6 6 0 0 0 6 6z"
            },
            child: []
        }]
    })(n)
}

function xh(n) {
    return Pe({
        attr: {
            viewBox: "0 0 384 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M172.268 501.67C26.97 291.031 0 269.413 0 192 0 85.961 85.961 0 192 0s192 85.961 192 192c0 77.413-26.97 99.031-172.268 309.67-9.535 13.774-29.93 13.773-39.464 0zM192 272c44.183 0 80-35.817 80-80s-35.817-80-80-80-80 35.817-80 80 35.817 80 80 80z"
            },
            child: []
        }]
    })(n)
}

function R_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M256 8C119 8 8 119 8 256s111 248 248 248 248-111 248-248S393 8 256 8zm115.7 272l-176 101c-15.8 8.8-35.7-2.5-35.7-21V152c0-18.4 19.8-29.8 35.7-21l176 107c16.4 9.2 16.4 32.9 0 42z"
            },
            child: []
        }]
    })(n)
}

function L_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 640 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M0 224v272c0 8.84 7.16 16 16 16h80V192H32c-17.67 0-32 14.33-32 32zm360-48h-24v-40c0-4.42-3.58-8-8-8h-16c-4.42 0-8 3.58-8 8v64c0 4.42 3.58 8 8 8h48c4.42 0 8-3.58 8-8v-16c0-4.42-3.58-8-8-8zm137.75-63.96l-160-106.67a32.02 32.02 0 0 0-35.5 0l-160 106.67A32.002 32.002 0 0 0 128 138.66V512h128V368c0-8.84 7.16-16 16-16h96c8.84 0 16 7.16 16 16v144h128V138.67c0-10.7-5.35-20.7-14.25-26.63zM320 256c-44.18 0-80-35.82-80-80s35.82-80 80-80 80 35.82 80 80-35.82 80-80 80zm288-64h-64v320h80c8.84 0 16-7.16 16-16V224c0-17.67-14.33-32-32-32z"
            },
            child: []
        }]
    })(n)
}

function j_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 576 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M259.3 17.8L194 150.2 47.9 171.5c-26.2 3.8-36.7 36.1-17.7 54.6l105.7 103-25 145.5c-4.5 26.3 23.2 46 46.4 33.7L288 439.6l130.7 68.7c23.2 12.2 50.9-7.4 46.4-33.7l-25-145.5 105.7-103c19-18.5 8.5-50.8-17.7-54.6L382 150.2 316.7 17.8c-11.7-23.6-45.6-23.9-57.4 0z"
            },
            child: []
        }]
    })(n)
}

function N_(n) {
    return Pe({
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M319.4 320.6L224 416l-95.4-95.4C57.1 323.7 0 382.2 0 454.4v9.6c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-9.6c0-72.2-57.1-130.7-128.6-133.8zM13.6 79.8l6.4 1.5v58.4c-7 4.2-12 11.5-12 20.3 0 8.4 4.6 15.4 11.1 19.7L3.5 242c-1.7 6.9 2.1 14 7.6 14h41.8c5.5 0 9.3-7.1 7.6-14l-15.6-62.3C51.4 175.4 56 168.4 56 160c0-8.8-5-16.1-12-20.3V87.1l66 15.9c-8.6 17.2-14 36.4-14 57 0 70.7 57.3 128 128 128s128-57.3 128-128c0-20.6-5.3-39.8-14-57l96.3-23.2c18.2-4.4 18.2-27.1 0-31.5l-190.4-46c-13-3.1-26.7-3.1-39.7 0L13.6 48.2c-18.1 4.4-18.1 27.2 0 31.6z"
            },
            child: []
        }]
    })(n)
}

function ei(n) {
    if (n === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return n
}

function wy(n, e) {
    n.prototype = Object.create(e.prototype), n.prototype.constructor = n, n.__proto__ = e
}
/*!
 * GSAP 3.14.2
 * https://gsap.com
 *
 * @license Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
 */
var Wt = {
        autoSleep: 120,
        force3D: "auto",
        nullTargetWarn: 1,
        units: {
            lineHeight: ""
        }
    },
    As = {
        duration: .5,
        overwrite: !1,
        delay: 0
    },
    Sh, pt, ke, pn = 1e8,
    Le = 1 / pn,
    Od = Math.PI * 2,
    V_ = Od / 4,
    k_ = 0,
    My = Math.sqrt,
    B_ = Math.cos,
    P_ = Math.sin,
    ct = function(e) {
        return typeof e == "string"
    },
    Ze = function(e) {
        return typeof e == "function"
    },
    ni = function(e) {
        return typeof e == "number"
    },
    Th = function(e) {
        return typeof e > "u"
    },
    kn = function(e) {
        return typeof e == "object"
    },
    Rt = function(e) {
        return e !== !1
    },
    _h = function() {
        return typeof window < "u"
    },
    ko = function(e) {
        return Ze(e) || ct(e)
    },
    Ay = typeof ArrayBuffer == "function" && ArrayBuffer.isView || function() {},
    St = Array.isArray,
    U_ = /random\([^)]+\)/g,
    H_ = /,\s*/g,
    C1 = /(?:-?\.?\d|\.)+/gi,
    Cy = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,
    hs = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g,
    Kf = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,
    Oy = /[+-]=-?[.\d]+/,
    G_ = /[^,'"\[\]\s]+/gi,
    q_ = /^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,
    Ge, Dn, Dd, Eh, Jt = {},
    tu = {},
    Dy, zy = function(e) {
        return (tu = Cs(e, Jt)) && Vt
    },
    wh = function(e, a) {
        return console.warn("Invalid property", e, "set to", a, "Missing plugin? gsap.registerPlugin()")
    },
    el = function(e, a) {
        return !a && console.warn(e)
    },
    Ry = function(e, a) {
        return e && (Jt[e] = a) && tu && (tu[e] = a) || Jt
    },
    tl = function() {
        return 0
    },
    Y_ = {
        suppressEvents: !0,
        isStart: !0,
        kill: !1
    },
    qo = {
        suppressEvents: !0,
        kill: !1
    },
    X_ = {
        suppressEvents: !0
    },
    Mh = {},
    Vi = [],
    zd = {},
    Ly, Kt = {},
    Zf = {},
    O1 = 30,
    Yo = [],
    Ah = "",
    Ch = function(e) {
        var a = e[0],
            s, l;
        if (kn(a) || Ze(a) || (e = [e]), !(s = (a._gsap || {}).harness)) {
            for (l = Yo.length; l-- && !Yo[l].targetTest(a););
            s = Yo[l]
        }
        for (l = e.length; l--;) e[l] && (e[l]._gsap || (e[l]._gsap = new i2(e[l], s))) || e.splice(l, 1);
        return e
    },
    va = function(e) {
        return e._gsap || Ch(gn(e))[0]._gsap
    },
    jy = function(e, a, s) {
        return (s = e[a]) && Ze(s) ? e[a]() : Th(s) && e.getAttribute && e.getAttribute(a) || s
    },
    Lt = function(e, a) {
        return (e = e.split(",")).forEach(a) || e
    },
    We = function(e) {
        return Math.round(e * 1e5) / 1e5 || 0
    },
    He = function(e) {
        return Math.round(e * 1e7) / 1e7 || 0
    },
    xs = function(e, a) {
        var s = a.charAt(0),
            l = parseFloat(a.substr(2));
        return e = parseFloat(e), s === "+" ? e + l : s === "-" ? e - l : s === "*" ? e * l : e / l
    },
    F_ = function(e, a) {
        for (var s = a.length, l = 0; e.indexOf(a[l]) < 0 && ++l < s;);
        return l < s
    },
    nu = function() {
        var e = Vi.length,
            a = Vi.slice(0),
            s, l;
        for (zd = {}, Vi.length = 0, s = 0; s < e; s++) l = a[s], l && l._lazy && (l.render(l._lazy[0], l._lazy[1], !0)._lazy = 0)
    },
    Oh = function(e) {
        return !!(e._initted || e._startAt || e.add)
    },
    Ny = function(e, a, s, l) {
        Vi.length && !pt && nu(), e.render(a, s, !!(pt && a < 0 && Oh(e))), Vi.length && !pt && nu()
    },
    Vy = function(e) {
        var a = parseFloat(e);
        return (a || a === 0) && (e + "").match(G_).length < 2 ? a : ct(e) ? e.trim() : e
    },
    ky = function(e) {
        return e
    },
    en = function(e, a) {
        for (var s in a) s in e || (e[s] = a[s]);
        return e
    },
    K_ = function(e) {
        return function(a, s) {
            for (var l in s) l in a || l === "duration" && e || l === "ease" || (a[l] = s[l])
        }
    },
    Cs = function(e, a) {
        for (var s in a) e[s] = a[s];
        return e
    },
    D1 = function n(e, a) {
        for (var s in a) s !== "__proto__" && s !== "constructor" && s !== "prototype" && (e[s] = kn(a[s]) ? n(e[s] || (e[s] = {}), a[s]) : a[s]);
        return e
    },
    iu = function(e, a) {
        var s = {},
            l;
        for (l in e) l in a || (s[l] = e[l]);
        return s
    },
    Xr = function(e) {
        var a = e.parent || Ge,
            s = e.keyframes ? K_(St(e.keyframes)) : en;
        if (Rt(e.inherit))
            for (; a;) s(e, a.vars.defaults), a = a.parent || a._dp;
        return e
    },
    Z_ = function(e, a) {
        for (var s = e.length, l = s === a.length; l && s-- && e[s] === a[s];);
        return s < 0
    },
    By = function(e, a, s, l, o) {
        var c = e[l],
            h;
        if (o)
            for (h = a[o]; c && c[o] > h;) c = c._prev;
        return c ? (a._next = c._next, c._next = a) : (a._next = e[s], e[s] = a), a._next ? a._next._prev = a : e[l] = a, a._prev = c, a.parent = a._dp = e, a
    },
    bu = function(e, a, s, l) {
        s === void 0 && (s = "_first"), l === void 0 && (l = "_last");
        var o = a._prev,
            c = a._next;
        o ? o._next = c : e[s] === a && (e[s] = c), c ? c._prev = o : e[l] === a && (e[l] = o), a._next = a._prev = a.parent = null
    },
    Bi = function(e, a) {
        e.parent && (!a || e.parent.autoRemoveChildren) && e.parent.remove && e.parent.remove(e), e._act = 0
    },
    ya = function(e, a) {
        if (e && (!a || a._end > e._dur || a._start < 0))
            for (var s = e; s;) s._dirty = 1, s = s.parent;
        return e
    },
    Q_ = function(e) {
        for (var a = e.parent; a && a.parent;) a._dirty = 1, a.totalDuration(), a = a.parent;
        return e
    },
    Rd = function(e, a, s, l) {
        return e._startAt && (pt ? e._startAt.revert(qo) : e.vars.immediateRender && !e.vars.autoRevert || e._startAt.render(a, !0, l))
    },
    I_ = function n(e) {
        return !e || e._ts && n(e.parent)
    },
    z1 = function(e) {
        return e._repeat ? Os(e._tTime, e = e.duration() + e._rDelay) * e : 0
    },
    Os = function(e, a) {
        var s = Math.floor(e = He(e / a));
        return e && s === e ? s - 1 : s
    },
    au = function(e, a) {
        return (e - a._start) * a._ts + (a._ts >= 0 ? 0 : a._dirty ? a.totalDuration() : a._tDur)
    },
    xu = function(e) {
        return e._end = He(e._start + (e._tDur / Math.abs(e._ts || e._rts || Le) || 0))
    },
    Su = function(e, a) {
        var s = e._dp;
        return s && s.smoothChildTiming && e._ts && (e._start = He(s._time - (e._ts > 0 ? a / e._ts : ((e._dirty ? e.totalDuration() : e._tDur) - a) / -e._ts)), xu(e), s._dirty || ya(s, e)), e
    },
    Py = function(e, a) {
        var s;
        if ((a._time || !a._dur && a._initted || a._start < e._time && (a._dur || !a.add)) && (s = au(e.rawTime(), a), (!a._dur || gl(0, a.totalDuration(), s) - a._tTime > Le) && a.render(s, !0)), ya(e, a)._dp && e._initted && e._time >= e._dur && e._ts) {
            if (e._dur < e.duration())
                for (s = e; s._dp;) s.rawTime() >= 0 && s.totalTime(s._tTime), s = s._dp;
            e._zTime = -Le
        }
    },
    zn = function(e, a, s, l) {
        return a.parent && Bi(a), a._start = He((ni(s) ? s : s || e !== Ge ? dn(e, s, a) : e._time) + a._delay), a._end = He(a._start + (a.totalDuration() / Math.abs(a.timeScale()) || 0)), By(e, a, "_first", "_last", e._sort ? "_start" : 0), Ld(a) || (e._recent = a), l || Py(e, a), e._ts < 0 && Su(e, e._tTime), e
    },
    Uy = function(e, a) {
        return (Jt.ScrollTrigger || wh("scrollTrigger", a)) && Jt.ScrollTrigger.create(a, e)
    },
    Hy = function(e, a, s, l, o) {
        if (zh(e, a, o), !e._initted) return 1;
        if (!s && e._pt && !pt && (e._dur && e.vars.lazy !== !1 || !e._dur && e.vars.lazy) && Ly !== Qt.frame) return Vi.push(e), e._lazy = [o, l], 1
    },
    $_ = function n(e) {
        var a = e.parent;
        return a && a._ts && a._initted && !a._lock && (a.rawTime() < 0 || n(a))
    },
    Ld = function(e) {
        var a = e.data;
        return a === "isFromStart" || a === "isStart"
    },
    W_ = function(e, a, s, l) {
        var o = e.ratio,
            c = a < 0 || !a && (!e._start && $_(e) && !(!e._initted && Ld(e)) || (e._ts < 0 || e._dp._ts < 0) && !Ld(e)) ? 0 : 1,
            h = e._rDelay,
            f = 0,
            m, p, v;
        if (h && e._repeat && (f = gl(0, e._tDur, a), p = Os(f, h), e._yoyo && p & 1 && (c = 1 - c), p !== Os(e._tTime, h) && (o = 1 - c, e.vars.repeatRefresh && e._initted && e.invalidate())), c !== o || pt || l || e._zTime === Le || !a && e._zTime) {
            if (!e._initted && Hy(e, a, l, s, f)) return;
            for (v = e._zTime, e._zTime = a || (s ? Le : 0), s || (s = a && !v), e.ratio = c, e._from && (c = 1 - c), e._time = 0, e._tTime = f, m = e._pt; m;) m.r(c, m.d), m = m._next;
            a < 0 && Rd(e, a, s, !0), e._onUpdate && !s && It(e, "onUpdate"), f && e._repeat && !s && e.parent && It(e, "onRepeat"), (a >= e._tDur || a < 0) && e.ratio === c && (c && Bi(e, 1), !s && !pt && (It(e, c ? "onComplete" : "onReverseComplete", !0), e._prom && e._prom()))
        } else e._zTime || (e._zTime = a)
    },
    J_ = function(e, a, s) {
        var l;
        if (s > a)
            for (l = e._first; l && l._start <= s;) {
                if (l.data === "isPause" && l._start > a) return l;
                l = l._next
            } else
                for (l = e._last; l && l._start >= s;) {
                    if (l.data === "isPause" && l._start < a) return l;
                    l = l._prev
                }
    },
    Ds = function(e, a, s, l) {
        var o = e._repeat,
            c = He(a) || 0,
            h = e._tTime / e._tDur;
        return h && !l && (e._time *= c / e._dur), e._dur = c, e._tDur = o ? o < 0 ? 1e10 : He(c * (o + 1) + e._rDelay * o) : c, h > 0 && !l && Su(e, e._tTime = e._tDur * h), e.parent && xu(e), s || ya(e.parent, e), e
    },
    R1 = function(e) {
        return e instanceof _t ? ya(e) : Ds(e, e._dur)
    },
    e4 = {
        _start: 0,
        endTime: tl,
        totalDuration: tl
    },
    dn = function n(e, a, s) {
        var l = e.labels,
            o = e._recent || e4,
            c = e.duration() >= pn ? o.endTime(!1) : e._dur,
            h, f, m;
        return ct(a) && (isNaN(a) || a in l) ? (f = a.charAt(0), m = a.substr(-1) === "%", h = a.indexOf("="), f === "<" || f === ">" ? (h >= 0 && (a = a.replace(/=/, "")), (f === "<" ? o._start : o.endTime(o._repeat >= 0)) + (parseFloat(a.substr(1)) || 0) * (m ? (h < 0 ? o : s).totalDuration() / 100 : 1)) : h < 0 ? (a in l || (l[a] = c), l[a]) : (f = parseFloat(a.charAt(h - 1) + a.substr(h + 1)), m && s && (f = f / 100 * (St(s) ? s[0] : s).totalDuration()), h > 1 ? n(e, a.substr(0, h - 1), s) + f : c + f)) : a == null ? c : +a
    },
    Fr = function(e, a, s) {
        var l = ni(a[1]),
            o = (l ? 2 : 1) + (e < 2 ? 0 : 1),
            c = a[o],
            h, f;
        if (l && (c.duration = a[1]), c.parent = s, e) {
            for (h = c, f = s; f && !("immediateRender" in h);) h = f.vars.defaults || {}, f = Rt(f.vars.inherit) && f.parent;
            c.immediateRender = Rt(h.immediateRender), e < 2 ? c.runBackwards = 1 : c.startAt = a[o - 1]
        }
        return new nt(a[0], c, a[o + 1])
    },
    qi = function(e, a) {
        return e || e === 0 ? a(e) : a
    },
    gl = function(e, a, s) {
        return s < e ? e : s > a ? a : s
    },
    bt = function(e, a) {
        return !ct(e) || !(a = q_.exec(e)) ? "" : a[1]
    },
    t4 = function(e, a, s) {
        return qi(s, function(l) {
            return gl(e, a, l)
        })
    },
    jd = [].slice,
    Gy = function(e, a) {
        return e && kn(e) && "length" in e && (!a && !e.length || e.length - 1 in e && kn(e[0])) && !e.nodeType && e !== Dn
    },
    n4 = function(e, a, s) {
        return s === void 0 && (s = []), e.forEach(function(l) {
            var o;
            return ct(l) && !a || Gy(l, 1) ? (o = s).push.apply(o, gn(l)) : s.push(l)
        }) || s
    },
    gn = function(e, a, s) {
        return ke && !a && ke.selector ? ke.selector(e) : ct(e) && !s && (Dd || !zs()) ? jd.call((a || Eh).querySelectorAll(e), 0) : St(e) ? n4(e, s) : Gy(e) ? jd.call(e, 0) : e ? [e] : []
    },
    Nd = function(e) {
        return e = gn(e)[0] || el("Invalid scope") || {},
            function(a) {
                var s = e.current || e.nativeElement || e;
                return gn(a, s.querySelectorAll ? s : s === e ? el("Invalid scope") || Eh.createElement("div") : e)
            }
    },
    qy = function(e) {
        return e.sort(function() {
            return .5 - Math.random()
        })
    },
    Yy = function(e) {
        if (Ze(e)) return e;
        var a = kn(e) ? e : {
                each: e
            },
            s = ba(a.ease),
            l = a.from || 0,
            o = parseFloat(a.base) || 0,
            c = {},
            h = l > 0 && l < 1,
            f = isNaN(l) || h,
            m = a.axis,
            p = l,
            v = l;
        return ct(l) ? p = v = {
                center: .5,
                edges: .5,
                end: 1
            }[l] || 0 : !h && f && (p = l[0], v = l[1]),
            function(b, y, T) {
                var S = (T || a).length,
                    M = c[S],
                    _, w, C, L, O, V, k, D, H;
                if (!M) {
                    if (H = a.grid === "auto" ? 0 : (a.grid || [1, pn])[1], !H) {
                        for (k = -pn; k < (k = T[H++].getBoundingClientRect().left) && H < S;);
                        H < S && H--
                    }
                    for (M = c[S] = [], _ = f ? Math.min(H, S) * p - .5 : l % H, w = H === pn ? 0 : f ? S * v / H - .5 : l / H | 0, k = 0, D = pn, V = 0; V < S; V++) C = V % H - _, L = w - (V / H | 0), M[V] = O = m ? Math.abs(m === "y" ? L : C) : My(C * C + L * L), O > k && (k = O), O < D && (D = O);
                    l === "random" && qy(M), M.max = k - D, M.min = D, M.v = S = (parseFloat(a.amount) || parseFloat(a.each) * (H > S ? S - 1 : m ? m === "y" ? S / H : H : Math.max(H, S / H)) || 0) * (l === "edges" ? -1 : 1), M.b = S < 0 ? o - S : o, M.u = bt(a.amount || a.each) || 0, s = s && S < 0 ? e2(s) : s
                }
                return S = (M[b] - M.min) / M.max || 0, He(M.b + (s ? s(S) : S) * M.v) + M.u
            }
    },
    Vd = function(e) {
        var a = Math.pow(10, ((e + "").split(".")[1] || "").length);
        return function(s) {
            var l = He(Math.round(parseFloat(s) / e) * e * a);
            return (l - l % 1) / a + (ni(s) ? 0 : bt(s))
        }
    },
    Xy = function(e, a) {
        var s = St(e),
            l, o;
        return !s && kn(e) && (l = s = e.radius || pn, e.values ? (e = gn(e.values), (o = !ni(e[0])) && (l *= l)) : e = Vd(e.increment)), qi(a, s ? Ze(e) ? function(c) {
            return o = e(c), Math.abs(o - c) <= l ? o : c
        } : function(c) {
            for (var h = parseFloat(o ? c.x : c), f = parseFloat(o ? c.y : 0), m = pn, p = 0, v = e.length, b, y; v--;) o ? (b = e[v].x - h, y = e[v].y - f, b = b * b + y * y) : b = Math.abs(e[v] - h), b < m && (m = b, p = v);
            return p = !l || m <= l ? e[p] : c, o || p === c || ni(c) ? p : p + bt(c)
        } : Vd(e))
    },
    Fy = function(e, a, s, l) {
        return qi(St(e) ? !a : s === !0 ? !!(s = 0) : !l, function() {
            return St(e) ? e[~~(Math.random() * e.length)] : (s = s || 1e-5) && (l = s < 1 ? Math.pow(10, (s + "").length - 2) : 1) && Math.floor(Math.round((e - s / 2 + Math.random() * (a - e + s * .99)) / s) * s * l) / l
        })
    },
    i4 = function() {
        for (var e = arguments.length, a = new Array(e), s = 0; s < e; s++) a[s] = arguments[s];
        return function(l) {
            return a.reduce(function(o, c) {
                return c(o)
            }, l)
        }
    },
    a4 = function(e, a) {
        return function(s) {
            return e(parseFloat(s)) + (a || bt(s))
        }
    },
    s4 = function(e, a, s) {
        return Zy(e, a, 0, 1, s)
    },
    Ky = function(e, a, s) {
        return qi(s, function(l) {
            return e[~~a(l)]
        })
    },
    r4 = function n(e, a, s) {
        var l = a - e;
        return St(e) ? Ky(e, n(0, e.length), a) : qi(s, function(o) {
            return (l + (o - e) % l) % l + e
        })
    },
    l4 = function n(e, a, s) {
        var l = a - e,
            o = l * 2;
        return St(e) ? Ky(e, n(0, e.length - 1), a) : qi(s, function(c) {
            return c = (o + (c - e) % o) % o || 0, e + (c > l ? o - c : c)
        })
    },
    nl = function(e) {
        return e.replace(U_, function(a) {
            var s = a.indexOf("[") + 1,
                l = a.substring(s || 7, s ? a.indexOf("]") : a.length - 1).split(H_);
            return Fy(s ? l : +l[0], s ? 0 : +l[1], +l[2] || 1e-5)
        })
    },
    Zy = function(e, a, s, l, o) {
        var c = a - e,
            h = l - s;
        return qi(o, function(f) {
            return s + ((f - e) / c * h || 0)
        })
    },
    o4 = function n(e, a, s, l) {
        var o = isNaN(e + a) ? 0 : function(y) {
            return (1 - y) * e + y * a
        };
        if (!o) {
            var c = ct(e),
                h = {},
                f, m, p, v, b;
            if (s === !0 && (l = 1) && (s = null), c) e = {
                p: e
            }, a = {
                p: a
            };
            else if (St(e) && !St(a)) {
                for (p = [], v = e.length, b = v - 2, m = 1; m < v; m++) p.push(n(e[m - 1], e[m]));
                v--, o = function(T) {
                    T *= v;
                    var S = Math.min(b, ~~T);
                    return p[S](T - S)
                }, s = a
            } else l || (e = Cs(St(e) ? [] : {}, e));
            if (!p) {
                for (f in a) Dh.call(h, e, f, "get", a[f]);
                o = function(T) {
                    return jh(T, h) || (c ? e.p : e)
                }
            }
        }
        return qi(s, o)
    },
    L1 = function(e, a, s) {
        var l = e.labels,
            o = pn,
            c, h, f;
        for (c in l) h = l[c] - a, h < 0 == !!s && h && o > (h = Math.abs(h)) && (f = c, o = h);
        return f
    },
    It = function(e, a, s) {
        var l = e.vars,
            o = l[a],
            c = ke,
            h = e._ctx,
            f, m, p;
        if (o) return f = l[a + "Params"], m = l.callbackScope || e, s && Vi.length && nu(), h && (ke = h), p = f ? o.apply(m, f) : o.call(m), ke = c, p
    },
    Gr = function(e) {
        return Bi(e), e.scrollTrigger && e.scrollTrigger.kill(!!pt), e.progress() < 1 && It(e, "onInterrupt"), e
    },
    ms, Qy = [],
    Iy = function(e) {
        if (e)
            if (e = !e.name && e.default || e, _h() || e.headless) {
                var a = e.name,
                    s = Ze(e),
                    l = a && !s && e.init ? function() {
                        this._props = []
                    } : e,
                    o = {
                        init: tl,
                        render: jh,
                        add: Dh,
                        kill: E4,
                        modifier: _4,
                        rawVars: 0
                    },
                    c = {
                        targetTest: 0,
                        get: 0,
                        getSetter: Lh,
                        aliases: {},
                        register: 0
                    };
                if (zs(), e !== l) {
                    if (Kt[a]) return;
                    en(l, en(iu(e, o), c)), Cs(l.prototype, Cs(o, iu(e, c))), Kt[l.prop = a] = l, e.targetTest && (Yo.push(l), Mh[a] = 1), a = (a === "css" ? "CSS" : a.charAt(0).toUpperCase() + a.substr(1)) + "Plugin"
                }
                Ry(a, l), e.register && e.register(Vt, l, jt)
            } else Qy.push(e)
    },
    Re = 255,
    qr = {
        aqua: [0, Re, Re],
        lime: [0, Re, 0],
        silver: [192, 192, 192],
        black: [0, 0, 0],
        maroon: [128, 0, 0],
        teal: [0, 128, 128],
        blue: [0, 0, Re],
        navy: [0, 0, 128],
        white: [Re, Re, Re],
        olive: [128, 128, 0],
        yellow: [Re, Re, 0],
        orange: [Re, 165, 0],
        gray: [128, 128, 128],
        purple: [128, 0, 128],
        green: [0, 128, 0],
        red: [Re, 0, 0],
        pink: [Re, 192, 203],
        cyan: [0, Re, Re],
        transparent: [Re, Re, Re, 0]
    },
    Qf = function(e, a, s) {
        return e += e < 0 ? 1 : e > 1 ? -1 : 0, (e * 6 < 1 ? a + (s - a) * e * 6 : e < .5 ? s : e * 3 < 2 ? a + (s - a) * (2 / 3 - e) * 6 : a) * Re + .5 | 0
    },
    $y = function(e, a, s) {
        var l = e ? ni(e) ? [e >> 16, e >> 8 & Re, e & Re] : 0 : qr.black,
            o, c, h, f, m, p, v, b, y, T;
        if (!l) {
            if (e.substr(-1) === "," && (e = e.substr(0, e.length - 1)), qr[e]) l = qr[e];
            else if (e.charAt(0) === "#") {
                if (e.length < 6 && (o = e.charAt(1), c = e.charAt(2), h = e.charAt(3), e = "#" + o + o + c + c + h + h + (e.length === 5 ? e.charAt(4) + e.charAt(4) : "")), e.length === 9) return l = parseInt(e.substr(1, 6), 16), [l >> 16, l >> 8 & Re, l & Re, parseInt(e.substr(7), 16) / 255];
                e = parseInt(e.substr(1), 16), l = [e >> 16, e >> 8 & Re, e & Re]
            } else if (e.substr(0, 3) === "hsl") {
                if (l = T = e.match(C1), !a) f = +l[0] % 360 / 360, m = +l[1] / 100, p = +l[2] / 100, c = p <= .5 ? p * (m + 1) : p + m - p * m, o = p * 2 - c, l.length > 3 && (l[3] *= 1), l[0] = Qf(f + 1 / 3, o, c), l[1] = Qf(f, o, c), l[2] = Qf(f - 1 / 3, o, c);
                else if (~e.indexOf("=")) return l = e.match(Cy), s && l.length < 4 && (l[3] = 1), l
            } else l = e.match(C1) || qr.transparent;
            l = l.map(Number)
        }
        return a && !T && (o = l[0] / Re, c = l[1] / Re, h = l[2] / Re, v = Math.max(o, c, h), b = Math.min(o, c, h), p = (v + b) / 2, v === b ? f = m = 0 : (y = v - b, m = p > .5 ? y / (2 - v - b) : y / (v + b), f = v === o ? (c - h) / y + (c < h ? 6 : 0) : v === c ? (h - o) / y + 2 : (o - c) / y + 4, f *= 60), l[0] = ~~(f + .5), l[1] = ~~(m * 100 + .5), l[2] = ~~(p * 100 + .5)), s && l.length < 4 && (l[3] = 1), l
    },
    Wy = function(e) {
        var a = [],
            s = [],
            l = -1;
        return e.split(ki).forEach(function(o) {
            var c = o.match(hs) || [];
            a.push.apply(a, c), s.push(l += c.length + 1)
        }), a.c = s, a
    },
    j1 = function(e, a, s) {
        var l = "",
            o = (e + l).match(ki),
            c = a ? "hsla(" : "rgba(",
            h = 0,
            f, m, p, v;
        if (!o) return e;
        if (o = o.map(function(b) {
                return (b = $y(b, a, 1)) && c + (a ? b[0] + "," + b[1] + "%," + b[2] + "%," + b[3] : b.join(",")) + ")"
            }), s && (p = Wy(e), f = s.c, f.join(l) !== p.c.join(l)))
            for (m = e.replace(ki, "1").split(hs), v = m.length - 1; h < v; h++) l += m[h] + (~f.indexOf(h) ? o.shift() || c + "0,0,0,0)" : (p.length ? p : o.length ? o : s).shift());
        if (!m)
            for (m = e.split(ki), v = m.length - 1; h < v; h++) l += m[h] + o[h];
        return l + m[v]
    },
    ki = (function() {
        var n = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",
            e;
        for (e in qr) n += "|" + e + "\\b";
        return new RegExp(n + ")", "gi")
    })(),
    u4 = /hsl[a]?\(/,
    Jy = function(e) {
        var a = e.join(" "),
            s;
        if (ki.lastIndex = 0, ki.test(a)) return s = u4.test(a), e[1] = j1(e[1], s), e[0] = j1(e[0], s, Wy(e[1])), !0
    },
    il, Qt = (function() {
        var n = Date.now,
            e = 500,
            a = 33,
            s = n(),
            l = s,
            o = 1e3 / 240,
            c = o,
            h = [],
            f, m, p, v, b, y, T = function S(M) {
                var _ = n() - l,
                    w = M === !0,
                    C, L, O, V;
                if ((_ > e || _ < 0) && (s += _ - a), l += _, O = l - s, C = O - c, (C > 0 || w) && (V = ++v.frame, b = O - v.time * 1e3, v.time = O = O / 1e3, c += C + (C >= o ? 4 : o - C), L = 1), w || (f = m(S)), L)
                    for (y = 0; y < h.length; y++) h[y](O, b, V, M)
            };
        return v = {
            time: 0,
            frame: 0,
            tick: function() {
                T(!0)
            },
            deltaRatio: function(M) {
                return b / (1e3 / (M || 60))
            },
            wake: function() {
                Dy && (!Dd && _h() && (Dn = Dd = window, Eh = Dn.document || {}, Jt.gsap = Vt, (Dn.gsapVersions || (Dn.gsapVersions = [])).push(Vt.version), zy(tu || Dn.GreenSockGlobals || !Dn.gsap && Dn || {}), Qy.forEach(Iy)), p = typeof requestAnimationFrame < "u" && requestAnimationFrame, f && v.sleep(), m = p || function(M) {
                    return setTimeout(M, c - v.time * 1e3 + 1 | 0)
                }, il = 1, T(2))
            },
            sleep: function() {
                (p ? cancelAnimationFrame : clearTimeout)(f), il = 0, m = tl
            },
            lagSmoothing: function(M, _) {
                e = M || 1 / 0, a = Math.min(_ || 33, e)
            },
            fps: function(M) {
                o = 1e3 / (M || 240), c = v.time * 1e3 + o
            },
            add: function(M, _, w) {
                var C = _ ? function(L, O, V, k) {
                    M(L, O, V, k), v.remove(C)
                } : M;
                return v.remove(M), h[w ? "unshift" : "push"](C), zs(), C
            },
            remove: function(M, _) {
                ~(_ = h.indexOf(M)) && h.splice(_, 1) && y >= _ && y--
            },
            _listeners: h
        }, v
    })(),
    zs = function() {
        return !il && Qt.wake()
    },
    Se = {},
    c4 = /^[\d.\-M][\d.\-,\s]/,
    f4 = /["']/g,
    d4 = function(e) {
        for (var a = {}, s = e.substr(1, e.length - 3).split(":"), l = s[0], o = 1, c = s.length, h, f, m; o < c; o++) f = s[o], h = o !== c - 1 ? f.lastIndexOf(",") : f.length, m = f.substr(0, h), a[l] = isNaN(m) ? m.replace(f4, "").trim() : +m, l = f.substr(h + 1).trim();
        return a
    },
    h4 = function(e) {
        var a = e.indexOf("(") + 1,
            s = e.indexOf(")"),
            l = e.indexOf("(", a);
        return e.substring(a, ~l && l < s ? e.indexOf(")", s + 1) : s)
    },
    m4 = function(e) {
        var a = (e + "").split("("),
            s = Se[a[0]];
        return s && a.length > 1 && s.config ? s.config.apply(null, ~e.indexOf("{") ? [d4(a[1])] : h4(e).split(",").map(Vy)) : Se._CE && c4.test(e) ? Se._CE("", e) : s
    },
    e2 = function(e) {
        return function(a) {
            return 1 - e(1 - a)
        }
    },
    t2 = function n(e, a) {
        for (var s = e._first, l; s;) s instanceof _t ? n(s, a) : s.vars.yoyoEase && (!s._yoyo || !s._repeat) && s._yoyo !== a && (s.timeline ? n(s.timeline, a) : (l = s._ease, s._ease = s._yEase, s._yEase = l, s._yoyo = a)), s = s._next
    },
    ba = function(e, a) {
        return e && (Ze(e) ? e : Se[e] || m4(e)) || a
    },
    Ea = function(e, a, s, l) {
        s === void 0 && (s = function(f) {
            return 1 - a(1 - f)
        }), l === void 0 && (l = function(f) {
            return f < .5 ? a(f * 2) / 2 : 1 - a((1 - f) * 2) / 2
        });
        var o = {
                easeIn: a,
                easeOut: s,
                easeInOut: l
            },
            c;
        return Lt(e, function(h) {
            Se[h] = Jt[h] = o, Se[c = h.toLowerCase()] = s;
            for (var f in o) Se[c + (f === "easeIn" ? ".in" : f === "easeOut" ? ".out" : ".inOut")] = Se[h + "." + f] = o[f]
        }), o
    },
    n2 = function(e) {
        return function(a) {
            return a < .5 ? (1 - e(1 - a * 2)) / 2 : .5 + e((a - .5) * 2) / 2
        }
    },
    If = function n(e, a, s) {
        var l = a >= 1 ? a : 1,
            o = (s || (e ? .3 : .45)) / (a < 1 ? a : 1),
            c = o / Od * (Math.asin(1 / l) || 0),
            h = function(p) {
                return p === 1 ? 1 : l * Math.pow(2, -10 * p) * P_((p - c) * o) + 1
            },
            f = e === "out" ? h : e === "in" ? function(m) {
                return 1 - h(1 - m)
            } : n2(h);
        return o = Od / o, f.config = function(m, p) {
            return n(e, m, p)
        }, f
    },
    $f = function n(e, a) {
        a === void 0 && (a = 1.70158);
        var s = function(c) {
                return c ? --c * c * ((a + 1) * c + a) + 1 : 0
            },
            l = e === "out" ? s : e === "in" ? function(o) {
                return 1 - s(1 - o)
            } : n2(s);
        return l.config = function(o) {
            return n(e, o)
        }, l
    };
Lt("Linear,Quad,Cubic,Quart,Quint,Strong", function(n, e) {
    var a = e < 5 ? e + 1 : e;
    Ea(n + ",Power" + (a - 1), e ? function(s) {
        return Math.pow(s, a)
    } : function(s) {
        return s
    }, function(s) {
        return 1 - Math.pow(1 - s, a)
    }, function(s) {
        return s < .5 ? Math.pow(s * 2, a) / 2 : 1 - Math.pow((1 - s) * 2, a) / 2
    })
});
Se.Linear.easeNone = Se.none = Se.Linear.easeIn;
Ea("Elastic", If("in"), If("out"), If());
(function(n, e) {
    var a = 1 / e,
        s = 2 * a,
        l = 2.5 * a,
        o = function(h) {
            return h < a ? n * h * h : h < s ? n * Math.pow(h - 1.5 / e, 2) + .75 : h < l ? n * (h -= 2.25 / e) * h + .9375 : n * Math.pow(h - 2.625 / e, 2) + .984375
        };
    Ea("Bounce", function(c) {
        return 1 - o(1 - c)
    }, o)
})(7.5625, 2.75);
Ea("Expo", function(n) {
    return Math.pow(2, 10 * (n - 1)) * n + n * n * n * n * n * n * (1 - n)
});
Ea("Circ", function(n) {
    return -(My(1 - n * n) - 1)
});
Ea("Sine", function(n) {
    return n === 1 ? 1 : -B_(n * V_) + 1
});
Ea("Back", $f("in"), $f("out"), $f());
Se.SteppedEase = Se.steps = Jt.SteppedEase = {
    config: function(e, a) {
        e === void 0 && (e = 1);
        var s = 1 / e,
            l = e + (a ? 0 : 1),
            o = a ? 1 : 0,
            c = 1 - Le;
        return function(h) {
            return ((l * gl(0, c, h) | 0) + o) * s
        }
    }
};
As.ease = Se["quad.out"];
Lt("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function(n) {
    return Ah += n + "," + n + "Params,"
});
var i2 = function(e, a) {
        this.id = k_++, e._gsap = this, this.target = e, this.harness = a, this.get = a ? a.get : jy, this.set = a ? a.getSetter : Lh
    },
    al = (function() {
        function n(a) {
            this.vars = a, this._delay = +a.delay || 0, (this._repeat = a.repeat === 1 / 0 ? -2 : a.repeat || 0) && (this._rDelay = a.repeatDelay || 0, this._yoyo = !!a.yoyo || !!a.yoyoEase), this._ts = 1, Ds(this, +a.duration, 1, 1), this.data = a.data, ke && (this._ctx = ke, ke.data.push(this)), il || Qt.wake()
        }
        var e = n.prototype;
        return e.delay = function(s) {
            return s || s === 0 ? (this.parent && this.parent.smoothChildTiming && this.startTime(this._start + s - this._delay), this._delay = s, this) : this._delay
        }, e.duration = function(s) {
            return arguments.length ? this.totalDuration(this._repeat > 0 ? s + (s + this._rDelay) * this._repeat : s) : this.totalDuration() && this._dur
        }, e.totalDuration = function(s) {
            return arguments.length ? (this._dirty = 0, Ds(this, this._repeat < 0 ? s : (s - this._repeat * this._rDelay) / (this._repeat + 1))) : this._tDur
        }, e.totalTime = function(s, l) {
            if (zs(), !arguments.length) return this._tTime;
            var o = this._dp;
            if (o && o.smoothChildTiming && this._ts) {
                for (Su(this, s), !o._dp || o.parent || Py(o, this); o && o.parent;) o.parent._time !== o._start + (o._ts >= 0 ? o._tTime / o._ts : (o.totalDuration() - o._tTime) / -o._ts) && o.totalTime(o._tTime, !0), o = o.parent;
                !this.parent && this._dp.autoRemoveChildren && (this._ts > 0 && s < this._tDur || this._ts < 0 && s > 0 || !this._tDur && !s) && zn(this._dp, this, this._start - this._delay)
            }
            return (this._tTime !== s || !this._dur && !l || this._initted && Math.abs(this._zTime) === Le || !this._initted && this._dur && s || !s && !this._initted && (this.add || this._ptLookup)) && (this._ts || (this._pTime = s), Ny(this, s, l)), this
        }, e.time = function(s, l) {
            return arguments.length ? this.totalTime(Math.min(this.totalDuration(), s + z1(this)) % (this._dur + this._rDelay) || (s ? this._dur : 0), l) : this._time
        }, e.totalProgress = function(s, l) {
            return arguments.length ? this.totalTime(this.totalDuration() * s, l) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.rawTime() >= 0 && this._initted ? 1 : 0
        }, e.progress = function(s, l) {
            return arguments.length ? this.totalTime(this.duration() * (this._yoyo && !(this.iteration() & 1) ? 1 - s : s) + z1(this), l) : this.duration() ? Math.min(1, this._time / this._dur) : this.rawTime() > 0 ? 1 : 0
        }, e.iteration = function(s, l) {
            var o = this.duration() + this._rDelay;
            return arguments.length ? this.totalTime(this._time + (s - 1) * o, l) : this._repeat ? Os(this._tTime, o) + 1 : 1
        }, e.timeScale = function(s, l) {
            if (!arguments.length) return this._rts === -Le ? 0 : this._rts;
            if (this._rts === s) return this;
            var o = this.parent && this._ts ? au(this.parent._time, this) : this._tTime;
            return this._rts = +s || 0, this._ts = this._ps || s === -Le ? 0 : this._rts, this.totalTime(gl(-Math.abs(this._delay), this.totalDuration(), o), l !== !1), xu(this), Q_(this)
        }, e.paused = function(s) {
            return arguments.length ? (this._ps !== s && (this._ps = s, s ? (this._pTime = this._tTime || Math.max(-this._delay, this.rawTime()), this._ts = this._act = 0) : (zs(), this._ts = this._rts, this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, this.progress() === 1 && Math.abs(this._zTime) !== Le && (this._tTime -= Le)))), this) : this._ps
        }, e.startTime = function(s) {
            if (arguments.length) {
                this._start = He(s);
                var l = this.parent || this._dp;
                return l && (l._sort || !this.parent) && zn(l, this, this._start - this._delay), this
            }
            return this._start
        }, e.endTime = function(s) {
            return this._start + (Rt(s) ? this.totalDuration() : this.duration()) / Math.abs(this._ts || 1)
        }, e.rawTime = function(s) {
            var l = this.parent || this._dp;
            return l ? s && (!this._ts || this._repeat && this._time && this.totalProgress() < 1) ? this._tTime % (this._dur + this._rDelay) : this._ts ? au(l.rawTime(s), this) : this._tTime : this._tTime
        }, e.revert = function(s) {
            s === void 0 && (s = X_);
            var l = pt;
            return pt = s, Oh(this) && (this.timeline && this.timeline.revert(s), this.totalTime(-.01, s.suppressEvents)), this.data !== "nested" && s.kill !== !1 && this.kill(), pt = l, this
        }, e.globalTime = function(s) {
            for (var l = this, o = arguments.length ? s : l.rawTime(); l;) o = l._start + o / (Math.abs(l._ts) || 1), l = l._dp;
            return !this.parent && this._sat ? this._sat.globalTime(s) : o
        }, e.repeat = function(s) {
            return arguments.length ? (this._repeat = s === 1 / 0 ? -2 : s, R1(this)) : this._repeat === -2 ? 1 / 0 : this._repeat
        }, e.repeatDelay = function(s) {
            if (arguments.length) {
                var l = this._time;
                return this._rDelay = s, R1(this), l ? this.time(l) : this
            }
            return this._rDelay
        }, e.yoyo = function(s) {
            return arguments.length ? (this._yoyo = s, this) : this._yoyo
        }, e.seek = function(s, l) {
            return this.totalTime(dn(this, s), Rt(l))
        }, e.restart = function(s, l) {
            return this.play().totalTime(s ? -this._delay : 0, Rt(l)), this._dur || (this._zTime = -Le), this
        }, e.play = function(s, l) {
            return s != null && this.seek(s, l), this.reversed(!1).paused(!1)
        }, e.reverse = function(s, l) {
            return s != null && this.seek(s || this.totalDuration(), l), this.reversed(!0).paused(!1)
        }, e.pause = function(s, l) {
            return s != null && this.seek(s, l), this.paused(!0)
        }, e.resume = function() {
            return this.paused(!1)
        }, e.reversed = function(s) {
            return arguments.length ? (!!s !== this.reversed() && this.timeScale(-this._rts || (s ? -Le : 0)), this) : this._rts < 0
        }, e.invalidate = function() {
            return this._initted = this._act = 0, this._zTime = -Le, this
        }, e.isActive = function() {
            var s = this.parent || this._dp,
                l = this._start,
                o;
            return !!(!s || this._ts && this._initted && s.isActive() && (o = s.rawTime(!0)) >= l && o < this.endTime(!0) - Le)
        }, e.eventCallback = function(s, l, o) {
            var c = this.vars;
            return arguments.length > 1 ? (l ? (c[s] = l, o && (c[s + "Params"] = o), s === "onUpdate" && (this._onUpdate = l)) : delete c[s], this) : c[s]
        }, e.then = function(s) {
            var l = this,
                o = l._prom;
            return new Promise(function(c) {
                var h = Ze(s) ? s : ky,
                    f = function() {
                        var p = l.then;
                        l.then = null, o && o(), Ze(h) && (h = h(l)) && (h.then || h === l) && (l.then = p), c(h), l.then = p
                    };
                l._initted && l.totalProgress() === 1 && l._ts >= 0 || !l._tTime && l._ts < 0 ? f() : l._prom = f
            })
        }, e.kill = function() {
            Gr(this)
        }, n
    })();
en(al.prototype, {
    _time: 0,
    _start: 0,
    _end: 0,
    _tTime: 0,
    _tDur: 0,
    _dirty: 0,
    _repeat: 0,
    _yoyo: !1,
    parent: null,
    _initted: !1,
    _rDelay: 0,
    _ts: 1,
    _dp: 0,
    ratio: 0,
    _zTime: -Le,
    _prom: 0,
    _ps: !1,
    _rts: 1
});
var _t = (function(n) {
    wy(e, n);

    function e(s, l) {
        var o;
        return s === void 0 && (s = {}), o = n.call(this, s) || this, o.labels = {}, o.smoothChildTiming = !!s.smoothChildTiming, o.autoRemoveChildren = !!s.autoRemoveChildren, o._sort = Rt(s.sortChildren), Ge && zn(s.parent || Ge, ei(o), l), s.reversed && o.reverse(), s.paused && o.paused(!0), s.scrollTrigger && Uy(ei(o), s.scrollTrigger), o
    }
    var a = e.prototype;
    return a.to = function(l, o, c) {
        return Fr(0, arguments, this), this
    }, a.from = function(l, o, c) {
        return Fr(1, arguments, this), this
    }, a.fromTo = function(l, o, c, h) {
        return Fr(2, arguments, this), this
    }, a.set = function(l, o, c) {
        return o.duration = 0, o.parent = this, Xr(o).repeatDelay || (o.repeat = 0), o.immediateRender = !!o.immediateRender, new nt(l, o, dn(this, c), 1), this
    }, a.call = function(l, o, c) {
        return zn(this, nt.delayedCall(0, l, o), c)
    }, a.staggerTo = function(l, o, c, h, f, m, p) {
        return c.duration = o, c.stagger = c.stagger || h, c.onComplete = m, c.onCompleteParams = p, c.parent = this, new nt(l, c, dn(this, f)), this
    }, a.staggerFrom = function(l, o, c, h, f, m, p) {
        return c.runBackwards = 1, Xr(c).immediateRender = Rt(c.immediateRender), this.staggerTo(l, o, c, h, f, m, p)
    }, a.staggerFromTo = function(l, o, c, h, f, m, p, v) {
        return h.startAt = c, Xr(h).immediateRender = Rt(h.immediateRender), this.staggerTo(l, o, h, f, m, p, v)
    }, a.render = function(l, o, c) {
        var h = this._time,
            f = this._dirty ? this.totalDuration() : this._tDur,
            m = this._dur,
            p = l <= 0 ? 0 : He(l),
            v = this._zTime < 0 != l < 0 && (this._initted || !m),
            b, y, T, S, M, _, w, C, L, O, V, k;
        if (this !== Ge && p > f && l >= 0 && (p = f), p !== this._tTime || c || v) {
            if (h !== this._time && m && (p += this._time - h, l += this._time - h), b = p, L = this._start, C = this._ts, _ = !C, v && (m || (h = this._zTime), (l || !o) && (this._zTime = l)), this._repeat) {
                if (V = this._yoyo, M = m + this._rDelay, this._repeat < -1 && l < 0) return this.totalTime(M * 100 + l, o, c);
                if (b = He(p % M), p === f ? (S = this._repeat, b = m) : (O = He(p / M), S = ~~O, S && S === O && (b = m, S--), b > m && (b = m)), O = Os(this._tTime, M), !h && this._tTime && O !== S && this._tTime - O * M - this._dur <= 0 && (O = S), V && S & 1 && (b = m - b, k = 1), S !== O && !this._lock) {
                    var D = V && O & 1,
                        H = D === (V && S & 1);
                    if (S < O && (D = !D), h = D ? 0 : p % m ? m : p, this._lock = 1, this.render(h || (k ? 0 : He(S * M)), o, !m)._lock = 0, this._tTime = p, !o && this.parent && It(this, "onRepeat"), this.vars.repeatRefresh && !k && (this.invalidate()._lock = 1, O = S), h && h !== this._time || _ !== !this._ts || this.vars.onRepeat && !this.parent && !this._act) return this;
                    if (m = this._dur, f = this._tDur, H && (this._lock = 2, h = D ? m : -1e-4, this.render(h, !0), this.vars.repeatRefresh && !k && this.invalidate()), this._lock = 0, !this._ts && !_) return this;
                    t2(this, k)
                }
            }
            if (this._hasPause && !this._forcing && this._lock < 2 && (w = J_(this, He(h), He(b)), w && (p -= b - (b = w._start))), this._tTime = p, this._time = b, this._act = !C, this._initted || (this._onUpdate = this.vars.onUpdate, this._initted = 1, this._zTime = l, h = 0), !h && p && m && !o && !O && (It(this, "onStart"), this._tTime !== p)) return this;
            if (b >= h && l >= 0)
                for (y = this._first; y;) {
                    if (T = y._next, (y._act || b >= y._start) && y._ts && w !== y) {
                        if (y.parent !== this) return this.render(l, o, c);
                        if (y.render(y._ts > 0 ? (b - y._start) * y._ts : (y._dirty ? y.totalDuration() : y._tDur) + (b - y._start) * y._ts, o, c), b !== this._time || !this._ts && !_) {
                            w = 0, T && (p += this._zTime = -Le);
                            break
                        }
                    }
                    y = T
                } else {
                    y = this._last;
                    for (var F = l < 0 ? l : b; y;) {
                        if (T = y._prev, (y._act || F <= y._end) && y._ts && w !== y) {
                            if (y.parent !== this) return this.render(l, o, c);
                            if (y.render(y._ts > 0 ? (F - y._start) * y._ts : (y._dirty ? y.totalDuration() : y._tDur) + (F - y._start) * y._ts, o, c || pt && Oh(y)), b !== this._time || !this._ts && !_) {
                                w = 0, T && (p += this._zTime = F ? -Le : Le);
                                break
                            }
                        }
                        y = T
                    }
                }
            if (w && !o && (this.pause(), w.render(b >= h ? 0 : -Le)._zTime = b >= h ? 1 : -1, this._ts)) return this._start = L, xu(this), this.render(l, o, c);
            this._onUpdate && !o && It(this, "onUpdate", !0), (p === f && this._tTime >= this.totalDuration() || !p && h) && (L === this._start || Math.abs(C) !== Math.abs(this._ts)) && (this._lock || ((l || !m) && (p === f && this._ts > 0 || !p && this._ts < 0) && Bi(this, 1), !o && !(l < 0 && !h) && (p || h || !f) && (It(this, p === f && l >= 0 ? "onComplete" : "onReverseComplete", !0), this._prom && !(p < f && this.timeScale() > 0) && this._prom())))
        }
        return this
    }, a.add = function(l, o) {
        var c = this;
        if (ni(o) || (o = dn(this, o, l)), !(l instanceof al)) {
            if (St(l)) return l.forEach(function(h) {
                return c.add(h, o)
            }), this;
            if (ct(l)) return this.addLabel(l, o);
            if (Ze(l)) l = nt.delayedCall(0, l);
            else return this
        }
        return this !== l ? zn(this, l, o) : this
    }, a.getChildren = function(l, o, c, h) {
        l === void 0 && (l = !0), o === void 0 && (o = !0), c === void 0 && (c = !0), h === void 0 && (h = -pn);
        for (var f = [], m = this._first; m;) m._start >= h && (m instanceof nt ? o && f.push(m) : (c && f.push(m), l && f.push.apply(f, m.getChildren(!0, o, c)))), m = m._next;
        return f
    }, a.getById = function(l) {
        for (var o = this.getChildren(1, 1, 1), c = o.length; c--;)
            if (o[c].vars.id === l) return o[c]
    }, a.remove = function(l) {
        return ct(l) ? this.removeLabel(l) : Ze(l) ? this.killTweensOf(l) : (l.parent === this && bu(this, l), l === this._recent && (this._recent = this._last), ya(this))
    }, a.totalTime = function(l, o) {
        return arguments.length ? (this._forcing = 1, !this._dp && this._ts && (this._start = He(Qt.time - (this._ts > 0 ? l / this._ts : (this.totalDuration() - l) / -this._ts))), n.prototype.totalTime.call(this, l, o), this._forcing = 0, this) : this._tTime
    }, a.addLabel = function(l, o) {
        return this.labels[l] = dn(this, o), this
    }, a.removeLabel = function(l) {
        return delete this.labels[l], this
    }, a.addPause = function(l, o, c) {
        var h = nt.delayedCall(0, o || tl, c);
        return h.data = "isPause", this._hasPause = 1, zn(this, h, dn(this, l))
    }, a.removePause = function(l) {
        var o = this._first;
        for (l = dn(this, l); o;) o._start === l && o.data === "isPause" && Bi(o), o = o._next
    }, a.killTweensOf = function(l, o, c) {
        for (var h = this.getTweensOf(l, c), f = h.length; f--;) Ri !== h[f] && h[f].kill(l, o);
        return this
    }, a.getTweensOf = function(l, o) {
        for (var c = [], h = gn(l), f = this._first, m = ni(o), p; f;) f instanceof nt ? F_(f._targets, h) && (m ? (!Ri || f._initted && f._ts) && f.globalTime(0) <= o && f.globalTime(f.totalDuration()) > o : !o || f.isActive()) && c.push(f) : (p = f.getTweensOf(h, o)).length && c.push.apply(c, p), f = f._next;
        return c
    }, a.tweenTo = function(l, o) {
        o = o || {};
        var c = this,
            h = dn(c, l),
            f = o,
            m = f.startAt,
            p = f.onStart,
            v = f.onStartParams,
            b = f.immediateRender,
            y, T = nt.to(c, en({
                ease: o.ease || "none",
                lazy: !1,
                immediateRender: !1,
                time: h,
                overwrite: "auto",
                duration: o.duration || Math.abs((h - (m && "time" in m ? m.time : c._time)) / c.timeScale()) || Le,
                onStart: function() {
                    if (c.pause(), !y) {
                        var M = o.duration || Math.abs((h - (m && "time" in m ? m.time : c._time)) / c.timeScale());
                        T._dur !== M && Ds(T, M, 0, 1).render(T._time, !0, !0), y = 1
                    }
                    p && p.apply(T, v || [])
                }
            }, o));
        return b ? T.render(0) : T
    }, a.tweenFromTo = function(l, o, c) {
        return this.tweenTo(o, en({
            startAt: {
                time: dn(this, l)
            }
        }, c))
    }, a.recent = function() {
        return this._recent
    }, a.nextLabel = function(l) {
        return l === void 0 && (l = this._time), L1(this, dn(this, l))
    }, a.previousLabel = function(l) {
        return l === void 0 && (l = this._time), L1(this, dn(this, l), 1)
    }, a.currentLabel = function(l) {
        return arguments.length ? this.seek(l, !0) : this.previousLabel(this._time + Le)
    }, a.shiftChildren = function(l, o, c) {
        c === void 0 && (c = 0);
        var h = this._first,
            f = this.labels,
            m;
        for (l = He(l); h;) h._start >= c && (h._start += l, h._end += l), h = h._next;
        if (o)
            for (m in f) f[m] >= c && (f[m] += l);
        return ya(this)
    }, a.invalidate = function(l) {
        var o = this._first;
        for (this._lock = 0; o;) o.invalidate(l), o = o._next;
        return n.prototype.invalidate.call(this, l)
    }, a.clear = function(l) {
        l === void 0 && (l = !0);
        for (var o = this._first, c; o;) c = o._next, this.remove(o), o = c;
        return this._dp && (this._time = this._tTime = this._pTime = 0), l && (this.labels = {}), ya(this)
    }, a.totalDuration = function(l) {
        var o = 0,
            c = this,
            h = c._last,
            f = pn,
            m, p, v;
        if (arguments.length) return c.timeScale((c._repeat < 0 ? c.duration() : c.totalDuration()) / (c.reversed() ? -l : l));
        if (c._dirty) {
            for (v = c.parent; h;) m = h._prev, h._dirty && h.totalDuration(), p = h._start, p > f && c._sort && h._ts && !c._lock ? (c._lock = 1, zn(c, h, p - h._delay, 1)._lock = 0) : f = p, p < 0 && h._ts && (o -= p, (!v && !c._dp || v && v.smoothChildTiming) && (c._start += He(p / c._ts), c._time -= p, c._tTime -= p), c.shiftChildren(-p, !1, -1 / 0), f = 0), h._end > o && h._ts && (o = h._end), h = m;
            Ds(c, c === Ge && c._time > o ? c._time : o, 1, 1), c._dirty = 0
        }
        return c._tDur
    }, e.updateRoot = function(l) {
        if (Ge._ts && (Ny(Ge, au(l, Ge)), Ly = Qt.frame), Qt.frame >= O1) {
            O1 += Wt.autoSleep || 120;
            var o = Ge._first;
            if ((!o || !o._ts) && Wt.autoSleep && Qt._listeners.length < 2) {
                for (; o && !o._ts;) o = o._next;
                o || Qt.sleep()
            }
        }
    }, e
})(al);
en(_t.prototype, {
    _lock: 0,
    _hasPause: 0,
    _forcing: 0
});
var p4 = function(e, a, s, l, o, c, h) {
        var f = new jt(this._pt, e, a, 0, 1, u2, null, o),
            m = 0,
            p = 0,
            v, b, y, T, S, M, _, w;
        for (f.b = s, f.e = l, s += "", l += "", (_ = ~l.indexOf("random(")) && (l = nl(l)), c && (w = [s, l], c(w, e, a), s = w[0], l = w[1]), b = s.match(Kf) || []; v = Kf.exec(l);) T = v[0], S = l.substring(m, v.index), y ? y = (y + 1) % 5 : S.substr(-5) === "rgba(" && (y = 1), T !== b[p++] && (M = parseFloat(b[p - 1]) || 0, f._pt = {
            _next: f._pt,
            p: S || p === 1 ? S : ",",
            s: M,
            c: T.charAt(1) === "=" ? xs(M, T) - M : parseFloat(T) - M,
            m: y && y < 4 ? Math.round : 0
        }, m = Kf.lastIndex);
        return f.c = m < l.length ? l.substring(m, l.length) : "", f.fp = h, (Oy.test(l) || _) && (f.e = 0), this._pt = f, f
    },
    Dh = function(e, a, s, l, o, c, h, f, m, p) {
        Ze(l) && (l = l(o || 0, e, c));
        var v = e[a],
            b = s !== "get" ? s : Ze(v) ? m ? e[a.indexOf("set") || !Ze(e["get" + a.substr(3)]) ? a : "get" + a.substr(3)](m) : e[a]() : v,
            y = Ze(v) ? m ? x4 : l2 : Rh,
            T;
        if (ct(l) && (~l.indexOf("random(") && (l = nl(l)), l.charAt(1) === "=" && (T = xs(b, l) + (bt(b) || 0), (T || T === 0) && (l = T))), !p || b !== l || kd) return !isNaN(b * l) && l !== "" ? (T = new jt(this._pt, e, a, +b || 0, l - (b || 0), typeof v == "boolean" ? T4 : o2, 0, y), m && (T.fp = m), h && T.modifier(h, this, e), this._pt = T) : (!v && !(a in e) && wh(a, l), p4.call(this, e, a, b, l, y, f || Wt.stringFilter, m))
    },
    g4 = function(e, a, s, l, o) {
        if (Ze(e) && (e = Kr(e, o, a, s, l)), !kn(e) || e.style && e.nodeType || St(e) || Ay(e)) return ct(e) ? Kr(e, o, a, s, l) : e;
        var c = {},
            h;
        for (h in e) c[h] = Kr(e[h], o, a, s, l);
        return c
    },
    a2 = function(e, a, s, l, o, c) {
        var h, f, m, p;
        if (Kt[e] && (h = new Kt[e]).init(o, h.rawVars ? a[e] : g4(a[e], l, o, c, s), s, l, c) !== !1 && (s._pt = f = new jt(s._pt, o, e, 0, 1, h.render, h, 0, h.priority), s !== ms))
            for (m = s._ptLookup[s._targets.indexOf(o)], p = h._props.length; p--;) m[h._props[p]] = f;
        return h
    },
    Ri, kd, zh = function n(e, a, s) {
        var l = e.vars,
            o = l.ease,
            c = l.startAt,
            h = l.immediateRender,
            f = l.lazy,
            m = l.onUpdate,
            p = l.runBackwards,
            v = l.yoyoEase,
            b = l.keyframes,
            y = l.autoRevert,
            T = e._dur,
            S = e._startAt,
            M = e._targets,
            _ = e.parent,
            w = _ && _.data === "nested" ? _.vars.targets : M,
            C = e._overwrite === "auto" && !Sh,
            L = e.timeline,
            O, V, k, D, H, F, I, W, ee, ae, se, P, G;
        if (L && (!b || !o) && (o = "none"), e._ease = ba(o, As.ease), e._yEase = v ? e2(ba(v === !0 ? o : v, As.ease)) : 0, v && e._yoyo && !e._repeat && (v = e._yEase, e._yEase = e._ease, e._ease = v), e._from = !L && !!l.runBackwards, !L || b && !l.stagger) {
            if (W = M[0] ? va(M[0]).harness : 0, P = W && l[W.prop], O = iu(l, Mh), S && (S._zTime < 0 && S.progress(1), a < 0 && p && h && !y ? S.render(-1, !0) : S.revert(p && T ? qo : Y_), S._lazy = 0), c) {
                if (Bi(e._startAt = nt.set(M, en({
                        data: "isStart",
                        overwrite: !1,
                        parent: _,
                        immediateRender: !0,
                        lazy: !S && Rt(f),
                        startAt: null,
                        delay: 0,
                        onUpdate: m && function() {
                            return It(e, "onUpdate")
                        },
                        stagger: 0
                    }, c))), e._startAt._dp = 0, e._startAt._sat = e, a < 0 && (pt || !h && !y) && e._startAt.revert(qo), h && T && a <= 0 && s <= 0) {
                    a && (e._zTime = a);
                    return
                }
            } else if (p && T && !S) {
                if (a && (h = !1), k = en({
                        overwrite: !1,
                        data: "isFromStart",
                        lazy: h && !S && Rt(f),
                        immediateRender: h,
                        stagger: 0,
                        parent: _
                    }, O), P && (k[W.prop] = P), Bi(e._startAt = nt.set(M, k)), e._startAt._dp = 0, e._startAt._sat = e, a < 0 && (pt ? e._startAt.revert(qo) : e._startAt.render(-1, !0)), e._zTime = a, !h) n(e._startAt, Le, Le);
                else if (!a) return
            }
            for (e._pt = e._ptCache = 0, f = T && Rt(f) || f && !T, V = 0; V < M.length; V++) {
                if (H = M[V], I = H._gsap || Ch(M)[V]._gsap, e._ptLookup[V] = ae = {}, zd[I.id] && Vi.length && nu(), se = w === M ? V : w.indexOf(H), W && (ee = new W).init(H, P || O, e, se, w) !== !1 && (e._pt = D = new jt(e._pt, H, ee.name, 0, 1, ee.render, ee, 0, ee.priority), ee._props.forEach(function(X) {
                        ae[X] = D
                    }), ee.priority && (F = 1)), !W || P)
                    for (k in O) Kt[k] && (ee = a2(k, O, e, se, H, w)) ? ee.priority && (F = 1) : ae[k] = D = Dh.call(e, H, k, "get", O[k], se, w, 0, l.stringFilter);
                e._op && e._op[V] && e.kill(H, e._op[V]), C && e._pt && (Ri = e, Ge.killTweensOf(H, ae, e.globalTime(a)), G = !e.parent, Ri = 0), e._pt && f && (zd[I.id] = 1)
            }
            F && c2(e), e._onInit && e._onInit(e)
        }
        e._onUpdate = m, e._initted = (!e._op || e._pt) && !G, b && a <= 0 && L.render(pn, !0, !0)
    },
    v4 = function(e, a, s, l, o, c, h, f) {
        var m = (e._pt && e._ptCache || (e._ptCache = {}))[a],
            p, v, b, y;
        if (!m)
            for (m = e._ptCache[a] = [], b = e._ptLookup, y = e._targets.length; y--;) {
                if (p = b[y][a], p && p.d && p.d._pt)
                    for (p = p.d._pt; p && p.p !== a && p.fp !== a;) p = p._next;
                if (!p) return kd = 1, e.vars[a] = "+=0", zh(e, h), kd = 0, f ? el(a + " not eligible for reset") : 1;
                m.push(p)
            }
        for (y = m.length; y--;) v = m[y], p = v._pt || v, p.s = (l || l === 0) && !o ? l : p.s + (l || 0) + c * p.c, p.c = s - p.s, v.e && (v.e = We(s) + bt(v.e)), v.b && (v.b = p.s + bt(v.b))
    },
    y4 = function(e, a) {
        var s = e[0] ? va(e[0]).harness : 0,
            l = s && s.aliases,
            o, c, h, f;
        if (!l) return a;
        o = Cs({}, a);
        for (c in l)
            if (c in o)
                for (f = l[c].split(","), h = f.length; h--;) o[f[h]] = o[c];
        return o
    },
    b4 = function(e, a, s, l) {
        var o = a.ease || l || "power1.inOut",
            c, h;
        if (St(a)) h = s[e] || (s[e] = []), a.forEach(function(f, m) {
            return h.push({
                t: m / (a.length - 1) * 100,
                v: f,
                e: o
            })
        });
        else
            for (c in a) h = s[c] || (s[c] = []), c === "ease" || h.push({
                t: parseFloat(e),
                v: a[c],
                e: o
            })
    },
    Kr = function(e, a, s, l, o) {
        return Ze(e) ? e.call(a, s, l, o) : ct(e) && ~e.indexOf("random(") ? nl(e) : e
    },
    s2 = Ah + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,autoRevert",
    r2 = {};
Lt(s2 + ",id,stagger,delay,duration,paused,scrollTrigger", function(n) {
    return r2[n] = 1
});
var nt = (function(n) {
    wy(e, n);

    function e(s, l, o, c) {
        var h;
        typeof l == "number" && (o.duration = l, l = o, o = null), h = n.call(this, c ? l : Xr(l)) || this;
        var f = h.vars,
            m = f.duration,
            p = f.delay,
            v = f.immediateRender,
            b = f.stagger,
            y = f.overwrite,
            T = f.keyframes,
            S = f.defaults,
            M = f.scrollTrigger,
            _ = f.yoyoEase,
            w = l.parent || Ge,
            C = (St(s) || Ay(s) ? ni(s[0]) : "length" in l) ? [s] : gn(s),
            L, O, V, k, D, H, F, I;
        if (h._targets = C.length ? Ch(C) : el("GSAP target " + s + " not found. https://gsap.com", !Wt.nullTargetWarn) || [], h._ptLookup = [], h._overwrite = y, T || b || ko(m) || ko(p)) {
            if (l = h.vars, L = h.timeline = new _t({
                    data: "nested",
                    defaults: S || {},
                    targets: w && w.data === "nested" ? w.vars.targets : C
                }), L.kill(), L.parent = L._dp = ei(h), L._start = 0, b || ko(m) || ko(p)) {
                if (k = C.length, F = b && Yy(b), kn(b))
                    for (D in b) ~s2.indexOf(D) && (I || (I = {}), I[D] = b[D]);
                for (O = 0; O < k; O++) V = iu(l, r2), V.stagger = 0, _ && (V.yoyoEase = _), I && Cs(V, I), H = C[O], V.duration = +Kr(m, ei(h), O, H, C), V.delay = (+Kr(p, ei(h), O, H, C) || 0) - h._delay, !b && k === 1 && V.delay && (h._delay = p = V.delay, h._start += p, V.delay = 0), L.to(H, V, F ? F(O, H, C) : 0), L._ease = Se.none;
                L.duration() ? m = p = 0 : h.timeline = 0
            } else if (T) {
                Xr(en(L.vars.defaults, {
                    ease: "none"
                })), L._ease = ba(T.ease || l.ease || "none");
                var W = 0,
                    ee, ae, se;
                if (St(T)) T.forEach(function(P) {
                    return L.to(C, P, ">")
                }), L.duration();
                else {
                    V = {};
                    for (D in T) D === "ease" || D === "easeEach" || b4(D, T[D], V, T.easeEach);
                    for (D in V)
                        for (ee = V[D].sort(function(P, G) {
                                return P.t - G.t
                            }), W = 0, O = 0; O < ee.length; O++) ae = ee[O], se = {
                            ease: ae.e,
                            duration: (ae.t - (O ? ee[O - 1].t : 0)) / 100 * m
                        }, se[D] = ae.v, L.to(C, se, W), W += se.duration;
                    L.duration() < m && L.to({}, {
                        duration: m - L.duration()
                    })
                }
            }
            m || h.duration(m = L.duration())
        } else h.timeline = 0;
        return y === !0 && !Sh && (Ri = ei(h), Ge.killTweensOf(C), Ri = 0), zn(w, ei(h), o), l.reversed && h.reverse(), l.paused && h.paused(!0), (v || !m && !T && h._start === He(w._time) && Rt(v) && I_(ei(h)) && w.data !== "nested") && (h._tTime = -Le, h.render(Math.max(0, -p) || 0)), M && Uy(ei(h), M), h
    }
    var a = e.prototype;
    return a.render = function(l, o, c) {
        var h = this._time,
            f = this._tDur,
            m = this._dur,
            p = l < 0,
            v = l > f - Le && !p ? f : l < Le ? 0 : l,
            b, y, T, S, M, _, w, C, L;
        if (!m) W_(this, l, o, c);
        else if (v !== this._tTime || !l || c || !this._initted && this._tTime || this._startAt && this._zTime < 0 !== p || this._lazy) {
            if (b = v, C = this.timeline, this._repeat) {
                if (S = m + this._rDelay, this._repeat < -1 && p) return this.totalTime(S * 100 + l, o, c);
                if (b = He(v % S), v === f ? (T = this._repeat, b = m) : (M = He(v / S), T = ~~M, T && T === M ? (b = m, T--) : b > m && (b = m)), _ = this._yoyo && T & 1, _ && (L = this._yEase, b = m - b), M = Os(this._tTime, S), b === h && !c && this._initted && T === M) return this._tTime = v, this;
                T !== M && (C && this._yEase && t2(C, _), this.vars.repeatRefresh && !_ && !this._lock && b !== S && this._initted && (this._lock = c = 1, this.render(He(S * T), !0).invalidate()._lock = 0))
            }
            if (!this._initted) {
                if (Hy(this, p ? l : b, c, o, v)) return this._tTime = 0, this;
                if (h !== this._time && !(c && this.vars.repeatRefresh && T !== M)) return this;
                if (m !== this._dur) return this.render(l, o, c)
            }
            if (this._tTime = v, this._time = b, !this._act && this._ts && (this._act = 1, this._lazy = 0), this.ratio = w = (L || this._ease)(b / m), this._from && (this.ratio = w = 1 - w), !h && v && !o && !M && (It(this, "onStart"), this._tTime !== v)) return this;
            for (y = this._pt; y;) y.r(w, y.d), y = y._next;
            C && C.render(l < 0 ? l : C._dur * C._ease(b / this._dur), o, c) || this._startAt && (this._zTime = l), this._onUpdate && !o && (p && Rd(this, l, o, c), It(this, "onUpdate")), this._repeat && T !== M && this.vars.onRepeat && !o && this.parent && It(this, "onRepeat"), (v === this._tDur || !v) && this._tTime === v && (p && !this._onUpdate && Rd(this, l, !0, !0), (l || !m) && (v === this._tDur && this._ts > 0 || !v && this._ts < 0) && Bi(this, 1), !o && !(p && !h) && (v || h || _) && (It(this, v === f ? "onComplete" : "onReverseComplete", !0), this._prom && !(v < f && this.timeScale() > 0) && this._prom()))
        }
        return this
    }, a.targets = function() {
        return this._targets
    }, a.invalidate = function(l) {
        return (!l || !this.vars.runBackwards) && (this._startAt = 0), this._pt = this._op = this._onUpdate = this._lazy = this.ratio = 0, this._ptLookup = [], this.timeline && this.timeline.invalidate(l), n.prototype.invalidate.call(this, l)
    }, a.resetTo = function(l, o, c, h, f) {
        il || Qt.wake(), this._ts || this.play();
        var m = Math.min(this._dur, (this._dp._time - this._start) * this._ts),
            p;
        return this._initted || zh(this, m), p = this._ease(m / this._dur), v4(this, l, o, c, h, p, m, f) ? this.resetTo(l, o, c, h, 1) : (Su(this, 0), this.parent || By(this._dp, this, "_first", "_last", this._dp._sort ? "_start" : 0), this.render(0))
    }, a.kill = function(l, o) {
        if (o === void 0 && (o = "all"), !l && (!o || o === "all")) return this._lazy = this._pt = 0, this.parent ? Gr(this) : this.scrollTrigger && this.scrollTrigger.kill(!!pt), this;
        if (this.timeline) {
            var c = this.timeline.totalDuration();
            return this.timeline.killTweensOf(l, o, Ri && Ri.vars.overwrite !== !0)._first || Gr(this), this.parent && c !== this.timeline.totalDuration() && Ds(this, this._dur * this.timeline._tDur / c, 0, 1), this
        }
        var h = this._targets,
            f = l ? gn(l) : h,
            m = this._ptLookup,
            p = this._pt,
            v, b, y, T, S, M, _;
        if ((!o || o === "all") && Z_(h, f)) return o === "all" && (this._pt = 0), Gr(this);
        for (v = this._op = this._op || [], o !== "all" && (ct(o) && (S = {}, Lt(o, function(w) {
                return S[w] = 1
            }), o = S), o = y4(h, o)), _ = h.length; _--;)
            if (~f.indexOf(h[_])) {
                b = m[_], o === "all" ? (v[_] = o, T = b, y = {}) : (y = v[_] = v[_] || {}, T = o);
                for (S in T) M = b && b[S], M && ((!("kill" in M.d) || M.d.kill(S) === !0) && bu(this, M, "_pt"), delete b[S]), y !== "all" && (y[S] = 1)
            }
        return this._initted && !this._pt && p && Gr(this), this
    }, e.to = function(l, o) {
        return new e(l, o, arguments[2])
    }, e.from = function(l, o) {
        return Fr(1, arguments)
    }, e.delayedCall = function(l, o, c, h) {
        return new e(o, 0, {
            immediateRender: !1,
            lazy: !1,
            overwrite: !1,
            delay: l,
            onComplete: o,
            onReverseComplete: o,
            onCompleteParams: c,
            onReverseCompleteParams: c,
            callbackScope: h
        })
    }, e.fromTo = function(l, o, c) {
        return Fr(2, arguments)
    }, e.set = function(l, o) {
        return o.duration = 0, o.repeatDelay || (o.repeat = 0), new e(l, o)
    }, e.killTweensOf = function(l, o, c) {
        return Ge.killTweensOf(l, o, c)
    }, e
})(al);
en(nt.prototype, {
    _targets: [],
    _lazy: 0,
    _startAt: 0,
    _op: 0,
    _onInit: 0
});
Lt("staggerTo,staggerFrom,staggerFromTo", function(n) {
    nt[n] = function() {
        var e = new _t,
            a = jd.call(arguments, 0);
        return a.splice(n === "staggerFromTo" ? 5 : 4, 0, 0), e[n].apply(e, a)
    }
});
var Rh = function(e, a, s) {
        return e[a] = s
    },
    l2 = function(e, a, s) {
        return e[a](s)
    },
    x4 = function(e, a, s, l) {
        return e[a](l.fp, s)
    },
    S4 = function(e, a, s) {
        return e.setAttribute(a, s)
    },
    Lh = function(e, a) {
        return Ze(e[a]) ? l2 : Th(e[a]) && e.setAttribute ? S4 : Rh
    },
    o2 = function(e, a) {
        return a.set(a.t, a.p, Math.round((a.s + a.c * e) * 1e6) / 1e6, a)
    },
    T4 = function(e, a) {
        return a.set(a.t, a.p, !!(a.s + a.c * e), a)
    },
    u2 = function(e, a) {
        var s = a._pt,
            l = "";
        if (!e && a.b) l = a.b;
        else if (e === 1 && a.e) l = a.e;
        else {
            for (; s;) l = s.p + (s.m ? s.m(s.s + s.c * e) : Math.round((s.s + s.c * e) * 1e4) / 1e4) + l, s = s._next;
            l += a.c
        }
        a.set(a.t, a.p, l, a)
    },
    jh = function(e, a) {
        for (var s = a._pt; s;) s.r(e, s.d), s = s._next
    },
    _4 = function(e, a, s, l) {
        for (var o = this._pt, c; o;) c = o._next, o.p === l && o.modifier(e, a, s), o = c
    },
    E4 = function(e) {
        for (var a = this._pt, s, l; a;) l = a._next, a.p === e && !a.op || a.op === e ? bu(this, a, "_pt") : a.dep || (s = 1), a = l;
        return !s
    },
    w4 = function(e, a, s, l) {
        l.mSet(e, a, l.m.call(l.tween, s, l.mt), l)
    },
    c2 = function(e) {
        for (var a = e._pt, s, l, o, c; a;) {
            for (s = a._next, l = o; l && l.pr > a.pr;) l = l._next;
            (a._prev = l ? l._prev : c) ? a._prev._next = a: o = a, (a._next = l) ? l._prev = a : c = a, a = s
        }
        e._pt = o
    },
    jt = (function() {
        function n(a, s, l, o, c, h, f, m, p) {
            this.t = s, this.s = o, this.c = c, this.p = l, this.r = h || o2, this.d = f || this, this.set = m || Rh, this.pr = p || 0, this._next = a, a && (a._prev = this)
        }
        var e = n.prototype;
        return e.modifier = function(s, l, o) {
            this.mSet = this.mSet || this.set, this.set = w4, this.m = s, this.mt = o, this.tween = l
        }, n
    })();
Lt(Ah + "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger", function(n) {
    return Mh[n] = 1
});
Jt.TweenMax = Jt.TweenLite = nt;
Jt.TimelineLite = Jt.TimelineMax = _t;
Ge = new _t({
    sortChildren: !1,
    defaults: As,
    autoRemoveChildren: !0,
    id: "root",
    smoothChildTiming: !0
});
Wt.stringFilter = Jy;
var xa = [],
    Xo = {},
    M4 = [],
    N1 = 0,
    A4 = 0,
    Wf = function(e) {
        return (Xo[e] || M4).map(function(a) {
            return a()
        })
    },
    Bd = function() {
        var e = Date.now(),
            a = [];
        e - N1 > 2 && (Wf("matchMediaInit"), xa.forEach(function(s) {
            var l = s.queries,
                o = s.conditions,
                c, h, f, m;
            for (h in l) c = Dn.matchMedia(l[h]).matches, c && (f = 1), c !== o[h] && (o[h] = c, m = 1);
            m && (s.revert(), f && a.push(s))
        }), Wf("matchMediaRevert"), a.forEach(function(s) {
            return s.onMatch(s, function(l) {
                return s.add(null, l)
            })
        }), N1 = e, Wf("matchMedia"))
    },
    f2 = (function() {
        function n(a, s) {
            this.selector = s && Nd(s), this.data = [], this._r = [], this.isReverted = !1, this.id = A4++, a && this.add(a)
        }
        var e = n.prototype;
        return e.add = function(s, l, o) {
            Ze(s) && (o = l, l = s, s = Ze);
            var c = this,
                h = function() {
                    var m = ke,
                        p = c.selector,
                        v;
                    return m && m !== c && m.data.push(c), o && (c.selector = Nd(o)), ke = c, v = l.apply(c, arguments), Ze(v) && c._r.push(v), ke = m, c.selector = p, c.isReverted = !1, v
                };
            return c.last = h, s === Ze ? h(c, function(f) {
                return c.add(null, f)
            }) : s ? c[s] = h : h
        }, e.ignore = function(s) {
            var l = ke;
            ke = null, s(this), ke = l
        }, e.getTweens = function() {
            var s = [];
            return this.data.forEach(function(l) {
                return l instanceof n ? s.push.apply(s, l.getTweens()) : l instanceof nt && !(l.parent && l.parent.data === "nested") && s.push(l)
            }), s
        }, e.clear = function() {
            this._r.length = this.data.length = 0
        }, e.kill = function(s, l) {
            var o = this;
            if (s ? (function() {
                    for (var h = o.getTweens(), f = o.data.length, m; f--;) m = o.data[f], m.data === "isFlip" && (m.revert(), m.getChildren(!0, !0, !1).forEach(function(p) {
                        return h.splice(h.indexOf(p), 1)
                    }));
                    for (h.map(function(p) {
                            return {
                                g: p._dur || p._delay || p._sat && !p._sat.vars.immediateRender ? p.globalTime(0) : -1 / 0,
                                t: p
                            }
                        }).sort(function(p, v) {
                            return v.g - p.g || -1 / 0
                        }).forEach(function(p) {
                            return p.t.revert(s)
                        }), f = o.data.length; f--;) m = o.data[f], m instanceof _t ? m.data !== "nested" && (m.scrollTrigger && m.scrollTrigger.revert(), m.kill()) : !(m instanceof nt) && m.revert && m.revert(s);
                    o._r.forEach(function(p) {
                        return p(s, o)
                    }), o.isReverted = !0
                })() : this.data.forEach(function(h) {
                    return h.kill && h.kill()
                }), this.clear(), l)
                for (var c = xa.length; c--;) xa[c].id === this.id && xa.splice(c, 1)
        }, e.revert = function(s) {
            this.kill(s || {})
        }, n
    })(),
    C4 = (function() {
        function n(a) {
            this.contexts = [], this.scope = a, ke && ke.data.push(this)
        }
        var e = n.prototype;
        return e.add = function(s, l, o) {
            kn(s) || (s = {
                matches: s
            });
            var c = new f2(0, o || this.scope),
                h = c.conditions = {},
                f, m, p;
            ke && !c.selector && (c.selector = ke.selector), this.contexts.push(c), l = c.add("onMatch", l), c.queries = s;
            for (m in s) m === "all" ? p = 1 : (f = Dn.matchMedia(s[m]), f && (xa.indexOf(c) < 0 && xa.push(c), (h[m] = f.matches) && (p = 1), f.addListener ? f.addListener(Bd) : f.addEventListener("change", Bd)));
            return p && l(c, function(v) {
                return c.add(null, v)
            }), this
        }, e.revert = function(s) {
            this.kill(s || {})
        }, e.kill = function(s) {
            this.contexts.forEach(function(l) {
                return l.kill(s, !0)
            })
        }, n
    })(),
    su = {
        registerPlugin: function() {
            for (var e = arguments.length, a = new Array(e), s = 0; s < e; s++) a[s] = arguments[s];
            a.forEach(function(l) {
                return Iy(l)
            })
        },
        timeline: function(e) {
            return new _t(e)
        },
        getTweensOf: function(e, a) {
            return Ge.getTweensOf(e, a)
        },
        getProperty: function(e, a, s, l) {
            ct(e) && (e = gn(e)[0]);
            var o = va(e || {}).get,
                c = s ? ky : Vy;
            return s === "native" && (s = ""), e && (a ? c((Kt[a] && Kt[a].get || o)(e, a, s, l)) : function(h, f, m) {
                return c((Kt[h] && Kt[h].get || o)(e, h, f, m))
            })
        },
        quickSetter: function(e, a, s) {
            if (e = gn(e), e.length > 1) {
                var l = e.map(function(p) {
                        return Vt.quickSetter(p, a, s)
                    }),
                    o = l.length;
                return function(p) {
                    for (var v = o; v--;) l[v](p)
                }
            }
            e = e[0] || {};
            var c = Kt[a],
                h = va(e),
                f = h.harness && (h.harness.aliases || {})[a] || a,
                m = c ? function(p) {
                    var v = new c;
                    ms._pt = 0, v.init(e, s ? p + s : p, ms, 0, [e]), v.render(1, v), ms._pt && jh(1, ms)
                } : h.set(e, f);
            return c ? m : function(p) {
                return m(e, f, s ? p + s : p, h, 1)
            }
        },
        quickTo: function(e, a, s) {
            var l, o = Vt.to(e, en((l = {}, l[a] = "+=0.1", l.paused = !0, l.stagger = 0, l), s || {})),
                c = function(f, m, p) {
                    return o.resetTo(a, f, m, p)
                };
            return c.tween = o, c
        },
        isTweening: function(e) {
            return Ge.getTweensOf(e, !0).length > 0
        },
        defaults: function(e) {
            return e && e.ease && (e.ease = ba(e.ease, As.ease)), D1(As, e || {})
        },
        config: function(e) {
            return D1(Wt, e || {})
        },
        registerEffect: function(e) {
            var a = e.name,
                s = e.effect,
                l = e.plugins,
                o = e.defaults,
                c = e.extendTimeline;
            (l || "").split(",").forEach(function(h) {
                return h && !Kt[h] && !Jt[h] && el(a + " effect requires " + h + " plugin.")
            }), Zf[a] = function(h, f, m) {
                return s(gn(h), en(f || {}, o), m)
            }, c && (_t.prototype[a] = function(h, f, m) {
                return this.add(Zf[a](h, kn(f) ? f : (m = f) && {}, this), m)
            })
        },
        registerEase: function(e, a) {
            Se[e] = ba(a)
        },
        parseEase: function(e, a) {
            return arguments.length ? ba(e, a) : Se
        },
        getById: function(e) {
            return Ge.getById(e)
        },
        exportRoot: function(e, a) {
            e === void 0 && (e = {});
            var s = new _t(e),
                l, o;
            for (s.smoothChildTiming = Rt(e.smoothChildTiming), Ge.remove(s), s._dp = 0, s._time = s._tTime = Ge._time, l = Ge._first; l;) o = l._next, (a || !(!l._dur && l instanceof nt && l.vars.onComplete === l._targets[0])) && zn(s, l, l._start - l._delay), l = o;
            return zn(Ge, s, 0), s
        },
        context: function(e, a) {
            return e ? new f2(e, a) : ke
        },
        matchMedia: function(e) {
            return new C4(e)
        },
        matchMediaRefresh: function() {
            return xa.forEach(function(e) {
                var a = e.conditions,
                    s, l;
                for (l in a) a[l] && (a[l] = !1, s = 1);
                s && e.revert()
            }) || Bd()
        },
        addEventListener: function(e, a) {
            var s = Xo[e] || (Xo[e] = []);
            ~s.indexOf(a) || s.push(a)
        },
        removeEventListener: function(e, a) {
            var s = Xo[e],
                l = s && s.indexOf(a);
            l >= 0 && s.splice(l, 1)
        },
        utils: {
            wrap: r4,
            wrapYoyo: l4,
            distribute: Yy,
            random: Fy,
            snap: Xy,
            normalize: s4,
            getUnit: bt,
            clamp: t4,
            splitColor: $y,
            toArray: gn,
            selector: Nd,
            mapRange: Zy,
            pipe: i4,
            unitize: a4,
            interpolate: o4,
            shuffle: qy
        },
        install: zy,
        effects: Zf,
        ticker: Qt,
        updateRoot: _t.updateRoot,
        plugins: Kt,
        globalTimeline: Ge,
        core: {
            PropTween: jt,
            globals: Ry,
            Tween: nt,
            Timeline: _t,
            Animation: al,
            getCache: va,
            _removeLinkedListItem: bu,
            reverting: function() {
                return pt
            },
            context: function(e) {
                return e && ke && (ke.data.push(e), e._ctx = ke), ke
            },
            suppressOverwrites: function(e) {
                return Sh = e
            }
        }
    };
Lt("to,from,fromTo,delayedCall,set,killTweensOf", function(n) {
    return su[n] = nt[n]
});
Qt.add(_t.updateRoot);
ms = su.to({}, {
    duration: 0
});
var O4 = function(e, a) {
        for (var s = e._pt; s && s.p !== a && s.op !== a && s.fp !== a;) s = s._next;
        return s
    },
    D4 = function(e, a) {
        var s = e._targets,
            l, o, c;
        for (l in a)
            for (o = s.length; o--;) c = e._ptLookup[o][l], c && (c = c.d) && (c._pt && (c = O4(c, l)), c && c.modifier && c.modifier(a[l], e, s[o], l))
    },
    Jf = function(e, a) {
        return {
            name: e,
            headless: 1,
            rawVars: 1,
            init: function(l, o, c) {
                c._onInit = function(h) {
                    var f, m;
                    if (ct(o) && (f = {}, Lt(o, function(p) {
                            return f[p] = 1
                        }), o = f), a) {
                        f = {};
                        for (m in o) f[m] = a(o[m]);
                        o = f
                    }
                    D4(h, o)
                }
            }
        }
    },
    Vt = su.registerPlugin({
        name: "attr",
        init: function(e, a, s, l, o) {
            var c, h, f;
            this.tween = s;
            for (c in a) f = e.getAttribute(c) || "", h = this.add(e, "setAttribute", (f || 0) + "", a[c], l, o, 0, 0, c), h.op = c, h.b = f, this._props.push(c)
        },
        render: function(e, a) {
            for (var s = a._pt; s;) pt ? s.set(s.t, s.p, s.b, s) : s.r(e, s.d), s = s._next
        }
    }, {
        name: "endArray",
        headless: 1,
        init: function(e, a) {
            for (var s = a.length; s--;) this.add(e, s, e[s] || 0, a[s], 0, 0, 0, 0, 0, 1)
        }
    }, Jf("roundProps", Vd), Jf("modifiers"), Jf("snap", Xy)) || su;
nt.version = _t.version = Vt.version = "3.14.2";
Dy = 1;
_h() && zs();
Se.Power0;
Se.Power1;
Se.Power2;
Se.Power3;
Se.Power4;
Se.Linear;
Se.Quad;
Se.Cubic;
Se.Quart;
Se.Quint;
Se.Strong;
Se.Elastic;
Se.Back;
Se.SteppedEase;
Se.Bounce;
Se.Sine;
Se.Expo;
Se.Circ;
/*!
 * CSSPlugin 3.14.2
 * https://gsap.com
 *
 * Copyright 2008-2025, GreenSock. All rights reserved.
 * Subject to the terms at https://gsap.com/standard-license
 * @author: Jack Doyle, jack@greensock.com
 */
var V1, Li, Ss, Nh, ma, k1, Vh, z4 = function() {
        return typeof window < "u"
    },
    ii = {},
    da = 180 / Math.PI,
    Ts = Math.PI / 180,
    cs = Math.atan2,
    B1 = 1e8,
    kh = /([A-Z])/g,
    R4 = /(left|right|width|margin|padding|x)/i,
    L4 = /[\s,\(]\S/,
    Rn = {
        autoAlpha: "opacity,visibility",
        scale: "scaleX,scaleY",
        alpha: "opacity"
    },
    Pd = function(e, a) {
        return a.set(a.t, a.p, Math.round((a.s + a.c * e) * 1e4) / 1e4 + a.u, a)
    },
    j4 = function(e, a) {
        return a.set(a.t, a.p, e === 1 ? a.e : Math.round((a.s + a.c * e) * 1e4) / 1e4 + a.u, a)
    },
    N4 = function(e, a) {
        return a.set(a.t, a.p, e ? Math.round((a.s + a.c * e) * 1e4) / 1e4 + a.u : a.b, a)
    },
    V4 = function(e, a) {
        return a.set(a.t, a.p, e === 1 ? a.e : e ? Math.round((a.s + a.c * e) * 1e4) / 1e4 + a.u : a.b, a)
    },
    k4 = function(e, a) {
        var s = a.s + a.c * e;
        a.set(a.t, a.p, ~~(s + (s < 0 ? -.5 : .5)) + a.u, a)
    },
    d2 = function(e, a) {
        return a.set(a.t, a.p, e ? a.e : a.b, a)
    },
    h2 = function(e, a) {
        return a.set(a.t, a.p, e !== 1 ? a.b : a.e, a)
    },
    B4 = function(e, a, s) {
        return e.style[a] = s
    },
    P4 = function(e, a, s) {
        return e.style.setProperty(a, s)
    },
    U4 = function(e, a, s) {
        return e._gsap[a] = s
    },
    H4 = function(e, a, s) {
        return e._gsap.scaleX = e._gsap.scaleY = s
    },
    G4 = function(e, a, s, l, o) {
        var c = e._gsap;
        c.scaleX = c.scaleY = s, c.renderTransform(o, c)
    },
    q4 = function(e, a, s, l, o) {
        var c = e._gsap;
        c[a] = s, c.renderTransform(o, c)
    },
    qe = "transform",
    Nt = qe + "Origin",
    Y4 = function n(e, a) {
        var s = this,
            l = this.target,
            o = l.style,
            c = l._gsap;
        if (e in ii && o) {
            if (this.tfm = this.tfm || {}, e !== "transform") e = Rn[e] || e, ~e.indexOf(",") ? e.split(",").forEach(function(h) {
                return s.tfm[h] = ti(l, h)
            }) : this.tfm[e] = c.x ? c[e] : ti(l, e), e === Nt && (this.tfm.zOrigin = c.zOrigin);
            else return Rn.transform.split(",").forEach(function(h) {
                return n.call(s, h, a)
            });
            if (this.props.indexOf(qe) >= 0) return;
            c.svg && (this.svgo = l.getAttribute("data-svg-origin"), this.props.push(Nt, a, "")), e = qe
        }(o || a) && this.props.push(e, a, o[e])
    },
    m2 = function(e) {
        e.translate && (e.removeProperty("translate"), e.removeProperty("scale"), e.removeProperty("rotate"))
    },
    X4 = function() {
        var e = this.props,
            a = this.target,
            s = a.style,
            l = a._gsap,
            o, c;
        for (o = 0; o < e.length; o += 3) e[o + 1] ? e[o + 1] === 2 ? a[e[o]](e[o + 2]) : a[e[o]] = e[o + 2] : e[o + 2] ? s[e[o]] = e[o + 2] : s.removeProperty(e[o].substr(0, 2) === "--" ? e[o] : e[o].replace(kh, "-$1").toLowerCase());
        if (this.tfm) {
            for (c in this.tfm) l[c] = this.tfm[c];
            l.svg && (l.renderTransform(), a.setAttribute("data-svg-origin", this.svgo || "")), o = Vh(), (!o || !o.isStart) && !s[qe] && (m2(s), l.zOrigin && s[Nt] && (s[Nt] += " " + l.zOrigin + "px", l.zOrigin = 0, l.renderTransform()), l.uncache = 1)
        }
    },
    p2 = function(e, a) {
        var s = {
            target: e,
            props: [],
            revert: X4,
            save: Y4
        };
        return e._gsap || Vt.core.getCache(e), a && e.style && e.nodeType && a.split(",").forEach(function(l) {
            return s.save(l)
        }), s
    },
    g2, Ud = function(e, a) {
        var s = Li.createElementNS ? Li.createElementNS((a || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), e) : Li.createElement(e);
        return s && s.style ? s : Li.createElement(e)
    },
    $t = function n(e, a, s) {
        var l = getComputedStyle(e);
        return l[a] || l.getPropertyValue(a.replace(kh, "-$1").toLowerCase()) || l.getPropertyValue(a) || !s && n(e, Rs(a) || a, 1) || ""
    },
    P1 = "O,Moz,ms,Ms,Webkit".split(","),
    Rs = function(e, a, s) {
        var l = a || ma,
            o = l.style,
            c = 5;
        if (e in o && !s) return e;
        for (e = e.charAt(0).toUpperCase() + e.substr(1); c-- && !(P1[c] + e in o););
        return c < 0 ? null : (c === 3 ? "ms" : c >= 0 ? P1[c] : "") + e
    },
    Hd = function() {
        z4() && window.document && (V1 = window, Li = V1.document, Ss = Li.documentElement, ma = Ud("div") || {
            style: {}
        }, Ud("div"), qe = Rs(qe), Nt = qe + "Origin", ma.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0", g2 = !!Rs("perspective"), Vh = Vt.core.reverting, Nh = 1)
    },
    U1 = function(e) {
        var a = e.ownerSVGElement,
            s = Ud("svg", a && a.getAttribute("xmlns") || "http://www.w3.org/2000/svg"),
            l = e.cloneNode(!0),
            o;
        l.style.display = "block", s.appendChild(l), Ss.appendChild(s);
        try {
            o = l.getBBox()
        } catch {}
        return s.removeChild(l), Ss.removeChild(s), o
    },
    H1 = function(e, a) {
        for (var s = a.length; s--;)
            if (e.hasAttribute(a[s])) return e.getAttribute(a[s])
    },
    v2 = function(e) {
        var a, s;
        try {
            a = e.getBBox()
        } catch {
            a = U1(e), s = 1
        }
        return a && (a.width || a.height) || s || (a = U1(e)), a && !a.width && !a.x && !a.y ? {
            x: +H1(e, ["x", "cx", "x1"]) || 0,
            y: +H1(e, ["y", "cy", "y1"]) || 0,
            width: 0,
            height: 0
        } : a
    },
    y2 = function(e) {
        return !!(e.getCTM && (!e.parentNode || e.ownerSVGElement) && v2(e))
    },
    Pi = function(e, a) {
        if (a) {
            var s = e.style,
                l;
            a in ii && a !== Nt && (a = qe), s.removeProperty ? (l = a.substr(0, 2), (l === "ms" || a.substr(0, 6) === "webkit") && (a = "-" + a), s.removeProperty(l === "--" ? a : a.replace(kh, "-$1").toLowerCase())) : s.removeAttribute(a)
        }
    },
    ji = function(e, a, s, l, o, c) {
        var h = new jt(e._pt, a, s, 0, 1, c ? h2 : d2);
        return e._pt = h, h.b = l, h.e = o, e._props.push(s), h
    },
    G1 = {
        deg: 1,
        rad: 1,
        turn: 1
    },
    F4 = {
        grid: 1,
        flex: 1
    },
    Ui = function n(e, a, s, l) {
        var o = parseFloat(s) || 0,
            c = (s + "").trim().substr((o + "").length) || "px",
            h = ma.style,
            f = R4.test(a),
            m = e.tagName.toLowerCase() === "svg",
            p = (m ? "client" : "offset") + (f ? "Width" : "Height"),
            v = 100,
            b = l === "px",
            y = l === "%",
            T, S, M, _;
        if (l === c || !o || G1[l] || G1[c]) return o;
        if (c !== "px" && !b && (o = n(e, a, s, "px")), _ = e.getCTM && y2(e), (y || c === "%") && (ii[a] || ~a.indexOf("adius"))) return T = _ ? e.getBBox()[f ? "width" : "height"] : e[p], We(y ? o / T * v : o / 100 * T);
        if (h[f ? "width" : "height"] = v + (b ? c : l), S = l !== "rem" && ~a.indexOf("adius") || l === "em" && e.appendChild && !m ? e : e.parentNode, _ && (S = (e.ownerSVGElement || {}).parentNode), (!S || S === Li || !S.appendChild) && (S = Li.body), M = S._gsap, M && y && M.width && f && M.time === Qt.time && !M.uncache) return We(o / M.width * v);
        if (y && (a === "height" || a === "width")) {
            var w = e.style[a];
            e.style[a] = v + l, T = e[p], w ? e.style[a] = w : Pi(e, a)
        } else(y || c === "%") && !F4[$t(S, "display")] && (h.position = $t(e, "position")), S === e && (h.position = "static"), S.appendChild(ma), T = ma[p], S.removeChild(ma), h.position = "absolute";
        return f && y && (M = va(S), M.time = Qt.time, M.width = S[p]), We(b ? T * o / v : T && o ? v / T * o : 0)
    },
    ti = function(e, a, s, l) {
        var o;
        return Nh || Hd(), a in Rn && a !== "transform" && (a = Rn[a], ~a.indexOf(",") && (a = a.split(",")[0])), ii[a] && a !== "transform" ? (o = rl(e, l), o = a !== "transformOrigin" ? o[a] : o.svg ? o.origin : lu($t(e, Nt)) + " " + o.zOrigin + "px") : (o = e.style[a], (!o || o === "auto" || l || ~(o + "").indexOf("calc(")) && (o = ru[a] && ru[a](e, a, s) || $t(e, a) || jy(e, a) || (a === "opacity" ? 1 : 0))), s && !~(o + "").trim().indexOf(" ") ? Ui(e, a, o, s) + s : o
    },
    K4 = function(e, a, s, l) {
        if (!s || s === "none") {
            var o = Rs(a, e, 1),
                c = o && $t(e, o, 1);
            c && c !== s ? (a = o, s = c) : a === "borderColor" && (s = $t(e, "borderTopColor"))
        }
        var h = new jt(this._pt, e.style, a, 0, 1, u2),
            f = 0,
            m = 0,
            p, v, b, y, T, S, M, _, w, C, L, O;
        if (h.b = s, h.e = l, s += "", l += "", l.substring(0, 6) === "var(--" && (l = $t(e, l.substring(4, l.indexOf(")")))), l === "auto" && (S = e.style[a], e.style[a] = l, l = $t(e, a) || l, S ? e.style[a] = S : Pi(e, a)), p = [s, l], Jy(p), s = p[0], l = p[1], b = s.match(hs) || [], O = l.match(hs) || [], O.length) {
            for (; v = hs.exec(l);) M = v[0], w = l.substring(f, v.index), T ? T = (T + 1) % 5 : (w.substr(-5) === "rgba(" || w.substr(-5) === "hsla(") && (T = 1), M !== (S = b[m++] || "") && (y = parseFloat(S) || 0, L = S.substr((y + "").length), M.charAt(1) === "=" && (M = xs(y, M) + L), _ = parseFloat(M), C = M.substr((_ + "").length), f = hs.lastIndex - C.length, C || (C = C || Wt.units[a] || L, f === l.length && (l += C, h.e += C)), L !== C && (y = Ui(e, a, S, C) || 0), h._pt = {
                _next: h._pt,
                p: w || m === 1 ? w : ",",
                s: y,
                c: _ - y,
                m: T && T < 4 || a === "zIndex" ? Math.round : 0
            });
            h.c = f < l.length ? l.substring(f, l.length) : ""
        } else h.r = a === "display" && l === "none" ? h2 : d2;
        return Oy.test(l) && (h.e = 0), this._pt = h, h
    },
    q1 = {
        top: "0%",
        bottom: "100%",
        left: "0%",
        right: "100%",
        center: "50%"
    },
    Z4 = function(e) {
        var a = e.split(" "),
            s = a[0],
            l = a[1] || "50%";
        return (s === "top" || s === "bottom" || l === "left" || l === "right") && (e = s, s = l, l = e), a[0] = q1[s] || s, a[1] = q1[l] || l, a.join(" ")
    },
    Q4 = function(e, a) {
        if (a.tween && a.tween._time === a.tween._dur) {
            var s = a.t,
                l = s.style,
                o = a.u,
                c = s._gsap,
                h, f, m;
            if (o === "all" || o === !0) l.cssText = "", f = 1;
            else
                for (o = o.split(","), m = o.length; --m > -1;) h = o[m], ii[h] && (f = 1, h = h === "transformOrigin" ? Nt : qe), Pi(s, h);
            f && (Pi(s, qe), c && (c.svg && s.removeAttribute("transform"), l.scale = l.rotate = l.translate = "none", rl(s, 1), c.uncache = 1, m2(l)))
        }
    },
    ru = {
        clearProps: function(e, a, s, l, o) {
            if (o.data !== "isFromStart") {
                var c = e._pt = new jt(e._pt, a, s, 0, 0, Q4);
                return c.u = l, c.pr = -10, c.tween = o, e._props.push(s), 1
            }
        }
    },
    sl = [1, 0, 0, 1, 0, 0],
    b2 = {},
    x2 = function(e) {
        return e === "matrix(1, 0, 0, 1, 0, 0)" || e === "none" || !e
    },
    Y1 = function(e) {
        var a = $t(e, qe);
        return x2(a) ? sl : a.substr(7).match(Cy).map(We)
    },
    Bh = function(e, a) {
        var s = e._gsap || va(e),
            l = e.style,
            o = Y1(e),
            c, h, f, m;
        return s.svg && e.getAttribute("transform") ? (f = e.transform.baseVal.consolidate().matrix, o = [f.a, f.b, f.c, f.d, f.e, f.f], o.join(",") === "1,0,0,1,0,0" ? sl : o) : (o === sl && !e.offsetParent && e !== Ss && !s.svg && (f = l.display, l.display = "block", c = e.parentNode, (!c || !e.offsetParent && !e.getBoundingClientRect().width) && (m = 1, h = e.nextElementSibling, Ss.appendChild(e)), o = Y1(e), f ? l.display = f : Pi(e, "display"), m && (h ? c.insertBefore(e, h) : c ? c.appendChild(e) : Ss.removeChild(e))), a && o.length > 6 ? [o[0], o[1], o[4], o[5], o[12], o[13]] : o)
    },
    Gd = function(e, a, s, l, o, c) {
        var h = e._gsap,
            f = o || Bh(e, !0),
            m = h.xOrigin || 0,
            p = h.yOrigin || 0,
            v = h.xOffset || 0,
            b = h.yOffset || 0,
            y = f[0],
            T = f[1],
            S = f[2],
            M = f[3],
            _ = f[4],
            w = f[5],
            C = a.split(" "),
            L = parseFloat(C[0]) || 0,
            O = parseFloat(C[1]) || 0,
            V, k, D, H;
        s ? f !== sl && (k = y * M - T * S) && (D = L * (M / k) + O * (-S / k) + (S * w - M * _) / k, H = L * (-T / k) + O * (y / k) - (y * w - T * _) / k, L = D, O = H) : (V = v2(e), L = V.x + (~C[0].indexOf("%") ? L / 100 * V.width : L), O = V.y + (~(C[1] || C[0]).indexOf("%") ? O / 100 * V.height : O)), l || l !== !1 && h.smooth ? (_ = L - m, w = O - p, h.xOffset = v + (_ * y + w * S) - _, h.yOffset = b + (_ * T + w * M) - w) : h.xOffset = h.yOffset = 0, h.xOrigin = L, h.yOrigin = O, h.smooth = !!l, h.origin = a, h.originIsAbsolute = !!s, e.style[Nt] = "0px 0px", c && (ji(c, h, "xOrigin", m, L), ji(c, h, "yOrigin", p, O), ji(c, h, "xOffset", v, h.xOffset), ji(c, h, "yOffset", b, h.yOffset)), e.setAttribute("data-svg-origin", L + " " + O)
    },
    rl = function(e, a) {
        var s = e._gsap || new i2(e);
        if ("x" in s && !a && !s.uncache) return s;
        var l = e.style,
            o = s.scaleX < 0,
            c = "px",
            h = "deg",
            f = getComputedStyle(e),
            m = $t(e, Nt) || "0",
            p, v, b, y, T, S, M, _, w, C, L, O, V, k, D, H, F, I, W, ee, ae, se, P, G, X, te, z, Z, ne, ie, le, pe;
        return p = v = b = S = M = _ = w = C = L = 0, y = T = 1, s.svg = !!(e.getCTM && y2(e)), f.translate && ((f.translate !== "none" || f.scale !== "none" || f.rotate !== "none") && (l[qe] = (f.translate !== "none" ? "translate3d(" + (f.translate + " 0 0").split(" ").slice(0, 3).join(", ") + ") " : "") + (f.rotate !== "none" ? "rotate(" + f.rotate + ") " : "") + (f.scale !== "none" ? "scale(" + f.scale.split(" ").join(",") + ") " : "") + (f[qe] !== "none" ? f[qe] : "")), l.scale = l.rotate = l.translate = "none"), k = Bh(e, s.svg), s.svg && (s.uncache ? (X = e.getBBox(), m = s.xOrigin - X.x + "px " + (s.yOrigin - X.y) + "px", G = "") : G = !a && e.getAttribute("data-svg-origin"), Gd(e, G || m, !!G || s.originIsAbsolute, s.smooth !== !1, k)), O = s.xOrigin || 0, V = s.yOrigin || 0, k !== sl && (I = k[0], W = k[1], ee = k[2], ae = k[3], p = se = k[4], v = P = k[5], k.length === 6 ? (y = Math.sqrt(I * I + W * W), T = Math.sqrt(ae * ae + ee * ee), S = I || W ? cs(W, I) * da : 0, w = ee || ae ? cs(ee, ae) * da + S : 0, w && (T *= Math.abs(Math.cos(w * Ts))), s.svg && (p -= O - (O * I + V * ee), v -= V - (O * W + V * ae))) : (pe = k[6], ie = k[7], z = k[8], Z = k[9], ne = k[10], le = k[11], p = k[12], v = k[13], b = k[14], D = cs(pe, ne), M = D * da, D && (H = Math.cos(-D), F = Math.sin(-D), G = se * H + z * F, X = P * H + Z * F, te = pe * H + ne * F, z = se * -F + z * H, Z = P * -F + Z * H, ne = pe * -F + ne * H, le = ie * -F + le * H, se = G, P = X, pe = te), D = cs(-ee, ne), _ = D * da, D && (H = Math.cos(-D), F = Math.sin(-D), G = I * H - z * F, X = W * H - Z * F, te = ee * H - ne * F, le = ae * F + le * H, I = G, W = X, ee = te), D = cs(W, I), S = D * da, D && (H = Math.cos(D), F = Math.sin(D), G = I * H + W * F, X = se * H + P * F, W = W * H - I * F, P = P * H - se * F, I = G, se = X), M && Math.abs(M) + Math.abs(S) > 359.9 && (M = S = 0, _ = 180 - _), y = We(Math.sqrt(I * I + W * W + ee * ee)), T = We(Math.sqrt(P * P + pe * pe)), D = cs(se, P), w = Math.abs(D) > 2e-4 ? D * da : 0, L = le ? 1 / (le < 0 ? -le : le) : 0), s.svg && (G = e.getAttribute("transform"), s.forceCSS = e.setAttribute("transform", "") || !x2($t(e, qe)), G && e.setAttribute("transform", G))), Math.abs(w) > 90 && Math.abs(w) < 270 && (o ? (y *= -1, w += S <= 0 ? 180 : -180, S += S <= 0 ? 180 : -180) : (T *= -1, w += w <= 0 ? 180 : -180)), a = a || s.uncache, s.x = p - ((s.xPercent = p && (!a && s.xPercent || (Math.round(e.offsetWidth / 2) === Math.round(-p) ? -50 : 0))) ? e.offsetWidth * s.xPercent / 100 : 0) + c, s.y = v - ((s.yPercent = v && (!a && s.yPercent || (Math.round(e.offsetHeight / 2) === Math.round(-v) ? -50 : 0))) ? e.offsetHeight * s.yPercent / 100 : 0) + c, s.z = b + c, s.scaleX = We(y), s.scaleY = We(T), s.rotation = We(S) + h, s.rotationX = We(M) + h, s.rotationY = We(_) + h, s.skewX = w + h, s.skewY = C + h, s.transformPerspective = L + c, (s.zOrigin = parseFloat(m.split(" ")[2]) || !a && s.zOrigin || 0) && (l[Nt] = lu(m)), s.xOffset = s.yOffset = 0, s.force3D = Wt.force3D, s.renderTransform = s.svg ? $4 : g2 ? S2 : I4, s.uncache = 0, s
    },
    lu = function(e) {
        return (e = e.split(" "))[0] + " " + e[1]
    },
    ed = function(e, a, s) {
        var l = bt(a);
        return We(parseFloat(a) + parseFloat(Ui(e, "x", s + "px", l))) + l
    },
    I4 = function(e, a) {
        a.z = "0px", a.rotationY = a.rotationX = "0deg", a.force3D = 0, S2(e, a)
    },
    ua = "0deg",
    kr = "0px",
    ca = ") ",
    S2 = function(e, a) {
        var s = a || this,
            l = s.xPercent,
            o = s.yPercent,
            c = s.x,
            h = s.y,
            f = s.z,
            m = s.rotation,
            p = s.rotationY,
            v = s.rotationX,
            b = s.skewX,
            y = s.skewY,
            T = s.scaleX,
            S = s.scaleY,
            M = s.transformPerspective,
            _ = s.force3D,
            w = s.target,
            C = s.zOrigin,
            L = "",
            O = _ === "auto" && e && e !== 1 || _ === !0;
        if (C && (v !== ua || p !== ua)) {
            var V = parseFloat(p) * Ts,
                k = Math.sin(V),
                D = Math.cos(V),
                H;
            V = parseFloat(v) * Ts, H = Math.cos(V), c = ed(w, c, k * H * -C), h = ed(w, h, -Math.sin(V) * -C), f = ed(w, f, D * H * -C + C)
        }
        M !== kr && (L += "perspective(" + M + ca), (l || o) && (L += "translate(" + l + "%, " + o + "%) "), (O || c !== kr || h !== kr || f !== kr) && (L += f !== kr || O ? "translate3d(" + c + ", " + h + ", " + f + ") " : "translate(" + c + ", " + h + ca), m !== ua && (L += "rotate(" + m + ca), p !== ua && (L += "rotateY(" + p + ca), v !== ua && (L += "rotateX(" + v + ca), (b !== ua || y !== ua) && (L += "skew(" + b + ", " + y + ca), (T !== 1 || S !== 1) && (L += "scale(" + T + ", " + S + ca), w.style[qe] = L || "translate(0, 0)"
    },
    $4 = function(e, a) {
        var s = a || this,
            l = s.xPercent,
            o = s.yPercent,
            c = s.x,
            h = s.y,
            f = s.rotation,
            m = s.skewX,
            p = s.skewY,
            v = s.scaleX,
            b = s.scaleY,
            y = s.target,
            T = s.xOrigin,
            S = s.yOrigin,
            M = s.xOffset,
            _ = s.yOffset,
            w = s.forceCSS,
            C = parseFloat(c),
            L = parseFloat(h),
            O, V, k, D, H;
        f = parseFloat(f), m = parseFloat(m), p = parseFloat(p), p && (p = parseFloat(p), m += p, f += p), f || m ? (f *= Ts, m *= Ts, O = Math.cos(f) * v, V = Math.sin(f) * v, k = Math.sin(f - m) * -b, D = Math.cos(f - m) * b, m && (p *= Ts, H = Math.tan(m - p), H = Math.sqrt(1 + H * H), k *= H, D *= H, p && (H = Math.tan(p), H = Math.sqrt(1 + H * H), O *= H, V *= H)), O = We(O), V = We(V), k = We(k), D = We(D)) : (O = v, D = b, V = k = 0), (C && !~(c + "").indexOf("px") || L && !~(h + "").indexOf("px")) && (C = Ui(y, "x", c, "px"), L = Ui(y, "y", h, "px")), (T || S || M || _) && (C = We(C + T - (T * O + S * k) + M), L = We(L + S - (T * V + S * D) + _)), (l || o) && (H = y.getBBox(), C = We(C + l / 100 * H.width), L = We(L + o / 100 * H.height)), H = "matrix(" + O + "," + V + "," + k + "," + D + "," + C + "," + L + ")", y.setAttribute("transform", H), w && (y.style[qe] = H)
    },
    W4 = function(e, a, s, l, o) {
        var c = 360,
            h = ct(o),
            f = parseFloat(o) * (h && ~o.indexOf("rad") ? da : 1),
            m = f - l,
            p = l + m + "deg",
            v, b;
        return h && (v = o.split("_")[1], v === "short" && (m %= c, m !== m % (c / 2) && (m += m < 0 ? c : -c)), v === "cw" && m < 0 ? m = (m + c * B1) % c - ~~(m / c) * c : v === "ccw" && m > 0 && (m = (m - c * B1) % c - ~~(m / c) * c)), e._pt = b = new jt(e._pt, a, s, l, m, j4), b.e = p, b.u = "deg", e._props.push(s), b
    },
    X1 = function(e, a) {
        for (var s in a) e[s] = a[s];
        return e
    },
    J4 = function(e, a, s) {
        var l = X1({}, s._gsap),
            o = "perspective,force3D,transformOrigin,svgOrigin",
            c = s.style,
            h, f, m, p, v, b, y, T;
        l.svg ? (m = s.getAttribute("transform"), s.setAttribute("transform", ""), c[qe] = a, h = rl(s, 1), Pi(s, qe), s.setAttribute("transform", m)) : (m = getComputedStyle(s)[qe], c[qe] = a, h = rl(s, 1), c[qe] = m);
        for (f in ii) m = l[f], p = h[f], m !== p && o.indexOf(f) < 0 && (y = bt(m), T = bt(p), v = y !== T ? Ui(s, f, m, T) : parseFloat(m), b = parseFloat(p), e._pt = new jt(e._pt, h, f, v, b - v, Pd), e._pt.u = T || 0, e._props.push(f));
        X1(h, l)
    };
Lt("padding,margin,Width,Radius", function(n, e) {
    var a = "Top",
        s = "Right",
        l = "Bottom",
        o = "Left",
        c = (e < 3 ? [a, s, l, o] : [a + o, a + s, l + s, l + o]).map(function(h) {
            return e < 2 ? n + h : "border" + h + n
        });
    ru[e > 1 ? "border" + n : n] = function(h, f, m, p, v) {
        var b, y;
        if (arguments.length < 4) return b = c.map(function(T) {
            return ti(h, T, m)
        }), y = b.join(" "), y.split(b[0]).length === 5 ? b[0] : y;
        b = (p + "").split(" "), y = {}, c.forEach(function(T, S) {
            return y[T] = b[S] = b[S] || b[(S - 1) / 2 | 0]
        }), h.init(f, y, v)
    }
});
var T2 = {
    name: "css",
    register: Hd,
    targetTest: function(e) {
        return e.style && e.nodeType
    },
    init: function(e, a, s, l, o) {
        var c = this._props,
            h = e.style,
            f = s.vars.startAt,
            m, p, v, b, y, T, S, M, _, w, C, L, O, V, k, D, H;
        Nh || Hd(), this.styles = this.styles || p2(e), D = this.styles.props, this.tween = s;
        for (S in a)
            if (S !== "autoRound" && (p = a[S], !(Kt[S] && a2(S, a, s, l, e, o)))) {
                if (y = typeof p, T = ru[S], y === "function" && (p = p.call(s, l, e, o), y = typeof p), y === "string" && ~p.indexOf("random(") && (p = nl(p)), T) T(this, e, S, p, s) && (k = 1);
                else if (S.substr(0, 2) === "--") m = (getComputedStyle(e).getPropertyValue(S) + "").trim(), p += "", ki.lastIndex = 0, ki.test(m) || (M = bt(m), _ = bt(p), _ ? M !== _ && (m = Ui(e, S, m, _) + _) : M && (p += M)), this.add(h, "setProperty", m, p, l, o, 0, 0, S), c.push(S), D.push(S, 0, h[S]);
                else if (y !== "undefined") {
                    if (f && S in f ? (m = typeof f[S] == "function" ? f[S].call(s, l, e, o) : f[S], ct(m) && ~m.indexOf("random(") && (m = nl(m)), bt(m + "") || m === "auto" || (m += Wt.units[S] || bt(ti(e, S)) || ""), (m + "").charAt(1) === "=" && (m = ti(e, S))) : m = ti(e, S), b = parseFloat(m), w = y === "string" && p.charAt(1) === "=" && p.substr(0, 2), w && (p = p.substr(2)), v = parseFloat(p), S in Rn && (S === "autoAlpha" && (b === 1 && ti(e, "visibility") === "hidden" && v && (b = 0), D.push("visibility", 0, h.visibility), ji(this, h, "visibility", b ? "inherit" : "hidden", v ? "inherit" : "hidden", !v)), S !== "scale" && S !== "transform" && (S = Rn[S], ~S.indexOf(",") && (S = S.split(",")[0]))), C = S in ii, C) {
                        if (this.styles.save(S), H = p, y === "string" && p.substring(0, 6) === "var(--") {
                            if (p = $t(e, p.substring(4, p.indexOf(")"))), p.substring(0, 5) === "calc(") {
                                var F = e.style.perspective;
                                e.style.perspective = p, p = $t(e, "perspective"), F ? e.style.perspective = F : Pi(e, "perspective")
                            }
                            v = parseFloat(p)
                        }
                        if (L || (O = e._gsap, O.renderTransform && !a.parseTransform || rl(e, a.parseTransform), V = a.smoothOrigin !== !1 && O.smooth, L = this._pt = new jt(this._pt, h, qe, 0, 1, O.renderTransform, O, 0, -1), L.dep = 1), S === "scale") this._pt = new jt(this._pt, O, "scaleY", O.scaleY, (w ? xs(O.scaleY, w + v) : v) - O.scaleY || 0, Pd), this._pt.u = 0, c.push("scaleY", S), S += "X";
                        else if (S === "transformOrigin") {
                            D.push(Nt, 0, h[Nt]), p = Z4(p), O.svg ? Gd(e, p, 0, V, 0, this) : (_ = parseFloat(p.split(" ")[2]) || 0, _ !== O.zOrigin && ji(this, O, "zOrigin", O.zOrigin, _), ji(this, h, S, lu(m), lu(p)));
                            continue
                        } else if (S === "svgOrigin") {
                            Gd(e, p, 1, V, 0, this);
                            continue
                        } else if (S in b2) {
                            W4(this, O, S, b, w ? xs(b, w + p) : p);
                            continue
                        } else if (S === "smoothOrigin") {
                            ji(this, O, "smooth", O.smooth, p);
                            continue
                        } else if (S === "force3D") {
                            O[S] = p;
                            continue
                        } else if (S === "transform") {
                            J4(this, p, e);
                            continue
                        }
                    } else S in h || (S = Rs(S) || S);
                    if (C || (v || v === 0) && (b || b === 0) && !L4.test(p) && S in h) M = (m + "").substr((b + "").length), v || (v = 0), _ = bt(p) || (S in Wt.units ? Wt.units[S] : M), M !== _ && (b = Ui(e, S, m, _)), this._pt = new jt(this._pt, C ? O : h, S, b, (w ? xs(b, w + v) : v) - b, !C && (_ === "px" || S === "zIndex") && a.autoRound !== !1 ? k4 : Pd), this._pt.u = _ || 0, C && H !== p ? (this._pt.b = m, this._pt.e = H, this._pt.r = V4) : M !== _ && _ !== "%" && (this._pt.b = m, this._pt.r = N4);
                    else if (S in h) K4.call(this, e, S, m, w ? w + p : p);
                    else if (S in e) this.add(e, S, m || e[S], w ? w + p : p, l, o);
                    else if (S !== "parseTransform") {
                        wh(S, p);
                        continue
                    }
                    C || (S in h ? D.push(S, 0, h[S]) : typeof e[S] == "function" ? D.push(S, 2, e[S]()) : D.push(S, 1, m || e[S])), c.push(S)
                }
            }
        k && c2(this)
    },
    render: function(e, a) {
        if (a.tween._time || !Vh())
            for (var s = a._pt; s;) s.r(e, s.d), s = s._next;
        else a.styles.revert()
    },
    get: ti,
    aliases: Rn,
    getSetter: function(e, a, s) {
        var l = Rn[a];
        return l && l.indexOf(",") < 0 && (a = l), a in ii && a !== Nt && (e._gsap.x || ti(e, "x")) ? s && k1 === s ? a === "scale" ? H4 : U4 : (k1 = s || {}) && (a === "scale" ? G4 : q4) : e.style && !Th(e.style[a]) ? B4 : ~a.indexOf("-") ? P4 : Lh(e, a)
    },
    core: {
        _removeProperty: Pi,
        _getMatrix: Bh
    }
};
Vt.utils.checkPrefix = Rs;
Vt.core.getStyleSaver = p2;
(function(n, e, a, s) {
    var l = Lt(n + "," + e + "," + a, function(o) {
        ii[o] = 1
    });
    Lt(e, function(o) {
        Wt.units[o] = "deg", b2[o] = 1
    }), Rn[l[13]] = n + "," + e, Lt(s, function(o) {
        var c = o.split(":");
        Rn[c[1]] = l[c[0]]
    })
})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent", "rotation,rotationX,rotationY,skewX,skewY", "transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", "0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");
Lt("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function(n) {
    Wt.units[n] = "px"
});
Vt.registerPlugin(T2);
var Fo = Vt.registerPlugin(T2) || Vt;
Fo.core.Tween;
const we = {
        avatar: "/img/profil.jpg",
        icon: "/img/optimized/icon-placeholder.webp",
        siteUrl: "https://your-portfolio.vercel.app",
        email: "contact@example.com",
        name: "Yassine El Amrani",
        title: "Zertifizierte Pflegefachkraft",
        location: "Fes, Marokko → Bayern, Deutschland",
        credentials: ["B2 Deutsch (TELC)", "Staatliches Diplom", "Pflege-Anerkennung i.A."],
        heroPhrases: ["Empathie in der täglichen Pflege.", "Fachkraft mit Herz und Verstand.", "Bereit für neue Herausforderungen in Deutschland.", "Spezialisiert auf Alten- und Krankenpflege."],
        social: {
            linkedin: "https://linkedin.com/in/yassine-pfleger",
            whatsapp: "https://wa.me/212600000000",
            email: "yassine.elamrani@email.ma"
        },
        cvUrl: "/cv/resume-example.pdf"
    },
    e3 = () => {
        const [n, e] = J.useState(""), [a, s] = J.useState(0), [l, o] = J.useState(!1), c = J.useRef(null), h = J.useRef(null), f = J.useRef(null);
        return J.useEffect(() => {
            const m = Fo.context(() => {
                Fo.from(h.current, {
                    duration: 1.2,
                    x: -50,
                    opacity: 0,
                    ease: "power3.out"
                }), Fo.from(".animate-text", {
                    duration: 1,
                    y: 30,
                    opacity: 0,
                    stagger: .2,
                    ease: "power3.out",
                    delay: .5
                })
            }, c);
            return () => m.revert()
        }, []), J.useEffect(() => {
            const m = we.heroPhrases[a],
                p = setTimeout(() => {
                    e(v => l ? m.substring(0, v.length - 1) : m.substring(0, v.length + 1)), !l && n === m ? setTimeout(() => o(!0), 2500) : l && n === "" && (o(!1), s(v => (v + 1) % we.heroPhrases.length))
                }, l ? 30 : 60);
            return () => clearTimeout(p)
        }, [n, l, a]), A.jsxs("section", {
            ref: c,
            className: "relative min-h-screen flex items-center justify-center  bg-[#f8fafc] dark:bg-[#0f172a] py-20 px-6",
            children: [A.jsx("div", {
                className: `
  absolute top-0 right-0
  -translate-y-1/4
  w-[600px] h-[600px]
  bg-emerald-100/40 dark:bg-emerald-900/20
  rounded-full blur-[120px]
  pointer-events-none
`
            }), A.jsx("div", {
                className: "container mx-auto max-w-6xl relative z-10",
                children: A.jsxs("div", {
                    className: "flex flex-col lg:flex-row items-center gap-12 lg:gap-24",
                    children: [A.jsxs("div", {
                        ref: h,
                        className: "relative group",
                        children: [A.jsx("div", {
                            className: "absolute -inset-4 border border-emerald-200 dark:border-emerald-800 rounded-[2rem] scale-95 group-hover:scale-100 transition-transform duration-700"
                        }), A.jsx("img", {
                            src: we.avatar,
                            alt: we.name,
                            className: "relative w-72 h-[400px] object-cover rounded-[2rem] shadow-2xl grayscale-[20%] hover:grayscale-0 transition-all duration-500"
                        }), A.jsxs("div", {
                            className: "absolute -bottom-6 -right-6 bg-white dark:bg-slate-800 p-4 rounded-xl shadow-xl border-l-4 border-emerald-500",
                            children: [A.jsx("p", {
                                className: "text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider",
                                children: "Status"
                            }), A.jsx("p", {
                                className: "text-emerald-600 dark:text-emerald-400 font-bold",
                                children: "B2 Zertifiziert"
                            })]
                        })]
                    }), A.jsxs("div", {
                        ref: f,
                        className: "flex-1 text-center lg:text-left",
                        children: [A.jsxs("div", {
                            className: "animate-text flex items-center justify-center lg:justify-start gap-2 mb-4 text-emerald-600 dark:text-emerald-400 font-medium tracking-wide",
                            children: [A.jsx("span", {
                                className: "w-8 h-[2px] bg-emerald-500"
                            }), we.location]
                        }), A.jsx("h1", {
                            className: "animate-text text-5xl lg:text-7xl font-bold text-slate-900 dark:text-white mb-4 tracking-tight",
                            children: we.name
                        }), A.jsx("h2", {
                            className: "animate-text text-2xl lg:text-3xl text-slate-600 dark:text-slate-300 mb-6 font-light",
                            children: we.title
                        }), A.jsx("div", {
                            className: "animate-text h-16 mb-8 flex items-center justify-center lg:justify-start",
                            children: A.jsxs("p", {
                                className: "text-xl text-emerald-600/80 dark:text-emerald-400/80 font-serif italic border-l-2 border-emerald-500 pl-4",
                                children: [n, A.jsx("span", {
                                    className: "inline-block w-1 h-6 bg-emerald-500 ml-1 animate-pulse"
                                })]
                            })
                        }), A.jsx("div", {
                            className: "animate-text flex flex-wrap gap-3 mb-10 justify-center lg:justify-start",
                            children: we.credentials.map((m, p) => A.jsxs("span", {
                                className: "flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-full text-sm text-slate-700 dark:text-slate-300 shadow-sm",
                                children: [A.jsx(w_, {
                                    className: "text-emerald-500"
                                }), " ", m]
                            }, p))
                        }), A.jsxs("div", {
                            className: "animate-text flex flex-col sm:flex-row gap-5 justify-center lg:justify-start",
                            children: [A.jsxs("a", {
                                href: we.cvUrl,
                                className: "group flex items-center justify-center gap-3 px-10 py-4 bg-slate-900 dark:bg-emerald-600 hover:bg-emerald-600 dark:hover:bg-emerald-700 text-white rounded-full transition-all duration-300 shadow-lg shadow-emerald-900/20",
                                children: [A.jsx(C_, {
                                    className: "group-hover:bounce"
                                }), A.jsx("span", {
                                    className: "font-semibold",
                                    children: "Lebenslauf PDF"
                                })]
                            }), A.jsxs("div", {
                                className: "flex items-center gap-4 px-6",
                                children: [A.jsx("a", {
                                    href: `mailto:${we.social.email}`,
                                    className: "p-3 text-slate-500 hover:text-emerald-600 transition-colors",
                                    children: A.jsx(bh, {
                                        size: 24
                                    })
                                }), A.jsx("a", {
                                    href: we.social.linkedin,
                                    className: "p-3 text-slate-500 hover:text-blue-600 transition-colors",
                                    children: A.jsx(yh, {
                                        size: 24
                                    })
                                }), A.jsx("a", {
                                    href: we.social.whatsapp,
                                    className: "p-3 text-slate-500 hover:text-green-500 transition-colors",
                                    children: A.jsx(Ty, {
                                        size: 24
                                    })
                                })]
                            })]
                        })]
                    })]
                })
            })]
        })
    },
    _2 = J.createContext({});

function t3(n) {
    const e = J.useRef(null);
    return e.current === null && (e.current = n()), e.current
}
const Ph = typeof window < "u",
    n3 = Ph ? J.useLayoutEffect : J.useEffect,
    Uh = J.createContext(null);

function Hh(n, e) {
    n.indexOf(e) === -1 && n.push(e)
}

function Gh(n, e) {
    const a = n.indexOf(e);
    a > -1 && n.splice(a, 1)
}
const ai = (n, e, a) => a > e ? e : a < n ? n : a;
let qh = () => {};
const si = {},
    E2 = n => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(n);

function w2(n) {
    return typeof n == "object" && n !== null
}
const M2 = n => /^0[^.\s]+$/u.test(n);

function Yh(n) {
    let e;
    return () => (e === void 0 && (e = n()), e)
}
const yn = n => n,
    i3 = (n, e) => a => e(n(a)),
    vl = (...n) => n.reduce(i3),
    ll = (n, e, a) => {
        const s = e - n;
        return s === 0 ? 1 : (a - n) / s
    };
class Xh {
    constructor() {
        this.subscriptions = []
    }
    add(e) {
        return Hh(this.subscriptions, e), () => Gh(this.subscriptions, e)
    }
    notify(e, a, s) {
        const l = this.subscriptions.length;
        if (l)
            if (l === 1) this.subscriptions[0](e, a, s);
            else
                for (let o = 0; o < l; o++) {
                    const c = this.subscriptions[o];
                    c && c(e, a, s)
                }
    }
    getSize() {
        return this.subscriptions.length
    }
    clear() {
        this.subscriptions.length = 0
    }
}
const jn = n => n * 1e3,
    vn = n => n / 1e3;

function A2(n, e) {
    return e ? n * (1e3 / e) : 0
}
const C2 = (n, e, a) => (((1 - 3 * a + 3 * e) * n + (3 * a - 6 * e)) * n + 3 * e) * n,
    a3 = 1e-7,
    s3 = 12;

function r3(n, e, a, s, l) {
    let o, c, h = 0;
    do c = e + (a - e) / 2, o = C2(c, s, l) - n, o > 0 ? a = c : e = c; while (Math.abs(o) > a3 && ++h < s3);
    return c
}

function yl(n, e, a, s) {
    if (n === e && a === s) return yn;
    const l = o => r3(o, 0, 1, n, a);
    return o => o === 0 || o === 1 ? o : C2(l(o), e, s)
}
const O2 = n => e => e <= .5 ? n(2 * e) / 2 : (2 - n(2 * (1 - e))) / 2,
    D2 = n => e => 1 - n(1 - e),
    z2 = yl(.33, 1.53, .69, .99),
    Fh = D2(z2),
    R2 = O2(Fh),
    L2 = n => (n *= 2) < 1 ? .5 * Fh(n) : .5 * (2 - Math.pow(2, -10 * (n - 1))),
    Kh = n => 1 - Math.sin(Math.acos(n)),
    j2 = D2(Kh),
    N2 = O2(Kh),
    l3 = yl(.42, 0, 1, 1),
    o3 = yl(0, 0, .58, 1),
    V2 = yl(.42, 0, .58, 1),
    u3 = n => Array.isArray(n) && typeof n[0] != "number",
    k2 = n => Array.isArray(n) && typeof n[0] == "number",
    c3 = {
        linear: yn,
        easeIn: l3,
        easeInOut: V2,
        easeOut: o3,
        circIn: Kh,
        circInOut: N2,
        circOut: j2,
        backIn: Fh,
        backInOut: R2,
        backOut: z2,
        anticipate: L2
    },
    f3 = n => typeof n == "string",
    F1 = n => {
        if (k2(n)) {
            qh(n.length === 4);
            const [e, a, s, l] = n;
            return yl(e, a, s, l)
        } else if (f3(n)) return c3[n];
        return n
    },
    Bo = ["setup", "read", "resolveKeyframes", "preUpdate", "update", "preRender", "render", "postRender"];

function d3(n, e) {
    let a = new Set,
        s = new Set,
        l = !1,
        o = !1;
    const c = new WeakSet;
    let h = {
        delta: 0,
        timestamp: 0,
        isProcessing: !1
    };

    function f(p) {
        c.has(p) && (m.schedule(p), n()), p(h)
    }
    const m = {
        schedule: (p, v = !1, b = !1) => {
            const T = b && l ? a : s;
            return v && c.add(p), T.has(p) || T.add(p), p
        },
        cancel: p => {
            s.delete(p), c.delete(p)
        },
        process: p => {
            if (h = p, l) {
                o = !0;
                return
            }
            l = !0, [a, s] = [s, a], a.forEach(f), a.clear(), l = !1, o && (o = !1, m.process(p))
        }
    };
    return m
}
const h3 = 40;

function B2(n, e) {
    let a = !1,
        s = !0;
    const l = {
            delta: 0,
            timestamp: 0,
            isProcessing: !1
        },
        o = () => a = !0,
        c = Bo.reduce((C, L) => (C[L] = d3(o), C), {}),
        {
            setup: h,
            read: f,
            resolveKeyframes: m,
            preUpdate: p,
            update: v,
            preRender: b,
            render: y,
            postRender: T
        } = c,
        S = () => {
            const C = si.useManualTiming ? l.timestamp : performance.now();
            a = !1, si.useManualTiming || (l.delta = s ? 1e3 / 60 : Math.max(Math.min(C - l.timestamp, h3), 1)), l.timestamp = C, l.isProcessing = !0, h.process(l), f.process(l), m.process(l), p.process(l), v.process(l), b.process(l), y.process(l), T.process(l), l.isProcessing = !1, a && e && (s = !1, n(S))
        },
        M = () => {
            a = !0, s = !0, l.isProcessing || n(S)
        };
    return {
        schedule: Bo.reduce((C, L) => {
            const O = c[L];
            return C[L] = (V, k = !1, D = !1) => (a || M(), O.schedule(V, k, D)), C
        }, {}),
        cancel: C => {
            for (let L = 0; L < Bo.length; L++) c[Bo[L]].cancel(C)
        },
        state: l,
        steps: c
    }
}
const {
    schedule: Be,
    cancel: Hi,
    state: mt,
    steps: td
} = B2(typeof requestAnimationFrame < "u" ? requestAnimationFrame : yn, !0);
let Ko;

function m3() {
    Ko = void 0
}
const zt = {
        now: () => (Ko === void 0 && zt.set(mt.isProcessing || si.useManualTiming ? mt.timestamp : performance.now()), Ko),
        set: n => {
            Ko = n, queueMicrotask(m3)
        }
    },
    P2 = n => e => typeof e == "string" && e.startsWith(n),
    Zh = P2("--"),
    p3 = P2("var(--"),
    Qh = n => p3(n) ? g3.test(n.split("/*")[0].trim()) : !1,
    g3 = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
    Ns = {
        test: n => typeof n == "number",
        parse: parseFloat,
        transform: n => n
    },
    ol = { ...Ns,
        transform: n => ai(0, 1, n)
    },
    Po = { ...Ns,
        default: 1
    },
    Zr = n => Math.round(n * 1e5) / 1e5,
    Ih = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;

function v3(n) {
    return n == null
}
const y3 = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
    $h = (n, e) => a => !!(typeof a == "string" && y3.test(a) && a.startsWith(n) || e && !v3(a) && Object.prototype.hasOwnProperty.call(a, e)),
    U2 = (n, e, a) => s => {
        if (typeof s != "string") return s;
        const [l, o, c, h] = s.match(Ih);
        return {
            [n]: parseFloat(l),
            [e]: parseFloat(o),
            [a]: parseFloat(c),
            alpha: h !== void 0 ? parseFloat(h) : 1
        }
    },
    b3 = n => ai(0, 255, n),
    nd = { ...Ns,
        transform: n => Math.round(b3(n))
    },
    pa = {
        test: $h("rgb", "red"),
        parse: U2("red", "green", "blue"),
        transform: ({
            red: n,
            green: e,
            blue: a,
            alpha: s = 1
        }) => "rgba(" + nd.transform(n) + ", " + nd.transform(e) + ", " + nd.transform(a) + ", " + Zr(ol.transform(s)) + ")"
    };

function x3(n) {
    let e = "",
        a = "",
        s = "",
        l = "";
    return n.length > 5 ? (e = n.substring(1, 3), a = n.substring(3, 5), s = n.substring(5, 7), l = n.substring(7, 9)) : (e = n.substring(1, 2), a = n.substring(2, 3), s = n.substring(3, 4), l = n.substring(4, 5), e += e, a += a, s += s, l += l), {
        red: parseInt(e, 16),
        green: parseInt(a, 16),
        blue: parseInt(s, 16),
        alpha: l ? parseInt(l, 16) / 255 : 1
    }
}
const qd = {
        test: $h("#"),
        parse: x3,
        transform: pa.transform
    },
    bl = n => ({
        test: e => typeof e == "string" && e.endsWith(n) && e.split(" ").length === 1,
        parse: parseFloat,
        transform: e => `${e}${n}`
    }),
    zi = bl("deg"),
    Nn = bl("%"),
    de = bl("px"),
    S3 = bl("vh"),
    T3 = bl("vw"),
    K1 = { ...Nn,
        parse: n => Nn.parse(n) / 100,
        transform: n => Nn.transform(n * 100)
    },
    ps = {
        test: $h("hsl", "hue"),
        parse: U2("hue", "saturation", "lightness"),
        transform: ({
            hue: n,
            saturation: e,
            lightness: a,
            alpha: s = 1
        }) => "hsla(" + Math.round(n) + ", " + Nn.transform(Zr(e)) + ", " + Nn.transform(Zr(a)) + ", " + Zr(ol.transform(s)) + ")"
    },
    tt = {
        test: n => pa.test(n) || qd.test(n) || ps.test(n),
        parse: n => pa.test(n) ? pa.parse(n) : ps.test(n) ? ps.parse(n) : qd.parse(n),
        transform: n => typeof n == "string" ? n : n.hasOwnProperty("red") ? pa.transform(n) : ps.transform(n),
        getAnimatableNone: n => {
            const e = tt.parse(n);
            return e.alpha = 0, tt.transform(e)
        }
    },
    _3 = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;

function E3(n) {
    return isNaN(n) && typeof n == "string" && (n.match(Ih) ? .length || 0) + (n.match(_3) ? .length || 0) > 0
}
const H2 = "number",
    G2 = "color",
    w3 = "var",
    M3 = "var(",
    Z1 = "${}",
    A3 = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

function ul(n) {
    const e = n.toString(),
        a = [],
        s = {
            color: [],
            number: [],
            var: []
        },
        l = [];
    let o = 0;
    const h = e.replace(A3, f => (tt.test(f) ? (s.color.push(o), l.push(G2), a.push(tt.parse(f))) : f.startsWith(M3) ? (s.var.push(o), l.push(w3), a.push(f)) : (s.number.push(o), l.push(H2), a.push(parseFloat(f))), ++o, Z1)).split(Z1);
    return {
        values: a,
        split: h,
        indexes: s,
        types: l
    }
}

function q2(n) {
    return ul(n).values
}

function Y2(n) {
    const {
        split: e,
        types: a
    } = ul(n), s = e.length;
    return l => {
        let o = "";
        for (let c = 0; c < s; c++)
            if (o += e[c], l[c] !== void 0) {
                const h = a[c];
                h === H2 ? o += Zr(l[c]) : h === G2 ? o += tt.transform(l[c]) : o += l[c]
            }
        return o
    }
}
const C3 = n => typeof n == "number" ? 0 : tt.test(n) ? tt.getAnimatableNone(n) : n;

function O3(n) {
    const e = q2(n);
    return Y2(n)(e.map(C3))
}
const Gi = {
    test: E3,
    parse: q2,
    createTransformer: Y2,
    getAnimatableNone: O3
};

function id(n, e, a) {
    return a < 0 && (a += 1), a > 1 && (a -= 1), a < 1 / 6 ? n + (e - n) * 6 * a : a < 1 / 2 ? e : a < 2 / 3 ? n + (e - n) * (2 / 3 - a) * 6 : n
}

function D3({
    hue: n,
    saturation: e,
    lightness: a,
    alpha: s
}) {
    n /= 360, e /= 100, a /= 100;
    let l = 0,
        o = 0,
        c = 0;
    if (!e) l = o = c = a;
    else {
        const h = a < .5 ? a * (1 + e) : a + e - a * e,
            f = 2 * a - h;
        l = id(f, h, n + 1 / 3), o = id(f, h, n), c = id(f, h, n - 1 / 3)
    }
    return {
        red: Math.round(l * 255),
        green: Math.round(o * 255),
        blue: Math.round(c * 255),
        alpha: s
    }
}

function ou(n, e) {
    return a => a > 0 ? e : n
}
const Ye = (n, e, a) => n + (e - n) * a,
    ad = (n, e, a) => {
        const s = n * n,
            l = a * (e * e - s) + s;
        return l < 0 ? 0 : Math.sqrt(l)
    },
    z3 = [qd, pa, ps],
    R3 = n => z3.find(e => e.test(n));

function Q1(n) {
    const e = R3(n);
    if (!e) return !1;
    let a = e.parse(n);
    return e === ps && (a = D3(a)), a
}
const I1 = (n, e) => {
        const a = Q1(n),
            s = Q1(e);
        if (!a || !s) return ou(n, e);
        const l = { ...a
        };
        return o => (l.red = ad(a.red, s.red, o), l.green = ad(a.green, s.green, o), l.blue = ad(a.blue, s.blue, o), l.alpha = Ye(a.alpha, s.alpha, o), pa.transform(l))
    },
    Yd = new Set(["none", "hidden"]);

function L3(n, e) {
    return Yd.has(n) ? a => a <= 0 ? n : e : a => a >= 1 ? e : n
}

function j3(n, e) {
    return a => Ye(n, e, a)
}

function Wh(n) {
    return typeof n == "number" ? j3 : typeof n == "string" ? Qh(n) ? ou : tt.test(n) ? I1 : k3 : Array.isArray(n) ? X2 : typeof n == "object" ? tt.test(n) ? I1 : N3 : ou
}

function X2(n, e) {
    const a = [...n],
        s = a.length,
        l = n.map((o, c) => Wh(o)(o, e[c]));
    return o => {
        for (let c = 0; c < s; c++) a[c] = l[c](o);
        return a
    }
}

function N3(n, e) {
    const a = { ...n,
            ...e
        },
        s = {};
    for (const l in a) n[l] !== void 0 && e[l] !== void 0 && (s[l] = Wh(n[l])(n[l], e[l]));
    return l => {
        for (const o in s) a[o] = s[o](l);
        return a
    }
}

function V3(n, e) {
    const a = [],
        s = {
            color: 0,
            var: 0,
            number: 0
        };
    for (let l = 0; l < e.values.length; l++) {
        const o = e.types[l],
            c = n.indexes[o][s[o]],
            h = n.values[c] ? ? 0;
        a[l] = h, s[o]++
    }
    return a
}
const k3 = (n, e) => {
    const a = Gi.createTransformer(e),
        s = ul(n),
        l = ul(e);
    return s.indexes.var.length === l.indexes.var.length && s.indexes.color.length === l.indexes.color.length && s.indexes.number.length >= l.indexes.number.length ? Yd.has(n) && !l.values.length || Yd.has(e) && !s.values.length ? L3(n, e) : vl(X2(V3(s, l), l.values), a) : ou(n, e)
};

function F2(n, e, a) {
    return typeof n == "number" && typeof e == "number" && typeof a == "number" ? Ye(n, e, a) : Wh(n)(n, e)
}
const B3 = n => {
        const e = ({
            timestamp: a
        }) => n(a);
        return {
            start: (a = !0) => Be.update(e, a),
            stop: () => Hi(e),
            now: () => mt.isProcessing ? mt.timestamp : zt.now()
        }
    },
    K2 = (n, e, a = 10) => {
        let s = "";
        const l = Math.max(Math.round(e / a), 2);
        for (let o = 0; o < l; o++) s += Math.round(n(o / (l - 1)) * 1e4) / 1e4 + ", ";
        return `linear(${s.substring(0,s.length-2)})`
    },
    uu = 2e4;

function Jh(n) {
    let e = 0;
    const a = 50;
    let s = n.next(e);
    for (; !s.done && e < uu;) e += a, s = n.next(e);
    return e >= uu ? 1 / 0 : e
}

function P3(n, e = 100, a) {
    const s = a({ ...n,
            keyframes: [0, e]
        }),
        l = Math.min(Jh(s), uu);
    return {
        type: "keyframes",
        ease: o => s.next(l * o).value / e,
        duration: vn(l)
    }
}
const U3 = 5;

function Z2(n, e, a) {
    const s = Math.max(e - U3, 0);
    return A2(a - n(s), e - s)
}
const Ke = {
        stiffness: 100,
        damping: 10,
        mass: 1,
        velocity: 0,
        duration: 800,
        bounce: .3,
        visualDuration: .3,
        restSpeed: {
            granular: .01,
            default: 2
        },
        restDelta: {
            granular: .005,
            default: .5
        },
        minDuration: .01,
        maxDuration: 10,
        minDamping: .05,
        maxDamping: 1
    },
    sd = .001;

function H3({
    duration: n = Ke.duration,
    bounce: e = Ke.bounce,
    velocity: a = Ke.velocity,
    mass: s = Ke.mass
}) {
    let l, o, c = 1 - e;
    c = ai(Ke.minDamping, Ke.maxDamping, c), n = ai(Ke.minDuration, Ke.maxDuration, vn(n)), c < 1 ? (l = m => {
        const p = m * c,
            v = p * n,
            b = p - a,
            y = Xd(m, c),
            T = Math.exp(-v);
        return sd - b / y * T
    }, o = m => {
        const v = m * c * n,
            b = v * a + a,
            y = Math.pow(c, 2) * Math.pow(m, 2) * n,
            T = Math.exp(-v),
            S = Xd(Math.pow(m, 2), c);
        return (-l(m) + sd > 0 ? -1 : 1) * ((b - y) * T) / S
    }) : (l = m => {
        const p = Math.exp(-m * n),
            v = (m - a) * n + 1;
        return -sd + p * v
    }, o = m => {
        const p = Math.exp(-m * n),
            v = (a - m) * (n * n);
        return p * v
    });
    const h = 5 / n,
        f = q3(l, o, h);
    if (n = jn(n), isNaN(f)) return {
        stiffness: Ke.stiffness,
        damping: Ke.damping,
        duration: n
    }; {
        const m = Math.pow(f, 2) * s;
        return {
            stiffness: m,
            damping: c * 2 * Math.sqrt(s * m),
            duration: n
        }
    }
}
const G3 = 12;

function q3(n, e, a) {
    let s = a;
    for (let l = 1; l < G3; l++) s = s - n(s) / e(s);
    return s
}

function Xd(n, e) {
    return n * Math.sqrt(1 - e * e)
}
const Y3 = ["duration", "bounce"],
    X3 = ["stiffness", "damping", "mass"];

function $1(n, e) {
    return e.some(a => n[a] !== void 0)
}

function F3(n) {
    let e = {
        velocity: Ke.velocity,
        stiffness: Ke.stiffness,
        damping: Ke.damping,
        mass: Ke.mass,
        isResolvedFromDuration: !1,
        ...n
    };
    if (!$1(n, X3) && $1(n, Y3))
        if (n.visualDuration) {
            const a = n.visualDuration,
                s = 2 * Math.PI / (a * 1.2),
                l = s * s,
                o = 2 * ai(.05, 1, 1 - (n.bounce || 0)) * Math.sqrt(l);
            e = { ...e,
                mass: Ke.mass,
                stiffness: l,
                damping: o
            }
        } else {
            const a = H3(n);
            e = { ...e,
                ...a,
                mass: Ke.mass
            }, e.isResolvedFromDuration = !0
        }
    return e
}

function cu(n = Ke.visualDuration, e = Ke.bounce) {
    const a = typeof n != "object" ? {
        visualDuration: n,
        keyframes: [0, 1],
        bounce: e
    } : n;
    let {
        restSpeed: s,
        restDelta: l
    } = a;
    const o = a.keyframes[0],
        c = a.keyframes[a.keyframes.length - 1],
        h = {
            done: !1,
            value: o
        },
        {
            stiffness: f,
            damping: m,
            mass: p,
            duration: v,
            velocity: b,
            isResolvedFromDuration: y
        } = F3({ ...a,
            velocity: -vn(a.velocity || 0)
        }),
        T = b || 0,
        S = m / (2 * Math.sqrt(f * p)),
        M = c - o,
        _ = vn(Math.sqrt(f / p)),
        w = Math.abs(M) < 5;
    s || (s = w ? Ke.restSpeed.granular : Ke.restSpeed.default), l || (l = w ? Ke.restDelta.granular : Ke.restDelta.default);
    let C;
    if (S < 1) {
        const O = Xd(_, S);
        C = V => {
            const k = Math.exp(-S * _ * V);
            return c - k * ((T + S * _ * M) / O * Math.sin(O * V) + M * Math.cos(O * V))
        }
    } else if (S === 1) C = O => c - Math.exp(-_ * O) * (M + (T + _ * M) * O);
    else {
        const O = _ * Math.sqrt(S * S - 1);
        C = V => {
            const k = Math.exp(-S * _ * V),
                D = Math.min(O * V, 300);
            return c - k * ((T + S * _ * M) * Math.sinh(D) + O * M * Math.cosh(D)) / O
        }
    }
    const L = {
        calculatedDuration: y && v || null,
        next: O => {
            const V = C(O);
            if (y) h.done = O >= v;
            else {
                let k = O === 0 ? T : 0;
                S < 1 && (k = O === 0 ? jn(T) : Z2(C, O, V));
                const D = Math.abs(k) <= s,
                    H = Math.abs(c - V) <= l;
                h.done = D && H
            }
            return h.value = h.done ? c : V, h
        },
        toString: () => {
            const O = Math.min(Jh(L), uu),
                V = K2(k => L.next(O * k).value, O, 30);
            return O + "ms " + V
        },
        toTransition: () => {}
    };
    return L
}
cu.applyToOptions = n => {
    const e = P3(n, 100, cu);
    return n.ease = e.ease, n.duration = jn(e.duration), n.type = "keyframes", n
};

function Fd({
    keyframes: n,
    velocity: e = 0,
    power: a = .8,
    timeConstant: s = 325,
    bounceDamping: l = 10,
    bounceStiffness: o = 500,
    modifyTarget: c,
    min: h,
    max: f,
    restDelta: m = .5,
    restSpeed: p
}) {
    const v = n[0],
        b = {
            done: !1,
            value: v
        },
        y = D => h !== void 0 && D < h || f !== void 0 && D > f,
        T = D => h === void 0 ? f : f === void 0 || Math.abs(h - D) < Math.abs(f - D) ? h : f;
    let S = a * e;
    const M = v + S,
        _ = c === void 0 ? M : c(M);
    _ !== M && (S = _ - v);
    const w = D => -S * Math.exp(-D / s),
        C = D => _ + w(D),
        L = D => {
            const H = w(D),
                F = C(D);
            b.done = Math.abs(H) <= m, b.value = b.done ? _ : F
        };
    let O, V;
    const k = D => {
        y(b.value) && (O = D, V = cu({
            keyframes: [b.value, T(b.value)],
            velocity: Z2(C, D, b.value),
            damping: l,
            stiffness: o,
            restDelta: m,
            restSpeed: p
        }))
    };
    return k(0), {
        calculatedDuration: null,
        next: D => {
            let H = !1;
            return !V && O === void 0 && (H = !0, L(D), k(D)), O !== void 0 && D >= O ? V.next(D - O) : (!H && L(D), b)
        }
    }
}

function K3(n, e, a) {
    const s = [],
        l = a || si.mix || F2,
        o = n.length - 1;
    for (let c = 0; c < o; c++) {
        let h = l(n[c], n[c + 1]);
        if (e) {
            const f = Array.isArray(e) ? e[c] || yn : e;
            h = vl(f, h)
        }
        s.push(h)
    }
    return s
}

function Z3(n, e, {
    clamp: a = !0,
    ease: s,
    mixer: l
} = {}) {
    const o = n.length;
    if (qh(o === e.length), o === 1) return () => e[0];
    if (o === 2 && e[0] === e[1]) return () => e[1];
    const c = n[0] === n[1];
    n[0] > n[o - 1] && (n = [...n].reverse(), e = [...e].reverse());
    const h = K3(e, s, l),
        f = h.length,
        m = p => {
            if (c && p < n[0]) return e[0];
            let v = 0;
            if (f > 1)
                for (; v < n.length - 2 && !(p < n[v + 1]); v++);
            const b = ll(n[v], n[v + 1], p);
            return h[v](b)
        };
    return a ? p => m(ai(n[0], n[o - 1], p)) : m
}

function Q3(n, e) {
    const a = n[n.length - 1];
    for (let s = 1; s <= e; s++) {
        const l = ll(0, e, s);
        n.push(Ye(a, 1, l))
    }
}

function I3(n) {
    const e = [0];
    return Q3(e, n.length - 1), e
}

function $3(n, e) {
    return n.map(a => a * e)
}

function W3(n, e) {
    return n.map(() => e || V2).splice(0, n.length - 1)
}

function Qr({
    duration: n = 300,
    keyframes: e,
    times: a,
    ease: s = "easeInOut"
}) {
    const l = u3(s) ? s.map(F1) : F1(s),
        o = {
            done: !1,
            value: e[0]
        },
        c = $3(a && a.length === e.length ? a : I3(e), n),
        h = Z3(c, e, {
            ease: Array.isArray(l) ? l : W3(e, l)
        });
    return {
        calculatedDuration: n,
        next: f => (o.value = h(f), o.done = f >= n, o)
    }
}
const J3 = n => n !== null;

function em(n, {
    repeat: e,
    repeatType: a = "loop"
}, s, l = 1) {
    const o = n.filter(J3),
        h = l < 0 || e && a !== "loop" && e % 2 === 1 ? 0 : o.length - 1;
    return !h || s === void 0 ? o[h] : s
}
const e6 = {
    decay: Fd,
    inertia: Fd,
    tween: Qr,
    keyframes: Qr,
    spring: cu
};

function Q2(n) {
    typeof n.type == "string" && (n.type = e6[n.type])
}
class tm {
    constructor() {
        this.updateFinished()
    }
    get finished() {
        return this._finished
    }
    updateFinished() {
        this._finished = new Promise(e => {
            this.resolve = e
        })
    }
    notifyFinished() {
        this.resolve()
    }
    then(e, a) {
        return this.finished.then(e, a)
    }
}
const t6 = n => n / 100;
class nm extends tm {
    constructor(e) {
        super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.stop = () => {
            const {
                motionValue: a
            } = this.options;
            a && a.updatedAt !== zt.now() && this.tick(zt.now()), this.isStopped = !0, this.state !== "idle" && (this.teardown(), this.options.onStop ? .())
        }, this.options = e, this.initAnimation(), this.play(), e.autoplay === !1 && this.pause()
    }
    initAnimation() {
        const {
            options: e
        } = this;
        Q2(e);
        const {
            type: a = Qr,
            repeat: s = 0,
            repeatDelay: l = 0,
            repeatType: o,
            velocity: c = 0
        } = e;
        let {
            keyframes: h
        } = e;
        const f = a || Qr;
        f !== Qr && typeof h[0] != "number" && (this.mixKeyframes = vl(t6, F2(h[0], h[1])), h = [0, 100]);
        const m = f({ ...e,
            keyframes: h
        });
        o === "mirror" && (this.mirroredGenerator = f({ ...e,
            keyframes: [...h].reverse(),
            velocity: -c
        })), m.calculatedDuration === null && (m.calculatedDuration = Jh(m));
        const {
            calculatedDuration: p
        } = m;
        this.calculatedDuration = p, this.resolvedDuration = p + l, this.totalDuration = this.resolvedDuration * (s + 1) - l, this.generator = m
    }
    updateTime(e) {
        const a = Math.round(e - this.startTime) * this.playbackSpeed;
        this.holdTime !== null ? this.currentTime = this.holdTime : this.currentTime = a
    }
    tick(e, a = !1) {
        const {
            generator: s,
            totalDuration: l,
            mixKeyframes: o,
            mirroredGenerator: c,
            resolvedDuration: h,
            calculatedDuration: f
        } = this;
        if (this.startTime === null) return s.next(0);
        const {
            delay: m = 0,
            keyframes: p,
            repeat: v,
            repeatType: b,
            repeatDelay: y,
            type: T,
            onUpdate: S,
            finalKeyframe: M
        } = this.options;
        this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - l / this.speed, this.startTime)), a ? this.currentTime = e : this.updateTime(e);
        const _ = this.currentTime - m * (this.playbackSpeed >= 0 ? 1 : -1),
            w = this.playbackSpeed >= 0 ? _ < 0 : _ > l;
        this.currentTime = Math.max(_, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = l);
        let C = this.currentTime,
            L = s;
        if (v) {
            const D = Math.min(this.currentTime, l) / h;
            let H = Math.floor(D),
                F = D % 1;
            !F && D >= 1 && (F = 1), F === 1 && H--, H = Math.min(H, v + 1), !!(H % 2) && (b === "reverse" ? (F = 1 - F, y && (F -= y / h)) : b === "mirror" && (L = c)), C = ai(0, 1, F) * h
        }
        const O = w ? {
            done: !1,
            value: p[0]
        } : L.next(C);
        o && (O.value = o(O.value));
        let {
            done: V
        } = O;
        !w && f !== null && (V = this.playbackSpeed >= 0 ? this.currentTime >= l : this.currentTime <= 0);
        const k = this.holdTime === null && (this.state === "finished" || this.state === "running" && V);
        return k && T !== Fd && (O.value = em(p, this.options, M, this.speed)), S && S(O.value), k && this.finish(), O
    }
    then(e, a) {
        return this.finished.then(e, a)
    }
    get duration() {
        return vn(this.calculatedDuration)
    }
    get iterationDuration() {
        const {
            delay: e = 0
        } = this.options || {};
        return this.duration + vn(e)
    }
    get time() {
        return vn(this.currentTime)
    }
    set time(e) {
        e = jn(e), this.currentTime = e, this.startTime === null || this.holdTime !== null || this.playbackSpeed === 0 ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed), this.driver ? .start(!1)
    }
    get speed() {
        return this.playbackSpeed
    }
    set speed(e) {
        this.updateTime(zt.now());
        const a = this.playbackSpeed !== e;
        this.playbackSpeed = e, a && (this.time = vn(this.currentTime))
    }
    play() {
        if (this.isStopped) return;
        const {
            driver: e = B3,
            startTime: a
        } = this.options;
        this.driver || (this.driver = e(l => this.tick(l))), this.options.onPlay ? .();
        const s = this.driver.now();
        this.state === "finished" ? (this.updateFinished(), this.startTime = s) : this.holdTime !== null ? this.startTime = s - this.holdTime : this.startTime || (this.startTime = a ? ? s), this.state === "finished" && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start()
    }
    pause() {
        this.state = "paused", this.updateTime(zt.now()), this.holdTime = this.currentTime
    }
    complete() {
        this.state !== "running" && this.play(), this.state = "finished", this.holdTime = null
    }
    finish() {
        this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete ? .()
    }
    cancel() {
        this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel ? .()
    }
    teardown() {
        this.state = "idle", this.stopDriver(), this.startTime = this.holdTime = null
    }
    stopDriver() {
        this.driver && (this.driver.stop(), this.driver = void 0)
    }
    sample(e) {
        return this.startTime = 0, this.tick(e, !0)
    }
    attachTimeline(e) {
        return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver ? .stop(), e.observe(this)
    }
}

function n6(n) {
    for (let e = 1; e < n.length; e++) n[e] ? ? (n[e] = n[e - 1])
}
const ga = n => n * 180 / Math.PI,
    Kd = n => {
        const e = ga(Math.atan2(n[1], n[0]));
        return Zd(e)
    },
    i6 = {
        x: 4,
        y: 5,
        translateX: 4,
        translateY: 5,
        scaleX: 0,
        scaleY: 3,
        scale: n => (Math.abs(n[0]) + Math.abs(n[3])) / 2,
        rotate: Kd,
        rotateZ: Kd,
        skewX: n => ga(Math.atan(n[1])),
        skewY: n => ga(Math.atan(n[2])),
        skew: n => (Math.abs(n[1]) + Math.abs(n[2])) / 2
    },
    Zd = n => (n = n % 360, n < 0 && (n += 360), n),
    W1 = Kd,
    J1 = n => Math.sqrt(n[0] * n[0] + n[1] * n[1]),
    ev = n => Math.sqrt(n[4] * n[4] + n[5] * n[5]),
    a6 = {
        x: 12,
        y: 13,
        z: 14,
        translateX: 12,
        translateY: 13,
        translateZ: 14,
        scaleX: J1,
        scaleY: ev,
        scale: n => (J1(n) + ev(n)) / 2,
        rotateX: n => Zd(ga(Math.atan2(n[6], n[5]))),
        rotateY: n => Zd(ga(Math.atan2(-n[2], n[0]))),
        rotateZ: W1,
        rotate: W1,
        skewX: n => ga(Math.atan(n[4])),
        skewY: n => ga(Math.atan(n[1])),
        skew: n => (Math.abs(n[1]) + Math.abs(n[4])) / 2
    };

function Qd(n) {
    return n.includes("scale") ? 1 : 0
}

function Id(n, e) {
    if (!n || n === "none") return Qd(e);
    const a = n.match(/^matrix3d\(([-\d.e\s,]+)\)$/u);
    let s, l;
    if (a) s = a6, l = a;
    else {
        const h = n.match(/^matrix\(([-\d.e\s,]+)\)$/u);
        s = i6, l = h
    }
    if (!l) return Qd(e);
    const o = s[e],
        c = l[1].split(",").map(r6);
    return typeof o == "function" ? o(c) : c[o]
}
const s6 = (n, e) => {
    const {
        transform: a = "none"
    } = getComputedStyle(n);
    return Id(a, e)
};

function r6(n) {
    return parseFloat(n.trim())
}
const Vs = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    ks = new Set(Vs),
    tv = n => n === Ns || n === de,
    l6 = new Set(["x", "y", "z"]),
    o6 = Vs.filter(n => !l6.has(n));

function u6(n) {
    const e = [];
    return o6.forEach(a => {
        const s = n.getValue(a);
        s !== void 0 && (e.push([a, s.get()]), s.set(a.startsWith("scale") ? 1 : 0))
    }), e
}
const Sa = {
    width: ({
        x: n
    }, {
        paddingLeft: e = "0",
        paddingRight: a = "0"
    }) => n.max - n.min - parseFloat(e) - parseFloat(a),
    height: ({
        y: n
    }, {
        paddingTop: e = "0",
        paddingBottom: a = "0"
    }) => n.max - n.min - parseFloat(e) - parseFloat(a),
    top: (n, {
        top: e
    }) => parseFloat(e),
    left: (n, {
        left: e
    }) => parseFloat(e),
    bottom: ({
        y: n
    }, {
        top: e
    }) => parseFloat(e) + (n.max - n.min),
    right: ({
        x: n
    }, {
        left: e
    }) => parseFloat(e) + (n.max - n.min),
    x: (n, {
        transform: e
    }) => Id(e, "x"),
    y: (n, {
        transform: e
    }) => Id(e, "y")
};
Sa.translateX = Sa.x;
Sa.translateY = Sa.y;
const Ta = new Set;
let $d = !1,
    Wd = !1,
    Jd = !1;

function I2() {
    if (Wd) {
        const n = Array.from(Ta).filter(s => s.needsMeasurement),
            e = new Set(n.map(s => s.element)),
            a = new Map;
        e.forEach(s => {
            const l = u6(s);
            l.length && (a.set(s, l), s.render())
        }), n.forEach(s => s.measureInitialState()), e.forEach(s => {
            s.render();
            const l = a.get(s);
            l && l.forEach(([o, c]) => {
                s.getValue(o) ? .set(c)
            })
        }), n.forEach(s => s.measureEndState()), n.forEach(s => {
            s.suspendedScrollY !== void 0 && window.scrollTo(0, s.suspendedScrollY)
        })
    }
    Wd = !1, $d = !1, Ta.forEach(n => n.complete(Jd)), Ta.clear()
}

function $2() {
    Ta.forEach(n => {
        n.readKeyframes(), n.needsMeasurement && (Wd = !0)
    })
}

function c6() {
    Jd = !0, $2(), I2(), Jd = !1
}
class im {
    constructor(e, a, s, l, o, c = !1) {
        this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...e], this.onComplete = a, this.name = s, this.motionValue = l, this.element = o, this.isAsync = c
    }
    scheduleResolve() {
        this.state = "scheduled", this.isAsync ? (Ta.add(this), $d || ($d = !0, Be.read($2), Be.resolveKeyframes(I2))) : (this.readKeyframes(), this.complete())
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: e,
            name: a,
            element: s,
            motionValue: l
        } = this;
        if (e[0] === null) {
            const o = l ? .get(),
                c = e[e.length - 1];
            if (o !== void 0) e[0] = o;
            else if (s && a) {
                const h = s.readValue(a, c);
                h != null && (e[0] = h)
            }
            e[0] === void 0 && (e[0] = c), l && o === void 0 && l.set(e[0])
        }
        n6(e)
    }
    setFinalKeyframe() {}
    measureInitialState() {}
    renderEndStyles() {}
    measureEndState() {}
    complete(e = !1) {
        this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e), Ta.delete(this)
    }
    cancel() {
        this.state === "scheduled" && (Ta.delete(this), this.state = "pending")
    }
    resume() {
        this.state === "pending" && this.scheduleResolve()
    }
}
const f6 = n => n.startsWith("--");

function d6(n, e, a) {
    f6(e) ? n.style.setProperty(e, a) : n.style[e] = a
}
const h6 = Yh(() => window.ScrollTimeline !== void 0),
    m6 = {};

function p6(n, e) {
    const a = Yh(n);
    return () => m6[e] ? ? a()
}
const W2 = p6(() => {
        try {
            document.createElement("div").animate({
                opacity: 0
            }, {
                easing: "linear(0, 1)"
            })
        } catch {
            return !1
        }
        return !0
    }, "linearEasing"),
    Yr = ([n, e, a, s]) => `cubic-bezier(${n}, ${e}, ${a}, ${s})`,
    nv = {
        linear: "linear",
        ease: "ease",
        easeIn: "ease-in",
        easeOut: "ease-out",
        easeInOut: "ease-in-out",
        circIn: Yr([0, .65, .55, 1]),
        circOut: Yr([.55, 0, 1, .45]),
        backIn: Yr([.31, .01, .66, -.59]),
        backOut: Yr([.33, 1.53, .69, .99])
    };

function J2(n, e) {
    if (n) return typeof n == "function" ? W2() ? K2(n, e) : "ease-out" : k2(n) ? Yr(n) : Array.isArray(n) ? n.map(a => J2(a, e) || nv.easeOut) : nv[n]
}

function g6(n, e, a, {
    delay: s = 0,
    duration: l = 300,
    repeat: o = 0,
    repeatType: c = "loop",
    ease: h = "easeOut",
    times: f
} = {}, m = void 0) {
    const p = {
        [e]: a
    };
    f && (p.offset = f);
    const v = J2(h, l);
    Array.isArray(v) && (p.easing = v);
    const b = {
        delay: s,
        duration: l,
        easing: Array.isArray(v) ? "linear" : v,
        fill: "both",
        iterations: o + 1,
        direction: c === "reverse" ? "alternate" : "normal"
    };
    return m && (b.pseudoElement = m), n.animate(p, b)
}

function eb(n) {
    return typeof n == "function" && "applyToOptions" in n
}

function v6({
    type: n,
    ...e
}) {
    return eb(n) && W2() ? n.applyToOptions(e) : (e.duration ? ? (e.duration = 300), e.ease ? ? (e.ease = "easeOut"), e)
}
class y6 extends tm {
    constructor(e) {
        if (super(), this.finishedTime = null, this.isStopped = !1, !e) return;
        const {
            element: a,
            name: s,
            keyframes: l,
            pseudoElement: o,
            allowFlatten: c = !1,
            finalKeyframe: h,
            onComplete: f
        } = e;
        this.isPseudoElement = !!o, this.allowFlatten = c, this.options = e, qh(typeof e.type != "string");
        const m = v6(e);
        this.animation = g6(a, s, l, m, o), m.autoplay === !1 && this.animation.pause(), this.animation.onfinish = () => {
            if (this.finishedTime = this.time, !o) {
                const p = em(l, this.options, h, this.speed);
                this.updateMotionValue ? this.updateMotionValue(p) : d6(a, s, p), this.animation.cancel()
            }
            f ? .(), this.notifyFinished()
        }
    }
    play() {
        this.isStopped || (this.animation.play(), this.state === "finished" && this.updateFinished())
    }
    pause() {
        this.animation.pause()
    }
    complete() {
        this.animation.finish ? .()
    }
    cancel() {
        try {
            this.animation.cancel()
        } catch {}
    }
    stop() {
        if (this.isStopped) return;
        this.isStopped = !0;
        const {
            state: e
        } = this;
        e === "idle" || e === "finished" || (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel())
    }
    commitStyles() {
        this.isPseudoElement || this.animation.commitStyles ? .()
    }
    get duration() {
        const e = this.animation.effect ? .getComputedTiming ? .().duration || 0;
        return vn(Number(e))
    }
    get iterationDuration() {
        const {
            delay: e = 0
        } = this.options || {};
        return this.duration + vn(e)
    }
    get time() {
        return vn(Number(this.animation.currentTime) || 0)
    }
    set time(e) {
        this.finishedTime = null, this.animation.currentTime = jn(e)
    }
    get speed() {
        return this.animation.playbackRate
    }
    set speed(e) {
        e < 0 && (this.finishedTime = null), this.animation.playbackRate = e
    }
    get state() {
        return this.finishedTime !== null ? "finished" : this.animation.playState
    }
    get startTime() {
        return Number(this.animation.startTime)
    }
    set startTime(e) {
        this.animation.startTime = e
    }
    attachTimeline({
        timeline: e,
        observe: a
    }) {
        return this.allowFlatten && this.animation.effect ? .updateTiming({
            easing: "linear"
        }), this.animation.onfinish = null, e && h6() ? (this.animation.timeline = e, yn) : a(this)
    }
}
const tb = {
    anticipate: L2,
    backInOut: R2,
    circInOut: N2
};

function b6(n) {
    return n in tb
}

function x6(n) {
    typeof n.ease == "string" && b6(n.ease) && (n.ease = tb[n.ease])
}
const iv = 10;
class S6 extends y6 {
    constructor(e) {
        x6(e), Q2(e), super(e), e.startTime && (this.startTime = e.startTime), this.options = e
    }
    updateMotionValue(e) {
        const {
            motionValue: a,
            onUpdate: s,
            onComplete: l,
            element: o,
            ...c
        } = this.options;
        if (!a) return;
        if (e !== void 0) {
            a.set(e);
            return
        }
        const h = new nm({ ...c,
                autoplay: !1
            }),
            f = jn(this.finishedTime ? ? this.time);
        a.setWithVelocity(h.sample(f - iv).value, h.sample(f).value, iv), h.stop()
    }
}
const av = (n, e) => e === "zIndex" ? !1 : !!(typeof n == "number" || Array.isArray(n) || typeof n == "string" && (Gi.test(n) || n === "0") && !n.startsWith("url("));

function T6(n) {
    const e = n[0];
    if (n.length === 1) return !0;
    for (let a = 0; a < n.length; a++)
        if (n[a] !== e) return !0
}

function _6(n, e, a, s) {
    const l = n[0];
    if (l === null) return !1;
    if (e === "display" || e === "visibility") return !0;
    const o = n[n.length - 1],
        c = av(l, e),
        h = av(o, e);
    return !c || !h ? !1 : T6(n) || (a === "spring" || eb(a)) && s
}

function eh(n) {
    n.duration = 0, n.type = "keyframes"
}
const E6 = new Set(["opacity", "clipPath", "filter", "transform"]),
    w6 = Yh(() => Object.hasOwnProperty.call(Element.prototype, "animate"));

function M6(n) {
    const {
        motionValue: e,
        name: a,
        repeatDelay: s,
        repeatType: l,
        damping: o,
        type: c
    } = n;
    if (!(e ? .owner ? .current instanceof HTMLElement)) return !1;
    const {
        onUpdate: f,
        transformTemplate: m
    } = e.owner.getProps();
    return w6() && a && E6.has(a) && (a !== "transform" || !m) && !f && !s && l !== "mirror" && o !== 0 && c !== "inertia"
}
const A6 = 40;
class C6 extends tm {
    constructor({
        autoplay: e = !0,
        delay: a = 0,
        type: s = "keyframes",
        repeat: l = 0,
        repeatDelay: o = 0,
        repeatType: c = "loop",
        keyframes: h,
        name: f,
        motionValue: m,
        element: p,
        ...v
    }) {
        super(), this.stop = () => {
            this._animation && (this._animation.stop(), this.stopTimeline ? .()), this.keyframeResolver ? .cancel()
        }, this.createdAt = zt.now();
        const b = {
                autoplay: e,
                delay: a,
                type: s,
                repeat: l,
                repeatDelay: o,
                repeatType: c,
                name: f,
                motionValue: m,
                element: p,
                ...v
            },
            y = p ? .KeyframeResolver || im;
        this.keyframeResolver = new y(h, (T, S, M) => this.onKeyframesResolved(T, S, b, !M), f, m, p), this.keyframeResolver ? .scheduleResolve()
    }
    onKeyframesResolved(e, a, s, l) {
        this.keyframeResolver = void 0;
        const {
            name: o,
            type: c,
            velocity: h,
            delay: f,
            isHandoff: m,
            onUpdate: p
        } = s;
        this.resolvedAt = zt.now(), _6(e, o, c, h) || ((si.instantAnimations || !f) && p ? .(em(e, s, a)), e[0] = e[e.length - 1], eh(s), s.repeat = 0);
        const b = {
                startTime: l ? this.resolvedAt ? this.resolvedAt - this.createdAt > A6 ? this.resolvedAt : this.createdAt : this.createdAt : void 0,
                finalKeyframe: a,
                ...s,
                keyframes: e
            },
            y = !m && M6(b) ? new S6({ ...b,
                element: b.motionValue.owner.current
            }) : new nm(b);
        y.finished.then(() => this.notifyFinished()).catch(yn), this.pendingTimeline && (this.stopTimeline = y.attachTimeline(this.pendingTimeline), this.pendingTimeline = void 0), this._animation = y
    }
    get finished() {
        return this._animation ? this.animation.finished : this._finished
    }
    then(e, a) {
        return this.finished.finally(e).then(() => {})
    }
    get animation() {
        return this._animation || (this.keyframeResolver ? .resume(), c6()), this._animation
    }
    get duration() {
        return this.animation.duration
    }
    get iterationDuration() {
        return this.animation.iterationDuration
    }
    get time() {
        return this.animation.time
    }
    set time(e) {
        this.animation.time = e
    }
    get speed() {
        return this.animation.speed
    }
    get state() {
        return this.animation.state
    }
    set speed(e) {
        this.animation.speed = e
    }
    get startTime() {
        return this.animation.startTime
    }
    attachTimeline(e) {
        return this._animation ? this.stopTimeline = this.animation.attachTimeline(e) : this.pendingTimeline = e, () => this.stop()
    }
    play() {
        this.animation.play()
    }
    pause() {
        this.animation.pause()
    }
    complete() {
        this.animation.complete()
    }
    cancel() {
        this._animation && this.animation.cancel(), this.keyframeResolver ? .cancel()
    }
}
const O6 = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

function D6(n) {
    const e = O6.exec(n);
    if (!e) return [, ];
    const [, a, s, l] = e;
    return [`--${a??s}`, l]
}

function nb(n, e, a = 1) {
    const [s, l] = D6(n);
    if (!s) return;
    const o = window.getComputedStyle(e).getPropertyValue(s);
    if (o) {
        const c = o.trim();
        return E2(c) ? parseFloat(c) : c
    }
    return Qh(l) ? nb(l, e, a + 1) : l
}

function am(n, e) {
    return n ? .[e] ? ? n ? .default ? ? n
}
const ib = new Set(["width", "height", "top", "left", "right", "bottom", ...Vs]),
    z6 = {
        test: n => n === "auto",
        parse: n => n
    },
    ab = n => e => e.test(n),
    sb = [Ns, de, Nn, zi, T3, S3, z6],
    sv = n => sb.find(ab(n));

function R6(n) {
    return typeof n == "number" ? n === 0 : n !== null ? n === "none" || n === "0" || M2(n) : !0
}
const L6 = new Set(["brightness", "contrast", "saturate", "opacity"]);

function j6(n) {
    const [e, a] = n.slice(0, -1).split("(");
    if (e === "drop-shadow") return n;
    const [s] = a.match(Ih) || [];
    if (!s) return n;
    const l = a.replace(s, "");
    let o = L6.has(e) ? 1 : 0;
    return s !== a && (o *= 100), e + "(" + o + l + ")"
}
const N6 = /\b([a-z-]*)\(.*?\)/gu,
    th = { ...Gi,
        getAnimatableNone: n => {
            const e = n.match(N6);
            return e ? e.map(j6).join(" ") : n
        }
    },
    rv = { ...Ns,
        transform: Math.round
    },
    V6 = {
        rotate: zi,
        rotateX: zi,
        rotateY: zi,
        rotateZ: zi,
        scale: Po,
        scaleX: Po,
        scaleY: Po,
        scaleZ: Po,
        skew: zi,
        skewX: zi,
        skewY: zi,
        distance: de,
        translateX: de,
        translateY: de,
        translateZ: de,
        x: de,
        y: de,
        z: de,
        perspective: de,
        transformPerspective: de,
        opacity: ol,
        originX: K1,
        originY: K1,
        originZ: de
    },
    sm = {
        borderWidth: de,
        borderTopWidth: de,
        borderRightWidth: de,
        borderBottomWidth: de,
        borderLeftWidth: de,
        borderRadius: de,
        radius: de,
        borderTopLeftRadius: de,
        borderTopRightRadius: de,
        borderBottomRightRadius: de,
        borderBottomLeftRadius: de,
        width: de,
        maxWidth: de,
        height: de,
        maxHeight: de,
        top: de,
        right: de,
        bottom: de,
        left: de,
        padding: de,
        paddingTop: de,
        paddingRight: de,
        paddingBottom: de,
        paddingLeft: de,
        margin: de,
        marginTop: de,
        marginRight: de,
        marginBottom: de,
        marginLeft: de,
        backgroundPositionX: de,
        backgroundPositionY: de,
        ...V6,
        zIndex: rv,
        fillOpacity: ol,
        strokeOpacity: ol,
        numOctaves: rv
    },
    k6 = { ...sm,
        color: tt,
        backgroundColor: tt,
        outlineColor: tt,
        fill: tt,
        stroke: tt,
        borderColor: tt,
        borderTopColor: tt,
        borderRightColor: tt,
        borderBottomColor: tt,
        borderLeftColor: tt,
        filter: th,
        WebkitFilter: th
    },
    rb = n => k6[n];

function lb(n, e) {
    let a = rb(n);
    return a !== th && (a = Gi), a.getAnimatableNone ? a.getAnimatableNone(e) : void 0
}
const B6 = new Set(["auto", "none", "0"]);

function P6(n, e, a) {
    let s = 0,
        l;
    for (; s < n.length && !l;) {
        const o = n[s];
        typeof o == "string" && !B6.has(o) && ul(o).values.length && (l = n[s]), s++
    }
    if (l && a)
        for (const o of e) n[o] = lb(a, l)
}
class U6 extends im {
    constructor(e, a, s, l, o) {
        super(e, a, s, l, o, !0)
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: e,
            element: a,
            name: s
        } = this;
        if (!a || !a.current) return;
        super.readKeyframes();
        for (let f = 0; f < e.length; f++) {
            let m = e[f];
            if (typeof m == "string" && (m = m.trim(), Qh(m))) {
                const p = nb(m, a.current);
                p !== void 0 && (e[f] = p), f === e.length - 1 && (this.finalKeyframe = m)
            }
        }
        if (this.resolveNoneKeyframes(), !ib.has(s) || e.length !== 2) return;
        const [l, o] = e, c = sv(l), h = sv(o);
        if (c !== h)
            if (tv(c) && tv(h))
                for (let f = 0; f < e.length; f++) {
                    const m = e[f];
                    typeof m == "string" && (e[f] = parseFloat(m))
                } else Sa[s] && (this.needsMeasurement = !0)
    }
    resolveNoneKeyframes() {
        const {
            unresolvedKeyframes: e,
            name: a
        } = this, s = [];
        for (let l = 0; l < e.length; l++)(e[l] === null || R6(e[l])) && s.push(l);
        s.length && P6(e, s, a)
    }
    measureInitialState() {
        const {
            element: e,
            unresolvedKeyframes: a,
            name: s
        } = this;
        if (!e || !e.current) return;
        s === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = Sa[s](e.measureViewportBox(), window.getComputedStyle(e.current)), a[0] = this.measuredOrigin;
        const l = a[a.length - 1];
        l !== void 0 && e.getValue(s, l).jump(l, !1)
    }
    measureEndState() {
        const {
            element: e,
            name: a,
            unresolvedKeyframes: s
        } = this;
        if (!e || !e.current) return;
        const l = e.getValue(a);
        l && l.jump(this.measuredOrigin, !1);
        const o = s.length - 1,
            c = s[o];
        s[o] = Sa[a](e.measureViewportBox(), window.getComputedStyle(e.current)), c !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = c), this.removedTransforms ? .length && this.removedTransforms.forEach(([h, f]) => {
            e.getValue(h).set(f)
        }), this.resolveNoneKeyframes()
    }
}

function ob(n, e, a) {
    if (n instanceof EventTarget) return [n];
    if (typeof n == "string") {
        const l = document.querySelectorAll(n);
        return l ? Array.from(l) : []
    }
    return Array.from(n)
}
const ub = (n, e) => e && typeof n == "number" ? e.transform(n) : n;

function H6(n) {
    return w2(n) && "offsetHeight" in n
}
const lv = 30,
    G6 = n => !isNaN(parseFloat(n));
class q6 {
    constructor(e, a = {}) {
        this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = s => {
            const l = zt.now();
            if (this.updatedAt !== l && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(s), this.current !== this.prev && (this.events.change ? .notify(this.current), this.dependents))
                for (const o of this.dependents) o.dirty()
        }, this.hasAnimated = !1, this.setCurrent(e), this.owner = a.owner
    }
    setCurrent(e) {
        this.current = e, this.updatedAt = zt.now(), this.canTrackVelocity === null && e !== void 0 && (this.canTrackVelocity = G6(this.current))
    }
    setPrevFrameValue(e = this.current) {
        this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt
    }
    onChange(e) {
        return this.on("change", e)
    }
    on(e, a) {
        this.events[e] || (this.events[e] = new Xh);
        const s = this.events[e].add(a);
        return e === "change" ? () => {
            s(), Be.read(() => {
                this.events.change.getSize() || this.stop()
            })
        } : s
    }
    clearListeners() {
        for (const e in this.events) this.events[e].clear()
    }
    attach(e, a) {
        this.passiveEffect = e, this.stopPassiveEffect = a
    }
    set(e) {
        this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e)
    }
    setWithVelocity(e, a, s) {
        this.set(a), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - s
    }
    jump(e, a = !0) {
        this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, a && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
    dirty() {
        this.events.change ? .notify(this.current)
    }
    addDependent(e) {
        this.dependents || (this.dependents = new Set), this.dependents.add(e)
    }
    removeDependent(e) {
        this.dependents && this.dependents.delete(e)
    }
    get() {
        return this.current
    }
    getPrevious() {
        return this.prev
    }
    getVelocity() {
        const e = zt.now();
        if (!this.canTrackVelocity || this.prevFrameValue === void 0 || e - this.updatedAt > lv) return 0;
        const a = Math.min(this.updatedAt - this.prevUpdatedAt, lv);
        return A2(parseFloat(this.current) - parseFloat(this.prevFrameValue), a)
    }
    start(e) {
        return this.stop(), new Promise(a => {
            this.hasAnimated = !0, this.animation = e(a), this.events.animationStart && this.events.animationStart.notify()
        }).then(() => {
            this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
        })
    }
    stop() {
        this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
    }
    isAnimating() {
        return !!this.animation
    }
    clearAnimation() {
        delete this.animation
    }
    destroy() {
        this.dependents ? .clear(), this.events.destroy ? .notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
}

function Ls(n, e) {
    return new q6(n, e)
}
const {
    schedule: rm
} = B2(queueMicrotask, !1), Tn = {
    x: !1,
    y: !1
};

function cb() {
    return Tn.x || Tn.y
}

function Y6(n) {
    return n === "x" || n === "y" ? Tn[n] ? null : (Tn[n] = !0, () => {
        Tn[n] = !1
    }) : Tn.x || Tn.y ? null : (Tn.x = Tn.y = !0, () => {
        Tn.x = Tn.y = !1
    })
}

function fb(n, e) {
    const a = ob(n),
        s = new AbortController,
        l = {
            passive: !0,
            ...e,
            signal: s.signal
        };
    return [a, l, () => s.abort()]
}

function ov(n) {
    return !(n.pointerType === "touch" || cb())
}

function X6(n, e, a = {}) {
    const [s, l, o] = fb(n, a), c = h => {
        if (!ov(h)) return;
        const {
            target: f
        } = h, m = e(f, h);
        if (typeof m != "function" || !f) return;
        const p = v => {
            ov(v) && (m(v), f.removeEventListener("pointerleave", p))
        };
        f.addEventListener("pointerleave", p, l)
    };
    return s.forEach(h => {
        h.addEventListener("pointerenter", c, l)
    }), o
}
const db = (n, e) => e ? n === e ? !0 : db(n, e.parentElement) : !1,
    lm = n => n.pointerType === "mouse" ? typeof n.button != "number" || n.button <= 0 : n.isPrimary !== !1,
    F6 = new Set(["BUTTON", "INPUT", "SELECT", "TEXTAREA", "A"]);

function K6(n) {
    return F6.has(n.tagName) || n.tabIndex !== -1
}
const Zo = new WeakSet;

function uv(n) {
    return e => {
        e.key === "Enter" && n(e)
    }
}

function rd(n, e) {
    n.dispatchEvent(new PointerEvent("pointer" + e, {
        isPrimary: !0,
        bubbles: !0
    }))
}
const Z6 = (n, e) => {
    const a = n.currentTarget;
    if (!a) return;
    const s = uv(() => {
        if (Zo.has(a)) return;
        rd(a, "down");
        const l = uv(() => {
                rd(a, "up")
            }),
            o = () => rd(a, "cancel");
        a.addEventListener("keyup", l, e), a.addEventListener("blur", o, e)
    });
    a.addEventListener("keydown", s, e), a.addEventListener("blur", () => a.removeEventListener("keydown", s), e)
};

function cv(n) {
    return lm(n) && !cb()
}

function Q6(n, e, a = {}) {
    const [s, l, o] = fb(n, a), c = h => {
        const f = h.currentTarget;
        if (!cv(h)) return;
        Zo.add(f);
        const m = e(f, h),
            p = (y, T) => {
                window.removeEventListener("pointerup", v), window.removeEventListener("pointercancel", b), Zo.has(f) && Zo.delete(f), cv(y) && typeof m == "function" && m(y, {
                    success: T
                })
            },
            v = y => {
                p(y, f === window || f === document || a.useGlobalTarget || db(f, y.target))
            },
            b = y => {
                p(y, !1)
            };
        window.addEventListener("pointerup", v, l), window.addEventListener("pointercancel", b, l)
    };
    return s.forEach(h => {
        (a.useGlobalTarget ? window : h).addEventListener("pointerdown", c, l), H6(h) && (h.addEventListener("focus", m => Z6(m, l)), !K6(h) && !h.hasAttribute("tabindex") && (h.tabIndex = 0))
    }), o
}

function hb(n) {
    return w2(n) && "ownerSVGElement" in n
}

function I6(n) {
    return hb(n) && n.tagName === "svg"
}
const xt = n => !!(n && n.getVelocity),
    $6 = [...sb, tt, Gi],
    W6 = n => $6.find(ab(n)),
    mb = J.createContext({
        transformPagePoint: n => n,
        isStatic: !1,
        reducedMotion: "never"
    });

function J6(n = !0) {
    const e = J.useContext(Uh);
    if (e === null) return [!0, null];
    const {
        isPresent: a,
        onExitComplete: s,
        register: l
    } = e, o = J.useId();
    J.useEffect(() => {
        if (n) return l(o)
    }, [n]);
    const c = J.useCallback(() => n && s && s(o), [o, s, n]);
    return !a && s ? [!1, c] : [!0]
}
const pb = J.createContext({
        strict: !1
    }),
    fv = {
        animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
        exit: ["exit"],
        drag: ["drag", "dragControls"],
        focus: ["whileFocus"],
        hover: ["whileHover", "onHoverStart", "onHoverEnd"],
        tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
        pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
        inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
        layout: ["layout", "layoutId"]
    },
    js = {};
for (const n in fv) js[n] = {
    isEnabled: e => fv[n].some(a => !!e[a])
};

function e5(n) {
    for (const e in n) js[e] = { ...js[e],
        ...n[e]
    }
}
const t5 = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

function fu(n) {
    return n.startsWith("while") || n.startsWith("drag") && n !== "draggable" || n.startsWith("layout") || n.startsWith("onTap") || n.startsWith("onPan") || n.startsWith("onLayout") || t5.has(n)
}
let gb = n => !fu(n);

function n5(n) {
    typeof n == "function" && (gb = e => e.startsWith("on") ? !fu(e) : n(e))
}
try {
    n5(require("@emotion/is-prop-valid").default)
} catch {}

function i5(n, e, a) {
    const s = {};
    for (const l in n) l === "values" && typeof n.values == "object" || (gb(l) || a === !0 && fu(l) || !e && !fu(l) || n.draggable && l.startsWith("onDrag")) && (s[l] = n[l]);
    return s
}
const Tu = J.createContext({});

function _u(n) {
    return n !== null && typeof n == "object" && typeof n.start == "function"
}

function cl(n) {
    return typeof n == "string" || Array.isArray(n)
}
const om = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
    um = ["initial", ...om];

function Eu(n) {
    return _u(n.animate) || um.some(e => cl(n[e]))
}

function vb(n) {
    return !!(Eu(n) || n.variants)
}

function a5(n, e) {
    if (Eu(n)) {
        const {
            initial: a,
            animate: s
        } = n;
        return {
            initial: a === !1 || cl(a) ? a : void 0,
            animate: cl(s) ? s : void 0
        }
    }
    return n.inherit !== !1 ? e : {}
}

function s5(n) {
    const {
        initial: e,
        animate: a
    } = a5(n, J.useContext(Tu));
    return J.useMemo(() => ({
        initial: e,
        animate: a
    }), [dv(e), dv(a)])
}

function dv(n) {
    return Array.isArray(n) ? n.join(" ") : n
}
const fl = {};

function r5(n) {
    for (const e in n) fl[e] = n[e], Zh(e) && (fl[e].isCSSVariable = !0)
}

function yb(n, {
    layout: e,
    layoutId: a
}) {
    return ks.has(n) || n.startsWith("origin") || (e || a !== void 0) && (!!fl[n] || n === "opacity")
}
const l5 = {
        x: "translateX",
        y: "translateY",
        z: "translateZ",
        transformPerspective: "perspective"
    },
    o5 = Vs.length;

function u5(n, e, a) {
    let s = "",
        l = !0;
    for (let o = 0; o < o5; o++) {
        const c = Vs[o],
            h = n[c];
        if (h === void 0) continue;
        let f = !0;
        if (typeof h == "number" ? f = h === (c.startsWith("scale") ? 1 : 0) : f = parseFloat(h) === 0, !f || a) {
            const m = ub(h, sm[c]);
            if (!f) {
                l = !1;
                const p = l5[c] || c;
                s += `${p}(${m}) `
            }
            a && (e[c] = m)
        }
    }
    return s = s.trim(), a ? s = a(e, l ? "" : s) : l && (s = "none"), s
}

function cm(n, e, a) {
    const {
        style: s,
        vars: l,
        transformOrigin: o
    } = n;
    let c = !1,
        h = !1;
    for (const f in e) {
        const m = e[f];
        if (ks.has(f)) {
            c = !0;
            continue
        } else if (Zh(f)) {
            l[f] = m;
            continue
        } else {
            const p = ub(m, sm[f]);
            f.startsWith("origin") ? (h = !0, o[f] = p) : s[f] = p
        }
    }
    if (e.transform || (c || a ? s.transform = u5(e, n.transform, a) : s.transform && (s.transform = "none")), h) {
        const {
            originX: f = "50%",
            originY: m = "50%",
            originZ: p = 0
        } = o;
        s.transformOrigin = `${f} ${m} ${p}`
    }
}
const fm = () => ({
    style: {},
    transform: {},
    transformOrigin: {},
    vars: {}
});

function bb(n, e, a) {
    for (const s in e) !xt(e[s]) && !yb(s, a) && (n[s] = e[s])
}

function c5({
    transformTemplate: n
}, e) {
    return J.useMemo(() => {
        const a = fm();
        return cm(a, e, n), Object.assign({}, a.vars, a.style)
    }, [e])
}

function f5(n, e) {
    const a = n.style || {},
        s = {};
    return bb(s, a, n), Object.assign(s, c5(n, e)), s
}

function d5(n, e) {
    const a = {},
        s = f5(n, e);
    return n.drag && n.dragListener !== !1 && (a.draggable = !1, s.userSelect = s.WebkitUserSelect = s.WebkitTouchCallout = "none", s.touchAction = n.drag === !0 ? "none" : `pan-${n.drag==="x"?"y":"x"}`), n.tabIndex === void 0 && (n.onTap || n.onTapStart || n.whileTap) && (a.tabIndex = 0), a.style = s, a
}
const h5 = {
        offset: "stroke-dashoffset",
        array: "stroke-dasharray"
    },
    m5 = {
        offset: "strokeDashoffset",
        array: "strokeDasharray"
    };

function p5(n, e, a = 1, s = 0, l = !0) {
    n.pathLength = 1;
    const o = l ? h5 : m5;
    n[o.offset] = de.transform(-s);
    const c = de.transform(e),
        h = de.transform(a);
    n[o.array] = `${c} ${h}`
}

function xb(n, {
    attrX: e,
    attrY: a,
    attrScale: s,
    pathLength: l,
    pathSpacing: o = 1,
    pathOffset: c = 0,
    ...h
}, f, m, p) {
    if (cm(n, h, m), f) {
        n.style.viewBox && (n.attrs.viewBox = n.style.viewBox);
        return
    }
    n.attrs = n.style, n.style = {};
    const {
        attrs: v,
        style: b
    } = n;
    v.transform && (b.transform = v.transform, delete v.transform), (b.transform || v.transformOrigin) && (b.transformOrigin = v.transformOrigin ? ? "50% 50%", delete v.transformOrigin), b.transform && (b.transformBox = p ? .transformBox ? ? "fill-box", delete v.transformBox), e !== void 0 && (v.x = e), a !== void 0 && (v.y = a), s !== void 0 && (v.scale = s), l !== void 0 && p5(v, l, o, c, !1)
}
const Sb = () => ({ ...fm(),
        attrs: {}
    }),
    Tb = n => typeof n == "string" && n.toLowerCase() === "svg";

function g5(n, e, a, s) {
    const l = J.useMemo(() => {
        const o = Sb();
        return xb(o, e, Tb(s), n.transformTemplate, n.style), { ...o.attrs,
            style: { ...o.style
            }
        }
    }, [e]);
    if (n.style) {
        const o = {};
        bb(o, n.style, n), l.style = { ...o,
            ...l.style
        }
    }
    return l
}
const v5 = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

function dm(n) {
    return typeof n != "string" || n.includes("-") ? !1 : !!(v5.indexOf(n) > -1 || /[A-Z]/u.test(n))
}

function y5(n, e, a, {
    latestValues: s
}, l, o = !1) {
    const h = (dm(n) ? g5 : d5)(e, s, l, n),
        f = i5(e, typeof n == "string", o),
        m = n !== J.Fragment ? { ...f,
            ...h,
            ref: a
        } : {},
        {
            children: p
        } = e,
        v = J.useMemo(() => xt(p) ? p.get() : p, [p]);
    return J.createElement(n, { ...m,
        children: v
    })
}

function hv(n) {
    const e = [{}, {}];
    return n ? .values.forEach((a, s) => {
        e[0][s] = a.get(), e[1][s] = a.getVelocity()
    }), e
}

function hm(n, e, a, s) {
    if (typeof e == "function") {
        const [l, o] = hv(s);
        e = e(a !== void 0 ? a : n.custom, l, o)
    }
    if (typeof e == "string" && (e = n.variants && n.variants[e]), typeof e == "function") {
        const [l, o] = hv(s);
        e = e(a !== void 0 ? a : n.custom, l, o)
    }
    return e
}

function Qo(n) {
    return xt(n) ? n.get() : n
}

function b5({
    scrapeMotionValuesFromProps: n,
    createRenderState: e
}, a, s, l) {
    return {
        latestValues: x5(a, s, l, n),
        renderState: e()
    }
}

function x5(n, e, a, s) {
    const l = {},
        o = s(n, {});
    for (const b in o) l[b] = Qo(o[b]);
    let {
        initial: c,
        animate: h
    } = n;
    const f = Eu(n),
        m = vb(n);
    e && m && !f && n.inherit !== !1 && (c === void 0 && (c = e.initial), h === void 0 && (h = e.animate));
    let p = a ? a.initial === !1 : !1;
    p = p || c === !1;
    const v = p ? h : c;
    if (v && typeof v != "boolean" && !_u(v)) {
        const b = Array.isArray(v) ? v : [v];
        for (let y = 0; y < b.length; y++) {
            const T = hm(n, b[y]);
            if (T) {
                const {
                    transitionEnd: S,
                    transition: M,
                    ..._
                } = T;
                for (const w in _) {
                    let C = _[w];
                    if (Array.isArray(C)) {
                        const L = p ? C.length - 1 : 0;
                        C = C[L]
                    }
                    C !== null && (l[w] = C)
                }
                for (const w in S) l[w] = S[w]
            }
        }
    }
    return l
}
const _b = n => (e, a) => {
    const s = J.useContext(Tu),
        l = J.useContext(Uh),
        o = () => b5(n, e, s, l);
    return a ? o() : t3(o)
};

function mm(n, e, a) {
    const {
        style: s
    } = n, l = {};
    for (const o in s)(xt(s[o]) || e.style && xt(e.style[o]) || yb(o, n) || a ? .getValue(o) ? .liveStyle !== void 0) && (l[o] = s[o]);
    return l
}
const S5 = _b({
    scrapeMotionValuesFromProps: mm,
    createRenderState: fm
});

function Eb(n, e, a) {
    const s = mm(n, e, a);
    for (const l in n)
        if (xt(n[l]) || xt(e[l])) {
            const o = Vs.indexOf(l) !== -1 ? "attr" + l.charAt(0).toUpperCase() + l.substring(1) : l;
            s[o] = n[l]
        }
    return s
}
const T5 = _b({
        scrapeMotionValuesFromProps: Eb,
        createRenderState: Sb
    }),
    _5 = Symbol.for("motionComponentSymbol");

function gs(n) {
    return n && typeof n == "object" && Object.prototype.hasOwnProperty.call(n, "current")
}

function E5(n, e, a) {
    return J.useCallback(s => {
        s && n.onMount && n.onMount(s), e && (s ? e.mount(s) : e.unmount()), a && (typeof a == "function" ? a(s) : gs(a) && (a.current = s))
    }, [e])
}
const pm = n => n.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
    w5 = "framerAppearId",
    wb = "data-" + pm(w5),
    Mb = J.createContext({});

function M5(n, e, a, s, l) {
    const {
        visualElement: o
    } = J.useContext(Tu), c = J.useContext(pb), h = J.useContext(Uh), f = J.useContext(mb).reducedMotion, m = J.useRef(null);
    s = s || c.renderer, !m.current && s && (m.current = s(n, {
        visualState: e,
        parent: o,
        props: a,
        presenceContext: h,
        blockInitialAnimation: h ? h.initial === !1 : !1,
        reducedMotionConfig: f
    }));
    const p = m.current,
        v = J.useContext(Mb);
    p && !p.projection && l && (p.type === "html" || p.type === "svg") && A5(m.current, a, l, v);
    const b = J.useRef(!1);
    J.useInsertionEffect(() => {
        p && b.current && p.update(a, h)
    });
    const y = a[wb],
        T = J.useRef(!!y && !window.MotionHandoffIsComplete ? .(y) && window.MotionHasOptimisedAnimation ? .(y));
    return n3(() => {
        p && (b.current = !0, window.MotionIsMounted = !0, p.updateFeatures(), p.scheduleRenderMicrotask(), T.current && p.animationState && p.animationState.animateChanges())
    }), J.useEffect(() => {
        p && (!T.current && p.animationState && p.animationState.animateChanges(), T.current && (queueMicrotask(() => {
            window.MotionHandoffMarkAsComplete ? .(y)
        }), T.current = !1), p.enteringChildren = void 0)
    }), p
}

function A5(n, e, a, s) {
    const {
        layoutId: l,
        layout: o,
        drag: c,
        dragConstraints: h,
        layoutScroll: f,
        layoutRoot: m,
        layoutCrossfade: p
    } = e;
    n.projection = new a(n.latestValues, e["data-framer-portal-id"] ? void 0 : Ab(n.parent)), n.projection.setOptions({
        layoutId: l,
        layout: o,
        alwaysMeasureLayout: !!c || h && gs(h),
        visualElement: n,
        animationType: typeof o == "string" ? o : "both",
        initialPromotionConfig: s,
        crossfade: p,
        layoutScroll: f,
        layoutRoot: m
    })
}

function Ab(n) {
    if (n) return n.options.allowProjection !== !1 ? n.projection : Ab(n.parent)
}

function ld(n, {
    forwardMotionProps: e = !1
} = {}, a, s) {
    a && e5(a);
    const l = dm(n) ? T5 : S5;

    function o(h, f) {
        let m;
        const p = { ...J.useContext(mb),
                ...h,
                layoutId: C5(h)
            },
            {
                isStatic: v
            } = p,
            b = s5(h),
            y = l(h, v);
        if (!v && Ph) {
            O5();
            const T = D5(p);
            m = T.MeasureLayout, b.visualElement = M5(n, y, p, s, T.ProjectionNode)
        }
        return A.jsxs(Tu.Provider, {
            value: b,
            children: [m && b.visualElement ? A.jsx(m, {
                visualElement: b.visualElement,
                ...p
            }) : null, y5(n, h, E5(y, b.visualElement, f), y, v, e)]
        })
    }
    o.displayName = `motion.${typeof n=="string"?n:`create(${n.displayName??n.name??""})`}`;
    const c = J.forwardRef(o);
    return c[_5] = n, c
}

function C5({
    layoutId: n
}) {
    const e = J.useContext(_2).id;
    return e && n !== void 0 ? e + "-" + n : n
}

function O5(n, e) {
    J.useContext(pb).strict
}

function D5(n) {
    const {
        drag: e,
        layout: a
    } = js;
    if (!e && !a) return {};
    const s = { ...e,
        ...a
    };
    return {
        MeasureLayout: e ? .isEnabled(n) || a ? .isEnabled(n) ? s.MeasureLayout : void 0,
        ProjectionNode: s.ProjectionNode
    }
}

function z5(n, e) {
    if (typeof Proxy > "u") return ld;
    const a = new Map,
        s = (o, c) => ld(o, c, n, e),
        l = (o, c) => s(o, c);
    return new Proxy(l, {
        get: (o, c) => c === "create" ? s : (a.has(c) || a.set(c, ld(c, void 0, n, e)), a.get(c))
    })
}

function Cb({
    top: n,
    left: e,
    right: a,
    bottom: s
}) {
    return {
        x: {
            min: e,
            max: a
        },
        y: {
            min: n,
            max: s
        }
    }
}

function R5({
    x: n,
    y: e
}) {
    return {
        top: e.min,
        right: n.max,
        bottom: e.max,
        left: n.min
    }
}

function L5(n, e) {
    if (!e) return n;
    const a = e({
            x: n.left,
            y: n.top
        }),
        s = e({
            x: n.right,
            y: n.bottom
        });
    return {
        top: a.y,
        left: a.x,
        bottom: s.y,
        right: s.x
    }
}

function od(n) {
    return n === void 0 || n === 1
}

function nh({
    scale: n,
    scaleX: e,
    scaleY: a
}) {
    return !od(n) || !od(e) || !od(a)
}

function ha(n) {
    return nh(n) || Ob(n) || n.z || n.rotate || n.rotateX || n.rotateY || n.skewX || n.skewY
}

function Ob(n) {
    return mv(n.x) || mv(n.y)
}

function mv(n) {
    return n && n !== "0%"
}

function du(n, e, a) {
    const s = n - a,
        l = e * s;
    return a + l
}

function pv(n, e, a, s, l) {
    return l !== void 0 && (n = du(n, l, s)), du(n, a, s) + e
}

function ih(n, e = 0, a = 1, s, l) {
    n.min = pv(n.min, e, a, s, l), n.max = pv(n.max, e, a, s, l)
}

function Db(n, {
    x: e,
    y: a
}) {
    ih(n.x, e.translate, e.scale, e.originPoint), ih(n.y, a.translate, a.scale, a.originPoint)
}
const gv = .999999999999,
    vv = 1.0000000000001;

function j5(n, e, a, s = !1) {
    const l = a.length;
    if (!l) return;
    e.x = e.y = 1;
    let o, c;
    for (let h = 0; h < l; h++) {
        o = a[h], c = o.projectionDelta;
        const {
            visualElement: f
        } = o.options;
        f && f.props.style && f.props.style.display === "contents" || (s && o.options.layoutScroll && o.scroll && o !== o.root && ys(n, {
            x: -o.scroll.offset.x,
            y: -o.scroll.offset.y
        }), c && (e.x *= c.x.scale, e.y *= c.y.scale, Db(n, c)), s && ha(o.latestValues) && ys(n, o.latestValues))
    }
    e.x < vv && e.x > gv && (e.x = 1), e.y < vv && e.y > gv && (e.y = 1)
}

function vs(n, e) {
    n.min = n.min + e, n.max = n.max + e
}

function yv(n, e, a, s, l = .5) {
    const o = Ye(n.min, n.max, l);
    ih(n, e, a, o, s)
}

function ys(n, e) {
    yv(n.x, e.x, e.scaleX, e.scale, e.originX), yv(n.y, e.y, e.scaleY, e.scale, e.originY)
}

function zb(n, e) {
    return Cb(L5(n.getBoundingClientRect(), e))
}

function N5(n, e, a) {
    const s = zb(n, a),
        {
            scroll: l
        } = e;
    return l && (vs(s.x, l.offset.x), vs(s.y, l.offset.y)), s
}
const bv = () => ({
        translate: 0,
        scale: 1,
        origin: 0,
        originPoint: 0
    }),
    bs = () => ({
        x: bv(),
        y: bv()
    }),
    xv = () => ({
        min: 0,
        max: 0
    }),
    $e = () => ({
        x: xv(),
        y: xv()
    }),
    ah = {
        current: null
    },
    Rb = {
        current: !1
    };

function V5() {
    if (Rb.current = !0, !!Ph)
        if (window.matchMedia) {
            const n = window.matchMedia("(prefers-reduced-motion)"),
                e = () => ah.current = n.matches;
            n.addEventListener("change", e), e()
        } else ah.current = !1
}
const k5 = new WeakMap;

function B5(n, e, a) {
    for (const s in e) {
        const l = e[s],
            o = a[s];
        if (xt(l)) n.addValue(s, l);
        else if (xt(o)) n.addValue(s, Ls(l, {
            owner: n
        }));
        else if (o !== l)
            if (n.hasValue(s)) {
                const c = n.getValue(s);
                c.liveStyle === !0 ? c.jump(l) : c.hasAnimated || c.set(l)
            } else {
                const c = n.getStaticValue(s);
                n.addValue(s, Ls(c !== void 0 ? c : l, {
                    owner: n
                }))
            }
    }
    for (const s in a) e[s] === void 0 && n.removeValue(s);
    return e
}
const Sv = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
class P5 {
    scrapeMotionValuesFromProps(e, a, s) {
        return {}
    }
    constructor({
        parent: e,
        props: a,
        presenceContext: s,
        reducedMotionConfig: l,
        blockInitialAnimation: o,
        visualState: c
    }, h = {}) {
        this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = im, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
            this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
        }, this.renderScheduledAt = 0, this.scheduleRender = () => {
            const b = zt.now();
            this.renderScheduledAt < b && (this.renderScheduledAt = b, Be.render(this.render, !1, !0))
        };
        const {
            latestValues: f,
            renderState: m
        } = c;
        this.latestValues = f, this.baseTarget = { ...f
        }, this.initialValues = a.initial ? { ...f
        } : {}, this.renderState = m, this.parent = e, this.props = a, this.presenceContext = s, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = l, this.options = h, this.blockInitialAnimation = !!o, this.isControllingVariants = Eu(a), this.isVariantNode = vb(a), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(e && e.current);
        const {
            willChange: p,
            ...v
        } = this.scrapeMotionValuesFromProps(a, {}, this);
        for (const b in v) {
            const y = v[b];
            f[b] !== void 0 && xt(y) && y.set(f[b])
        }
    }
    mount(e) {
        this.current = e, k5.set(e, this), this.projection && !this.projection.instance && this.projection.mount(e), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((a, s) => this.bindToMotionValue(s, a)), Rb.current || V5(), this.shouldReduceMotion = this.reducedMotionConfig === "never" ? !1 : this.reducedMotionConfig === "always" ? !0 : ah.current, this.parent ? .addChild(this), this.update(this.props, this.presenceContext)
    }
    unmount() {
        this.projection && this.projection.unmount(), Hi(this.notifyUpdate), Hi(this.render), this.valueSubscriptions.forEach(e => e()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent ? .removeChild(this);
        for (const e in this.events) this.events[e].clear();
        for (const e in this.features) {
            const a = this.features[e];
            a && (a.unmount(), a.isMounted = !1)
        }
        this.current = null
    }
    addChild(e) {
        this.children.add(e), this.enteringChildren ? ? (this.enteringChildren = new Set), this.enteringChildren.add(e)
    }
    removeChild(e) {
        this.children.delete(e), this.enteringChildren && this.enteringChildren.delete(e)
    }
    bindToMotionValue(e, a) {
        this.valueSubscriptions.has(e) && this.valueSubscriptions.get(e)();
        const s = ks.has(e);
        s && this.onBindTransform && this.onBindTransform();
        const l = a.on("change", c => {
            this.latestValues[e] = c, this.props.onUpdate && Be.preRender(this.notifyUpdate), s && this.projection && (this.projection.isTransformDirty = !0), this.scheduleRender()
        });
        let o;
        window.MotionCheckAppearSync && (o = window.MotionCheckAppearSync(this, e, a)), this.valueSubscriptions.set(e, () => {
            l(), o && o(), a.owner && a.stop()
        })
    }
    sortNodePosition(e) {
        return !this.current || !this.sortInstanceNodePosition || this.type !== e.type ? 0 : this.sortInstanceNodePosition(this.current, e.current)
    }
    updateFeatures() {
        let e = "animation";
        for (e in js) {
            const a = js[e];
            if (!a) continue;
            const {
                isEnabled: s,
                Feature: l
            } = a;
            if (!this.features[e] && l && s(this.props) && (this.features[e] = new l(this)), this.features[e]) {
                const o = this.features[e];
                o.isMounted ? o.update() : (o.mount(), o.isMounted = !0)
            }
        }
    }
    triggerBuild() {
        this.build(this.renderState, this.latestValues, this.props)
    }
    measureViewportBox() {
        return this.current ? this.measureInstanceViewportBox(this.current, this.props) : $e()
    }
    getStaticValue(e) {
        return this.latestValues[e]
    }
    setStaticValue(e, a) {
        this.latestValues[e] = a
    }
    update(e, a) {
        (e.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = a;
        for (let s = 0; s < Sv.length; s++) {
            const l = Sv[s];
            this.propEventSubscriptions[l] && (this.propEventSubscriptions[l](), delete this.propEventSubscriptions[l]);
            const o = "on" + l,
                c = e[o];
            c && (this.propEventSubscriptions[l] = this.on(l, c))
        }
        this.prevMotionValues = B5(this, this.scrapeMotionValuesFromProps(e, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
    }
    getProps() {
        return this.props
    }
    getVariant(e) {
        return this.props.variants ? this.props.variants[e] : void 0
    }
    getDefaultTransition() {
        return this.props.transition
    }
    getTransformPagePoint() {
        return this.props.transformPagePoint
    }
    getClosestVariantNode() {
        return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
    }
    addVariantChild(e) {
        const a = this.getClosestVariantNode();
        if (a) return a.variantChildren && a.variantChildren.add(e), () => a.variantChildren.delete(e)
    }
    addValue(e, a) {
        const s = this.values.get(e);
        a !== s && (s && this.removeValue(e), this.bindToMotionValue(e, a), this.values.set(e, a), this.latestValues[e] = a.get())
    }
    removeValue(e) {
        this.values.delete(e);
        const a = this.valueSubscriptions.get(e);
        a && (a(), this.valueSubscriptions.delete(e)), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState)
    }
    hasValue(e) {
        return this.values.has(e)
    }
    getValue(e, a) {
        if (this.props.values && this.props.values[e]) return this.props.values[e];
        let s = this.values.get(e);
        return s === void 0 && a !== void 0 && (s = Ls(a === null ? void 0 : a, {
            owner: this
        }), this.addValue(e, s)), s
    }
    readValue(e, a) {
        let s = this.latestValues[e] !== void 0 || !this.current ? this.latestValues[e] : this.getBaseTargetFromProps(this.props, e) ? ? this.readValueFromInstance(this.current, e, this.options);
        return s != null && (typeof s == "string" && (E2(s) || M2(s)) ? s = parseFloat(s) : !W6(s) && Gi.test(a) && (s = lb(e, a)), this.setBaseTarget(e, xt(s) ? s.get() : s)), xt(s) ? s.get() : s
    }
    setBaseTarget(e, a) {
        this.baseTarget[e] = a
    }
    getBaseTarget(e) {
        const {
            initial: a
        } = this.props;
        let s;
        if (typeof a == "string" || typeof a == "object") {
            const o = hm(this.props, a, this.presenceContext ? .custom);
            o && (s = o[e])
        }
        if (a && s !== void 0) return s;
        const l = this.getBaseTargetFromProps(this.props, e);
        return l !== void 0 && !xt(l) ? l : this.initialValues[e] !== void 0 && s === void 0 ? void 0 : this.baseTarget[e]
    }
    on(e, a) {
        return this.events[e] || (this.events[e] = new Xh), this.events[e].add(a)
    }
    notify(e, ...a) {
        this.events[e] && this.events[e].notify(...a)
    }
    scheduleRenderMicrotask() {
        rm.render(this.render)
    }
}
class Lb extends P5 {
    constructor() {
        super(...arguments), this.KeyframeResolver = U6
    }
    sortInstanceNodePosition(e, a) {
        return e.compareDocumentPosition(a) & 2 ? 1 : -1
    }
    getBaseTargetFromProps(e, a) {
        return e.style ? e.style[a] : void 0
    }
    removeValueFromRenderState(e, {
        vars: a,
        style: s
    }) {
        delete a[e], delete s[e]
    }
    handleChildMotionValue() {
        this.childSubscription && (this.childSubscription(), delete this.childSubscription);
        const {
            children: e
        } = this.props;
        xt(e) && (this.childSubscription = e.on("change", a => {
            this.current && (this.current.textContent = `${a}`)
        }))
    }
}

function jb(n, {
    style: e,
    vars: a
}, s, l) {
    const o = n.style;
    let c;
    for (c in e) o[c] = e[c];
    l ? .applyProjectionStyles(o, s);
    for (c in a) o.setProperty(c, a[c])
}

function U5(n) {
    return window.getComputedStyle(n)
}
class H5 extends Lb {
    constructor() {
        super(...arguments), this.type = "html", this.renderInstance = jb
    }
    readValueFromInstance(e, a) {
        if (ks.has(a)) return this.projection ? .isProjecting ? Qd(a) : s6(e, a); {
            const s = U5(e),
                l = (Zh(a) ? s.getPropertyValue(a) : s[a]) || 0;
            return typeof l == "string" ? l.trim() : l
        }
    }
    measureInstanceViewportBox(e, {
        transformPagePoint: a
    }) {
        return zb(e, a)
    }
    build(e, a, s) {
        cm(e, a, s.transformTemplate)
    }
    scrapeMotionValuesFromProps(e, a, s) {
        return mm(e, a, s)
    }
}
const Nb = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

function G5(n, e, a, s) {
    jb(n, e, void 0, s);
    for (const l in e.attrs) n.setAttribute(Nb.has(l) ? l : pm(l), e.attrs[l])
}
class q5 extends Lb {
    constructor() {
        super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = $e
    }
    getBaseTargetFromProps(e, a) {
        return e[a]
    }
    readValueFromInstance(e, a) {
        if (ks.has(a)) {
            const s = rb(a);
            return s && s.default || 0
        }
        return a = Nb.has(a) ? a : pm(a), e.getAttribute(a)
    }
    scrapeMotionValuesFromProps(e, a, s) {
        return Eb(e, a, s)
    }
    build(e, a, s) {
        xb(e, a, this.isSVGTag, s.transformTemplate, s.style)
    }
    renderInstance(e, a, s, l) {
        G5(e, a, s, l)
    }
    mount(e) {
        this.isSVGTag = Tb(e.tagName), super.mount(e)
    }
}
const Y5 = (n, e) => dm(n) ? new q5(e) : new H5(e, {
    allowProjection: n !== J.Fragment
});

function _s(n, e, a) {
    const s = n.getProps();
    return hm(s, e, a !== void 0 ? a : s.custom, n)
}
const sh = n => Array.isArray(n);

function X5(n, e, a) {
    n.hasValue(e) ? n.getValue(e).set(a) : n.addValue(e, Ls(a))
}

function F5(n) {
    return sh(n) ? n[n.length - 1] || 0 : n
}

function K5(n, e) {
    const a = _s(n, e);
    let {
        transitionEnd: s = {},
        transition: l = {},
        ...o
    } = a || {};
    o = { ...o,
        ...s
    };
    for (const c in o) {
        const h = F5(o[c]);
        X5(n, c, h)
    }
}

function Z5(n) {
    return !!(xt(n) && n.add)
}

function rh(n, e) {
    const a = n.getValue("willChange");
    if (Z5(a)) return a.add(e);
    if (!a && si.WillChange) {
        const s = new si.WillChange("auto");
        n.addValue("willChange", s), s.add(e)
    }
}

function Vb(n) {
    return n.props[wb]
}
const Q5 = n => n !== null;

function I5(n, {
    repeat: e,
    repeatType: a = "loop"
}, s) {
    const l = n.filter(Q5),
        o = e && a !== "loop" && e % 2 === 1 ? 0 : l.length - 1;
    return l[o]
}
const $5 = {
        type: "spring",
        stiffness: 500,
        damping: 25,
        restSpeed: 10
    },
    W5 = n => ({
        type: "spring",
        stiffness: 550,
        damping: n === 0 ? 2 * Math.sqrt(550) : 30,
        restSpeed: 10
    }),
    J5 = {
        type: "keyframes",
        duration: .8
    },
    e8 = {
        type: "keyframes",
        ease: [.25, .1, .35, 1],
        duration: .3
    },
    t8 = (n, {
        keyframes: e
    }) => e.length > 2 ? J5 : ks.has(n) ? n.startsWith("scale") ? W5(e[1]) : $5 : e8;

function n8({
    when: n,
    delay: e,
    delayChildren: a,
    staggerChildren: s,
    staggerDirection: l,
    repeat: o,
    repeatType: c,
    repeatDelay: h,
    from: f,
    elapsed: m,
    ...p
}) {
    return !!Object.keys(p).length
}
const gm = (n, e, a, s = {}, l, o) => c => {
    const h = am(s, n) || {},
        f = h.delay || s.delay || 0;
    let {
        elapsed: m = 0
    } = s;
    m = m - jn(f);
    const p = {
        keyframes: Array.isArray(a) ? a : [null, a],
        ease: "easeOut",
        velocity: e.getVelocity(),
        ...h,
        delay: -m,
        onUpdate: b => {
            e.set(b), h.onUpdate && h.onUpdate(b)
        },
        onComplete: () => {
            c(), h.onComplete && h.onComplete()
        },
        name: n,
        motionValue: e,
        element: o ? void 0 : l
    };
    n8(h) || Object.assign(p, t8(n, p)), p.duration && (p.duration = jn(p.duration)), p.repeatDelay && (p.repeatDelay = jn(p.repeatDelay)), p.from !== void 0 && (p.keyframes[0] = p.from);
    let v = !1;
    if ((p.type === !1 || p.duration === 0 && !p.repeatDelay) && (eh(p), p.delay === 0 && (v = !0)), (si.instantAnimations || si.skipAnimations) && (v = !0, eh(p), p.delay = 0), p.allowFlatten = !h.type && !h.ease, v && !o && e.get() !== void 0) {
        const b = I5(p.keyframes, h);
        if (b !== void 0) {
            Be.update(() => {
                p.onUpdate(b), p.onComplete()
            });
            return
        }
    }
    return h.isSync ? new nm(p) : new C6(p)
};

function i8({
    protectedKeys: n,
    needsAnimating: e
}, a) {
    const s = n.hasOwnProperty(a) && e[a] !== !0;
    return e[a] = !1, s
}

function kb(n, e, {
    delay: a = 0,
    transitionOverride: s,
    type: l
} = {}) {
    let {
        transition: o = n.getDefaultTransition(),
        transitionEnd: c,
        ...h
    } = e;
    s && (o = s);
    const f = [],
        m = l && n.animationState && n.animationState.getState()[l];
    for (const p in h) {
        const v = n.getValue(p, n.latestValues[p] ? ? null),
            b = h[p];
        if (b === void 0 || m && i8(m, p)) continue;
        const y = {
                delay: a,
                ...am(o || {}, p)
            },
            T = v.get();
        if (T !== void 0 && !v.isAnimating && !Array.isArray(b) && b === T && !y.velocity) continue;
        let S = !1;
        if (window.MotionHandoffAnimation) {
            const _ = Vb(n);
            if (_) {
                const w = window.MotionHandoffAnimation(_, p, Be);
                w !== null && (y.startTime = w, S = !0)
            }
        }
        rh(n, p), v.start(gm(p, v, b, n.shouldReduceMotion && ib.has(p) ? {
            type: !1
        } : y, n, S));
        const M = v.animation;
        M && f.push(M)
    }
    return c && Promise.all(f).then(() => {
        Be.update(() => {
            c && K5(n, c)
        })
    }), f
}

function Bb(n, e, a, s = 0, l = 1) {
    const o = Array.from(n).sort((m, p) => m.sortNodePosition(p)).indexOf(e),
        c = n.size,
        h = (c - 1) * s;
    return typeof a == "function" ? a(o, c) : l === 1 ? o * s : h - o * s
}

function lh(n, e, a = {}) {
    const s = _s(n, e, a.type === "exit" ? n.presenceContext ? .custom : void 0);
    let {
        transition: l = n.getDefaultTransition() || {}
    } = s || {};
    a.transitionOverride && (l = a.transitionOverride);
    const o = s ? () => Promise.all(kb(n, s, a)) : () => Promise.resolve(),
        c = n.variantChildren && n.variantChildren.size ? (f = 0) => {
            const {
                delayChildren: m = 0,
                staggerChildren: p,
                staggerDirection: v
            } = l;
            return a8(n, e, f, m, p, v, a)
        } : () => Promise.resolve(),
        {
            when: h
        } = l;
    if (h) {
        const [f, m] = h === "beforeChildren" ? [o, c] : [c, o];
        return f().then(() => m())
    } else return Promise.all([o(), c(a.delay)])
}

function a8(n, e, a = 0, s = 0, l = 0, o = 1, c) {
    const h = [];
    for (const f of n.variantChildren) f.notify("AnimationStart", e), h.push(lh(f, e, { ...c,
        delay: a + (typeof s == "function" ? 0 : s) + Bb(n.variantChildren, f, s, l, o)
    }).then(() => f.notify("AnimationComplete", e)));
    return Promise.all(h)
}

function s8(n, e, a = {}) {
    n.notify("AnimationStart", e);
    let s;
    if (Array.isArray(e)) {
        const l = e.map(o => lh(n, o, a));
        s = Promise.all(l)
    } else if (typeof e == "string") s = lh(n, e, a);
    else {
        const l = typeof e == "function" ? _s(n, e, a.custom) : e;
        s = Promise.all(kb(n, l, a))
    }
    return s.then(() => {
        n.notify("AnimationComplete", e)
    })
}

function Pb(n, e) {
    if (!Array.isArray(e)) return !1;
    const a = e.length;
    if (a !== n.length) return !1;
    for (let s = 0; s < a; s++)
        if (e[s] !== n[s]) return !1;
    return !0
}
const r8 = um.length;

function Ub(n) {
    if (!n) return;
    if (!n.isControllingVariants) {
        const a = n.parent ? Ub(n.parent) || {} : {};
        return n.props.initial !== void 0 && (a.initial = n.props.initial), a
    }
    const e = {};
    for (let a = 0; a < r8; a++) {
        const s = um[a],
            l = n.props[s];
        (cl(l) || l === !1) && (e[s] = l)
    }
    return e
}
const l8 = [...om].reverse(),
    o8 = om.length;

function u8(n) {
    return e => Promise.all(e.map(({
        animation: a,
        options: s
    }) => s8(n, a, s)))
}

function c8(n) {
    let e = u8(n),
        a = Tv(),
        s = !0;
    const l = f => (m, p) => {
        const v = _s(n, p, f === "exit" ? n.presenceContext ? .custom : void 0);
        if (v) {
            const {
                transition: b,
                transitionEnd: y,
                ...T
            } = v;
            m = { ...m,
                ...T,
                ...y
            }
        }
        return m
    };

    function o(f) {
        e = f(n)
    }

    function c(f) {
        const {
            props: m
        } = n, p = Ub(n.parent) || {}, v = [], b = new Set;
        let y = {},
            T = 1 / 0;
        for (let M = 0; M < o8; M++) {
            const _ = l8[M],
                w = a[_],
                C = m[_] !== void 0 ? m[_] : p[_],
                L = cl(C),
                O = _ === f ? w.isActive : null;
            O === !1 && (T = M);
            let V = C === p[_] && C !== m[_] && L;
            if (V && s && n.manuallyAnimateOnMount && (V = !1), w.protectedKeys = { ...y
                }, !w.isActive && O === null || !C && !w.prevProp || _u(C) || typeof C == "boolean") continue;
            const k = f8(w.prevProp, C);
            let D = k || _ === f && w.isActive && !V && L || M > T && L,
                H = !1;
            const F = Array.isArray(C) ? C : [C];
            let I = F.reduce(l(_), {});
            O === !1 && (I = {});
            const {
                prevResolvedValues: W = {}
            } = w, ee = { ...W,
                ...I
            }, ae = G => {
                D = !0, b.has(G) && (H = !0, b.delete(G)), w.needsAnimating[G] = !0;
                const X = n.getValue(G);
                X && (X.liveStyle = !1)
            };
            for (const G in ee) {
                const X = I[G],
                    te = W[G];
                if (y.hasOwnProperty(G)) continue;
                let z = !1;
                sh(X) && sh(te) ? z = !Pb(X, te) : z = X !== te, z ? X != null ? ae(G) : b.add(G) : X !== void 0 && b.has(G) ? ae(G) : w.protectedKeys[G] = !0
            }
            w.prevProp = C, w.prevResolvedValues = I, w.isActive && (y = { ...y,
                ...I
            }), s && n.blockInitialAnimation && (D = !1);
            const se = V && k;
            D && (!se || H) && v.push(...F.map(G => {
                const X = {
                    type: _
                };
                if (typeof G == "string" && s && !se && n.manuallyAnimateOnMount && n.parent) {
                    const {
                        parent: te
                    } = n, z = _s(te, G);
                    if (te.enteringChildren && z) {
                        const {
                            delayChildren: Z
                        } = z.transition || {};
                        X.delay = Bb(te.enteringChildren, n, Z)
                    }
                }
                return {
                    animation: G,
                    options: X
                }
            }))
        }
        if (b.size) {
            const M = {};
            if (typeof m.initial != "boolean") {
                const _ = _s(n, Array.isArray(m.initial) ? m.initial[0] : m.initial);
                _ && _.transition && (M.transition = _.transition)
            }
            b.forEach(_ => {
                const w = n.getBaseTarget(_),
                    C = n.getValue(_);
                C && (C.liveStyle = !0), M[_] = w ? ? null
            }), v.push({
                animation: M
            })
        }
        let S = !!v.length;
        return s && (m.initial === !1 || m.initial === m.animate) && !n.manuallyAnimateOnMount && (S = !1), s = !1, S ? e(v) : Promise.resolve()
    }

    function h(f, m) {
        if (a[f].isActive === m) return Promise.resolve();
        n.variantChildren ? .forEach(v => v.animationState ? .setActive(f, m)), a[f].isActive = m;
        const p = c(f);
        for (const v in a) a[v].protectedKeys = {};
        return p
    }
    return {
        animateChanges: c,
        setActive: h,
        setAnimateFunction: o,
        getState: () => a,
        reset: () => {
            a = Tv(), s = !0
        }
    }
}

function f8(n, e) {
    return typeof e == "string" ? e !== n : Array.isArray(e) ? !Pb(e, n) : !1
}

function fa(n = !1) {
    return {
        isActive: n,
        protectedKeys: {},
        needsAnimating: {},
        prevResolvedValues: {}
    }
}

function Tv() {
    return {
        animate: fa(!0),
        whileInView: fa(),
        whileHover: fa(),
        whileTap: fa(),
        whileDrag: fa(),
        whileFocus: fa(),
        exit: fa()
    }
}
class Yi {
    constructor(e) {
        this.isMounted = !1, this.node = e
    }
    update() {}
}
class d8 extends Yi {
    constructor(e) {
        super(e), e.animationState || (e.animationState = c8(e))
    }
    updateAnimationControlsSubscription() {
        const {
            animate: e
        } = this.node.getProps();
        _u(e) && (this.unmountControls = e.subscribe(this.node))
    }
    mount() {
        this.updateAnimationControlsSubscription()
    }
    update() {
        const {
            animate: e
        } = this.node.getProps(), {
            animate: a
        } = this.node.prevProps || {};
        e !== a && this.updateAnimationControlsSubscription()
    }
    unmount() {
        this.node.animationState.reset(), this.unmountControls ? .()
    }
}
let h8 = 0;
class m8 extends Yi {
    constructor() {
        super(...arguments), this.id = h8++
    }
    update() {
        if (!this.node.presenceContext) return;
        const {
            isPresent: e,
            onExitComplete: a
        } = this.node.presenceContext, {
            isPresent: s
        } = this.node.prevPresenceContext || {};
        if (!this.node.animationState || e === s) return;
        const l = this.node.animationState.setActive("exit", !e);
        a && !e && l.then(() => {
            a(this.id)
        })
    }
    mount() {
        const {
            register: e,
            onExitComplete: a
        } = this.node.presenceContext || {};
        a && a(this.id), e && (this.unmount = e(this.id))
    }
    unmount() {}
}
const p8 = {
    animation: {
        Feature: d8
    },
    exit: {
        Feature: m8
    }
};

function dl(n, e, a, s = {
    passive: !0
}) {
    return n.addEventListener(e, a, s), () => n.removeEventListener(e, a)
}

function xl(n) {
    return {
        point: {
            x: n.pageX,
            y: n.pageY
        }
    }
}
const g8 = n => e => lm(e) && n(e, xl(e));

function Ir(n, e, a, s) {
    return dl(n, e, g8(a), s)
}
const Hb = 1e-4,
    v8 = 1 - Hb,
    y8 = 1 + Hb,
    Gb = .01,
    b8 = 0 - Gb,
    x8 = 0 + Gb;

function Et(n) {
    return n.max - n.min
}

function S8(n, e, a) {
    return Math.abs(n - e) <= a
}

function _v(n, e, a, s = .5) {
    n.origin = s, n.originPoint = Ye(e.min, e.max, n.origin), n.scale = Et(a) / Et(e), n.translate = Ye(a.min, a.max, n.origin) - n.originPoint, (n.scale >= v8 && n.scale <= y8 || isNaN(n.scale)) && (n.scale = 1), (n.translate >= b8 && n.translate <= x8 || isNaN(n.translate)) && (n.translate = 0)
}

function $r(n, e, a, s) {
    _v(n.x, e.x, a.x, s ? s.originX : void 0), _v(n.y, e.y, a.y, s ? s.originY : void 0)
}

function Ev(n, e, a) {
    n.min = a.min + e.min, n.max = n.min + Et(e)
}

function T8(n, e, a) {
    Ev(n.x, e.x, a.x), Ev(n.y, e.y, a.y)
}

function wv(n, e, a) {
    n.min = e.min - a.min, n.max = n.min + Et(e)
}

function Wr(n, e, a) {
    wv(n.x, e.x, a.x), wv(n.y, e.y, a.y)
}

function hn(n) {
    return [n("x"), n("y")]
}
const qb = ({
        current: n
    }) => n ? n.ownerDocument.defaultView : null,
    Mv = (n, e) => Math.abs(n - e);

function _8(n, e) {
    const a = Mv(n.x, e.x),
        s = Mv(n.y, e.y);
    return Math.sqrt(a ** 2 + s ** 2)
}
class Yb {
    constructor(e, a, {
        transformPagePoint: s,
        contextWindow: l = window,
        dragSnapToOrigin: o = !1,
        distanceThreshold: c = 3
    } = {}) {
        if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                const b = cd(this.lastMoveEventInfo, this.history),
                    y = this.startEvent !== null,
                    T = _8(b.offset, {
                        x: 0,
                        y: 0
                    }) >= this.distanceThreshold;
                if (!y && !T) return;
                const {
                    point: S
                } = b, {
                    timestamp: M
                } = mt;
                this.history.push({ ...S,
                    timestamp: M
                });
                const {
                    onStart: _,
                    onMove: w
                } = this.handlers;
                y || (_ && _(this.lastMoveEvent, b), this.startEvent = this.lastMoveEvent), w && w(this.lastMoveEvent, b)
            }, this.handlePointerMove = (b, y) => {
                this.lastMoveEvent = b, this.lastMoveEventInfo = ud(y, this.transformPagePoint), Be.update(this.updatePoint, !0)
            }, this.handlePointerUp = (b, y) => {
                this.end();
                const {
                    onEnd: T,
                    onSessionEnd: S,
                    resumeAnimation: M
                } = this.handlers;
                if (this.dragSnapToOrigin && M && M(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                const _ = cd(b.type === "pointercancel" ? this.lastMoveEventInfo : ud(y, this.transformPagePoint), this.history);
                this.startEvent && T && T(b, _), S && S(b, _)
            }, !lm(e)) return;
        this.dragSnapToOrigin = o, this.handlers = a, this.transformPagePoint = s, this.distanceThreshold = c, this.contextWindow = l || window;
        const h = xl(e),
            f = ud(h, this.transformPagePoint),
            {
                point: m
            } = f,
            {
                timestamp: p
            } = mt;
        this.history = [{ ...m,
            timestamp: p
        }];
        const {
            onSessionStart: v
        } = a;
        v && v(e, cd(f, this.history)), this.removeListeners = vl(Ir(this.contextWindow, "pointermove", this.handlePointerMove), Ir(this.contextWindow, "pointerup", this.handlePointerUp), Ir(this.contextWindow, "pointercancel", this.handlePointerUp))
    }
    updateHandlers(e) {
        this.handlers = e
    }
    end() {
        this.removeListeners && this.removeListeners(), Hi(this.updatePoint)
    }
}

function ud(n, e) {
    return e ? {
        point: e(n.point)
    } : n
}

function Av(n, e) {
    return {
        x: n.x - e.x,
        y: n.y - e.y
    }
}

function cd({
    point: n
}, e) {
    return {
        point: n,
        delta: Av(n, Xb(e)),
        offset: Av(n, E8(e)),
        velocity: w8(e, .1)
    }
}

function E8(n) {
    return n[0]
}

function Xb(n) {
    return n[n.length - 1]
}

function w8(n, e) {
    if (n.length < 2) return {
        x: 0,
        y: 0
    };
    let a = n.length - 1,
        s = null;
    const l = Xb(n);
    for (; a >= 0 && (s = n[a], !(l.timestamp - s.timestamp > jn(e)));) a--;
    if (!s) return {
        x: 0,
        y: 0
    };
    const o = vn(l.timestamp - s.timestamp);
    if (o === 0) return {
        x: 0,
        y: 0
    };
    const c = {
        x: (l.x - s.x) / o,
        y: (l.y - s.y) / o
    };
    return c.x === 1 / 0 && (c.x = 0), c.y === 1 / 0 && (c.y = 0), c
}

function M8(n, {
    min: e,
    max: a
}, s) {
    return e !== void 0 && n < e ? n = s ? Ye(e, n, s.min) : Math.max(n, e) : a !== void 0 && n > a && (n = s ? Ye(a, n, s.max) : Math.min(n, a)), n
}

function Cv(n, e, a) {
    return {
        min: e !== void 0 ? n.min + e : void 0,
        max: a !== void 0 ? n.max + a - (n.max - n.min) : void 0
    }
}

function A8(n, {
    top: e,
    left: a,
    bottom: s,
    right: l
}) {
    return {
        x: Cv(n.x, a, l),
        y: Cv(n.y, e, s)
    }
}

function Ov(n, e) {
    let a = e.min - n.min,
        s = e.max - n.max;
    return e.max - e.min < n.max - n.min && ([a, s] = [s, a]), {
        min: a,
        max: s
    }
}

function C8(n, e) {
    return {
        x: Ov(n.x, e.x),
        y: Ov(n.y, e.y)
    }
}

function O8(n, e) {
    let a = .5;
    const s = Et(n),
        l = Et(e);
    return l > s ? a = ll(e.min, e.max - s, n.min) : s > l && (a = ll(n.min, n.max - l, e.min)), ai(0, 1, a)
}

function D8(n, e) {
    const a = {};
    return e.min !== void 0 && (a.min = e.min - n.min), e.max !== void 0 && (a.max = e.max - n.min), a
}
const oh = .35;

function z8(n = oh) {
    return n === !1 ? n = 0 : n === !0 && (n = oh), {
        x: Dv(n, "left", "right"),
        y: Dv(n, "top", "bottom")
    }
}

function Dv(n, e, a) {
    return {
        min: zv(n, e),
        max: zv(n, a)
    }
}

function zv(n, e) {
    return typeof n == "number" ? n : n[e] || 0
}
const R8 = new WeakMap;
class L8 {
    constructor(e) {
        this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
            x: 0,
            y: 0
        }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = $e(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = e
    }
    start(e, {
        snapToCursor: a = !1,
        distanceThreshold: s
    } = {}) {
        const {
            presenceContext: l
        } = this.visualElement;
        if (l && l.isPresent === !1) return;
        const o = v => {
                const {
                    dragSnapToOrigin: b
                } = this.getProps();
                b ? this.pauseAnimation() : this.stopAnimation(), a && this.snapToCursor(xl(v).point)
            },
            c = (v, b) => {
                const {
                    drag: y,
                    dragPropagation: T,
                    onDragStart: S
                } = this.getProps();
                if (y && !T && (this.openDragLock && this.openDragLock(), this.openDragLock = Y6(y), !this.openDragLock)) return;
                this.latestPointerEvent = v, this.latestPanInfo = b, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), hn(_ => {
                    let w = this.getAxisMotionValue(_).get() || 0;
                    if (Nn.test(w)) {
                        const {
                            projection: C
                        } = this.visualElement;
                        if (C && C.layout) {
                            const L = C.layout.layoutBox[_];
                            L && (w = Et(L) * (parseFloat(w) / 100))
                        }
                    }
                    this.originPoint[_] = w
                }), S && Be.postRender(() => S(v, b)), rh(this.visualElement, "transform");
                const {
                    animationState: M
                } = this.visualElement;
                M && M.setActive("whileDrag", !0)
            },
            h = (v, b) => {
                this.latestPointerEvent = v, this.latestPanInfo = b;
                const {
                    dragPropagation: y,
                    dragDirectionLock: T,
                    onDirectionLock: S,
                    onDrag: M
                } = this.getProps();
                if (!y && !this.openDragLock) return;
                const {
                    offset: _
                } = b;
                if (T && this.currentDirection === null) {
                    this.currentDirection = j8(_), this.currentDirection !== null && S && S(this.currentDirection);
                    return
                }
                this.updateAxis("x", b.point, _), this.updateAxis("y", b.point, _), this.visualElement.render(), M && M(v, b)
            },
            f = (v, b) => {
                this.latestPointerEvent = v, this.latestPanInfo = b, this.stop(v, b), this.latestPointerEvent = null, this.latestPanInfo = null
            },
            m = () => hn(v => this.getAnimationState(v) === "paused" && this.getAxisMotionValue(v).animation ? .play()),
            {
                dragSnapToOrigin: p
            } = this.getProps();
        this.panSession = new Yb(e, {
            onSessionStart: o,
            onStart: c,
            onMove: h,
            onSessionEnd: f,
            resumeAnimation: m
        }, {
            transformPagePoint: this.visualElement.getTransformPagePoint(),
            dragSnapToOrigin: p,
            distanceThreshold: s,
            contextWindow: qb(this.visualElement)
        })
    }
    stop(e, a) {
        const s = e || this.latestPointerEvent,
            l = a || this.latestPanInfo,
            o = this.isDragging;
        if (this.cancel(), !o || !l || !s) return;
        const {
            velocity: c
        } = l;
        this.startAnimation(c);
        const {
            onDragEnd: h
        } = this.getProps();
        h && Be.postRender(() => h(s, l))
    }
    cancel() {
        this.isDragging = !1;
        const {
            projection: e,
            animationState: a
        } = this.visualElement;
        e && (e.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
        const {
            dragPropagation: s
        } = this.getProps();
        !s && this.openDragLock && (this.openDragLock(), this.openDragLock = null), a && a.setActive("whileDrag", !1)
    }
    updateAxis(e, a, s) {
        const {
            drag: l
        } = this.getProps();
        if (!s || !Uo(e, l, this.currentDirection)) return;
        const o = this.getAxisMotionValue(e);
        let c = this.originPoint[e] + s[e];
        this.constraints && this.constraints[e] && (c = M8(c, this.constraints[e], this.elastic[e])), o.set(c)
    }
    resolveConstraints() {
        const {
            dragConstraints: e,
            dragElastic: a
        } = this.getProps(), s = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : this.visualElement.projection ? .layout, l = this.constraints;
        e && gs(e) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : e && s ? this.constraints = A8(s.layoutBox, e) : this.constraints = !1, this.elastic = z8(a), l !== this.constraints && s && this.constraints && !this.hasMutatedConstraints && hn(o => {
            this.constraints !== !1 && this.getAxisMotionValue(o) && (this.constraints[o] = D8(s.layoutBox[o], this.constraints[o]))
        })
    }
    resolveRefConstraints() {
        const {
            dragConstraints: e,
            onMeasureDragConstraints: a
        } = this.getProps();
        if (!e || !gs(e)) return !1;
        const s = e.current,
            {
                projection: l
            } = this.visualElement;
        if (!l || !l.layout) return !1;
        const o = N5(s, l.root, this.visualElement.getTransformPagePoint());
        let c = C8(l.layout.layoutBox, o);
        if (a) {
            const h = a(R5(c));
            this.hasMutatedConstraints = !!h, h && (c = Cb(h))
        }
        return c
    }
    startAnimation(e) {
        const {
            drag: a,
            dragMomentum: s,
            dragElastic: l,
            dragTransition: o,
            dragSnapToOrigin: c,
            onDragTransitionEnd: h
        } = this.getProps(), f = this.constraints || {}, m = hn(p => {
            if (!Uo(p, a, this.currentDirection)) return;
            let v = f && f[p] || {};
            c && (v = {
                min: 0,
                max: 0
            });
            const b = l ? 200 : 1e6,
                y = l ? 40 : 1e7,
                T = {
                    type: "inertia",
                    velocity: s ? e[p] : 0,
                    bounceStiffness: b,
                    bounceDamping: y,
                    timeConstant: 750,
                    restDelta: 1,
                    restSpeed: 10,
                    ...o,
                    ...v
                };
            return this.startAxisValueAnimation(p, T)
        });
        return Promise.all(m).then(h)
    }
    startAxisValueAnimation(e, a) {
        const s = this.getAxisMotionValue(e);
        return rh(this.visualElement, e), s.start(gm(e, s, 0, a, this.visualElement, !1))
    }
    stopAnimation() {
        hn(e => this.getAxisMotionValue(e).stop())
    }
    pauseAnimation() {
        hn(e => this.getAxisMotionValue(e).animation ? .pause())
    }
    getAnimationState(e) {
        return this.getAxisMotionValue(e).animation ? .state
    }
    getAxisMotionValue(e) {
        const a = `_drag${e.toUpperCase()}`,
            s = this.visualElement.getProps(),
            l = s[a];
        return l || this.visualElement.getValue(e, (s.initial ? s.initial[e] : void 0) || 0)
    }
    snapToCursor(e) {
        hn(a => {
            const {
                drag: s
            } = this.getProps();
            if (!Uo(a, s, this.currentDirection)) return;
            const {
                projection: l
            } = this.visualElement, o = this.getAxisMotionValue(a);
            if (l && l.layout) {
                const {
                    min: c,
                    max: h
                } = l.layout.layoutBox[a];
                o.set(e[a] - Ye(c, h, .5))
            }
        })
    }
    scalePositionWithinConstraints() {
        if (!this.visualElement.current) return;
        const {
            drag: e,
            dragConstraints: a
        } = this.getProps(), {
            projection: s
        } = this.visualElement;
        if (!gs(a) || !s || !this.constraints) return;
        this.stopAnimation();
        const l = {
            x: 0,
            y: 0
        };
        hn(c => {
            const h = this.getAxisMotionValue(c);
            if (h && this.constraints !== !1) {
                const f = h.get();
                l[c] = O8({
                    min: f,
                    max: f
                }, this.constraints[c])
            }
        });
        const {
            transformTemplate: o
        } = this.visualElement.getProps();
        this.visualElement.current.style.transform = o ? o({}, "") : "none", s.root && s.root.updateScroll(), s.updateLayout(), this.resolveConstraints(), hn(c => {
            if (!Uo(c, e, null)) return;
            const h = this.getAxisMotionValue(c),
                {
                    min: f,
                    max: m
                } = this.constraints[c];
            h.set(Ye(f, m, l[c]))
        })
    }
    addListeners() {
        if (!this.visualElement.current) return;
        R8.set(this.visualElement, this);
        const e = this.visualElement.current,
            a = Ir(e, "pointerdown", f => {
                const {
                    drag: m,
                    dragListener: p = !0
                } = this.getProps();
                m && p && this.start(f)
            }),
            s = () => {
                const {
                    dragConstraints: f
                } = this.getProps();
                gs(f) && f.current && (this.constraints = this.resolveRefConstraints())
            },
            {
                projection: l
            } = this.visualElement,
            o = l.addEventListener("measure", s);
        l && !l.layout && (l.root && l.root.updateScroll(), l.updateLayout()), Be.read(s);
        const c = dl(window, "resize", () => this.scalePositionWithinConstraints()),
            h = l.addEventListener("didUpdate", (({
                delta: f,
                hasLayoutChanged: m
            }) => {
                this.isDragging && m && (hn(p => {
                    const v = this.getAxisMotionValue(p);
                    v && (this.originPoint[p] += f[p].translate, v.set(v.get() + f[p].translate))
                }), this.visualElement.render())
            }));
        return () => {
            c(), a(), o(), h && h()
        }
    }
    getProps() {
        const e = this.visualElement.getProps(),
            {
                drag: a = !1,
                dragDirectionLock: s = !1,
                dragPropagation: l = !1,
                dragConstraints: o = !1,
                dragElastic: c = oh,
                dragMomentum: h = !0
            } = e;
        return { ...e,
            drag: a,
            dragDirectionLock: s,
            dragPropagation: l,
            dragConstraints: o,
            dragElastic: c,
            dragMomentum: h
        }
    }
}

function Uo(n, e, a) {
    return (e === !0 || e === n) && (a === null || a === n)
}

function j8(n, e = 10) {
    let a = null;
    return Math.abs(n.y) > e ? a = "y" : Math.abs(n.x) > e && (a = "x"), a
}
class N8 extends Yi {
    constructor(e) {
        super(e), this.removeGroupControls = yn, this.removeListeners = yn, this.controls = new L8(e)
    }
    mount() {
        const {
            dragControls: e
        } = this.node.getProps();
        e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || yn
    }
    unmount() {
        this.removeGroupControls(), this.removeListeners()
    }
}
const Rv = n => (e, a) => {
    n && Be.postRender(() => n(e, a))
};
class V8 extends Yi {
    constructor() {
        super(...arguments), this.removePointerDownListener = yn
    }
    onPointerDown(e) {
        this.session = new Yb(e, this.createPanHandlers(), {
            transformPagePoint: this.node.getTransformPagePoint(),
            contextWindow: qb(this.node)
        })
    }
    createPanHandlers() {
        const {
            onPanSessionStart: e,
            onPanStart: a,
            onPan: s,
            onPanEnd: l
        } = this.node.getProps();
        return {
            onSessionStart: Rv(e),
            onStart: Rv(a),
            onMove: s,
            onEnd: (o, c) => {
                delete this.session, l && Be.postRender(() => l(o, c))
            }
        }
    }
    mount() {
        this.removePointerDownListener = Ir(this.node.current, "pointerdown", e => this.onPointerDown(e))
    }
    update() {
        this.session && this.session.updateHandlers(this.createPanHandlers())
    }
    unmount() {
        this.removePointerDownListener(), this.session && this.session.end()
    }
}
const Io = {
    hasAnimatedSinceResize: !0,
    hasEverUpdated: !1
};

function Lv(n, e) {
    return e.max === e.min ? 0 : n / (e.max - e.min) * 100
}
const Br = {
        correct: (n, e) => {
            if (!e.target) return n;
            if (typeof n == "string")
                if (de.test(n)) n = parseFloat(n);
                else return n;
            const a = Lv(n, e.target.x),
                s = Lv(n, e.target.y);
            return `${a}% ${s}%`
        }
    },
    k8 = {
        correct: (n, {
            treeScale: e,
            projectionDelta: a
        }) => {
            const s = n,
                l = Gi.parse(n);
            if (l.length > 5) return s;
            const o = Gi.createTransformer(n),
                c = typeof l[0] != "number" ? 1 : 0,
                h = a.x.scale * e.x,
                f = a.y.scale * e.y;
            l[0 + c] /= h, l[1 + c] /= f;
            const m = Ye(h, f, .5);
            return typeof l[2 + c] == "number" && (l[2 + c] /= m), typeof l[3 + c] == "number" && (l[3 + c] /= m), o(l)
        }
    };
let fd = !1;
class B8 extends J.Component {
    componentDidMount() {
        const {
            visualElement: e,
            layoutGroup: a,
            switchLayoutGroup: s,
            layoutId: l
        } = this.props, {
            projection: o
        } = e;
        r5(P8), o && (a.group && a.group.add(o), s && s.register && l && s.register(o), fd && o.root.didUpdate(), o.addEventListener("animationComplete", () => {
            this.safeToRemove()
        }), o.setOptions({ ...o.options,
            onExitComplete: () => this.safeToRemove()
        })), Io.hasEverUpdated = !0
    }
    getSnapshotBeforeUpdate(e) {
        const {
            layoutDependency: a,
            visualElement: s,
            drag: l,
            isPresent: o
        } = this.props, {
            projection: c
        } = s;
        return c && (c.isPresent = o, fd = !0, l || e.layoutDependency !== a || a === void 0 || e.isPresent !== o ? c.willUpdate() : this.safeToRemove(), e.isPresent !== o && (o ? c.promote() : c.relegate() || Be.postRender(() => {
            const h = c.getStack();
            (!h || !h.members.length) && this.safeToRemove()
        }))), null
    }
    componentDidUpdate() {
        const {
            projection: e
        } = this.props.visualElement;
        e && (e.root.didUpdate(), rm.postRender(() => {
            !e.currentAnimation && e.isLead() && this.safeToRemove()
        }))
    }
    componentWillUnmount() {
        const {
            visualElement: e,
            layoutGroup: a,
            switchLayoutGroup: s
        } = this.props, {
            projection: l
        } = e;
        fd = !0, l && (l.scheduleCheckAfterUnmount(), a && a.group && a.group.remove(l), s && s.deregister && s.deregister(l))
    }
    safeToRemove() {
        const {
            safeToRemove: e
        } = this.props;
        e && e()
    }
    render() {
        return null
    }
}

function Fb(n) {
    const [e, a] = J6(), s = J.useContext(_2);
    return A.jsx(B8, { ...n,
        layoutGroup: s,
        switchLayoutGroup: J.useContext(Mb),
        isPresent: e,
        safeToRemove: a
    })
}
const P8 = {
    borderRadius: { ...Br,
        applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
    },
    borderTopLeftRadius: Br,
    borderTopRightRadius: Br,
    borderBottomLeftRadius: Br,
    borderBottomRightRadius: Br,
    boxShadow: k8
};

function U8(n, e, a) {
    const s = xt(n) ? n : Ls(n);
    return s.start(gm("", s, e, a)), s.animation
}
const H8 = (n, e) => n.depth - e.depth;
class G8 {
    constructor() {
        this.children = [], this.isDirty = !1
    }
    add(e) {
        Hh(this.children, e), this.isDirty = !0
    }
    remove(e) {
        Gh(this.children, e), this.isDirty = !0
    }
    forEach(e) {
        this.isDirty && this.children.sort(H8), this.isDirty = !1, this.children.forEach(e)
    }
}

function q8(n, e) {
    const a = zt.now(),
        s = ({
            timestamp: l
        }) => {
            const o = l - a;
            o >= e && (Hi(s), n(o - e))
        };
    return Be.setup(s, !0), () => Hi(s)
}
const Kb = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
    Y8 = Kb.length,
    jv = n => typeof n == "string" ? parseFloat(n) : n,
    Nv = n => typeof n == "number" || de.test(n);

function X8(n, e, a, s, l, o) {
    l ? (n.opacity = Ye(0, a.opacity ? ? 1, F8(s)), n.opacityExit = Ye(e.opacity ? ? 1, 0, K8(s))) : o && (n.opacity = Ye(e.opacity ? ? 1, a.opacity ? ? 1, s));
    for (let c = 0; c < Y8; c++) {
        const h = `border${Kb[c]}Radius`;
        let f = Vv(e, h),
            m = Vv(a, h);
        if (f === void 0 && m === void 0) continue;
        f || (f = 0), m || (m = 0), f === 0 || m === 0 || Nv(f) === Nv(m) ? (n[h] = Math.max(Ye(jv(f), jv(m), s), 0), (Nn.test(m) || Nn.test(f)) && (n[h] += "%")) : n[h] = m
    }(e.rotate || a.rotate) && (n.rotate = Ye(e.rotate || 0, a.rotate || 0, s))
}

function Vv(n, e) {
    return n[e] !== void 0 ? n[e] : n.borderRadius
}
const F8 = Zb(0, .5, j2),
    K8 = Zb(.5, .95, yn);

function Zb(n, e, a) {
    return s => s < n ? 0 : s > e ? 1 : a(ll(n, e, s))
}

function kv(n, e) {
    n.min = e.min, n.max = e.max
}

function fn(n, e) {
    kv(n.x, e.x), kv(n.y, e.y)
}

function Bv(n, e) {
    n.translate = e.translate, n.scale = e.scale, n.originPoint = e.originPoint, n.origin = e.origin
}

function Pv(n, e, a, s, l) {
    return n -= e, n = du(n, 1 / a, s), l !== void 0 && (n = du(n, 1 / l, s)), n
}

function Z8(n, e = 0, a = 1, s = .5, l, o = n, c = n) {
    if (Nn.test(e) && (e = parseFloat(e), e = Ye(c.min, c.max, e / 100) - c.min), typeof e != "number") return;
    let h = Ye(o.min, o.max, s);
    n === o && (h -= e), n.min = Pv(n.min, e, a, h, l), n.max = Pv(n.max, e, a, h, l)
}

function Uv(n, e, [a, s, l], o, c) {
    Z8(n, e[a], e[s], e[l], e.scale, o, c)
}
const Q8 = ["x", "scaleX", "originX"],
    I8 = ["y", "scaleY", "originY"];

function Hv(n, e, a, s) {
    Uv(n.x, e, Q8, a ? a.x : void 0, s ? s.x : void 0), Uv(n.y, e, I8, a ? a.y : void 0, s ? s.y : void 0)
}

function Gv(n) {
    return n.translate === 0 && n.scale === 1
}

function Qb(n) {
    return Gv(n.x) && Gv(n.y)
}

function qv(n, e) {
    return n.min === e.min && n.max === e.max
}

function $8(n, e) {
    return qv(n.x, e.x) && qv(n.y, e.y)
}

function Yv(n, e) {
    return Math.round(n.min) === Math.round(e.min) && Math.round(n.max) === Math.round(e.max)
}

function Ib(n, e) {
    return Yv(n.x, e.x) && Yv(n.y, e.y)
}

function Xv(n) {
    return Et(n.x) / Et(n.y)
}

function Fv(n, e) {
    return n.translate === e.translate && n.scale === e.scale && n.originPoint === e.originPoint
}
class W8 {
    constructor() {
        this.members = []
    }
    add(e) {
        Hh(this.members, e), e.scheduleRender()
    }
    remove(e) {
        if (Gh(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
            const a = this.members[this.members.length - 1];
            a && this.promote(a)
        }
    }
    relegate(e) {
        const a = this.members.findIndex(l => e === l);
        if (a === 0) return !1;
        let s;
        for (let l = a; l >= 0; l--) {
            const o = this.members[l];
            if (o.isPresent !== !1) {
                s = o;
                break
            }
        }
        return s ? (this.promote(s), !0) : !1
    }
    promote(e, a) {
        const s = this.lead;
        if (e !== s && (this.prevLead = s, this.lead = e, e.show(), s)) {
            s.instance && s.scheduleRender(), e.scheduleRender(), e.resumeFrom = s, a && (e.resumeFrom.preserveOpacity = !0), s.snapshot && (e.snapshot = s.snapshot, e.snapshot.latestValues = s.animationValues || s.latestValues), e.root && e.root.isUpdating && (e.isLayoutDirty = !0);
            const {
                crossfade: l
            } = e.options;
            l === !1 && s.hide()
        }
    }
    exitAnimationComplete() {
        this.members.forEach(e => {
            const {
                options: a,
                resumingFrom: s
            } = e;
            a.onExitComplete && a.onExitComplete(), s && s.options.onExitComplete && s.options.onExitComplete()
        })
    }
    scheduleRender() {
        this.members.forEach(e => {
            e.instance && e.scheduleRender(!1)
        })
    }
    removeLeadSnapshot() {
        this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
    }
}

function J8(n, e, a) {
    let s = "";
    const l = n.x.translate / e.x,
        o = n.y.translate / e.y,
        c = a ? .z || 0;
    if ((l || o || c) && (s = `translate3d(${l}px, ${o}px, ${c}px) `), (e.x !== 1 || e.y !== 1) && (s += `scale(${1/e.x}, ${1/e.y}) `), a) {
        const {
            transformPerspective: m,
            rotate: p,
            rotateX: v,
            rotateY: b,
            skewX: y,
            skewY: T
        } = a;
        m && (s = `perspective(${m}px) ${s}`), p && (s += `rotate(${p}deg) `), v && (s += `rotateX(${v}deg) `), b && (s += `rotateY(${b}deg) `), y && (s += `skewX(${y}deg) `), T && (s += `skewY(${T}deg) `)
    }
    const h = n.x.scale * e.x,
        f = n.y.scale * e.y;
    return (h !== 1 || f !== 1) && (s += `scale(${h}, ${f})`), s || "none"
}
const dd = ["", "X", "Y", "Z"],
    eE = 1e3;
let tE = 0;

function hd(n, e, a, s) {
    const {
        latestValues: l
    } = e;
    l[n] && (a[n] = l[n], e.setStaticValue(n, 0), s && (s[n] = 0))
}

function $b(n) {
    if (n.hasCheckedOptimisedAppear = !0, n.root === n) return;
    const {
        visualElement: e
    } = n.options;
    if (!e) return;
    const a = Vb(e);
    if (window.MotionHasOptimisedAnimation(a, "transform")) {
        const {
            layout: l,
            layoutId: o
        } = n.options;
        window.MotionCancelOptimisedAnimation(a, "transform", Be, !(l || o))
    }
    const {
        parent: s
    } = n;
    s && !s.hasCheckedOptimisedAppear && $b(s)
}

function Wb({
    attachResizeListener: n,
    defaultParent: e,
    measureScroll: a,
    checkIsScrollRoot: s,
    resetTransform: l
}) {
    return class {
        constructor(c = {}, h = e ? .()) {
            this.id = tE++, this.animationId = 0, this.animationCommitId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                x: 1,
                y: 1
            }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
            }, this.updateProjection = () => {
                this.projectionUpdateScheduled = !1, this.nodes.forEach(aE), this.nodes.forEach(oE), this.nodes.forEach(uE), this.nodes.forEach(sE)
            }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = c, this.root = h ? h.root || h : this, this.path = h ? [...h.path, h] : [], this.parent = h, this.depth = h ? h.depth + 1 : 0;
            for (let f = 0; f < this.path.length; f++) this.path[f].shouldResetTransform = !0;
            this.root === this && (this.nodes = new G8)
        }
        addEventListener(c, h) {
            return this.eventHandlers.has(c) || this.eventHandlers.set(c, new Xh), this.eventHandlers.get(c).add(h)
        }
        notifyListeners(c, ...h) {
            const f = this.eventHandlers.get(c);
            f && f.notify(...h)
        }
        hasListeners(c) {
            return this.eventHandlers.has(c)
        }
        mount(c) {
            if (this.instance) return;
            this.isSVG = hb(c) && !I6(c), this.instance = c;
            const {
                layoutId: h,
                layout: f,
                visualElement: m
            } = this.options;
            if (m && !m.current && m.mount(c), this.root.nodes.add(this), this.parent && this.parent.children.add(this), this.root.hasTreeAnimated && (f || h) && (this.isLayoutDirty = !0), n) {
                let p, v = 0;
                const b = () => this.root.updateBlockedByResize = !1;
                Be.read(() => {
                    v = window.innerWidth
                }), n(c, () => {
                    const y = window.innerWidth;
                    y !== v && (v = y, this.root.updateBlockedByResize = !0, p && p(), p = q8(b, 250), Io.hasAnimatedSinceResize && (Io.hasAnimatedSinceResize = !1, this.nodes.forEach(Qv)))
                })
            }
            h && this.root.registerSharedNode(h, this), this.options.animate !== !1 && m && (h || f) && this.addEventListener("didUpdate", ({
                delta: p,
                hasLayoutChanged: v,
                hasRelativeLayoutChanged: b,
                layout: y
            }) => {
                if (this.isTreeAnimationBlocked()) {
                    this.target = void 0, this.relativeTarget = void 0;
                    return
                }
                const T = this.options.transition || m.getDefaultTransition() || mE,
                    {
                        onLayoutAnimationStart: S,
                        onLayoutAnimationComplete: M
                    } = m.getProps(),
                    _ = !this.targetLayout || !Ib(this.targetLayout, y),
                    w = !v && b;
                if (this.options.layoutRoot || this.resumeFrom || w || v && (_ || !this.currentAnimation)) {
                    this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
                    const C = { ...am(T, "layout"),
                        onPlay: S,
                        onComplete: M
                    };
                    (m.shouldReduceMotion || this.options.layoutRoot) && (C.delay = 0, C.type = !1), this.startAnimation(C), this.setAnimationOrigin(p, w)
                } else v || Qv(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                this.targetLayout = y
            })
        }
        unmount() {
            this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
            const c = this.getStack();
            c && c.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), Hi(this.updateProjection)
        }
        blockUpdate() {
            this.updateManuallyBlocked = !0
        }
        unblockUpdate() {
            this.updateManuallyBlocked = !1
        }
        isUpdateBlocked() {
            return this.updateManuallyBlocked || this.updateBlockedByResize
        }
        isTreeAnimationBlocked() {
            return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
        }
        startUpdate() {
            this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(cE), this.animationId++)
        }
        getTransformTemplate() {
            const {
                visualElement: c
            } = this.options;
            return c && c.getProps().transformTemplate
        }
        willUpdate(c = !0) {
            if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                this.options.onExitComplete && this.options.onExitComplete();
                return
            }
            if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && $b(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
            this.isLayoutDirty = !0;
            for (let p = 0; p < this.path.length; p++) {
                const v = this.path[p];
                v.shouldResetTransform = !0, v.updateScroll("snapshot"), v.options.layoutRoot && v.willUpdate(!1)
            }
            const {
                layoutId: h,
                layout: f
            } = this.options;
            if (h === void 0 && !f) return;
            const m = this.getTransformTemplate();
            this.prevTransformTemplateValue = m ? m(this.latestValues, "") : void 0, this.updateSnapshot(), c && this.notifyListeners("willUpdate")
        }
        update() {
            if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(Kv);
                return
            }
            if (this.animationId <= this.animationCommitId) {
                this.nodes.forEach(Zv);
                return
            }
            this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(lE), this.nodes.forEach(nE), this.nodes.forEach(iE)) : this.nodes.forEach(Zv), this.clearAllSnapshots();
            const h = zt.now();
            mt.delta = ai(0, 1e3 / 60, h - mt.timestamp), mt.timestamp = h, mt.isProcessing = !0, td.update.process(mt), td.preRender.process(mt), td.render.process(mt), mt.isProcessing = !1
        }
        didUpdate() {
            this.updateScheduled || (this.updateScheduled = !0, rm.read(this.scheduleUpdate))
        }
        clearAllSnapshots() {
            this.nodes.forEach(rE), this.sharedNodes.forEach(fE)
        }
        scheduleUpdateProjection() {
            this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, Be.preRender(this.updateProjection, !1, !0))
        }
        scheduleCheckAfterUnmount() {
            Be.postRender(() => {
                this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
            })
        }
        updateSnapshot() {
            this.snapshot || !this.instance || (this.snapshot = this.measure(), this.snapshot && !Et(this.snapshot.measuredBox.x) && !Et(this.snapshot.measuredBox.y) && (this.snapshot = void 0))
        }
        updateLayout() {
            if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
            if (this.resumeFrom && !this.resumeFrom.instance)
                for (let f = 0; f < this.path.length; f++) this.path[f].updateScroll();
            const c = this.layout;
            this.layout = this.measure(!1), this.layoutCorrected = $e(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
            const {
                visualElement: h
            } = this.options;
            h && h.notify("LayoutMeasure", this.layout.layoutBox, c ? c.layoutBox : void 0)
        }
        updateScroll(c = "measure") {
            let h = !!(this.options.layoutScroll && this.instance);
            if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === c && (h = !1), h && this.instance) {
                const f = s(this.instance);
                this.scroll = {
                    animationId: this.root.animationId,
                    phase: c,
                    isRoot: f,
                    offset: a(this.instance),
                    wasRoot: this.scroll ? this.scroll.isRoot : f
                }
            }
        }
        resetTransform() {
            if (!l) return;
            const c = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                h = this.projectionDelta && !Qb(this.projectionDelta),
                f = this.getTransformTemplate(),
                m = f ? f(this.latestValues, "") : void 0,
                p = m !== this.prevTransformTemplateValue;
            c && this.instance && (h || ha(this.latestValues) || p) && (l(this.instance, m), this.shouldResetTransform = !1, this.scheduleRender())
        }
        measure(c = !0) {
            const h = this.measurePageBox();
            let f = this.removeElementScroll(h);
            return c && (f = this.removeTransform(f)), pE(f), {
                animationId: this.root.animationId,
                measuredBox: h,
                layoutBox: f,
                latestValues: {},
                source: this.id
            }
        }
        measurePageBox() {
            const {
                visualElement: c
            } = this.options;
            if (!c) return $e();
            const h = c.measureViewportBox();
            if (!(this.scroll ? .wasRoot || this.path.some(gE))) {
                const {
                    scroll: m
                } = this.root;
                m && (vs(h.x, m.offset.x), vs(h.y, m.offset.y))
            }
            return h
        }
        removeElementScroll(c) {
            const h = $e();
            if (fn(h, c), this.scroll ? .wasRoot) return h;
            for (let f = 0; f < this.path.length; f++) {
                const m = this.path[f],
                    {
                        scroll: p,
                        options: v
                    } = m;
                m !== this.root && p && v.layoutScroll && (p.wasRoot && fn(h, c), vs(h.x, p.offset.x), vs(h.y, p.offset.y))
            }
            return h
        }
        applyTransform(c, h = !1) {
            const f = $e();
            fn(f, c);
            for (let m = 0; m < this.path.length; m++) {
                const p = this.path[m];
                !h && p.options.layoutScroll && p.scroll && p !== p.root && ys(f, {
                    x: -p.scroll.offset.x,
                    y: -p.scroll.offset.y
                }), ha(p.latestValues) && ys(f, p.latestValues)
            }
            return ha(this.latestValues) && ys(f, this.latestValues), f
        }
        removeTransform(c) {
            const h = $e();
            fn(h, c);
            for (let f = 0; f < this.path.length; f++) {
                const m = this.path[f];
                if (!m.instance || !ha(m.latestValues)) continue;
                nh(m.latestValues) && m.updateSnapshot();
                const p = $e(),
                    v = m.measurePageBox();
                fn(p, v), Hv(h, m.latestValues, m.snapshot ? m.snapshot.layoutBox : void 0, p)
            }
            return ha(this.latestValues) && Hv(h, this.latestValues), h
        }
        setTargetDelta(c) {
            this.targetDelta = c, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
        }
        setOptions(c) {
            this.options = { ...this.options,
                ...c,
                crossfade: c.crossfade !== void 0 ? c.crossfade : !0
            }
        }
        clearMeasurements() {
            this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
        }
        forceRelativeParentToResolveTarget() {
            this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== mt.timestamp && this.relativeParent.resolveTargetDelta(!0)
        }
        resolveTargetDelta(c = !1) {
            const h = this.getLead();
            this.isProjectionDirty || (this.isProjectionDirty = h.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = h.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = h.isSharedProjectionDirty);
            const f = !!this.resumingFrom || this !== h;
            if (!(c || f && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent ? .isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
            const {
                layout: p,
                layoutId: v
            } = this.options;
            if (!(!this.layout || !(p || v))) {
                if (this.resolvedRelativeTargetAt = mt.timestamp, !this.targetDelta && !this.relativeTarget) {
                    const b = this.getClosestProjectingParent();
                    b && b.layout && this.animationProgress !== 1 ? (this.relativeParent = b, this.forceRelativeParentToResolveTarget(), this.relativeTarget = $e(), this.relativeTargetOrigin = $e(), Wr(this.relativeTargetOrigin, this.layout.layoutBox, b.layout.layoutBox), fn(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                }
                if (!(!this.relativeTarget && !this.targetDelta) && (this.target || (this.target = $e(), this.targetWithTransforms = $e()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), T8(this.target, this.relativeTarget, this.relativeParent.target)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : fn(this.target, this.layout.layoutBox), Db(this.target, this.targetDelta)) : fn(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget)) {
                    this.attemptToResolveRelativeTarget = !1;
                    const b = this.getClosestProjectingParent();
                    b && !!b.resumingFrom == !!this.resumingFrom && !b.options.layoutScroll && b.target && this.animationProgress !== 1 ? (this.relativeParent = b, this.forceRelativeParentToResolveTarget(), this.relativeTarget = $e(), this.relativeTargetOrigin = $e(), Wr(this.relativeTargetOrigin, this.target, b.target), fn(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                }
            }
        }
        getClosestProjectingParent() {
            if (!(!this.parent || nh(this.parent.latestValues) || Ob(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
        }
        isProjecting() {
            return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
        }
        calcProjection() {
            const c = this.getLead(),
                h = !!this.resumingFrom || this !== c;
            let f = !0;
            if ((this.isProjectionDirty || this.parent ? .isProjectionDirty) && (f = !1), h && (this.isSharedProjectionDirty || this.isTransformDirty) && (f = !1), this.resolvedRelativeTargetAt === mt.timestamp && (f = !1), f) return;
            const {
                layout: m,
                layoutId: p
            } = this.options;
            if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(m || p)) return;
            fn(this.layoutCorrected, this.layout.layoutBox);
            const v = this.treeScale.x,
                b = this.treeScale.y;
            j5(this.layoutCorrected, this.treeScale, this.path, h), c.layout && !c.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (c.target = c.layout.layoutBox, c.targetWithTransforms = $e());
            const {
                target: y
            } = c;
            if (!y) {
                this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                return
            }!this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (Bv(this.prevProjectionDelta.x, this.projectionDelta.x), Bv(this.prevProjectionDelta.y, this.projectionDelta.y)), $r(this.projectionDelta, this.layoutCorrected, y, this.latestValues), (this.treeScale.x !== v || this.treeScale.y !== b || !Fv(this.projectionDelta.x, this.prevProjectionDelta.x) || !Fv(this.projectionDelta.y, this.prevProjectionDelta.y)) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", y))
        }
        hide() {
            this.isVisible = !1
        }
        show() {
            this.isVisible = !0
        }
        scheduleRender(c = !0) {
            if (this.options.visualElement ? .scheduleRender(), c) {
                const h = this.getStack();
                h && h.scheduleRender()
            }
            this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
        }
        createProjectionDeltas() {
            this.prevProjectionDelta = bs(), this.projectionDelta = bs(), this.projectionDeltaWithTransform = bs()
        }
        setAnimationOrigin(c, h = !1) {
            const f = this.snapshot,
                m = f ? f.latestValues : {},
                p = { ...this.latestValues
                },
                v = bs();
            (!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !h;
            const b = $e(),
                y = f ? f.source : void 0,
                T = this.layout ? this.layout.source : void 0,
                S = y !== T,
                M = this.getStack(),
                _ = !M || M.members.length <= 1,
                w = !!(S && !_ && this.options.crossfade === !0 && !this.path.some(hE));
            this.animationProgress = 0;
            let C;
            this.mixTargetDelta = L => {
                const O = L / 1e3;
                Iv(v.x, c.x, O), Iv(v.y, c.y, O), this.setTargetDelta(v), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (Wr(b, this.layout.layoutBox, this.relativeParent.layout.layoutBox), dE(this.relativeTarget, this.relativeTargetOrigin, b, O), C && $8(this.relativeTarget, C) && (this.isProjectionDirty = !1), C || (C = $e()), fn(C, this.relativeTarget)), S && (this.animationValues = p, X8(p, m, this.latestValues, O, w, _)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = O
            }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
        }
        startAnimation(c) {
            this.notifyListeners("animationStart"), this.currentAnimation ? .stop(), this.resumingFrom ? .currentAnimation ? .stop(), this.pendingAnimation && (Hi(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = Be.update(() => {
                Io.hasAnimatedSinceResize = !0, this.motionValue || (this.motionValue = Ls(0)), this.currentAnimation = U8(this.motionValue, [0, 1e3], { ...c,
                    velocity: 0,
                    isSync: !0,
                    onUpdate: h => {
                        this.mixTargetDelta(h), c.onUpdate && c.onUpdate(h)
                    },
                    onStop: () => {},
                    onComplete: () => {
                        c.onComplete && c.onComplete(), this.completeAnimation()
                    }
                }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
            })
        }
        completeAnimation() {
            this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
            const c = this.getStack();
            c && c.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
        }
        finishAnimation() {
            this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(eE), this.currentAnimation.stop()), this.completeAnimation()
        }
        applyTransformsToTarget() {
            const c = this.getLead();
            let {
                targetWithTransforms: h,
                target: f,
                layout: m,
                latestValues: p
            } = c;
            if (!(!h || !f || !m)) {
                if (this !== c && this.layout && m && Jb(this.options.animationType, this.layout.layoutBox, m.layoutBox)) {
                    f = this.target || $e();
                    const v = Et(this.layout.layoutBox.x);
                    f.x.min = c.target.x.min, f.x.max = f.x.min + v;
                    const b = Et(this.layout.layoutBox.y);
                    f.y.min = c.target.y.min, f.y.max = f.y.min + b
                }
                fn(h, f), ys(h, p), $r(this.projectionDeltaWithTransform, this.layoutCorrected, h, p)
            }
        }
        registerSharedNode(c, h) {
            this.sharedNodes.has(c) || this.sharedNodes.set(c, new W8), this.sharedNodes.get(c).add(h);
            const m = h.options.initialPromotionConfig;
            h.promote({
                transition: m ? m.transition : void 0,
                preserveFollowOpacity: m && m.shouldPreserveFollowOpacity ? m.shouldPreserveFollowOpacity(h) : void 0
            })
        }
        isLead() {
            const c = this.getStack();
            return c ? c.lead === this : !0
        }
        getLead() {
            const {
                layoutId: c
            } = this.options;
            return c ? this.getStack() ? .lead || this : this
        }
        getPrevLead() {
            const {
                layoutId: c
            } = this.options;
            return c ? this.getStack() ? .prevLead : void 0
        }
        getStack() {
            const {
                layoutId: c
            } = this.options;
            if (c) return this.root.sharedNodes.get(c)
        }
        promote({
            needsReset: c,
            transition: h,
            preserveFollowOpacity: f
        } = {}) {
            const m = this.getStack();
            m && m.promote(this, f), c && (this.projectionDelta = void 0, this.needsReset = !0), h && this.setOptions({
                transition: h
            })
        }
        relegate() {
            const c = this.getStack();
            return c ? c.relegate(this) : !1
        }
        resetSkewAndRotation() {
            const {
                visualElement: c
            } = this.options;
            if (!c) return;
            let h = !1;
            const {
                latestValues: f
            } = c;
            if ((f.z || f.rotate || f.rotateX || f.rotateY || f.rotateZ || f.skewX || f.skewY) && (h = !0), !h) return;
            const m = {};
            f.z && hd("z", c, m, this.animationValues);
            for (let p = 0; p < dd.length; p++) hd(`rotate${dd[p]}`, c, m, this.animationValues), hd(`skew${dd[p]}`, c, m, this.animationValues);
            c.render();
            for (const p in m) c.setStaticValue(p, m[p]), this.animationValues && (this.animationValues[p] = m[p]);
            c.scheduleRender()
        }
        applyProjectionStyles(c, h) {
            if (!this.instance || this.isSVG) return;
            if (!this.isVisible) {
                c.visibility = "hidden";
                return
            }
            const f = this.getTransformTemplate();
            if (this.needsReset) {
                this.needsReset = !1, c.visibility = "", c.opacity = "", c.pointerEvents = Qo(h ? .pointerEvents) || "", c.transform = f ? f(this.latestValues, "") : "none";
                return
            }
            const m = this.getLead();
            if (!this.projectionDelta || !this.layout || !m.target) {
                this.options.layoutId && (c.opacity = this.latestValues.opacity !== void 0 ? this.latestValues.opacity : 1, c.pointerEvents = Qo(h ? .pointerEvents) || ""), this.hasProjected && !ha(this.latestValues) && (c.transform = f ? f({}, "") : "none", this.hasProjected = !1);
                return
            }
            c.visibility = "";
            const p = m.animationValues || m.latestValues;
            this.applyTransformsToTarget();
            let v = J8(this.projectionDeltaWithTransform, this.treeScale, p);
            f && (v = f(p, v)), c.transform = v;
            const {
                x: b,
                y
            } = this.projectionDelta;
            c.transformOrigin = `${b.origin*100}% ${y.origin*100}% 0`, m.animationValues ? c.opacity = m === this ? p.opacity ? ? this.latestValues.opacity ? ? 1 : this.preserveOpacity ? this.latestValues.opacity : p.opacityExit : c.opacity = m === this ? p.opacity !== void 0 ? p.opacity : "" : p.opacityExit !== void 0 ? p.opacityExit : 0;
            for (const T in fl) {
                if (p[T] === void 0) continue;
                const {
                    correct: S,
                    applyTo: M,
                    isCSSVariable: _
                } = fl[T], w = v === "none" ? p[T] : S(p[T], m);
                if (M) {
                    const C = M.length;
                    for (let L = 0; L < C; L++) c[M[L]] = w
                } else _ ? this.options.visualElement.renderState.vars[T] = w : c[T] = w
            }
            this.options.layoutId && (c.pointerEvents = m === this ? Qo(h ? .pointerEvents) || "" : "none")
        }
        clearSnapshot() {
            this.resumeFrom = this.snapshot = void 0
        }
        resetTree() {
            this.root.nodes.forEach(c => c.currentAnimation ? .stop()), this.root.nodes.forEach(Kv), this.root.sharedNodes.clear()
        }
    }
}

function nE(n) {
    n.updateLayout()
}

function iE(n) {
    const e = n.resumeFrom ? .snapshot || n.snapshot;
    if (n.isLead() && n.layout && e && n.hasListeners("didUpdate")) {
        const {
            layoutBox: a,
            measuredBox: s
        } = n.layout, {
            animationType: l
        } = n.options, o = e.source !== n.layout.source;
        l === "size" ? hn(p => {
            const v = o ? e.measuredBox[p] : e.layoutBox[p],
                b = Et(v);
            v.min = a[p].min, v.max = v.min + b
        }) : Jb(l, e.layoutBox, a) && hn(p => {
            const v = o ? e.measuredBox[p] : e.layoutBox[p],
                b = Et(a[p]);
            v.max = v.min + b, n.relativeTarget && !n.currentAnimation && (n.isProjectionDirty = !0, n.relativeTarget[p].max = n.relativeTarget[p].min + b)
        });
        const c = bs();
        $r(c, a, e.layoutBox);
        const h = bs();
        o ? $r(h, n.applyTransform(s, !0), e.measuredBox) : $r(h, a, e.layoutBox);
        const f = !Qb(c);
        let m = !1;
        if (!n.resumeFrom) {
            const p = n.getClosestProjectingParent();
            if (p && !p.resumeFrom) {
                const {
                    snapshot: v,
                    layout: b
                } = p;
                if (v && b) {
                    const y = $e();
                    Wr(y, e.layoutBox, v.layoutBox);
                    const T = $e();
                    Wr(T, a, b.layoutBox), Ib(y, T) || (m = !0), p.options.layoutRoot && (n.relativeTarget = T, n.relativeTargetOrigin = y, n.relativeParent = p)
                }
            }
        }
        n.notifyListeners("didUpdate", {
            layout: a,
            snapshot: e,
            delta: h,
            layoutDelta: c,
            hasLayoutChanged: f,
            hasRelativeLayoutChanged: m
        })
    } else if (n.isLead()) {
        const {
            onExitComplete: a
        } = n.options;
        a && a()
    }
    n.options.transition = void 0
}

function aE(n) {
    n.parent && (n.isProjecting() || (n.isProjectionDirty = n.parent.isProjectionDirty), n.isSharedProjectionDirty || (n.isSharedProjectionDirty = !!(n.isProjectionDirty || n.parent.isProjectionDirty || n.parent.isSharedProjectionDirty)), n.isTransformDirty || (n.isTransformDirty = n.parent.isTransformDirty))
}

function sE(n) {
    n.isProjectionDirty = n.isSharedProjectionDirty = n.isTransformDirty = !1
}

function rE(n) {
    n.clearSnapshot()
}

function Kv(n) {
    n.clearMeasurements()
}

function Zv(n) {
    n.isLayoutDirty = !1
}

function lE(n) {
    const {
        visualElement: e
    } = n.options;
    e && e.getProps().onBeforeLayoutMeasure && e.notify("BeforeLayoutMeasure"), n.resetTransform()
}

function Qv(n) {
    n.finishAnimation(), n.targetDelta = n.relativeTarget = n.target = void 0, n.isProjectionDirty = !0
}

function oE(n) {
    n.resolveTargetDelta()
}

function uE(n) {
    n.calcProjection()
}

function cE(n) {
    n.resetSkewAndRotation()
}

function fE(n) {
    n.removeLeadSnapshot()
}

function Iv(n, e, a) {
    n.translate = Ye(e.translate, 0, a), n.scale = Ye(e.scale, 1, a), n.origin = e.origin, n.originPoint = e.originPoint
}

function $v(n, e, a, s) {
    n.min = Ye(e.min, a.min, s), n.max = Ye(e.max, a.max, s)
}

function dE(n, e, a, s) {
    $v(n.x, e.x, a.x, s), $v(n.y, e.y, a.y, s)
}

function hE(n) {
    return n.animationValues && n.animationValues.opacityExit !== void 0
}
const mE = {
        duration: .45,
        ease: [.4, 0, .1, 1]
    },
    Wv = n => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(n),
    Jv = Wv("applewebkit/") && !Wv("chrome/") ? Math.round : yn;

function ey(n) {
    n.min = Jv(n.min), n.max = Jv(n.max)
}

function pE(n) {
    ey(n.x), ey(n.y)
}

function Jb(n, e, a) {
    return n === "position" || n === "preserve-aspect" && !S8(Xv(e), Xv(a), .2)
}

function gE(n) {
    return n !== n.root && n.scroll ? .wasRoot
}
const vE = Wb({
        attachResizeListener: (n, e) => dl(n, "resize", e),
        measureScroll: () => ({
            x: document.documentElement.scrollLeft || document.body.scrollLeft,
            y: document.documentElement.scrollTop || document.body.scrollTop
        }),
        checkIsScrollRoot: () => !0
    }),
    md = {
        current: void 0
    },
    ex = Wb({
        measureScroll: n => ({
            x: n.scrollLeft,
            y: n.scrollTop
        }),
        defaultParent: () => {
            if (!md.current) {
                const n = new vE({});
                n.mount(window), n.setOptions({
                    layoutScroll: !0
                }), md.current = n
            }
            return md.current
        },
        resetTransform: (n, e) => {
            n.style.transform = e !== void 0 ? e : "none"
        },
        checkIsScrollRoot: n => window.getComputedStyle(n).position === "fixed"
    }),
    yE = {
        pan: {
            Feature: V8
        },
        drag: {
            Feature: N8,
            ProjectionNode: ex,
            MeasureLayout: Fb
        }
    };

function ty(n, e, a) {
    const {
        props: s
    } = n;
    n.animationState && s.whileHover && n.animationState.setActive("whileHover", a === "Start");
    const l = "onHover" + a,
        o = s[l];
    o && Be.postRender(() => o(e, xl(e)))
}
class bE extends Yi {
    mount() {
        const {
            current: e
        } = this.node;
        e && (this.unmount = X6(e, (a, s) => (ty(this.node, s, "Start"), l => ty(this.node, l, "End"))))
    }
    unmount() {}
}
class xE extends Yi {
    constructor() {
        super(...arguments), this.isActive = !1
    }
    onFocus() {
        let e = !1;
        try {
            e = this.node.current.matches(":focus-visible")
        } catch {
            e = !0
        }!e || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
    }
    onBlur() {
        !this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
    }
    mount() {
        this.unmount = vl(dl(this.node.current, "focus", () => this.onFocus()), dl(this.node.current, "blur", () => this.onBlur()))
    }
    unmount() {}
}

function ny(n, e, a) {
    const {
        props: s
    } = n;
    if (n.current instanceof HTMLButtonElement && n.current.disabled) return;
    n.animationState && s.whileTap && n.animationState.setActive("whileTap", a === "Start");
    const l = "onTap" + (a === "End" ? "" : a),
        o = s[l];
    o && Be.postRender(() => o(e, xl(e)))
}
class SE extends Yi {
    mount() {
        const {
            current: e
        } = this.node;
        e && (this.unmount = Q6(e, (a, s) => (ny(this.node, s, "Start"), (l, {
            success: o
        }) => ny(this.node, l, o ? "End" : "Cancel")), {
            useGlobalTarget: this.node.props.globalTapTarget
        }))
    }
    unmount() {}
}
const uh = new WeakMap,
    pd = new WeakMap,
    TE = n => {
        const e = uh.get(n.target);
        e && e(n)
    },
    _E = n => {
        n.forEach(TE)
    };

function EE({
    root: n,
    ...e
}) {
    const a = n || document;
    pd.has(a) || pd.set(a, {});
    const s = pd.get(a),
        l = JSON.stringify(e);
    return s[l] || (s[l] = new IntersectionObserver(_E, {
        root: n,
        ...e
    })), s[l]
}

function wE(n, e, a) {
    const s = EE(e);
    return uh.set(n, a), s.observe(n), () => {
        uh.delete(n), s.unobserve(n)
    }
}
const ME = {
    some: 0,
    all: 1
};
class AE extends Yi {
    constructor() {
        super(...arguments), this.hasEnteredView = !1, this.isInView = !1
    }
    startObserver() {
        this.unmount();
        const {
            viewport: e = {}
        } = this.node.getProps(), {
            root: a,
            margin: s,
            amount: l = "some",
            once: o
        } = e, c = {
            root: a ? a.current : void 0,
            rootMargin: s,
            threshold: typeof l == "number" ? l : ME[l]
        }, h = f => {
            const {
                isIntersecting: m
            } = f;
            if (this.isInView === m || (this.isInView = m, o && !m && this.hasEnteredView)) return;
            m && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", m);
            const {
                onViewportEnter: p,
                onViewportLeave: v
            } = this.node.getProps(), b = m ? p : v;
            b && b(f)
        };
        return wE(this.node.current, c, h)
    }
    mount() {
        this.startObserver()
    }
    update() {
        if (typeof IntersectionObserver > "u") return;
        const {
            props: e,
            prevProps: a
        } = this.node;
        ["amount", "margin", "root"].some(CE(e, a)) && this.startObserver()
    }
    unmount() {}
}

function CE({
    viewport: n = {}
}, {
    viewport: e = {}
} = {}) {
    return a => n[a] !== e[a]
}
const OE = {
        inView: {
            Feature: AE
        },
        tap: {
            Feature: SE
        },
        focus: {
            Feature: xE
        },
        hover: {
            Feature: bE
        }
    },
    DE = {
        layout: {
            ProjectionNode: ex,
            MeasureLayout: Fb
        }
    },
    zE = { ...p8,
        ...OE,
        ...yE,
        ...DE
    },
    RE = z5(zE, Y5),
    LE = {
        some: 0,
        all: 1
    };

function jE(n, e, {
    root: a,
    margin: s,
    amount: l = "some"
} = {}) {
    const o = ob(n),
        c = new WeakMap,
        h = m => {
            m.forEach(p => {
                const v = c.get(p.target);
                if (p.isIntersecting !== !!v)
                    if (p.isIntersecting) {
                        const b = e(p.target, p);
                        typeof b == "function" ? c.set(p.target, b) : f.unobserve(p.target)
                    } else typeof v == "function" && (v(p), c.delete(p.target))
            })
        },
        f = new IntersectionObserver(h, {
            root: a,
            rootMargin: s,
            threshold: typeof l == "number" ? l : LE[l]
        });
    return o.forEach(m => f.observe(m)), () => f.disconnect()
}

function NE(n, {
    root: e,
    margin: a,
    amount: s,
    once: l = !1,
    initial: o = !1
} = {}) {
    const [c, h] = J.useState(o);
    return J.useEffect(() => {
        if (!n.current || l && c) return;
        const f = () => (h(!0), l ? void 0 : () => h(!1)),
            m = {
                root: e && e.current || void 0,
                margin: a,
                amount: s
            };
        return jE(n.current, f, m)
    }, [e, n, a, l, s]), c
}
const hl = ({
        children: n,
        delay: e = 0
    }) => {
        const a = J.useRef(null),
            s = NE(a, {
                once: !0,
                margin: "-100px"
            });
        return A.jsx(RE.div, {
            ref: a,
            initial: {
                opacity: 0,
                y: 30
            },
            animate: s ? {
                opacity: 1,
                y: 0
            } : {
                opacity: 0,
                y: 30
            },
            transition: {
                duration: .6,
                delay: e
            },
            children: n
        })
    },
    VE = () => {
        const {
            t: n
        } = yu(), e = "gSZIBt1dpXY", a = [{
            icon: A.jsx(Ey, {}),
            label: "Abschluss",
            value: "Staatliches Diplom"
        }, {
            icon: A.jsx(xh, {}),
            label: "Wohnort",
            value: "Fes, Marokko"
        }, {
            icon: A.jsx(E_, {}),
            label: "Bereit ab",
            value: "März 2026"
        }, {
            icon: A.jsx(_y, {}),
            label: "Deutsch",
            value: "B2 Zertifiziert"
        }];
        return A.jsx("section", {
            id: "about",
            className: "min-h-screen py-24 px-6  dark:bg-[#0f172a] transition-colors duration-500 flex items-center",
            children: A.jsx("div", {
                className: "container mx-auto max-w-6xl",
                children: A.jsxs("div", {
                    className: "grid grid-cols-1 lg:grid-cols-2 gap-20 items-start",
                    children: [A.jsx("div", {
                        className: "text-left order-2 lg:order-1",
                        children: A.jsxs(hl, {
                            children: [A.jsxs("div", {
                                className: "flex items-center gap-3 mb-4",
                                children: [A.jsx("span", {
                                    className: "flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/30",
                                    children: "01"
                                }), A.jsx("h2", {
                                    className: "text-xs font-black uppercase tracking-[0.4em] text-emerald-600/80",
                                    children: "Über mich"
                                })]
                            }), A.jsxs("h3", {
                                className: "text-3xl lg:text-4xl font-bold text-slate-900 dark:text-white mb-6 leading-tight",
                                children: ["Engagierte Fachkraft für ", A.jsx("br", {}), A.jsx("span", {
                                    className: "text-emerald-600",
                                    children: "Ihre Einrichtung."
                                })]
                            }), A.jsx("div", {
                                className: "text-lg text-slate-600 dark:text-slate-400 space-y-6 mb-12 max-w-xl border-l-4 border-emerald-500/20 pl-6",
                                children: n.about.bio.map((s, l) => A.jsx("p", {
                                    className: "leading-relaxed font-normal",
                                    children: s
                                }, l))
                            }), A.jsx("div", {
                                className: "grid grid-cols-2 gap-6 pt-8 border-t border-slate-100 dark:border-slate-800",
                                children: a.map((s, l) => A.jsxs("div", {
                                    className: "flex items-center gap-3",
                                    children: [A.jsx("div", {
                                        className: "text-emerald-500 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-900/20 p-2 rounded-lg",
                                        children: s.icon
                                    }), A.jsxs("div", {
                                        children: [A.jsx("p", {
                                            className: "text-[10px] uppercase font-bold tracking-widest text-slate-400",
                                            children: s.label
                                        }), A.jsx("p", {
                                            className: "text-sm font-semibold text-slate-800 dark:text-slate-200",
                                            children: s.value
                                        })]
                                    })]
                                }, l))
                            })]
                        })
                    }), A.jsx("div", {
                        className: "order-1 lg:order-2 sticky top-32",
                        children: A.jsx(hl, {
                            delay: .3,
                            children: A.jsxs("div", {
                                className: "relative",
                                children: [A.jsx("div", {
                                    className: "absolute -top-4 -right-4 z-20 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest px-4 py-2 rounded-lg shadow-lg rotate-3",
                                    children: "Jetzt Ansehen"
                                }), A.jsx("div", {
                                    className: "relative aspect-video overflow-hidden rounded-2xl bg-slate-900 shadow-[0_32px_64px_-15px_rgba(0,0,0,0.3)] dark:shadow-[0_32px_64px_-15px_rgba(0,0,0,0.6)]",
                                    children: A.jsx("iframe", {
                                        className: "w-full h-full",
                                        src: `https://www.youtube.com/embed/${e}?modestbranding=1&rel=0`,
                                        title: "Video Vorstellung",
                                        frameBorder: "0",
                                        allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                                        allowFullScreen: !0
                                    })
                                }), A.jsxs("div", {
                                    className: "mt-6 flex items-start gap-4 p-4 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700",
                                    children: [A.jsx(R_, {
                                        className: "text-slate-400 mt-1 flex-shrink-0"
                                    }), A.jsx("p", {
                                        className: "text-xs text-slate-500 dark:text-slate-400 leading-relaxed italic",
                                        children: "In diesem Video stelle ich mich persönlich auf Deutsch vor und erläutere meine Motivation für die Pflegearbeit in Deutschland."
                                    })]
                                })]
                            })
                        })
                    })]
                })
            })
        })
    },
    kE = [{
        id: "nursing_ma",
        role: "Pflegefachkraft (Staatliches Diplom)",
        company: "Hôpital Universitaire (CHU)",
        location: "Fes, Marokko",
        period: "2022 - 2024",
        desc: "Vollzeitpflege auf der chirurgischen Station. Durchführung von Grund- und Behandlungspflege sowie Wundversorgung.",
        icon: "work"
    }, {
        id: "internship",
        role: "Pflegepraktikum (Geriatrie)",
        company: "Lokale Gesundheitsklinik",
        location: "Fes, Marokko",
        period: "2022 – 2023",
        tasks: ["Unterstützung im Alltag", "Vitalzeichenkontrolle", "Hygiene-Management"]
    }, {
        id: "internship",
        role: "Praktikant in der Altenpflege",
        company: "Privatklinik Atlas",
        location: "Fes, Marokko",
        period: "2021 - 2022",
        desc: "Unterstützung bei der täglichen Mobilisation und Körperpflege von Senioren. Dokumentation nach klinischen Standards.",
        icon: "intern"
    }],
    BE = () => {
        const n = e => {
            switch (e) {
                case "education":
                    return A.jsx(N_, {});
                case "work":
                    return A.jsx(z_, {});
                default:
                    return A.jsx(M_, {})
            }
        };
        return A.jsx("section", {
            id: "experience",
            className: "py-24 px-6 bg-white dark:bg-[#0f172a] transition-colors duration-500",
            children: A.jsxs("div", {
                className: "container mx-auto max-w-5xl",
                children: [A.jsxs("div", {
                    className: "mb-20 border-l-4 border-emerald-500 pl-6",
                    children: [A.jsx("h2", {
                        className: "text-sm font-black uppercase tracking-[0.3em] text-emerald-600 mb-2",
                        children: "Werdegang"
                    }), A.jsxs("h3", {
                        className: "text-4xl font-bold text-slate-900 dark:text-white",
                        children: ["Berufserfahrung & ", A.jsx("span", {
                            className: "text-emerald-600",
                            children: "Ausbildung."
                        })]
                    })]
                }), A.jsxs("div", {
                    className: "relative",
                    children: [A.jsx("div", {
                        className: "absolute left-4 md:left-8 top-0 w-px h-full bg-slate-200 dark:bg-slate-800"
                    }), A.jsx("div", {
                        className: "space-y-12",
                        children: kE.map((e, a) => A.jsx(hl, {
                            delay: a * .1,
                            children: A.jsxs("div", {
                                className: "relative pl-12 md:pl-20 group",
                                children: [A.jsx("div", {
                                    className: "absolute left-0 md:left-4 top-0 w-8 h-8 md:w-10 md:h-10 bg-white dark:bg-slate-900 border-2 border-emerald-500 rounded-full flex items-center justify-center text-emerald-600 z-10 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300 shadow-lg",
                                    children: n(e.icon)
                                }), A.jsxs("div", {
                                    className: "bg-[#f8fafc] dark:bg-slate-800/50 p-6 md:p-8 rounded-[2rem] border border-slate-100 dark:border-slate-700 hover:border-emerald-500/30 hover:shadow-2xl hover:shadow-emerald-500/5 transition-all duration-500",
                                    children: [A.jsxs("div", {
                                        className: "flex flex-col md:flex-row md:items-center justify-between gap-2 mb-4",
                                        children: [A.jsxs("div", {
                                            children: [A.jsx("span", {
                                                className: "inline-block px-3 py-1 bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-400 text-[10px] font-bold uppercase tracking-widest rounded-md mb-2",
                                                children: e.period
                                            }), A.jsx("h4", {
                                                className: "text-xl md:text-2xl font-bold text-slate-800 dark:text-white",
                                                children: e.role
                                            })]
                                        }), A.jsxs("div", {
                                            className: "flex items-center gap-2 text-slate-400 dark:text-slate-500 text-sm",
                                            children: [A.jsx(xh, {}), A.jsx("span", {
                                                children: e.location
                                            })]
                                        })]
                                    }), A.jsxs("p", {
                                        className: "text-emerald-600 dark:text-emerald-400 font-semibold mb-3 flex items-center gap-2",
                                        children: [A.jsx("span", {
                                            className: "w-4 h-px bg-emerald-500"
                                        }), e.company]
                                    }), A.jsx("p", {
                                        className: "text-slate-600 dark:text-slate-400 leading-relaxed font-light",
                                        children: e.desc
                                    })]
                                })]
                            })
                        }, a))
                    })]
                })]
            })
        })
    },
    PE = [{
        id: "b2_cert",
        degree: "TELC Deutsch B2 Zertifikat",
        school: "Sprachakademie / Goethe-Institut Partner",
        year: "2025",
        description: "Nachweis über fortgeschrittene Deutschkenntnisse für den klinischen Bereich.",
        icon: T_
    }, {
        id: "nursing_diploma",
        degree: "Staatliches Diplom: Krankenpflege (Infirmier Polyvalent)",
        school: "ISPITS (Institut Supérieur des Professions Infirmières)",
        year: "2021 - 2024",
        description: "Spezialisierung in allgemeiner Krankenpflege und medizinischer Versorgung.",
        icon: Ey
    }, {
        id: "bac",
        degree: "Baccalauréat (Abitur) - Sciences Physiques",
        school: "Lycée Qualifiant, Fes",
        year: "2021",
        description: "Allgemeine Hochschulreife mit Schwerpunkt Naturwissenschaften.",
        icon: L_
    }],
    UE = () => A.jsx("section", {
        id: "education",
        className: "py-24 px-6 bg-white dark:bg-[#0f172a] transition-colors duration-500",
        children: A.jsxs("div", {
            className: "container mx-auto max-w-5xl",
            children: [A.jsxs("header", {
                className: "mb-20 border-l-4 border-emerald-500 pl-6",
                children: [A.jsx("h2", {
                    className: "text-sm font-black uppercase tracking-[0.4em] text-emerald-600 mb-2",
                    children: "Bildungsweg"
                }), A.jsxs("h3", {
                    className: "text-4xl font-bold text-slate-900 dark:text-white",
                    children: ["Akademische ", A.jsx("span", {
                        className: "text-emerald-600",
                        children: "Qualifikationen."
                    })]
                })]
            }), A.jsxs("div", {
                className: "relative",
                children: [A.jsx("div", {
                    className: "absolute left-6 md:left-10 top-0 w-[2px] h-full bg-slate-100 dark:bg-slate-800"
                }), A.jsx("div", {
                    className: "space-y-12",
                    children: PE.map((n, e) => A.jsx(hl, {
                        delay: e * .1,
                        children: A.jsxs("div", {
                            className: "relative pl-16 md:pl-24",
                            children: [A.jsx("div", {
                                className: "absolute left-0 md:left-4 top-0 w-12 h-12 bg-white dark:bg-slate-900 border-2 border-emerald-500 rounded-2xl flex items-center justify-center z-10 shadow-lg shadow-emerald-500/10 transition-transform hover:rotate-6",
                                children: A.jsx(n.icon, {
                                    className: "text-emerald-600 text-xl"
                                })
                            }), A.jsxs("div", {
                                className: "group relative bg-slate-50 dark:bg-slate-800/40 p-8 rounded-[2rem] border border-transparent hover:border-emerald-500/20 hover:bg-white dark:hover:bg-slate-800 transition-all duration-500",
                                children: [A.jsx("span", {
                                    className: "inline-block px-4 py-1 mb-4 text-[10px] font-black tracking-widest text-emerald-700 uppercase bg-emerald-100 dark:bg-emerald-900/30 rounded-full",
                                    children: n.year
                                }), A.jsx("h4", {
                                    className: "text-2xl font-bold text-slate-900 dark:text-white mb-2 group-hover:text-emerald-600 transition-colors",
                                    children: n.degree
                                }), A.jsx("p", {
                                    className: "text-lg text-emerald-600 dark:text-emerald-400 font-medium mb-4 italic",
                                    children: n.school
                                }), A.jsx("p", {
                                    className: "text-slate-500 dark:text-slate-400 leading-relaxed max-w-2xl",
                                    children: n.description
                                }), A.jsx("div", {
                                    className: "absolute top-8 right-8 opacity-10 group-hover:opacity-30 transition-opacity hidden md:block",
                                    children: A.jsx(S_, {
                                        size: 60,
                                        className: "text-emerald-600"
                                    })
                                })]
                            })]
                        })
                    }, e))
                })]
            })]
        })
    });

function HE(n) {
    return Pe({
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"
            },
            child: []
        }]
    })(n)
}
const GE = {
        hardSkills: [{
            name: "Grundpflege",
            icon: "FaHandHoldingHeart"
        }, {
            name: "Behandlungspflege",
            icon: "FaStethoscope"
        }, {
            name: "Dokumentation",
            icon: "FaFileMedical"
        }, {
            name: "Notfallmanagement",
            icon: "FaFirstAid"
        }],
        softSkills: ["Empathie", "Belastbarkeit", "Teamfähigkeit", "Zuverlässigkeit"],
        languages: [{
            lang: "Deutsch",
            level: "B2 (Zertifiziert)",
            percentage: 80
        }, {
            lang: "Arabisch",
            level: "Muttersprache",
            percentage: 100
        }, {
            lang: "Französisch",
            level: "Fließend",
            percentage: 85
        }]
    },
    qE = () => {
        const {
            hardSkills: n,
            softSkills: e,
            languages: a
        } = GE;
        return A.jsxs("section", {
            id: "skills",
            className: "py-24 px-6 bg-[#fbfcfd] dark:bg-[#0f172a] transition-colors duration-500 overflow-hidden relative",
            children: [A.jsx("div", {
                className: "absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-emerald-500/20 to-transparent"
            }), A.jsxs("div", {
                className: "container mx-auto max-w-6xl",
                children: [A.jsxs("header", {
                    className: "mb-20 text-left lg:flex items-end justify-between gap-4",
                    children: [A.jsxs("div", {
                        className: "max-w-2xl",
                        children: [A.jsxs("div", {
                            className: "flex items-center gap-3 mb-4",
                            children: [A.jsx("span", {
                                className: "flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/30",
                                children: "03"
                            }), A.jsx("h2", {
                                className: "text-xs font-black uppercase tracking-[0.4em] text-emerald-600/80",
                                children: "Qualifikationen"
                            })]
                        }), A.jsxs("h3", {
                            className: "text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white leading-[1.1]",
                            children: ["Technisches Know-how & ", A.jsx("br", {}), A.jsx("span", {
                                className: "text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500",
                                children: "Kommunikationsstärke."
                            })]
                        })]
                    }), A.jsxs("div", {
                        className: "hidden lg:block text-right",
                        children: [A.jsx("p", {
                            className: "text-slate-400 text-sm font-medium tracking-widest uppercase",
                            children: "Expertise & Softskills"
                        }), A.jsx("div", {
                            className: "flex justify-end gap-1 mt-2",
                            children: [...Array(5)].map((s, l) => A.jsx(j_, {
                                className: "text-emerald-500 text-[10px]"
                            }, l))
                        })]
                    })]
                }), A.jsxs("div", {
                    className: "grid grid-cols-1 lg:grid-cols-12 gap-10 items-start",
                    children: [A.jsxs("div", {
                        className: "lg:col-span-8",
                        children: [A.jsxs("div", {
                            className: "flex items-center gap-2 mb-8 group",
                            children: [A.jsx(__, {
                                className: "text-slate-400 group-hover:text-emerald-500 transition-colors"
                            }), A.jsx("h4", {
                                className: "text-xs font-bold uppercase text-slate-400 tracking-widest",
                                children: "Fachliche Qualifikationen"
                            })]
                        }), A.jsx("div", {
                            className: "grid grid-cols-1 md:grid-cols-2 gap-5",
                            children: n ? .map((s, l) => A.jsx(hl, {
                                delay: l * .1,
                                children: A.jsxs("div", {
                                    className: "group relative p-8 bg-white dark:bg-slate-800/50 rounded-3xl border border-slate-200/60 dark:border-slate-700/50 shadow-sm hover:shadow-2xl hover:shadow-emerald-500/10 transition-all duration-500",
                                    children: [A.jsx("div", {
                                        className: "absolute inset-0 border-2 border-emerald-500 opacity-0 group-hover:opacity-100 rounded-3xl transition-opacity pointer-events-none"
                                    }), A.jsxs("div", {
                                        className: "relative z-10",
                                        children: [A.jsx("div", {
                                            className: "inline-flex p-3 rounded-2xl bg-slate-50 dark:bg-slate-700/50 text-emerald-600 dark:text-emerald-400 mb-5 group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300",
                                            children: A.jsx(s.icon, {
                                                size: 24
                                            })
                                        }), A.jsx("h5", {
                                            className: "text-xl font-bold text-slate-800 dark:text-white mb-2",
                                            children: s.name
                                        }), A.jsx("p", {
                                            className: "text-sm text-slate-500 dark:text-slate-400 leading-relaxed",
                                            children: s.desc
                                        })]
                                    })]
                                })
                            }, l))
                        })]
                    }), A.jsxs("aside", {
                        className: "lg:col-span-4 space-y-10",
                        children: [A.jsxs("div", {
                            className: "bg-white dark:bg-slate-800/80 p-8 rounded-[2.5rem] shadow-xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-700",
                            children: [A.jsxs("div", {
                                className: "flex items-center gap-2 mb-8",
                                children: [A.jsx(O_, {
                                    className: "text-emerald-500"
                                }), A.jsx("h4", {
                                    className: "text-xs font-bold uppercase text-slate-400 tracking-widest",
                                    children: "Sprachkenntnisse"
                                })]
                            }), A.jsx("div", {
                                className: "space-y-8",
                                children: a ? .map((s, l) => A.jsxs("div", {
                                    className: "space-y-3",
                                    children: [A.jsxs("div", {
                                        className: "flex justify-between items-center",
                                        children: [A.jsx("span", {
                                            className: "text-sm font-bold text-slate-700 dark:text-slate-200 uppercase tracking-tighter",
                                            children: s.lang
                                        }), A.jsx("span", {
                                            className: "px-2 py-1 rounded bg-emerald-50 dark:bg-emerald-900/30 text-[10px] font-black text-emerald-600",
                                            children: s.level
                                        })]
                                    }), A.jsx("div", {
                                        className: "h-1.5 w-full bg-slate-100 dark:bg-slate-700 rounded-full",
                                        children: A.jsx("div", {
                                            className: "h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full transition-all duration-1000 shadow-[0_0_10px_rgba(16,185,129,0.3)]",
                                            style: {
                                                width: `${s.percentage}%`
                                            }
                                        })
                                    })]
                                }, l))
                            })]
                        }), A.jsxs("div", {
                            className: "relative overflow-hidden bg-slate-900 dark:bg-emerald-950 p-8 rounded-[2.5rem] text-white shadow-2xl",
                            children: [A.jsx("div", {
                                className: "absolute -top-10 -right-10 w-32 h-32 bg-emerald-500/20 rounded-full blur-3xl"
                            }), A.jsx("h4", {
                                className: "relative z-10 text-xs font-bold uppercase text-emerald-500 tracking-widest mb-6",
                                children: "Soft Skills"
                            }), A.jsx("div", {
                                className: "relative z-10 flex flex-wrap gap-2",
                                children: e ? .map((s, l) => A.jsx("span", {
                                    className: "px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-[13px] font-medium transition-colors",
                                    children: s
                                }, l))
                            }), A.jsxs("div", {
                                className: "relative z-10 mt-8 flex items-start gap-3 p-4 bg-emerald-500/10 rounded-2xl border border-emerald-500/20",
                                children: [A.jsx(_y, {
                                    className: "text-emerald-400 mt-1 flex-shrink-0"
                                }), A.jsx("p", {
                                    className: "text-[11px] text-emerald-100/70 italic leading-relaxed",
                                    children: "Bereit für eine verantwortungsvolle Tätigkeit im Schichtdienst und Teamarbeit."
                                })]
                            })]
                        })]
                    })]
                })]
            })]
        })
    },
    YE = () => {
        const {
            email: n,
            social: e
        } = we, a = [{
            id: 1,
            title: "E-Mail",
            value: n,
            icon: A.jsx(bh, {}),
            link: `mailto:${n}`,
            color: "bg-blue-50 text-blue-600 dark:bg-blue-900/20"
        }, {
            id: 2,
            title: "WhatsApp",
            value: "Direktnachricht senden",
            icon: A.jsx(Ty, {}),
            link: e.whatsapp,
            color: "bg-green-50 text-green-600 dark:bg-green-900/20"
        }, {
            id: 3,
            title: "LinkedIn",
            value: "Berufliches Profil",
            icon: A.jsx(yh, {}),
            link: e.linkedin,
            color: "bg-slate-50 text-slate-700 dark:bg-slate-900/20 dark:text-slate-300"
        }];
        return A.jsx("section", {
            id: "contact",
            className: "py-24 px-6 bg-white dark:bg-[#0f172a] transition-colors duration-500",
            children: A.jsxs("div", {
                className: "container mx-auto max-w-5xl",
                children: [A.jsxs("div", {
                    className: "text-center mb-16",
                    children: [A.jsx("h2", {
                        className: "text-sm font-black uppercase tracking-[0.4em] text-emerald-600 mb-4",
                        children: "Kontakt"
                    }), A.jsxs("h3", {
                        className: "text-4xl md:text-5xl font-bold text-slate-900 dark:text-white mb-6",
                        children: ["Lassen Sie uns ", A.jsx("span", {
                            className: "text-emerald-600",
                            children: "verbinden."
                        })]
                    }), A.jsx("p", {
                        className: "text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed",
                        children: "Ich bin bereit für neue Herausforderungen in Deutschland. Kontaktieren Sie mich direkt über einen der folgenden Kanäle für ein Erstgespräch."
                    })]
                }), A.jsx("div", {
                    className: "grid grid-cols-1 md:grid-cols-3 gap-6 mb-12",
                    children: a.map(s => A.jsxs("a", {
                        href: s.link,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        className: "group p-8 bg-slate-50 dark:bg-slate-800/40 rounded-[2rem] border border-transparent hover:border-emerald-500/30 hover:bg-white dark:hover:bg-slate-800 transition-all duration-500 shadow-sm hover:shadow-2xl text-center",
                        children: [A.jsx("div", {
                            className: `inline-flex p-4 rounded-2xl ${s.color} text-2xl mb-6 group-hover:scale-110 transition-transform duration-300`,
                            children: s.icon
                        }), A.jsx("h4", {
                            className: "text-lg font-bold text-slate-900 dark:text-white mb-2",
                            children: s.title
                        }), A.jsx("p", {
                            className: "text-sm text-slate-500 dark:text-slate-400 font-medium",
                            children: s.value
                        })]
                    }, s.id))
                }), A.jsxs("div", {
                    className: "flex flex-col md:flex-row items-center justify-center gap-8 p-8 bg-emerald-600 rounded-[2.5rem] text-white shadow-xl shadow-emerald-900/20 overflow-hidden relative",
                    children: [A.jsx("div", {
                        className: "absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none",
                        style: {
                            backgroundImage: "radial-gradient(circle at 2px 2px, white 1px, transparent 0)",
                            backgroundSize: "24px 24px"
                        }
                    }), A.jsxs("div", {
                        className: "relative z-10 flex items-center gap-3",
                        children: [A.jsx(xh, {
                            className: "text-emerald-200"
                        }), A.jsx("span", {
                            className: "font-bold tracking-wide uppercase text-sm",
                            children: "Standort: Fes, Marokko"
                        })]
                    }), A.jsx("div", {
                        className: "hidden md:block h-8 w-[1px] bg-emerald-400/50 relative z-10"
                    }), A.jsxs("div", {
                        className: "relative z-10 flex items-center gap-3",
                        children: [A.jsxs("div", {
                            className: "flex h-3 w-3 relative",
                            children: [A.jsx("span", {
                                className: "animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"
                            }), A.jsx("span", {
                                className: "relative inline-flex rounded-full h-3 w-3 bg-white"
                            })]
                        }), A.jsx("span", {
                            className: "font-bold tracking-wide uppercase text-sm italic",
                            children: "Bereit für Visum & Umzug"
                        })]
                    })]
                })]
            })
        })
    },
    XE = () => {
        const {
            t: n
        } = yu();
        return A.jsx("footer", {
            className: "bg-white dark:bg-gray-800 py-12 px-6 border-t border-gray-200 dark:border-gray-700",
            children: A.jsxs("div", {
                className: "container mx-auto max-w-6xl",
                children: [A.jsxs("div", {
                    className: "flex flex-col md:flex-row md:justify-between md:items-center gap-8",
                    children: [A.jsxs("div", {
                        className: "flex justify-center md:justify-start gap-6 text-lg",
                        children: [we.social.github && A.jsx("a", {
                            href: we.social.github,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition transform hover:scale-110",
                            "aria-label": "GitHub",
                            children: A.jsx(x_, {})
                        }), A.jsx("a", {
                            href: we.social.linkedin,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition transform hover:scale-110",
                            "aria-label": "LinkedIn",
                            children: A.jsx(yh, {})
                        }), we.social.twitter && A.jsx("a", {
                            href: we.social.twitter,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition transform hover:scale-110",
                            "aria-label": "Twitter",
                            children: A.jsx(HE, {})
                        }), we.social.discord && A.jsx("a", {
                            href: we.social.discord,
                            target: "_blank",
                            rel: "noopener noreferrer",
                            className: "text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition transform hover:scale-110",
                            "aria-label": "Discord",
                            children: A.jsx(b_, {})
                        }), A.jsx("a", {
                            href: `mailto:${we.email}`,
                            className: "text-gray-600 dark:text-gray-400 hover:text-blue-600 dark:hover:text-blue-400 transition transform hover:scale-110",
                            "aria-label": "Email",
                            children: A.jsx(bh, {})
                        })]
                    }), A.jsx("div", {
                        children: A.jsxs("a", {
                            href: "#hero",
                            className: `inline-flex items-center gap-2 px-4 py-2 text-blue-600 dark:text-blue-400 hover:text-white
                        hover:bg-blue-600 dark:hover:bg-blue-800 rounded-lg transition-all duration-300 group`,
                            children: [A.jsx(D_, {
                                className: "text-lg group-hover:scale-110 transition-transform"
                            }), A.jsx("span", {
                                className: "font-medium",
                                children: n.nav.home
                            })]
                        })
                    })]
                }), A.jsx("div", {
                    className: "mt-8 pt-8 border-t border-gray-200 dark:border-gray-700 text-center",
                    children: A.jsxs("p", {
                        className: "text-sm text-gray-600 dark:text-gray-400 mt-1",
                        children: ["© ", new Date().getFullYear(), " - ", n.footer.rights]
                    })
                })]
            })
        })
    };

function iy(n) {
    return n !== null && typeof n == "object" && "constructor" in n && n.constructor === Object
}

function vm(n = {}, e = {}) {
    const a = ["__proto__", "constructor", "prototype"];
    Object.keys(e).filter(s => a.indexOf(s) < 0).forEach(s => {
        typeof n[s] > "u" ? n[s] = e[s] : iy(e[s]) && iy(n[s]) && Object.keys(e[s]).length > 0 && vm(n[s], e[s])
    })
}
const tx = {
    body: {},
    addEventListener() {},
    removeEventListener() {},
    activeElement: {
        blur() {},
        nodeName: ""
    },
    querySelector() {
        return null
    },
    querySelectorAll() {
        return []
    },
    getElementById() {
        return null
    },
    createEvent() {
        return {
            initEvent() {}
        }
    },
    createElement() {
        return {
            children: [],
            childNodes: [],
            style: {},
            setAttribute() {},
            getElementsByTagName() {
                return []
            }
        }
    },
    createElementNS() {
        return {}
    },
    importNode() {
        return null
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    }
};

function Vn() {
    const n = typeof document < "u" ? document : {};
    return vm(n, tx), n
}
const FE = {
    document: tx,
    navigator: {
        userAgent: ""
    },
    location: {
        hash: "",
        host: "",
        hostname: "",
        href: "",
        origin: "",
        pathname: "",
        protocol: "",
        search: ""
    },
    history: {
        replaceState() {},
        pushState() {},
        go() {},
        back() {}
    },
    CustomEvent: function() {
        return this
    },
    addEventListener() {},
    removeEventListener() {},
    getComputedStyle() {
        return {
            getPropertyValue() {
                return ""
            }
        }
    },
    Image() {},
    Date() {},
    screen: {},
    setTimeout() {},
    clearTimeout() {},
    matchMedia() {
        return {}
    },
    requestAnimationFrame(n) {
        return typeof setTimeout > "u" ? (n(), null) : setTimeout(n, 0)
    },
    cancelAnimationFrame(n) {
        typeof setTimeout > "u" || clearTimeout(n)
    }
};

function wt() {
    const n = typeof window < "u" ? window : {};
    return vm(n, FE), n
}

function KE(n = "") {
    return n.trim().split(" ").filter(e => !!e.trim())
}

function ZE(n) {
    const e = n;
    Object.keys(e).forEach(a => {
        try {
            e[a] = null
        } catch {}
        try {
            delete e[a]
        } catch {}
    })
}

function nx(n, e = 0) {
    return setTimeout(n, e)
}

function hu() {
    return Date.now()
}

function QE(n) {
    const e = wt();
    let a;
    return e.getComputedStyle && (a = e.getComputedStyle(n, null)), !a && n.currentStyle && (a = n.currentStyle), a || (a = n.style), a
}

function IE(n, e = "x") {
    const a = wt();
    let s, l, o;
    const c = QE(n);
    return a.WebKitCSSMatrix ? (l = c.transform || c.webkitTransform, l.split(",").length > 6 && (l = l.split(", ").map(h => h.replace(",", ".")).join(", ")), o = new a.WebKitCSSMatrix(l === "none" ? "" : l)) : (o = c.MozTransform || c.OTransform || c.MsTransform || c.msTransform || c.transform || c.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,"), s = o.toString().split(",")), e === "x" && (a.WebKitCSSMatrix ? l = o.m41 : s.length === 16 ? l = parseFloat(s[12]) : l = parseFloat(s[4])), e === "y" && (a.WebKitCSSMatrix ? l = o.m42 : s.length === 16 ? l = parseFloat(s[13]) : l = parseFloat(s[5])), l || 0
}

function Ho(n) {
    return typeof n == "object" && n !== null && n.constructor && Object.prototype.toString.call(n).slice(8, -1) === "Object"
}

function $E(n) {
    return typeof window < "u" && typeof window.HTMLElement < "u" ? n instanceof HTMLElement : n && (n.nodeType === 1 || n.nodeType === 11)
}

function Zt(...n) {
    const e = Object(n[0]),
        a = ["__proto__", "constructor", "prototype"];
    for (let s = 1; s < n.length; s += 1) {
        const l = n[s];
        if (l != null && !$E(l)) {
            const o = Object.keys(Object(l)).filter(c => a.indexOf(c) < 0);
            for (let c = 0, h = o.length; c < h; c += 1) {
                const f = o[c],
                    m = Object.getOwnPropertyDescriptor(l, f);
                m !== void 0 && m.enumerable && (Ho(e[f]) && Ho(l[f]) ? l[f].__swiper__ ? e[f] = l[f] : Zt(e[f], l[f]) : !Ho(e[f]) && Ho(l[f]) ? (e[f] = {}, l[f].__swiper__ ? e[f] = l[f] : Zt(e[f], l[f])) : e[f] = l[f])
            }
        }
    }
    return e
}

function fs(n, e, a) {
    n.style.setProperty(e, a)
}

function ix({
    swiper: n,
    targetPosition: e,
    side: a
}) {
    const s = wt(),
        l = -n.translate;
    let o = null,
        c;
    const h = n.params.speed;
    n.wrapperEl.style.scrollSnapType = "none", s.cancelAnimationFrame(n.cssModeFrameID);
    const f = e > l ? "next" : "prev",
        m = (v, b) => f === "next" && v >= b || f === "prev" && v <= b,
        p = () => {
            c = new Date().getTime(), o === null && (o = c);
            const v = Math.max(Math.min((c - o) / h, 1), 0),
                b = .5 - Math.cos(v * Math.PI) / 2;
            let y = l + b * (e - l);
            if (m(y, e) && (y = e), n.wrapperEl.scrollTo({
                    [a]: y
                }), m(y, e)) {
                n.wrapperEl.style.overflow = "hidden", n.wrapperEl.style.scrollSnapType = "", setTimeout(() => {
                    n.wrapperEl.style.overflow = "", n.wrapperEl.scrollTo({
                        [a]: y
                    })
                }), s.cancelAnimationFrame(n.cssModeFrameID);
                return
            }
            n.cssModeFrameID = s.requestAnimationFrame(p)
        };
    p()
}

function ym(n) {
    return n.querySelector(".swiper-slide-transform") || n.shadowRoot && n.shadowRoot.querySelector(".swiper-slide-transform") || n
}

function Ln(n, e = "") {
    const a = wt(),
        s = [...n.children];
    return a.HTMLSlotElement && n instanceof HTMLSlotElement && s.push(...n.assignedElements()), e ? s.filter(l => l.matches(e)) : s
}

function WE(n, e) {
    const a = [e];
    for (; a.length > 0;) {
        const s = a.shift();
        if (n === s) return !0;
        a.push(...s.children, ...s.shadowRoot ? s.shadowRoot.children : [], ...s.assignedElements ? s.assignedElements() : [])
    }
}

function JE(n, e) {
    const a = wt();
    let s = e.contains(n);
    return !s && a.HTMLSlotElement && e instanceof HTMLSlotElement && (s = [...e.assignedElements()].includes(n), s || (s = WE(n, e))), s
}

function mu(n) {
    try {
        console.warn(n);
        return
    } catch {}
}

function ml(n, e = []) {
    const a = document.createElement(n);
    return a.classList.add(...Array.isArray(e) ? e : KE(e)), a
}

function ew(n, e) {
    const a = [];
    for (; n.previousElementSibling;) {
        const s = n.previousElementSibling;
        e ? s.matches(e) && a.push(s) : a.push(s), n = s
    }
    return a
}

function tw(n, e) {
    const a = [];
    for (; n.nextElementSibling;) {
        const s = n.nextElementSibling;
        e ? s.matches(e) && a.push(s) : a.push(s), n = s
    }
    return a
}

function Ni(n, e) {
    return wt().getComputedStyle(n, null).getPropertyValue(e)
}

function pu(n) {
    let e = n,
        a;
    if (e) {
        for (a = 0;
            (e = e.previousSibling) !== null;) e.nodeType === 1 && (a += 1);
        return a
    }
}

function ax(n, e) {
    const a = [];
    let s = n.parentElement;
    for (; s;) e ? s.matches(e) && a.push(s) : a.push(s), s = s.parentElement;
    return a
}

function ch(n, e, a) {
    const s = wt();
    return n[e === "width" ? "offsetWidth" : "offsetHeight"] + parseFloat(s.getComputedStyle(n, null).getPropertyValue(e === "width" ? "margin-right" : "margin-top")) + parseFloat(s.getComputedStyle(n, null).getPropertyValue(e === "width" ? "margin-left" : "margin-bottom"))
}

function ut(n) {
    return (Array.isArray(n) ? n : [n]).filter(e => !!e)
}

function nw(n) {
    return e => Math.abs(e) > 0 && n.browser && n.browser.need3dFix && Math.abs(e) % 90 === 0 ? e + .001 : e
}

function pl(n, e = "") {
    typeof trustedTypes < "u" ? n.innerHTML = trustedTypes.createPolicy("html", {
        createHTML: a => a
    }).createHTML(e) : n.innerHTML = e
}
let gd;

function iw() {
    const n = wt(),
        e = Vn();
    return {
        smoothScroll: e.documentElement && e.documentElement.style && "scrollBehavior" in e.documentElement.style,
        touch: !!("ontouchstart" in n || n.DocumentTouch && e instanceof n.DocumentTouch)
    }
}

function sx() {
    return gd || (gd = iw()), gd
}
let vd;

function aw({
    userAgent: n
} = {}) {
    const e = sx(),
        a = wt(),
        s = a.navigator.platform,
        l = n || a.navigator.userAgent,
        o = {
            ios: !1,
            android: !1
        },
        c = a.screen.width,
        h = a.screen.height,
        f = l.match(/(Android);?[\s\/]+([\d.]+)?/);
    let m = l.match(/(iPad)(?!\1).*OS\s([\d_]+)/);
    const p = l.match(/(iPod)(.*OS\s([\d_]+))?/),
        v = !m && l.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
        b = s === "Win32";
    let y = s === "MacIntel";
    const T = ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"];
    return !m && y && e.touch && T.indexOf(`${c}x${h}`) >= 0 && (m = l.match(/(Version)\/([\d.]+)/), m || (m = [0, 1, "13_0_0"]), y = !1), f && !b && (o.os = "android", o.android = !0), (m || v || p) && (o.os = "ios", o.ios = !0), o
}

function rx(n = {}) {
    return vd || (vd = aw(n)), vd
}
let yd;

function sw() {
    const n = wt(),
        e = rx();
    let a = !1;

    function s() {
        const h = n.navigator.userAgent.toLowerCase();
        return h.indexOf("safari") >= 0 && h.indexOf("chrome") < 0 && h.indexOf("android") < 0
    }
    if (s()) {
        const h = String(n.navigator.userAgent);
        if (h.includes("Version/")) {
            const [f, m] = h.split("Version/")[1].split(" ")[0].split(".").map(p => Number(p));
            a = f < 16 || f === 16 && m < 2
        }
    }
    const l = /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(n.navigator.userAgent),
        o = s(),
        c = o || l && e.ios;
    return {
        isSafari: a || o,
        needPerspectiveFix: a,
        need3dFix: c,
        isWebView: l
    }
}

function lx() {
    return yd || (yd = sw()), yd
}

function rw({
    swiper: n,
    on: e,
    emit: a
}) {
    const s = wt();
    let l = null,
        o = null;
    const c = () => {
            !n || n.destroyed || !n.initialized || (a("beforeResize"), a("resize"))
        },
        h = () => {
            !n || n.destroyed || !n.initialized || (l = new ResizeObserver(p => {
                o = s.requestAnimationFrame(() => {
                    const {
                        width: v,
                        height: b
                    } = n;
                    let y = v,
                        T = b;
                    p.forEach(({
                        contentBoxSize: S,
                        contentRect: M,
                        target: _
                    }) => {
                        _ && _ !== n.el || (y = M ? M.width : (S[0] || S).inlineSize, T = M ? M.height : (S[0] || S).blockSize)
                    }), (y !== v || T !== b) && c()
                })
            }), l.observe(n.el))
        },
        f = () => {
            o && s.cancelAnimationFrame(o), l && l.unobserve && n.el && (l.unobserve(n.el), l = null)
        },
        m = () => {
            !n || n.destroyed || !n.initialized || a("orientationchange")
        };
    e("init", () => {
        if (n.params.resizeObserver && typeof s.ResizeObserver < "u") {
            h();
            return
        }
        s.addEventListener("resize", c), s.addEventListener("orientationchange", m)
    }), e("destroy", () => {
        f(), s.removeEventListener("resize", c), s.removeEventListener("orientationchange", m)
    })
}

function lw({
    swiper: n,
    extendParams: e,
    on: a,
    emit: s
}) {
    const l = [],
        o = wt(),
        c = (m, p = {}) => {
            const v = o.MutationObserver || o.WebkitMutationObserver,
                b = new v(y => {
                    if (n.__preventObserver__) return;
                    if (y.length === 1) {
                        s("observerUpdate", y[0]);
                        return
                    }
                    const T = function() {
                        s("observerUpdate", y[0])
                    };
                    o.requestAnimationFrame ? o.requestAnimationFrame(T) : o.setTimeout(T, 0)
                });
            b.observe(m, {
                attributes: typeof p.attributes > "u" ? !0 : p.attributes,
                childList: n.isElement || (typeof p.childList > "u" ? !0 : p).childList,
                characterData: typeof p.characterData > "u" ? !0 : p.characterData
            }), l.push(b)
        },
        h = () => {
            if (n.params.observer) {
                if (n.params.observeParents) {
                    const m = ax(n.hostEl);
                    for (let p = 0; p < m.length; p += 1) c(m[p])
                }
                c(n.hostEl, {
                    childList: n.params.observeSlideChildren
                }), c(n.wrapperEl, {
                    attributes: !1
                })
            }
        },
        f = () => {
            l.forEach(m => {
                m.disconnect()
            }), l.splice(0, l.length)
        };
    e({
        observer: !1,
        observeParents: !1,
        observeSlideChildren: !1
    }), a("init", h), a("destroy", f)
}
var ow = {
    on(n, e, a) {
        const s = this;
        if (!s.eventsListeners || s.destroyed || typeof e != "function") return s;
        const l = a ? "unshift" : "push";
        return n.split(" ").forEach(o => {
            s.eventsListeners[o] || (s.eventsListeners[o] = []), s.eventsListeners[o][l](e)
        }), s
    },
    once(n, e, a) {
        const s = this;
        if (!s.eventsListeners || s.destroyed || typeof e != "function") return s;

        function l(...o) {
            s.off(n, l), l.__emitterProxy && delete l.__emitterProxy, e.apply(s, o)
        }
        return l.__emitterProxy = e, s.on(n, l, a)
    },
    onAny(n, e) {
        const a = this;
        if (!a.eventsListeners || a.destroyed || typeof n != "function") return a;
        const s = e ? "unshift" : "push";
        return a.eventsAnyListeners.indexOf(n) < 0 && a.eventsAnyListeners[s](n), a
    },
    offAny(n) {
        const e = this;
        if (!e.eventsListeners || e.destroyed || !e.eventsAnyListeners) return e;
        const a = e.eventsAnyListeners.indexOf(n);
        return a >= 0 && e.eventsAnyListeners.splice(a, 1), e
    },
    off(n, e) {
        const a = this;
        return !a.eventsListeners || a.destroyed || !a.eventsListeners || n.split(" ").forEach(s => {
            typeof e > "u" ? a.eventsListeners[s] = [] : a.eventsListeners[s] && a.eventsListeners[s].forEach((l, o) => {
                (l === e || l.__emitterProxy && l.__emitterProxy === e) && a.eventsListeners[s].splice(o, 1)
            })
        }), a
    },
    emit(...n) {
        const e = this;
        if (!e.eventsListeners || e.destroyed || !e.eventsListeners) return e;
        let a, s, l;
        return typeof n[0] == "string" || Array.isArray(n[0]) ? (a = n[0], s = n.slice(1, n.length), l = e) : (a = n[0].events, s = n[0].data, l = n[0].context || e), s.unshift(l), (Array.isArray(a) ? a : a.split(" ")).forEach(c => {
            e.eventsAnyListeners && e.eventsAnyListeners.length && e.eventsAnyListeners.forEach(h => {
                h.apply(l, [c, ...s])
            }), e.eventsListeners && e.eventsListeners[c] && e.eventsListeners[c].forEach(h => {
                h.apply(l, s)
            })
        }), e
    }
};

function uw() {
    const n = this;
    let e, a;
    const s = n.el;
    typeof n.params.width < "u" && n.params.width !== null ? e = n.params.width : e = s.clientWidth, typeof n.params.height < "u" && n.params.height !== null ? a = n.params.height : a = s.clientHeight, !(e === 0 && n.isHorizontal() || a === 0 && n.isVertical()) && (e = e - parseInt(Ni(s, "padding-left") || 0, 10) - parseInt(Ni(s, "padding-right") || 0, 10), a = a - parseInt(Ni(s, "padding-top") || 0, 10) - parseInt(Ni(s, "padding-bottom") || 0, 10), Number.isNaN(e) && (e = 0), Number.isNaN(a) && (a = 0), Object.assign(n, {
        width: e,
        height: a,
        size: n.isHorizontal() ? e : a
    }))
}

function cw() {
    const n = this;

    function e(F, I) {
        return parseFloat(F.getPropertyValue(n.getDirectionLabel(I)) || 0)
    }
    const a = n.params,
        {
            wrapperEl: s,
            slidesEl: l,
            rtlTranslate: o,
            wrongRTL: c
        } = n,
        h = n.virtual && a.virtual.enabled,
        f = h ? n.virtual.slides.length : n.slides.length,
        m = Ln(l, `.${n.params.slideClass}, swiper-slide`),
        p = h ? n.virtual.slides.length : m.length;
    let v = [];
    const b = [],
        y = [];
    let T = a.slidesOffsetBefore;
    typeof T == "function" && (T = a.slidesOffsetBefore.call(n));
    let S = a.slidesOffsetAfter;
    typeof S == "function" && (S = a.slidesOffsetAfter.call(n));
    const M = n.snapGrid.length,
        _ = n.slidesGrid.length,
        w = n.size - T - S;
    let C = a.spaceBetween,
        L = -T,
        O = 0,
        V = 0;
    if (typeof w > "u") return;
    typeof C == "string" && C.indexOf("%") >= 0 ? C = parseFloat(C.replace("%", "")) / 100 * w : typeof C == "string" && (C = parseFloat(C)), n.virtualSize = -C - T - S, m.forEach(F => {
        o ? F.style.marginLeft = "" : F.style.marginRight = "", F.style.marginBottom = "", F.style.marginTop = ""
    }), a.centeredSlides && a.cssMode && (fs(s, "--swiper-centered-offset-before", ""), fs(s, "--swiper-centered-offset-after", "")), a.cssMode && (fs(s, "--swiper-slides-offset-before", `${T}px`), fs(s, "--swiper-slides-offset-after", `${S}px`));
    const k = a.grid && a.grid.rows > 1 && n.grid;
    k ? n.grid.initSlides(m) : n.grid && n.grid.unsetSlides();
    let D;
    const H = a.slidesPerView === "auto" && a.breakpoints && Object.keys(a.breakpoints).filter(F => typeof a.breakpoints[F].slidesPerView < "u").length > 0;
    for (let F = 0; F < p; F += 1) {
        D = 0;
        const I = m[F];
        if (!(I && (k && n.grid.updateSlide(F, I, m), Ni(I, "display") === "none"))) {
            if (h && a.slidesPerView === "auto") a.virtual.slidesPerViewAutoSlideSize && (D = a.virtual.slidesPerViewAutoSlideSize), D && I && (a.roundLengths && (D = Math.floor(D)), I.style[n.getDirectionLabel("width")] = `${D}px`);
            else if (a.slidesPerView === "auto") {
                H && (I.style[n.getDirectionLabel("width")] = "");
                const W = getComputedStyle(I),
                    ee = I.style.transform,
                    ae = I.style.webkitTransform;
                if (ee && (I.style.transform = "none"), ae && (I.style.webkitTransform = "none"), a.roundLengths) D = n.isHorizontal() ? ch(I, "width") : ch(I, "height");
                else {
                    const se = e(W, "width"),
                        P = e(W, "padding-left"),
                        G = e(W, "padding-right"),
                        X = e(W, "margin-left"),
                        te = e(W, "margin-right"),
                        z = W.getPropertyValue("box-sizing");
                    if (z && z === "border-box") D = se + X + te;
                    else {
                        const {
                            clientWidth: Z,
                            offsetWidth: ne
                        } = I;
                        D = se + P + G + X + te + (ne - Z)
                    }
                }
                ee && (I.style.transform = ee), ae && (I.style.webkitTransform = ae), a.roundLengths && (D = Math.floor(D))
            } else D = (w - (a.slidesPerView - 1) * C) / a.slidesPerView, a.roundLengths && (D = Math.floor(D)), I && (I.style[n.getDirectionLabel("width")] = `${D}px`);
            I && (I.swiperSlideSize = D), y.push(D), a.centeredSlides ? (L = L + D / 2 + O / 2 + C, O === 0 && F !== 0 && (L = L - w / 2 - C), F === 0 && (L = L - w / 2 - C), Math.abs(L) < 1 / 1e3 && (L = 0), a.roundLengths && (L = Math.floor(L)), V % a.slidesPerGroup === 0 && v.push(L), b.push(L)) : (a.roundLengths && (L = Math.floor(L)), (V - Math.min(n.params.slidesPerGroupSkip, V)) % n.params.slidesPerGroup === 0 && v.push(L), b.push(L), L = L + D + C), n.virtualSize += D + C, O = D, V += 1
        }
    }
    if (n.virtualSize = Math.max(n.virtualSize, w) + S, o && c && (a.effect === "slide" || a.effect === "coverflow") && (s.style.width = `${n.virtualSize+C}px`), a.setWrapperSize && (s.style[n.getDirectionLabel("width")] = `${n.virtualSize+C}px`), k && n.grid.updateWrapperSize(D, v), !a.centeredSlides) {
        const F = a.slidesPerView !== "auto" && a.slidesPerView % 1 !== 0,
            I = a.snapToSlideEdge && !a.loop && (a.slidesPerView === "auto" || F);
        let W = v.length;
        if (I) {
            let ae;
            if (a.slidesPerView === "auto") {
                ae = 1;
                let se = 0;
                for (let P = y.length - 1; P >= 0 && (se += y[P] + (P < y.length - 1 ? C : 0), se <= w); P -= 1) ae = y.length - P
            } else ae = Math.floor(a.slidesPerView);
            W = Math.max(p - ae, 0)
        }
        const ee = [];
        for (let ae = 0; ae < v.length; ae += 1) {
            let se = v[ae];
            a.roundLengths && (se = Math.floor(se)), I ? ae <= W && ee.push(se) : v[ae] <= n.virtualSize - w && ee.push(se)
        }
        v = ee, Math.floor(n.virtualSize - w) - Math.floor(v[v.length - 1]) > 1 && (I || v.push(n.virtualSize - w))
    }
    if (h && a.loop) {
        const F = y[0] + C;
        if (a.slidesPerGroup > 1) {
            const I = Math.ceil((n.virtual.slidesBefore + n.virtual.slidesAfter) / a.slidesPerGroup),
                W = F * a.slidesPerGroup;
            for (let ee = 0; ee < I; ee += 1) v.push(v[v.length - 1] + W)
        }
        for (let I = 0; I < n.virtual.slidesBefore + n.virtual.slidesAfter; I += 1) a.slidesPerGroup === 1 && v.push(v[v.length - 1] + F), b.push(b[b.length - 1] + F), n.virtualSize += F
    }
    if (v.length === 0 && (v = [0]), C !== 0) {
        const F = n.isHorizontal() && o ? "marginLeft" : n.getDirectionLabel("marginRight");
        m.filter((I, W) => !a.cssMode || a.loop ? !0 : W !== m.length - 1).forEach(I => {
            I.style[F] = `${C}px`
        })
    }
    if (a.centeredSlides && a.centeredSlidesBounds) {
        let F = 0;
        y.forEach(W => {
            F += W + (C || 0)
        }), F -= C;
        const I = F > w ? F - w : 0;
        v = v.map(W => W <= 0 ? -T : W > I ? I + S : W)
    }
    if (a.centerInsufficientSlides) {
        let F = 0;
        y.forEach(W => {
            F += W + (C || 0)
        }), F -= C;
        const I = (T || 0) + (S || 0);
        if (F + I < w) {
            const W = (w - F - I) / 2;
            v.forEach((ee, ae) => {
                v[ae] = ee - W
            }), b.forEach((ee, ae) => {
                b[ae] = ee + W
            })
        }
    }
    if (Object.assign(n, {
            slides: m,
            snapGrid: v,
            slidesGrid: b,
            slidesSizesGrid: y
        }), a.centeredSlides && a.cssMode && !a.centeredSlidesBounds) {
        fs(s, "--swiper-centered-offset-before", `${-v[0]}px`), fs(s, "--swiper-centered-offset-after", `${n.size/2-y[y.length-1]/2}px`);
        const F = -n.snapGrid[0],
            I = -n.slidesGrid[0];
        n.snapGrid = n.snapGrid.map(W => W + F), n.slidesGrid = n.slidesGrid.map(W => W + I)
    }
    if (p !== f && n.emit("slidesLengthChange"), v.length !== M && (n.params.watchOverflow && n.checkOverflow(), n.emit("snapGridLengthChange")), b.length !== _ && n.emit("slidesGridLengthChange"), a.watchSlidesProgress && n.updateSlidesOffset(), n.emit("slidesUpdated"), !h && !a.cssMode && (a.effect === "slide" || a.effect === "fade")) {
        const F = `${a.containerModifierClass}backface-hidden`,
            I = n.el.classList.contains(F);
        p <= a.maxBackfaceHiddenSlides ? I || n.el.classList.add(F) : I && n.el.classList.remove(F)
    }
}

function fw(n) {
    const e = this,
        a = [],
        s = e.virtual && e.params.virtual.enabled;
    let l = 0,
        o;
    typeof n == "number" ? e.setTransition(n) : n === !0 && e.setTransition(e.params.speed);
    const c = h => s ? e.slides[e.getSlideIndexByData(h)] : e.slides[h];
    if (e.params.slidesPerView !== "auto" && e.params.slidesPerView > 1)
        if (e.params.centeredSlides)(e.visibleSlides || []).forEach(h => {
            a.push(h)
        });
        else
            for (o = 0; o < Math.ceil(e.params.slidesPerView); o += 1) {
                const h = e.activeIndex + o;
                if (h > e.slides.length && !s) break;
                a.push(c(h))
            } else a.push(c(e.activeIndex));
    for (o = 0; o < a.length; o += 1)
        if (typeof a[o] < "u") {
            const h = a[o].offsetHeight;
            l = h > l ? h : l
        }(l || l === 0) && (e.wrapperEl.style.height = `${l}px`)
}

function dw() {
    const n = this,
        e = n.slides,
        a = n.isElement ? n.isHorizontal() ? n.wrapperEl.offsetLeft : n.wrapperEl.offsetTop : 0;
    for (let s = 0; s < e.length; s += 1) e[s].swiperSlideOffset = (n.isHorizontal() ? e[s].offsetLeft : e[s].offsetTop) - a - n.cssOverflowAdjustment()
}
const ay = (n, e, a) => {
    e && !n.classList.contains(a) ? n.classList.add(a) : !e && n.classList.contains(a) && n.classList.remove(a)
};

function hw(n = this && this.translate || 0) {
    const e = this,
        a = e.params,
        {
            slides: s,
            rtlTranslate: l,
            snapGrid: o
        } = e;
    if (s.length === 0) return;
    typeof s[0].swiperSlideOffset > "u" && e.updateSlidesOffset();
    let c = -n;
    l && (c = n), e.visibleSlidesIndexes = [], e.visibleSlides = [];
    let h = a.spaceBetween;
    typeof h == "string" && h.indexOf("%") >= 0 ? h = parseFloat(h.replace("%", "")) / 100 * e.size : typeof h == "string" && (h = parseFloat(h));
    for (let f = 0; f < s.length; f += 1) {
        const m = s[f];
        let p = m.swiperSlideOffset;
        a.cssMode && a.centeredSlides && (p -= s[0].swiperSlideOffset);
        const v = (c + (a.centeredSlides ? e.minTranslate() : 0) - p) / (m.swiperSlideSize + h),
            b = (c - o[0] + (a.centeredSlides ? e.minTranslate() : 0) - p) / (m.swiperSlideSize + h),
            y = -(c - p),
            T = y + e.slidesSizesGrid[f],
            S = y >= 0 && y <= e.size - e.slidesSizesGrid[f],
            M = y >= 0 && y < e.size - 1 || T > 1 && T <= e.size || y <= 0 && T >= e.size;
        M && (e.visibleSlides.push(m), e.visibleSlidesIndexes.push(f)), ay(m, M, a.slideVisibleClass), ay(m, S, a.slideFullyVisibleClass), m.progress = l ? -v : v, m.originalProgress = l ? -b : b
    }
}

function mw(n) {
    const e = this;
    if (typeof n > "u") {
        const p = e.rtlTranslate ? -1 : 1;
        n = e && e.translate && e.translate * p || 0
    }
    const a = e.params,
        s = e.maxTranslate() - e.minTranslate();
    let {
        progress: l,
        isBeginning: o,
        isEnd: c,
        progressLoop: h
    } = e;
    const f = o,
        m = c;
    if (s === 0) l = 0, o = !0, c = !0;
    else {
        l = (n - e.minTranslate()) / s;
        const p = Math.abs(n - e.minTranslate()) < 1,
            v = Math.abs(n - e.maxTranslate()) < 1;
        o = p || l <= 0, c = v || l >= 1, p && (l = 0), v && (l = 1)
    }
    if (a.loop) {
        const p = e.getSlideIndexByData(0),
            v = e.getSlideIndexByData(e.slides.length - 1),
            b = e.slidesGrid[p],
            y = e.slidesGrid[v],
            T = e.slidesGrid[e.slidesGrid.length - 1],
            S = Math.abs(n);
        S >= b ? h = (S - b) / T : h = (S + T - y) / T, h > 1 && (h -= 1)
    }
    Object.assign(e, {
        progress: l,
        progressLoop: h,
        isBeginning: o,
        isEnd: c
    }), (a.watchSlidesProgress || a.centeredSlides && a.autoHeight) && e.updateSlidesProgress(n), o && !f && e.emit("reachBeginning toEdge"), c && !m && e.emit("reachEnd toEdge"), (f && !o || m && !c) && e.emit("fromEdge"), e.emit("progress", l)
}
const bd = (n, e, a) => {
    e && !n.classList.contains(a) ? n.classList.add(a) : !e && n.classList.contains(a) && n.classList.remove(a)
};

function pw() {
    const n = this,
        {
            slides: e,
            params: a,
            slidesEl: s,
            activeIndex: l
        } = n,
        o = n.virtual && a.virtual.enabled,
        c = n.grid && a.grid && a.grid.rows > 1,
        h = v => Ln(s, `.${a.slideClass}${v}, swiper-slide${v}`)[0];
    let f, m, p;
    if (o)
        if (a.loop) {
            let v = l - n.virtual.slidesBefore;
            v < 0 && (v = n.virtual.slides.length + v), v >= n.virtual.slides.length && (v -= n.virtual.slides.length), f = h(`[data-swiper-slide-index="${v}"]`)
        } else f = h(`[data-swiper-slide-index="${l}"]`);
    else c ? (f = e.find(v => v.column === l), p = e.find(v => v.column === l + 1), m = e.find(v => v.column === l - 1)) : f = e[l];
    f && (c || (p = tw(f, `.${a.slideClass}, swiper-slide`)[0], a.loop && !p && (p = e[0]), m = ew(f, `.${a.slideClass}, swiper-slide`)[0], a.loop && !m === 0 && (m = e[e.length - 1]))), e.forEach(v => {
        bd(v, v === f, a.slideActiveClass), bd(v, v === p, a.slideNextClass), bd(v, v === m, a.slidePrevClass)
    }), n.emitSlidesClasses()
}
const $o = (n, e) => {
        if (!n || n.destroyed || !n.params) return;
        const a = () => n.isElement ? "swiper-slide" : `.${n.params.slideClass}`,
            s = e.closest(a());
        if (s) {
            let l = s.querySelector(`.${n.params.lazyPreloaderClass}`);
            !l && n.isElement && (s.shadowRoot ? l = s.shadowRoot.querySelector(`.${n.params.lazyPreloaderClass}`) : requestAnimationFrame(() => {
                s.shadowRoot && (l = s.shadowRoot.querySelector(`.${n.params.lazyPreloaderClass}`), l && !l.lazyPreloaderManaged && l.remove())
            })), l && !l.lazyPreloaderManaged && l.remove()
        }
    },
    xd = (n, e) => {
        if (!n.slides[e]) return;
        const a = n.slides[e].querySelector('[loading="lazy"]');
        a && a.removeAttribute("loading")
    },
    fh = n => {
        if (!n || n.destroyed || !n.params) return;
        let e = n.params.lazyPreloadPrevNext;
        const a = n.slides.length;
        if (!a || !e || e < 0) return;
        e = Math.min(e, a);
        const s = n.params.slidesPerView === "auto" ? n.slidesPerViewDynamic() : Math.ceil(n.params.slidesPerView),
            l = n.activeIndex;
        if (n.params.grid && n.params.grid.rows > 1) {
            const c = l,
                h = [c - e];
            h.push(...Array.from({
                length: e
            }).map((f, m) => c + s + m)), n.slides.forEach((f, m) => {
                h.includes(f.column) && xd(n, m)
            });
            return
        }
        const o = l + s - 1;
        if (n.params.rewind || n.params.loop)
            for (let c = l - e; c <= o + e; c += 1) {
                const h = (c % a + a) % a;
                (h < l || h > o) && xd(n, h)
            } else
                for (let c = Math.max(l - e, 0); c <= Math.min(o + e, a - 1); c += 1) c !== l && (c > o || c < l) && xd(n, c)
    };

function gw(n) {
    const {
        slidesGrid: e,
        params: a
    } = n, s = n.rtlTranslate ? n.translate : -n.translate;
    let l;
    for (let o = 0; o < e.length; o += 1) typeof e[o + 1] < "u" ? s >= e[o] && s < e[o + 1] - (e[o + 1] - e[o]) / 2 ? l = o : s >= e[o] && s < e[o + 1] && (l = o + 1) : s >= e[o] && (l = o);
    return a.normalizeSlideIndex && (l < 0 || typeof l > "u") && (l = 0), l
}

function vw(n) {
    const e = this,
        a = e.rtlTranslate ? e.translate : -e.translate,
        {
            snapGrid: s,
            params: l,
            activeIndex: o,
            realIndex: c,
            snapIndex: h
        } = e;
    let f = n,
        m;
    const p = y => {
        let T = y - e.virtual.slidesBefore;
        return T < 0 && (T = e.virtual.slides.length + T), T >= e.virtual.slides.length && (T -= e.virtual.slides.length), T
    };
    if (typeof f > "u" && (f = gw(e)), s.indexOf(a) >= 0) m = s.indexOf(a);
    else {
        const y = Math.min(l.slidesPerGroupSkip, f);
        m = y + Math.floor((f - y) / l.slidesPerGroup)
    }
    if (m >= s.length && (m = s.length - 1), f === o && !e.params.loop) {
        m !== h && (e.snapIndex = m, e.emit("snapIndexChange"));
        return
    }
    if (f === o && e.params.loop && e.virtual && e.params.virtual.enabled) {
        e.realIndex = p(f);
        return
    }
    const v = e.grid && l.grid && l.grid.rows > 1;
    let b;
    if (e.virtual && l.virtual.enabled) l.loop ? b = p(f) : b = f;
    else if (v) {
        const y = e.slides.find(S => S.column === f);
        let T = parseInt(y.getAttribute("data-swiper-slide-index"), 10);
        Number.isNaN(T) && (T = Math.max(e.slides.indexOf(y), 0)), b = Math.floor(T / l.grid.rows)
    } else if (e.slides[f]) {
        const y = e.slides[f].getAttribute("data-swiper-slide-index");
        y ? b = parseInt(y, 10) : b = f
    } else b = f;
    Object.assign(e, {
        previousSnapIndex: h,
        snapIndex: m,
        previousRealIndex: c,
        realIndex: b,
        previousIndex: o,
        activeIndex: f
    }), e.initialized && fh(e), e.emit("activeIndexChange"), e.emit("snapIndexChange"), (e.initialized || e.params.runCallbacksOnInit) && (c !== b && e.emit("realIndexChange"), e.emit("slideChange"))
}

function yw(n, e) {
    const a = this,
        s = a.params;
    let l = n.closest(`.${s.slideClass}, swiper-slide`);
    !l && a.isElement && e && e.length > 1 && e.includes(n) && [...e.slice(e.indexOf(n) + 1, e.length)].forEach(h => {
        !l && h.matches && h.matches(`.${s.slideClass}, swiper-slide`) && (l = h)
    });
    let o = !1,
        c;
    if (l) {
        for (let h = 0; h < a.slides.length; h += 1)
            if (a.slides[h] === l) {
                o = !0, c = h;
                break
            }
    }
    if (l && o) a.clickedSlide = l, a.virtual && a.params.virtual.enabled ? a.clickedIndex = parseInt(l.getAttribute("data-swiper-slide-index"), 10) : a.clickedIndex = c;
    else {
        a.clickedSlide = void 0, a.clickedIndex = void 0;
        return
    }
    s.slideToClickedSlide && a.clickedIndex !== void 0 && a.clickedIndex !== a.activeIndex && a.slideToClickedSlide()
}
var bw = {
    updateSize: uw,
    updateSlides: cw,
    updateAutoHeight: fw,
    updateSlidesOffset: dw,
    updateSlidesProgress: hw,
    updateProgress: mw,
    updateSlidesClasses: pw,
    updateActiveIndex: vw,
    updateClickedSlide: yw
};

function xw(n = this.isHorizontal() ? "x" : "y") {
    const e = this,
        {
            params: a,
            rtlTranslate: s,
            translate: l,
            wrapperEl: o
        } = e;
    if (a.virtualTranslate) return s ? -l : l;
    if (a.cssMode) return l;
    let c = IE(o, n);
    return c += e.cssOverflowAdjustment(), s && (c = -c), c || 0
}

function Sw(n, e) {
    const a = this,
        {
            rtlTranslate: s,
            params: l,
            wrapperEl: o,
            progress: c
        } = a;
    let h = 0,
        f = 0;
    const m = 0;
    a.isHorizontal() ? h = s ? -n : n : f = n, l.roundLengths && (h = Math.floor(h), f = Math.floor(f)), a.previousTranslate = a.translate, a.translate = a.isHorizontal() ? h : f, l.cssMode ? o[a.isHorizontal() ? "scrollLeft" : "scrollTop"] = a.isHorizontal() ? -h : -f : l.virtualTranslate || (a.isHorizontal() ? h -= a.cssOverflowAdjustment() : f -= a.cssOverflowAdjustment(), o.style.transform = `translate3d(${h}px, ${f}px, ${m}px)`);
    let p;
    const v = a.maxTranslate() - a.minTranslate();
    v === 0 ? p = 0 : p = (n - a.minTranslate()) / v, p !== c && a.updateProgress(n), a.emit("setTranslate", a.translate, e)
}

function Tw() {
    return -this.snapGrid[0]
}

function _w() {
    return -this.snapGrid[this.snapGrid.length - 1]
}

function Ew(n = 0, e = this.params.speed, a = !0, s = !0, l) {
    const o = this,
        {
            params: c,
            wrapperEl: h
        } = o;
    if (o.animating && c.preventInteractionOnTransition) return !1;
    const f = o.minTranslate(),
        m = o.maxTranslate();
    let p;
    if (s && n > f ? p = f : s && n < m ? p = m : p = n, o.updateProgress(p), c.cssMode) {
        const v = o.isHorizontal();
        if (e === 0) h[v ? "scrollLeft" : "scrollTop"] = -p;
        else {
            if (!o.support.smoothScroll) return ix({
                swiper: o,
                targetPosition: -p,
                side: v ? "left" : "top"
            }), !0;
            h.scrollTo({
                [v ? "left" : "top"]: -p,
                behavior: "smooth"
            })
        }
        return !0
    }
    return e === 0 ? (o.setTransition(0), o.setTranslate(p), a && (o.emit("beforeTransitionStart", e, l), o.emit("transitionEnd"))) : (o.setTransition(e), o.setTranslate(p), a && (o.emit("beforeTransitionStart", e, l), o.emit("transitionStart")), o.animating || (o.animating = !0, o.onTranslateToWrapperTransitionEnd || (o.onTranslateToWrapperTransitionEnd = function(b) {
        !o || o.destroyed || b.target === this && (o.wrapperEl.removeEventListener("transitionend", o.onTranslateToWrapperTransitionEnd), o.onTranslateToWrapperTransitionEnd = null, delete o.onTranslateToWrapperTransitionEnd, o.animating = !1, a && o.emit("transitionEnd"))
    }), o.wrapperEl.addEventListener("transitionend", o.onTranslateToWrapperTransitionEnd))), !0
}
var ww = {
    getTranslate: xw,
    setTranslate: Sw,
    minTranslate: Tw,
    maxTranslate: _w,
    translateTo: Ew
};

function Mw(n, e) {
    const a = this;
    a.params.cssMode || (a.wrapperEl.style.transitionDuration = `${n}ms`, a.wrapperEl.style.transitionDelay = n === 0 ? "0ms" : ""), a.emit("setTransition", n, e)
}

function ox({
    swiper: n,
    runCallbacks: e,
    direction: a,
    step: s
}) {
    const {
        activeIndex: l,
        previousIndex: o
    } = n;
    let c = a;
    c || (l > o ? c = "next" : l < o ? c = "prev" : c = "reset"), n.emit(`transition${s}`), e && c === "reset" ? n.emit(`slideResetTransition${s}`) : e && l !== o && (n.emit(`slideChangeTransition${s}`), c === "next" ? n.emit(`slideNextTransition${s}`) : n.emit(`slidePrevTransition${s}`))
}

function Aw(n = !0, e) {
    const a = this,
        {
            params: s
        } = a;
    s.cssMode || (s.autoHeight && a.updateAutoHeight(), ox({
        swiper: a,
        runCallbacks: n,
        direction: e,
        step: "Start"
    }))
}

function Cw(n = !0, e) {
    const a = this,
        {
            params: s
        } = a;
    a.animating = !1, !s.cssMode && (a.setTransition(0), ox({
        swiper: a,
        runCallbacks: n,
        direction: e,
        step: "End"
    }))
}
var Ow = {
    setTransition: Mw,
    transitionStart: Aw,
    transitionEnd: Cw
};

function Dw(n = 0, e, a = !0, s, l) {
    typeof n == "string" && (n = parseInt(n, 10));
    const o = this;
    let c = n;
    c < 0 && (c = 0);
    const {
        params: h,
        snapGrid: f,
        slidesGrid: m,
        previousIndex: p,
        activeIndex: v,
        rtlTranslate: b,
        wrapperEl: y,
        enabled: T
    } = o;
    if (!T && !s && !l || o.destroyed || o.animating && h.preventInteractionOnTransition) return !1;
    typeof e > "u" && (e = o.params.speed);
    const S = Math.min(o.params.slidesPerGroupSkip, c);
    let M = S + Math.floor((c - S) / o.params.slidesPerGroup);
    M >= f.length && (M = f.length - 1);
    const _ = -f[M];
    if (h.normalizeSlideIndex)
        for (let k = 0; k < m.length; k += 1) {
            const D = -Math.floor(_ * 100),
                H = Math.floor(m[k] * 100),
                F = Math.floor(m[k + 1] * 100);
            typeof m[k + 1] < "u" ? D >= H && D < F - (F - H) / 2 ? c = k : D >= H && D < F && (c = k + 1) : D >= H && (c = k)
        }
    if (o.initialized && c !== v && (!o.allowSlideNext && (b ? _ > o.translate && _ > o.minTranslate() : _ < o.translate && _ < o.minTranslate()) || !o.allowSlidePrev && _ > o.translate && _ > o.maxTranslate() && (v || 0) !== c)) return !1;
    c !== (p || 0) && a && o.emit("beforeSlideChangeStart"), o.updateProgress(_);
    let w;
    c > v ? w = "next" : c < v ? w = "prev" : w = "reset";
    const C = o.virtual && o.params.virtual.enabled;
    if (!(C && l) && (b && -_ === o.translate || !b && _ === o.translate)) return o.updateActiveIndex(c), h.autoHeight && o.updateAutoHeight(), o.updateSlidesClasses(), h.effect !== "slide" && o.setTranslate(_), w !== "reset" && (o.transitionStart(a, w), o.transitionEnd(a, w)), !1;
    if (h.cssMode) {
        const k = o.isHorizontal(),
            D = b ? _ : -_;
        if (e === 0) C && (o.wrapperEl.style.scrollSnapType = "none", o._immediateVirtual = !0), C && !o._cssModeVirtualInitialSet && o.params.initialSlide > 0 ? (o._cssModeVirtualInitialSet = !0, requestAnimationFrame(() => {
            y[k ? "scrollLeft" : "scrollTop"] = D
        })) : y[k ? "scrollLeft" : "scrollTop"] = D, C && requestAnimationFrame(() => {
            o.wrapperEl.style.scrollSnapType = "", o._immediateVirtual = !1
        });
        else {
            if (!o.support.smoothScroll) return ix({
                swiper: o,
                targetPosition: D,
                side: k ? "left" : "top"
            }), !0;
            y.scrollTo({
                [k ? "left" : "top"]: D,
                behavior: "smooth"
            })
        }
        return !0
    }
    const V = lx().isSafari;
    return C && !l && V && o.isElement && o.virtual.update(!1, !1, c), o.setTransition(e), o.setTranslate(_), o.updateActiveIndex(c), o.updateSlidesClasses(), o.emit("beforeTransitionStart", e, s), o.transitionStart(a, w), e === 0 ? o.transitionEnd(a, w) : o.animating || (o.animating = !0, o.onSlideToWrapperTransitionEnd || (o.onSlideToWrapperTransitionEnd = function(D) {
        !o || o.destroyed || D.target === this && (o.wrapperEl.removeEventListener("transitionend", o.onSlideToWrapperTransitionEnd), o.onSlideToWrapperTransitionEnd = null, delete o.onSlideToWrapperTransitionEnd, o.transitionEnd(a, w))
    }), o.wrapperEl.addEventListener("transitionend", o.onSlideToWrapperTransitionEnd)), !0
}

function zw(n = 0, e, a = !0, s) {
    typeof n == "string" && (n = parseInt(n, 10));
    const l = this;
    if (l.destroyed) return;
    typeof e > "u" && (e = l.params.speed);
    const o = l.grid && l.params.grid && l.params.grid.rows > 1;
    let c = n;
    if (l.params.loop)
        if (l.virtual && l.params.virtual.enabled) c = c + l.virtual.slidesBefore;
        else {
            let h;
            if (o) {
                const S = c * l.params.grid.rows;
                h = l.slides.find(M => M.getAttribute("data-swiper-slide-index") * 1 === S).column
            } else h = l.getSlideIndexByData(c);
            const f = o ? Math.ceil(l.slides.length / l.params.grid.rows) : l.slides.length,
                {
                    centeredSlides: m,
                    slidesOffsetBefore: p,
                    slidesOffsetAfter: v
                } = l.params,
                b = m || !!p || !!v;
            let y = l.params.slidesPerView;
            y === "auto" ? y = l.slidesPerViewDynamic() : (y = Math.ceil(parseFloat(l.params.slidesPerView, 10)), b && y % 2 === 0 && (y = y + 1));
            let T = f - h < y;
            if (b && (T = T || h < Math.ceil(y / 2)), s && b && l.params.slidesPerView !== "auto" && !o && (T = !1), T) {
                const S = b ? h < l.activeIndex ? "prev" : "next" : h - l.activeIndex - 1 < l.params.slidesPerView ? "next" : "prev";
                l.loopFix({
                    direction: S,
                    slideTo: !0,
                    activeSlideIndex: S === "next" ? h + 1 : h - f + 1,
                    slideRealIndex: S === "next" ? l.realIndex : void 0
                })
            }
            if (o) {
                const S = c * l.params.grid.rows;
                c = l.slides.find(M => M.getAttribute("data-swiper-slide-index") * 1 === S).column
            } else c = l.getSlideIndexByData(c)
        }
    return requestAnimationFrame(() => {
        l.slideTo(c, e, a, s)
    }), l
}

function Rw(n, e = !0, a) {
    const s = this,
        {
            enabled: l,
            params: o,
            animating: c
        } = s;
    if (!l || s.destroyed) return s;
    typeof n > "u" && (n = s.params.speed);
    let h = o.slidesPerGroup;
    o.slidesPerView === "auto" && o.slidesPerGroup === 1 && o.slidesPerGroupAuto && (h = Math.max(s.slidesPerViewDynamic("current", !0), 1));
    const f = s.activeIndex < o.slidesPerGroupSkip ? 1 : h,
        m = s.virtual && o.virtual.enabled;
    if (o.loop) {
        if (c && !m && o.loopPreventsSliding) return !1;
        if (s.loopFix({
                direction: "next"
            }), s._clientLeft = s.wrapperEl.clientLeft, s.activeIndex === s.slides.length - 1 && o.cssMode) return requestAnimationFrame(() => {
            s.slideTo(s.activeIndex + f, n, e, a)
        }), !0
    }
    return o.rewind && s.isEnd ? s.slideTo(0, n, e, a) : s.slideTo(s.activeIndex + f, n, e, a)
}

function Lw(n, e = !0, a) {
    const s = this,
        {
            params: l,
            snapGrid: o,
            slidesGrid: c,
            rtlTranslate: h,
            enabled: f,
            animating: m
        } = s;
    if (!f || s.destroyed) return s;
    typeof n > "u" && (n = s.params.speed);
    const p = s.virtual && l.virtual.enabled;
    if (l.loop) {
        if (m && !p && l.loopPreventsSliding) return !1;
        s.loopFix({
            direction: "prev"
        }), s._clientLeft = s.wrapperEl.clientLeft
    }
    const v = h ? s.translate : -s.translate;

    function b(w) {
        return w < 0 ? -Math.floor(Math.abs(w)) : Math.floor(w)
    }
    const y = b(v),
        T = o.map(w => b(w)),
        S = l.freeMode && l.freeMode.enabled;
    let M = o[T.indexOf(y) - 1];
    if (typeof M > "u" && (l.cssMode || S)) {
        let w;
        o.forEach((C, L) => {
            y >= C && (w = L)
        }), typeof w < "u" && (M = S ? o[w] : o[w > 0 ? w - 1 : w])
    }
    let _ = 0;
    if (typeof M < "u" && (_ = c.indexOf(M), _ < 0 && (_ = s.activeIndex - 1), l.slidesPerView === "auto" && l.slidesPerGroup === 1 && l.slidesPerGroupAuto && (_ = _ - s.slidesPerViewDynamic("previous", !0) + 1, _ = Math.max(_, 0))), l.rewind && s.isBeginning) {
        const w = s.params.virtual && s.params.virtual.enabled && s.virtual ? s.virtual.slides.length - 1 : s.slides.length - 1;
        return s.slideTo(w, n, e, a)
    } else if (l.loop && s.activeIndex === 0 && l.cssMode) return requestAnimationFrame(() => {
        s.slideTo(_, n, e, a)
    }), !0;
    return s.slideTo(_, n, e, a)
}

function jw(n, e = !0, a) {
    const s = this;
    if (!s.destroyed) return typeof n > "u" && (n = s.params.speed), s.slideTo(s.activeIndex, n, e, a)
}

function Nw(n, e = !0, a, s = .5) {
    const l = this;
    if (l.destroyed) return;
    typeof n > "u" && (n = l.params.speed);
    let o = l.activeIndex;
    const c = Math.min(l.params.slidesPerGroupSkip, o),
        h = c + Math.floor((o - c) / l.params.slidesPerGroup),
        f = l.rtlTranslate ? l.translate : -l.translate;
    if (f >= l.snapGrid[h]) {
        const m = l.snapGrid[h],
            p = l.snapGrid[h + 1];
        f - m > (p - m) * s && (o += l.params.slidesPerGroup)
    } else {
        const m = l.snapGrid[h - 1],
            p = l.snapGrid[h];
        f - m <= (p - m) * s && (o -= l.params.slidesPerGroup)
    }
    return o = Math.max(o, 0), o = Math.min(o, l.slidesGrid.length - 1), l.slideTo(o, n, e, a)
}

function Vw() {
    const n = this;
    if (n.destroyed) return;
    const {
        params: e,
        slidesEl: a
    } = n, s = e.slidesPerView === "auto" ? n.slidesPerViewDynamic() : e.slidesPerView;
    let l = n.getSlideIndexWhenGrid(n.clickedIndex),
        o;
    const c = n.isElement ? "swiper-slide" : `.${e.slideClass}`,
        h = n.grid && n.params.grid && n.params.grid.rows > 1;
    if (e.loop) {
        if (n.animating) return;
        o = parseInt(n.clickedSlide.getAttribute("data-swiper-slide-index"), 10), e.centeredSlides ? n.slideToLoop(o) : l > (h ? (n.slides.length - s) / 2 - (n.params.grid.rows - 1) : n.slides.length - s) ? (n.loopFix(), l = n.getSlideIndex(Ln(a, `${c}[data-swiper-slide-index="${o}"]`)[0]), nx(() => {
            n.slideTo(l)
        })) : n.slideTo(l)
    } else n.slideTo(l)
}
var kw = {
    slideTo: Dw,
    slideToLoop: zw,
    slideNext: Rw,
    slidePrev: Lw,
    slideReset: jw,
    slideToClosest: Nw,
    slideToClickedSlide: Vw
};

function Bw(n, e) {
    const a = this,
        {
            params: s,
            slidesEl: l
        } = a;
    if (!s.loop || a.virtual && a.params.virtual.enabled) return;
    const o = () => {
            Ln(l, `.${s.slideClass}, swiper-slide`).forEach((T, S) => {
                T.setAttribute("data-swiper-slide-index", S)
            })
        },
        c = () => {
            const y = Ln(l, `.${s.slideBlankClass}`);
            y.forEach(T => {
                T.remove()
            }), y.length > 0 && (a.recalcSlides(), a.updateSlides())
        },
        h = a.grid && s.grid && s.grid.rows > 1;
    s.loopAddBlankSlides && (s.slidesPerGroup > 1 || h) && c();
    const f = s.slidesPerGroup * (h ? s.grid.rows : 1),
        m = a.slides.length % f !== 0,
        p = h && a.slides.length % s.grid.rows !== 0,
        v = y => {
            for (let T = 0; T < y; T += 1) {
                const S = a.isElement ? ml("swiper-slide", [s.slideBlankClass]) : ml("div", [s.slideClass, s.slideBlankClass]);
                a.slidesEl.append(S)
            }
        };
    if (m) {
        if (s.loopAddBlankSlides) {
            const y = f - a.slides.length % f;
            v(y), a.recalcSlides(), a.updateSlides()
        } else mu("Swiper Loop Warning: The number of slides is not even to slidesPerGroup, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)");
        o()
    } else if (p) {
        if (s.loopAddBlankSlides) {
            const y = s.grid.rows - a.slides.length % s.grid.rows;
            v(y), a.recalcSlides(), a.updateSlides()
        } else mu("Swiper Loop Warning: The number of slides is not even to grid.rows, loop mode may not function properly. You need to add more slides (or make duplicates, or empty slides)");
        o()
    } else o();
    const b = s.centeredSlides || !!s.slidesOffsetBefore || !!s.slidesOffsetAfter;
    a.loopFix({
        slideRealIndex: n,
        direction: b ? void 0 : "next",
        initial: e
    })
}

function Pw({
    slideRealIndex: n,
    slideTo: e = !0,
    direction: a,
    setTranslate: s,
    activeSlideIndex: l,
    initial: o,
    byController: c,
    byMousewheel: h
} = {}) {
    const f = this;
    if (!f.params.loop) return;
    f.emit("beforeLoopFix");
    const {
        slides: m,
        allowSlidePrev: p,
        allowSlideNext: v,
        slidesEl: b,
        params: y
    } = f, {
        centeredSlides: T,
        slidesOffsetBefore: S,
        slidesOffsetAfter: M,
        initialSlide: _
    } = y, w = T || !!S || !!M;
    if (f.allowSlidePrev = !0, f.allowSlideNext = !0, f.virtual && y.virtual.enabled) {
        e && (!w && f.snapIndex === 0 ? f.slideTo(f.virtual.slides.length, 0, !1, !0) : w && f.snapIndex < y.slidesPerView ? f.slideTo(f.virtual.slides.length + f.snapIndex, 0, !1, !0) : f.snapIndex === f.snapGrid.length - 1 && f.slideTo(f.virtual.slidesBefore, 0, !1, !0)), f.allowSlidePrev = p, f.allowSlideNext = v, f.emit("loopFix");
        return
    }
    let C = y.slidesPerView;
    C === "auto" ? C = f.slidesPerViewDynamic() : (C = Math.ceil(parseFloat(y.slidesPerView, 10)), w && C % 2 === 0 && (C = C + 1));
    const L = y.slidesPerGroupAuto ? C : y.slidesPerGroup;
    let O = w ? Math.max(L, Math.ceil(C / 2)) : L;
    O % L !== 0 && (O += L - O % L), O += y.loopAdditionalSlides, f.loopedSlides = O;
    const V = f.grid && y.grid && y.grid.rows > 1;
    m.length < C + O || f.params.effect === "cards" && m.length < C + O * 2 ? mu("Swiper Loop Warning: The number of slides is not enough for loop mode, it will be disabled or not function properly. You need to add more slides (or make duplicates) or lower the values of slidesPerView and slidesPerGroup parameters") : V && y.grid.fill === "row" && mu("Swiper Loop Warning: Loop mode is not compatible with grid.fill = `row`");
    const k = [],
        D = [],
        H = V ? Math.ceil(m.length / y.grid.rows) : m.length,
        F = o && H - _ < C && !w;
    let I = F ? _ : f.activeIndex;
    typeof l > "u" ? l = f.getSlideIndex(m.find(X => X.classList.contains(y.slideActiveClass))) : I = l;
    const W = a === "next" || !a,
        ee = a === "prev" || !a;
    let ae = 0,
        se = 0;
    const G = (V ? m[l].column : l) + (w && typeof s > "u" ? -C / 2 + .5 : 0);
    if (G < O) {
        ae = Math.max(O - G, L);
        for (let X = 0; X < O - G; X += 1) {
            const te = X - Math.floor(X / H) * H;
            if (V) {
                const z = H - te - 1;
                for (let Z = m.length - 1; Z >= 0; Z -= 1) m[Z].column === z && k.push(Z)
            } else k.push(H - te - 1)
        }
    } else if (G + C > H - O) {
        se = Math.max(G - (H - O * 2), L), F && (se = Math.max(se, C - H + _ + 1));
        for (let X = 0; X < se; X += 1) {
            const te = X - Math.floor(X / H) * H;
            V ? m.forEach((z, Z) => {
                z.column === te && D.push(Z)
            }) : D.push(te)
        }
    }
    if (f.__preventObserver__ = !0, requestAnimationFrame(() => {
            f.__preventObserver__ = !1
        }), f.params.effect === "cards" && m.length < C + O * 2 && (D.includes(l) && D.splice(D.indexOf(l), 1), k.includes(l) && k.splice(k.indexOf(l), 1)), ee && k.forEach(X => {
            m[X].swiperLoopMoveDOM = !0, b.prepend(m[X]), m[X].swiperLoopMoveDOM = !1
        }), W && D.forEach(X => {
            m[X].swiperLoopMoveDOM = !0, b.append(m[X]), m[X].swiperLoopMoveDOM = !1
        }), f.recalcSlides(), y.slidesPerView === "auto" ? f.updateSlides() : V && (k.length > 0 && ee || D.length > 0 && W) && f.slides.forEach((X, te) => {
            f.grid.updateSlide(te, X, f.slides)
        }), y.watchSlidesProgress && f.updateSlidesOffset(), e) {
        if (k.length > 0 && ee) {
            if (typeof n > "u") {
                const X = f.slidesGrid[I],
                    z = f.slidesGrid[I + ae] - X;
                h ? f.setTranslate(f.translate - z) : (f.slideTo(I + Math.ceil(ae), 0, !1, !0), s && (f.touchEventsData.startTranslate = f.touchEventsData.startTranslate - z, f.touchEventsData.currentTranslate = f.touchEventsData.currentTranslate - z))
            } else if (s) {
                const X = V ? k.length / y.grid.rows : k.length;
                f.slideTo(f.activeIndex + X, 0, !1, !0), f.touchEventsData.currentTranslate = f.translate
            }
        } else if (D.length > 0 && W)
            if (typeof n > "u") {
                const X = f.slidesGrid[I],
                    z = f.slidesGrid[I - se] - X;
                h ? f.setTranslate(f.translate - z) : (f.slideTo(I - se, 0, !1, !0), s && (f.touchEventsData.startTranslate = f.touchEventsData.startTranslate - z, f.touchEventsData.currentTranslate = f.touchEventsData.currentTranslate - z))
            } else {
                const X = V ? D.length / y.grid.rows : D.length;
                f.slideTo(f.activeIndex - X, 0, !1, !0)
            }
    }
    if (f.allowSlidePrev = p, f.allowSlideNext = v, f.controller && f.controller.control && !c) {
        const X = {
            slideRealIndex: n,
            direction: a,
            setTranslate: s,
            activeSlideIndex: l,
            byController: !0
        };
        Array.isArray(f.controller.control) ? f.controller.control.forEach(te => {
            !te.destroyed && te.params.loop && te.loopFix({ ...X,
                slideTo: te.params.slidesPerView === y.slidesPerView ? e : !1
            })
        }) : f.controller.control instanceof f.constructor && f.controller.control.params.loop && f.controller.control.loopFix({ ...X,
            slideTo: f.controller.control.params.slidesPerView === y.slidesPerView ? e : !1
        })
    }
    f.emit("loopFix")
}

function Uw() {
    const n = this,
        {
            params: e,
            slidesEl: a
        } = n;
    if (!e.loop || !a || n.virtual && n.params.virtual.enabled) return;
    n.recalcSlides();
    const s = [];
    n.slides.forEach(l => {
        const o = typeof l.swiperSlideIndex > "u" ? l.getAttribute("data-swiper-slide-index") * 1 : l.swiperSlideIndex;
        s[o] = l
    }), n.slides.forEach(l => {
        l.removeAttribute("data-swiper-slide-index")
    }), s.forEach(l => {
        a.append(l)
    }), n.recalcSlides(), n.slideTo(n.realIndex, 0)
}
var Hw = {
    loopCreate: Bw,
    loopFix: Pw,
    loopDestroy: Uw
};

function Gw(n) {
    const e = this;
    if (!e.params.simulateTouch || e.params.watchOverflow && e.isLocked || e.params.cssMode) return;
    const a = e.params.touchEventsTarget === "container" ? e.el : e.wrapperEl;
    e.isElement && (e.__preventObserver__ = !0), a.style.cursor = "move", a.style.cursor = n ? "grabbing" : "grab", e.isElement && requestAnimationFrame(() => {
        e.__preventObserver__ = !1
    })
}

function qw() {
    const n = this;
    n.params.watchOverflow && n.isLocked || n.params.cssMode || (n.isElement && (n.__preventObserver__ = !0), n[n.params.touchEventsTarget === "container" ? "el" : "wrapperEl"].style.cursor = "", n.isElement && requestAnimationFrame(() => {
        n.__preventObserver__ = !1
    }))
}
var Yw = {
    setGrabCursor: Gw,
    unsetGrabCursor: qw
};

function Xw(n, e = this) {
    function a(s) {
        if (!s || s === Vn() || s === wt()) return null;
        s.assignedSlot && (s = s.assignedSlot);
        const l = s.closest(n);
        return !l && !s.getRootNode ? null : l || a(s.getRootNode().host)
    }
    return a(e)
}

function sy(n, e, a) {
    const s = wt(),
        {
            params: l
        } = n,
        o = l.edgeSwipeDetection,
        c = l.edgeSwipeThreshold;
    return o && (a <= c || a >= s.innerWidth - c) ? o === "prevent" ? (e.preventDefault(), !0) : !1 : !0
}

function Fw(n) {
    const e = this,
        a = Vn();
    let s = n;
    s.originalEvent && (s = s.originalEvent);
    const l = e.touchEventsData;
    if (s.type === "pointerdown") {
        if (l.pointerId !== null && l.pointerId !== s.pointerId) return;
        l.pointerId = s.pointerId
    } else s.type === "touchstart" && s.targetTouches.length === 1 && (l.touchId = s.targetTouches[0].identifier);
    if (s.type === "touchstart") {
        sy(e, s, s.targetTouches[0].pageX);
        return
    }
    const {
        params: o,
        touches: c,
        enabled: h
    } = e;
    if (!h || !o.simulateTouch && s.pointerType === "mouse" || e.animating && o.preventInteractionOnTransition) return;
    !e.animating && o.cssMode && o.loop && e.loopFix();
    let f = s.target;
    if (o.touchEventsTarget === "wrapper" && !JE(f, e.wrapperEl) || "which" in s && s.which === 3 || "button" in s && s.button > 0 || l.isTouched && l.isMoved) return;
    const m = !!o.noSwipingClass && o.noSwipingClass !== "",
        p = s.composedPath ? s.composedPath() : s.path;
    m && s.target && s.target.shadowRoot && p && (f = p[0]);
    const v = o.noSwipingSelector ? o.noSwipingSelector : `.${o.noSwipingClass}`,
        b = !!(s.target && s.target.shadowRoot);
    if (o.noSwiping && (b ? Xw(v, f) : f.closest(v))) {
        e.allowClick = !0;
        return
    }
    if (o.swipeHandler && !f.closest(o.swipeHandler)) return;
    c.currentX = s.pageX, c.currentY = s.pageY;
    const y = c.currentX,
        T = c.currentY;
    if (!sy(e, s, y)) return;
    Object.assign(l, {
        isTouched: !0,
        isMoved: !1,
        allowTouchCallbacks: !0,
        isScrolling: void 0,
        startMoving: void 0
    }), c.startX = y, c.startY = T, l.touchStartTime = hu(), e.allowClick = !0, e.updateSize(), e.swipeDirection = void 0, o.threshold > 0 && (l.allowThresholdMove = !1);
    let S = !0;
    f.matches(l.focusableElements) && (S = !1, f.nodeName === "SELECT" && (l.isTouched = !1)), a.activeElement && a.activeElement.matches(l.focusableElements) && a.activeElement !== f && (s.pointerType === "mouse" || s.pointerType !== "mouse" && !f.matches(l.focusableElements)) && a.activeElement.blur();
    const M = S && e.allowTouchMove && o.touchStartPreventDefault;
    (o.touchStartForcePreventDefault || M) && !f.isContentEditable && s.preventDefault(), o.freeMode && o.freeMode.enabled && e.freeMode && e.animating && !o.cssMode && e.freeMode.onTouchStart(), e.emit("touchStart", s)
}

function Kw(n) {
    const e = Vn(),
        a = this,
        s = a.touchEventsData,
        {
            params: l,
            touches: o,
            rtlTranslate: c,
            enabled: h
        } = a;
    if (!h || !l.simulateTouch && n.pointerType === "mouse") return;
    let f = n;
    if (f.originalEvent && (f = f.originalEvent), f.type === "pointermove" && (s.touchId !== null || f.pointerId !== s.pointerId)) return;
    let m;
    if (f.type === "touchmove") {
        if (m = [...f.changedTouches].find(O => O.identifier === s.touchId), !m || m.identifier !== s.touchId) return
    } else m = f;
    if (!s.isTouched) {
        s.startMoving && s.isScrolling && a.emit("touchMoveOpposite", f);
        return
    }
    const p = m.pageX,
        v = m.pageY;
    if (f.preventedByNestedSwiper) {
        o.startX = p, o.startY = v;
        return
    }
    if (!a.allowTouchMove) {
        f.target.matches(s.focusableElements) || (a.allowClick = !1), s.isTouched && (Object.assign(o, {
            startX: p,
            startY: v,
            currentX: p,
            currentY: v
        }), s.touchStartTime = hu());
        return
    }
    if (l.touchReleaseOnEdges && !l.loop)
        if (a.isVertical()) {
            if (v < o.startY && a.translate <= a.maxTranslate() || v > o.startY && a.translate >= a.minTranslate()) {
                s.isTouched = !1, s.isMoved = !1;
                return
            }
        } else {
            if (c && (p > o.startX && -a.translate <= a.maxTranslate() || p < o.startX && -a.translate >= a.minTranslate())) return;
            if (!c && (p < o.startX && a.translate <= a.maxTranslate() || p > o.startX && a.translate >= a.minTranslate())) return
        }
    if (e.activeElement && e.activeElement.matches(s.focusableElements) && e.activeElement !== f.target && f.pointerType !== "mouse" && e.activeElement.blur(), e.activeElement && f.target === e.activeElement && f.target.matches(s.focusableElements)) {
        s.isMoved = !0, a.allowClick = !1;
        return
    }
    s.allowTouchCallbacks && a.emit("touchMove", f), o.previousX = o.currentX, o.previousY = o.currentY, o.currentX = p, o.currentY = v;
    const b = o.currentX - o.startX,
        y = o.currentY - o.startY;
    if (a.params.threshold && Math.sqrt(b ** 2 + y ** 2) < a.params.threshold) return;
    if (typeof s.isScrolling > "u") {
        let O;
        a.isHorizontal() && o.currentY === o.startY || a.isVertical() && o.currentX === o.startX ? s.isScrolling = !1 : b * b + y * y >= 25 && (O = Math.atan2(Math.abs(y), Math.abs(b)) * 180 / Math.PI, s.isScrolling = a.isHorizontal() ? O > l.touchAngle : 90 - O > l.touchAngle)
    }
    if (s.isScrolling && a.emit("touchMoveOpposite", f), typeof s.startMoving > "u" && (o.currentX !== o.startX || o.currentY !== o.startY) && (s.startMoving = !0), s.isScrolling || f.type === "touchmove" && s.preventTouchMoveFromPointerMove) {
        s.isTouched = !1;
        return
    }
    if (!s.startMoving) return;
    a.allowClick = !1, !l.cssMode && f.cancelable && f.preventDefault(), l.touchMoveStopPropagation && !l.nested && f.stopPropagation();
    let T = a.isHorizontal() ? b : y,
        S = a.isHorizontal() ? o.currentX - o.previousX : o.currentY - o.previousY;
    l.oneWayMovement && (T = Math.abs(T) * (c ? 1 : -1), S = Math.abs(S) * (c ? 1 : -1)), o.diff = T, T *= l.touchRatio, c && (T = -T, S = -S);
    const M = a.touchesDirection;
    a.swipeDirection = T > 0 ? "prev" : "next", a.touchesDirection = S > 0 ? "prev" : "next";
    const _ = a.params.loop && !l.cssMode,
        w = a.touchesDirection === "next" && a.allowSlideNext || a.touchesDirection === "prev" && a.allowSlidePrev;
    if (!s.isMoved) {
        if (_ && w && a.loopFix({
                direction: a.swipeDirection
            }), s.startTranslate = a.getTranslate(), a.setTransition(0), a.animating) {
            const O = new window.CustomEvent("transitionend", {
                bubbles: !0,
                cancelable: !0,
                detail: {
                    bySwiperTouchMove: !0
                }
            });
            a.wrapperEl.dispatchEvent(O)
        }
        s.allowMomentumBounce = !1, l.grabCursor && (a.allowSlideNext === !0 || a.allowSlidePrev === !0) && a.setGrabCursor(!0), a.emit("sliderFirstMove", f)
    }
    if (new Date().getTime(), l._loopSwapReset !== !1 && s.isMoved && s.allowThresholdMove && M !== a.touchesDirection && _ && w && Math.abs(T) >= 1) {
        Object.assign(o, {
            startX: p,
            startY: v,
            currentX: p,
            currentY: v,
            startTranslate: s.currentTranslate
        }), s.loopSwapReset = !0, s.startTranslate = s.currentTranslate;
        return
    }
    a.emit("sliderMove", f), s.isMoved = !0, s.currentTranslate = T + s.startTranslate;
    let C = !0,
        L = l.resistanceRatio;
    if (l.touchReleaseOnEdges && (L = 0), T > 0 ? (_ && w && s.allowThresholdMove && s.currentTranslate > (l.centeredSlides ? a.minTranslate() - a.slidesSizesGrid[a.activeIndex + 1] - (l.slidesPerView !== "auto" && a.slides.length - l.slidesPerView >= 2 ? a.slidesSizesGrid[a.activeIndex + 1] + a.params.spaceBetween : 0) - a.params.spaceBetween : a.minTranslate()) && a.loopFix({
            direction: "prev",
            setTranslate: !0,
            activeSlideIndex: 0
        }), s.currentTranslate > a.minTranslate() && (C = !1, l.resistance && (s.currentTranslate = a.minTranslate() - 1 + (-a.minTranslate() + s.startTranslate + T) ** L))) : T < 0 && (_ && w && s.allowThresholdMove && s.currentTranslate < (l.centeredSlides ? a.maxTranslate() + a.slidesSizesGrid[a.slidesSizesGrid.length - 1] + a.params.spaceBetween + (l.slidesPerView !== "auto" && a.slides.length - l.slidesPerView >= 2 ? a.slidesSizesGrid[a.slidesSizesGrid.length - 1] + a.params.spaceBetween : 0) : a.maxTranslate()) && a.loopFix({
            direction: "next",
            setTranslate: !0,
            activeSlideIndex: a.slides.length - (l.slidesPerView === "auto" ? a.slidesPerViewDynamic() : Math.ceil(parseFloat(l.slidesPerView, 10)))
        }), s.currentTranslate < a.maxTranslate() && (C = !1, l.resistance && (s.currentTranslate = a.maxTranslate() + 1 - (a.maxTranslate() - s.startTranslate - T) ** L))), C && (f.preventedByNestedSwiper = !0), !a.allowSlideNext && a.swipeDirection === "next" && s.currentTranslate < s.startTranslate && (s.currentTranslate = s.startTranslate), !a.allowSlidePrev && a.swipeDirection === "prev" && s.currentTranslate > s.startTranslate && (s.currentTranslate = s.startTranslate), !a.allowSlidePrev && !a.allowSlideNext && (s.currentTranslate = s.startTranslate), l.threshold > 0)
        if (Math.abs(T) > l.threshold || s.allowThresholdMove) {
            if (!s.allowThresholdMove) {
                s.allowThresholdMove = !0, o.startX = o.currentX, o.startY = o.currentY, s.currentTranslate = s.startTranslate, o.diff = a.isHorizontal() ? o.currentX - o.startX : o.currentY - o.startY;
                return
            }
        } else {
            s.currentTranslate = s.startTranslate;
            return
        }!l.followFinger || l.cssMode || ((l.freeMode && l.freeMode.enabled && a.freeMode || l.watchSlidesProgress) && (a.updateActiveIndex(), a.updateSlidesClasses()), l.freeMode && l.freeMode.enabled && a.freeMode && a.freeMode.onTouchMove(), a.updateProgress(s.currentTranslate), a.setTranslate(s.currentTranslate))
}

function Zw(n) {
    const e = this,
        a = e.touchEventsData;
    let s = n;
    s.originalEvent && (s = s.originalEvent);
    let l;
    if (s.type === "touchend" || s.type === "touchcancel") {
        if (l = [...s.changedTouches].find(O => O.identifier === a.touchId), !l || l.identifier !== a.touchId) return
    } else {
        if (a.touchId !== null || s.pointerId !== a.pointerId) return;
        l = s
    }
    if (["pointercancel", "pointerout", "pointerleave", "contextmenu"].includes(s.type) && !(["pointercancel", "contextmenu"].includes(s.type) && (e.browser.isSafari || e.browser.isWebView))) return;
    a.pointerId = null, a.touchId = null;
    const {
        params: c,
        touches: h,
        rtlTranslate: f,
        slidesGrid: m,
        enabled: p
    } = e;
    if (!p || !c.simulateTouch && s.pointerType === "mouse") return;
    if (a.allowTouchCallbacks && e.emit("touchEnd", s), a.allowTouchCallbacks = !1, !a.isTouched) {
        a.isMoved && c.grabCursor && e.setGrabCursor(!1), a.isMoved = !1, a.startMoving = !1;
        return
    }
    c.grabCursor && a.isMoved && a.isTouched && (e.allowSlideNext === !0 || e.allowSlidePrev === !0) && e.setGrabCursor(!1);
    const v = hu(),
        b = v - a.touchStartTime;
    if (e.allowClick) {
        const O = s.path || s.composedPath && s.composedPath();
        e.updateClickedSlide(O && O[0] || s.target, O), e.emit("tap click", s), b < 300 && v - a.lastClickTime < 300 && e.emit("doubleTap doubleClick", s)
    }
    if (a.lastClickTime = hu(), nx(() => {
            e.destroyed || (e.allowClick = !0)
        }), !a.isTouched || !a.isMoved || !e.swipeDirection || h.diff === 0 && !a.loopSwapReset || a.currentTranslate === a.startTranslate && !a.loopSwapReset) {
        a.isTouched = !1, a.isMoved = !1, a.startMoving = !1;
        return
    }
    a.isTouched = !1, a.isMoved = !1, a.startMoving = !1;
    let y;
    if (c.followFinger ? y = f ? e.translate : -e.translate : y = -a.currentTranslate, c.cssMode) return;
    if (c.freeMode && c.freeMode.enabled) {
        e.freeMode.onTouchEnd({
            currentPos: y
        });
        return
    }
    const T = y >= -e.maxTranslate() && !e.params.loop;
    let S = 0,
        M = e.slidesSizesGrid[0];
    for (let O = 0; O < m.length; O += O < c.slidesPerGroupSkip ? 1 : c.slidesPerGroup) {
        const V = O < c.slidesPerGroupSkip - 1 ? 1 : c.slidesPerGroup;
        typeof m[O + V] < "u" ? (T || y >= m[O] && y < m[O + V]) && (S = O, M = m[O + V] - m[O]) : (T || y >= m[O]) && (S = O, M = m[m.length - 1] - m[m.length - 2])
    }
    let _ = null,
        w = null;
    c.rewind && (e.isBeginning ? w = c.virtual && c.virtual.enabled && e.virtual ? e.virtual.slides.length - 1 : e.slides.length - 1 : e.isEnd && (_ = 0));
    const C = (y - m[S]) / M,
        L = S < c.slidesPerGroupSkip - 1 ? 1 : c.slidesPerGroup;
    if (b > c.longSwipesMs) {
        if (!c.longSwipes) {
            e.slideTo(e.activeIndex);
            return
        }
        e.swipeDirection === "next" && (C >= c.longSwipesRatio ? e.slideTo(c.rewind && e.isEnd ? _ : S + L) : e.slideTo(S)), e.swipeDirection === "prev" && (C > 1 - c.longSwipesRatio ? e.slideTo(S + L) : w !== null && C < 0 && Math.abs(C) > c.longSwipesRatio ? e.slideTo(w) : e.slideTo(S))
    } else {
        if (!c.shortSwipes) {
            e.slideTo(e.activeIndex);
            return
        }
        e.navigation && (s.target === e.navigation.nextEl || s.target === e.navigation.prevEl) ? s.target === e.navigation.nextEl ? e.slideTo(S + L) : e.slideTo(S) : (e.swipeDirection === "next" && e.slideTo(_ !== null ? _ : S + L), e.swipeDirection === "prev" && e.slideTo(w !== null ? w : S))
    }
}

function ry() {
    const n = this,
        {
            params: e,
            el: a
        } = n;
    if (a && a.offsetWidth === 0) return;
    e.breakpoints && n.setBreakpoint();
    const {
        allowSlideNext: s,
        allowSlidePrev: l,
        snapGrid: o
    } = n, c = n.virtual && n.params.virtual.enabled;
    n.allowSlideNext = !0, n.allowSlidePrev = !0, n.updateSize(), n.updateSlides(), n.updateSlidesClasses();
    const h = c && e.loop;
    (e.slidesPerView === "auto" || e.slidesPerView > 1) && n.isEnd && !n.isBeginning && !n.params.centeredSlides && !h ? n.slideTo(n.slides.length - 1, 0, !1, !0) : n.params.loop && !c ? n.slideToLoop(n.realIndex, 0, !1, !0) : n.slideTo(n.activeIndex, 0, !1, !0), n.autoplay && n.autoplay.running && n.autoplay.paused && (clearTimeout(n.autoplay.resizeTimeout), n.autoplay.resizeTimeout = setTimeout(() => {
        n.autoplay && n.autoplay.running && n.autoplay.paused && n.autoplay.resume()
    }, 500)), n.allowSlidePrev = l, n.allowSlideNext = s, n.params.watchOverflow && o !== n.snapGrid && n.checkOverflow()
}

function Qw(n) {
    const e = this;
    e.enabled && (e.allowClick || (e.params.preventClicks && n.preventDefault(), e.params.preventClicksPropagation && e.animating && (n.stopPropagation(), n.stopImmediatePropagation())))
}

function Iw() {
    const n = this,
        {
            wrapperEl: e,
            rtlTranslate: a,
            enabled: s
        } = n;
    if (!s) return;
    n.previousTranslate = n.translate, n.isHorizontal() ? n.translate = -e.scrollLeft : n.translate = -e.scrollTop, n.translate === 0 && (n.translate = 0), n.updateActiveIndex(), n.updateSlidesClasses();
    let l;
    const o = n.maxTranslate() - n.minTranslate();
    o === 0 ? l = 0 : l = (n.translate - n.minTranslate()) / o, l !== n.progress && n.updateProgress(a ? -n.translate : n.translate), n.emit("setTranslate", n.translate, !1)
}

function $w(n) {
    const e = this;
    $o(e, n.target), !(e.params.cssMode || e.params.slidesPerView !== "auto" && !e.params.autoHeight) && e.update()
}

function Ww() {
    const n = this;
    n.documentTouchHandlerProceeded || (n.documentTouchHandlerProceeded = !0, n.params.touchReleaseOnEdges && (n.el.style.touchAction = "auto"))
}
const ux = (n, e) => {
    const a = Vn(),
        {
            params: s,
            el: l,
            wrapperEl: o,
            device: c
        } = n,
        h = !!s.nested,
        f = e === "on" ? "addEventListener" : "removeEventListener",
        m = e;
    !l || typeof l == "string" || (a[f]("touchstart", n.onDocumentTouchStart, {
        passive: !1,
        capture: h
    }), l[f]("touchstart", n.onTouchStart, {
        passive: !1
    }), l[f]("pointerdown", n.onTouchStart, {
        passive: !1
    }), a[f]("touchmove", n.onTouchMove, {
        passive: !1,
        capture: h
    }), a[f]("pointermove", n.onTouchMove, {
        passive: !1,
        capture: h
    }), a[f]("touchend", n.onTouchEnd, {
        passive: !0
    }), a[f]("pointerup", n.onTouchEnd, {
        passive: !0
    }), a[f]("pointercancel", n.onTouchEnd, {
        passive: !0
    }), a[f]("touchcancel", n.onTouchEnd, {
        passive: !0
    }), a[f]("pointerout", n.onTouchEnd, {
        passive: !0
    }), a[f]("pointerleave", n.onTouchEnd, {
        passive: !0
    }), a[f]("contextmenu", n.onTouchEnd, {
        passive: !0
    }), (s.preventClicks || s.preventClicksPropagation) && l[f]("click", n.onClick, !0), s.cssMode && o[f]("scroll", n.onScroll), s.updateOnWindowResize ? n[m](c.ios || c.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", ry, !0) : n[m]("observerUpdate", ry, !0), l[f]("load", n.onLoad, {
        capture: !0
    }))
};

function Jw() {
    const n = this,
        {
            params: e
        } = n;
    n.onTouchStart = Fw.bind(n), n.onTouchMove = Kw.bind(n), n.onTouchEnd = Zw.bind(n), n.onDocumentTouchStart = Ww.bind(n), e.cssMode && (n.onScroll = Iw.bind(n)), n.onClick = Qw.bind(n), n.onLoad = $w.bind(n), ux(n, "on")
}

function eM() {
    ux(this, "off")
}
var tM = {
    attachEvents: Jw,
    detachEvents: eM
};
const ly = (n, e) => n.grid && e.grid && e.grid.rows > 1;

function nM() {
    const n = this,
        {
            realIndex: e,
            initialized: a,
            params: s,
            el: l
        } = n,
        o = s.breakpoints;
    if (!o || o && Object.keys(o).length === 0) return;
    const c = Vn(),
        h = s.breakpointsBase === "window" || !s.breakpointsBase ? s.breakpointsBase : "container",
        f = ["window", "container"].includes(s.breakpointsBase) || !s.breakpointsBase ? n.el : c.querySelector(s.breakpointsBase),
        m = n.getBreakpoint(o, h, f);
    if (!m || n.currentBreakpoint === m) return;
    const v = (m in o ? o[m] : void 0) || n.originalParams,
        b = ly(n, s),
        y = ly(n, v),
        T = n.params.grabCursor,
        S = v.grabCursor,
        M = s.enabled;
    b && !y ? (l.classList.remove(`${s.containerModifierClass}grid`, `${s.containerModifierClass}grid-column`), n.emitContainerClasses()) : !b && y && (l.classList.add(`${s.containerModifierClass}grid`), (v.grid.fill && v.grid.fill === "column" || !v.grid.fill && s.grid.fill === "column") && l.classList.add(`${s.containerModifierClass}grid-column`), n.emitContainerClasses()), T && !S ? n.unsetGrabCursor() : !T && S && n.setGrabCursor(), ["navigation", "pagination", "scrollbar"].forEach(V => {
        if (typeof v[V] > "u") return;
        const k = s[V] && s[V].enabled,
            D = v[V] && v[V].enabled;
        k && !D && n[V].disable(), !k && D && n[V].enable()
    });
    const _ = v.direction && v.direction !== s.direction,
        w = s.loop && (v.slidesPerView !== s.slidesPerView || _),
        C = s.loop;
    _ && a && n.changeDirection(), Zt(n.params, v);
    const L = n.params.enabled,
        O = n.params.loop;
    Object.assign(n, {
        allowTouchMove: n.params.allowTouchMove,
        allowSlideNext: n.params.allowSlideNext,
        allowSlidePrev: n.params.allowSlidePrev
    }), M && !L ? n.disable() : !M && L && n.enable(), n.currentBreakpoint = m, n.emit("_beforeBreakpoint", v), a && (w ? (n.loopDestroy(), n.loopCreate(e), n.updateSlides()) : !C && O ? (n.loopCreate(e), n.updateSlides()) : C && !O && n.loopDestroy()), n.emit("breakpoint", v)
}

function iM(n, e = "window", a) {
    if (!n || e === "container" && !a) return;
    let s = !1;
    const l = wt(),
        o = e === "window" ? l.innerHeight : a.clientHeight,
        c = Object.keys(n).map(h => {
            if (typeof h == "string" && h.indexOf("@") === 0) {
                const f = parseFloat(h.substr(1));
                return {
                    value: o * f,
                    point: h
                }
            }
            return {
                value: h,
                point: h
            }
        });
    c.sort((h, f) => parseInt(h.value, 10) - parseInt(f.value, 10));
    for (let h = 0; h < c.length; h += 1) {
        const {
            point: f,
            value: m
        } = c[h];
        e === "window" ? l.matchMedia(`(min-width: ${m}px)`).matches && (s = f) : m <= a.clientWidth && (s = f)
    }
    return s || "max"
}
var aM = {
    setBreakpoint: nM,
    getBreakpoint: iM
};

function sM(n, e) {
    const a = [];
    return n.forEach(s => {
        typeof s == "object" ? Object.keys(s).forEach(l => {
            s[l] && a.push(e + l)
        }) : typeof s == "string" && a.push(e + s)
    }), a
}

function rM() {
    const n = this,
        {
            classNames: e,
            params: a,
            rtl: s,
            el: l,
            device: o
        } = n,
        c = sM(["initialized", a.direction, {
            "free-mode": n.params.freeMode && a.freeMode.enabled
        }, {
            autoheight: a.autoHeight
        }, {
            rtl: s
        }, {
            grid: a.grid && a.grid.rows > 1
        }, {
            "grid-column": a.grid && a.grid.rows > 1 && a.grid.fill === "column"
        }, {
            android: o.android
        }, {
            ios: o.ios
        }, {
            "css-mode": a.cssMode
        }, {
            centered: a.cssMode && a.centeredSlides
        }, {
            "watch-progress": a.watchSlidesProgress
        }], a.containerModifierClass);
    e.push(...c), l.classList.add(...e), n.emitContainerClasses()
}

function lM() {
    const n = this,
        {
            el: e,
            classNames: a
        } = n;
    !e || typeof e == "string" || (e.classList.remove(...a), n.emitContainerClasses())
}
var oM = {
    addClasses: rM,
    removeClasses: lM
};

function uM() {
    const n = this,
        {
            isLocked: e,
            params: a
        } = n,
        {
            slidesOffsetBefore: s
        } = a;
    if (s) {
        const l = n.slides.length - 1,
            o = n.slidesGrid[l] + n.slidesSizesGrid[l] + s * 2;
        n.isLocked = n.size > o
    } else n.isLocked = n.snapGrid.length === 1;
    a.allowSlideNext === !0 && (n.allowSlideNext = !n.isLocked), a.allowSlidePrev === !0 && (n.allowSlidePrev = !n.isLocked), e && e !== n.isLocked && (n.isEnd = !1), e !== n.isLocked && n.emit(n.isLocked ? "lock" : "unlock")
}
var cM = {
        checkOverflow: uM
    },
    dh = {
        init: !0,
        direction: "horizontal",
        oneWayMovement: !1,
        swiperElementNodeName: "SWIPER-CONTAINER",
        touchEventsTarget: "wrapper",
        initialSlide: 0,
        speed: 300,
        cssMode: !1,
        updateOnWindowResize: !0,
        resizeObserver: !0,
        nested: !1,
        createElements: !1,
        eventsPrefix: "swiper",
        enabled: !0,
        focusableElements: "input, select, option, textarea, button, video, label",
        width: null,
        height: null,
        preventInteractionOnTransition: !1,
        userAgent: null,
        url: null,
        edgeSwipeDetection: !1,
        edgeSwipeThreshold: 20,
        autoHeight: !1,
        setWrapperSize: !1,
        virtualTranslate: !1,
        effect: "slide",
        breakpoints: void 0,
        breakpointsBase: "window",
        spaceBetween: 0,
        slidesPerView: 1,
        slidesPerGroup: 1,
        slidesPerGroupSkip: 0,
        slidesPerGroupAuto: !1,
        centeredSlides: !1,
        centeredSlidesBounds: !1,
        slidesOffsetBefore: 0,
        slidesOffsetAfter: 0,
        normalizeSlideIndex: !0,
        centerInsufficientSlides: !1,
        snapToSlideEdge: !1,
        watchOverflow: !0,
        roundLengths: !1,
        touchRatio: 1,
        touchAngle: 45,
        simulateTouch: !0,
        shortSwipes: !0,
        longSwipes: !0,
        longSwipesRatio: .5,
        longSwipesMs: 300,
        followFinger: !0,
        allowTouchMove: !0,
        threshold: 5,
        touchMoveStopPropagation: !1,
        touchStartPreventDefault: !0,
        touchStartForcePreventDefault: !1,
        touchReleaseOnEdges: !1,
        uniqueNavElements: !0,
        resistance: !0,
        resistanceRatio: .85,
        watchSlidesProgress: !1,
        grabCursor: !1,
        preventClicks: !0,
        preventClicksPropagation: !0,
        slideToClickedSlide: !1,
        loop: !1,
        loopAddBlankSlides: !0,
        loopAdditionalSlides: 0,
        loopPreventsSliding: !0,
        rewind: !1,
        allowSlidePrev: !0,
        allowSlideNext: !0,
        swipeHandler: null,
        noSwiping: !0,
        noSwipingClass: "swiper-no-swiping",
        noSwipingSelector: null,
        passiveListeners: !0,
        maxBackfaceHiddenSlides: 10,
        containerModifierClass: "swiper-",
        slideClass: "swiper-slide",
        slideBlankClass: "swiper-slide-blank",
        slideActiveClass: "swiper-slide-active",
        slideVisibleClass: "swiper-slide-visible",
        slideFullyVisibleClass: "swiper-slide-fully-visible",
        slideNextClass: "swiper-slide-next",
        slidePrevClass: "swiper-slide-prev",
        wrapperClass: "swiper-wrapper",
        lazyPreloaderClass: "swiper-lazy-preloader",
        lazyPreloadPrevNext: 0,
        runCallbacksOnInit: !0,
        _emitClasses: !1
    };

function fM(n, e) {
    return function(s = {}) {
        const l = Object.keys(s)[0],
            o = s[l];
        if (typeof o != "object" || o === null) {
            Zt(e, s);
            return
        }
        if (n[l] === !0 && (n[l] = {
                enabled: !0
            }), l === "navigation" && n[l] && n[l].enabled && !n[l].prevEl && !n[l].nextEl && (n[l].auto = !0), ["pagination", "scrollbar"].indexOf(l) >= 0 && n[l] && n[l].enabled && !n[l].el && (n[l].auto = !0), !(l in n && "enabled" in o)) {
            Zt(e, s);
            return
        }
        typeof n[l] == "object" && !("enabled" in n[l]) && (n[l].enabled = !0), n[l] || (n[l] = {
            enabled: !1
        }), Zt(e, s)
    }
}
const Sd = {
        eventsEmitter: ow,
        update: bw,
        translate: ww,
        transition: Ow,
        slide: kw,
        loop: Hw,
        grabCursor: Yw,
        events: tM,
        breakpoints: aM,
        checkOverflow: cM,
        classes: oM
    },
    Td = {};
let bm = class Jn {
    constructor(...e) {
        let a, s;
        e.length === 1 && e[0].constructor && Object.prototype.toString.call(e[0]).slice(8, -1) === "Object" ? s = e[0] : [a, s] = e, s || (s = {}), s = Zt({}, s), a && !s.el && (s.el = a);
        const l = Vn();
        if (s.el && typeof s.el == "string" && l.querySelectorAll(s.el).length > 1) {
            const f = [];
            return l.querySelectorAll(s.el).forEach(m => {
                const p = Zt({}, s, {
                    el: m
                });
                f.push(new Jn(p))
            }), f
        }
        const o = this;
        o.__swiper__ = !0, o.support = sx(), o.device = rx({
            userAgent: s.userAgent
        }), o.browser = lx(), o.eventsListeners = {}, o.eventsAnyListeners = [], o.modules = [...o.__modules__], s.modules && Array.isArray(s.modules) && o.modules.push(...s.modules);
        const c = {};
        o.modules.forEach(f => {
            f({
                params: s,
                swiper: o,
                extendParams: fM(s, c),
                on: o.on.bind(o),
                once: o.once.bind(o),
                off: o.off.bind(o),
                emit: o.emit.bind(o)
            })
        });
        const h = Zt({}, dh, c);
        return o.params = Zt({}, h, Td, s), o.originalParams = Zt({}, o.params), o.passedParams = Zt({}, s), o.params && o.params.on && Object.keys(o.params.on).forEach(f => {
            o.on(f, o.params.on[f])
        }), o.params && o.params.onAny && o.onAny(o.params.onAny), Object.assign(o, {
            enabled: o.params.enabled,
            el: a,
            classNames: [],
            slides: [],
            slidesGrid: [],
            snapGrid: [],
            slidesSizesGrid: [],
            isHorizontal() {
                return o.params.direction === "horizontal"
            },
            isVertical() {
                return o.params.direction === "vertical"
            },
            activeIndex: 0,
            realIndex: 0,
            isBeginning: !0,
            isEnd: !1,
            translate: 0,
            previousTranslate: 0,
            progress: 0,
            velocity: 0,
            animating: !1,
            cssOverflowAdjustment() {
                return Math.trunc(this.translate / 2 ** 23) * 2 ** 23
            },
            allowSlideNext: o.params.allowSlideNext,
            allowSlidePrev: o.params.allowSlidePrev,
            touchEventsData: {
                isTouched: void 0,
                isMoved: void 0,
                allowTouchCallbacks: void 0,
                touchStartTime: void 0,
                isScrolling: void 0,
                currentTranslate: void 0,
                startTranslate: void 0,
                allowThresholdMove: void 0,
                focusableElements: o.params.focusableElements,
                lastClickTime: 0,
                clickTimeout: void 0,
                velocities: [],
                allowMomentumBounce: void 0,
                startMoving: void 0,
                pointerId: null,
                touchId: null
            },
            allowClick: !0,
            allowTouchMove: o.params.allowTouchMove,
            touches: {
                startX: 0,
                startY: 0,
                currentX: 0,
                currentY: 0,
                diff: 0
            },
            imagesToLoad: [],
            imagesLoaded: 0
        }), o.emit("_swiper"), o.params.init && o.init(), o
    }
    getDirectionLabel(e) {
        return this.isHorizontal() ? e : {
            width: "height",
            "margin-top": "margin-left",
            "margin-bottom ": "margin-right",
            "margin-left": "margin-top",
            "margin-right": "margin-bottom",
            "padding-left": "padding-top",
            "padding-right": "padding-bottom",
            marginRight: "marginBottom"
        }[e]
    }
    getSlideIndex(e) {
        const {
            slidesEl: a,
            params: s
        } = this, l = Ln(a, `.${s.slideClass}, swiper-slide`), o = pu(l[0]);
        return pu(e) - o
    }
    getSlideIndexByData(e) {
        return this.getSlideIndex(this.slides.find(a => a.getAttribute("data-swiper-slide-index") * 1 === e))
    }
    getSlideIndexWhenGrid(e) {
        return this.grid && this.params.grid && this.params.grid.rows > 1 && (this.params.grid.fill === "column" ? e = Math.floor(e / this.params.grid.rows) : this.params.grid.fill === "row" && (e = e % Math.ceil(this.slides.length / this.params.grid.rows))), e
    }
    recalcSlides() {
        const e = this,
            {
                slidesEl: a,
                params: s
            } = e;
        e.slides = Ln(a, `.${s.slideClass}, swiper-slide`)
    }
    enable() {
        const e = this;
        e.enabled || (e.enabled = !0, e.params.grabCursor && e.setGrabCursor(), e.emit("enable"))
    }
    disable() {
        const e = this;
        e.enabled && (e.enabled = !1, e.params.grabCursor && e.unsetGrabCursor(), e.emit("disable"))
    }
    setProgress(e, a) {
        const s = this;
        e = Math.min(Math.max(e, 0), 1);
        const l = s.minTranslate(),
            c = (s.maxTranslate() - l) * e + l;
        s.translateTo(c, typeof a > "u" ? 0 : a), s.updateActiveIndex(), s.updateSlidesClasses()
    }
    emitContainerClasses() {
        const e = this;
        if (!e.params._emitClasses || !e.el) return;
        const a = e.el.className.split(" ").filter(s => s.indexOf("swiper") === 0 || s.indexOf(e.params.containerModifierClass) === 0);
        e.emit("_containerClasses", a.join(" "))
    }
    getSlideClasses(e) {
        const a = this;
        return a.destroyed ? "" : e.className.split(" ").filter(s => s.indexOf("swiper-slide") === 0 || s.indexOf(a.params.slideClass) === 0).join(" ")
    }
    emitSlidesClasses() {
        const e = this;
        if (!e.params._emitClasses || !e.el) return;
        const a = [];
        e.slides.forEach(s => {
            const l = e.getSlideClasses(s);
            a.push({
                slideEl: s,
                classNames: l
            }), e.emit("_slideClass", s, l)
        }), e.emit("_slideClasses", a)
    }
    slidesPerViewDynamic(e = "current", a = !1) {
        const s = this,
            {
                params: l,
                slides: o,
                slidesGrid: c,
                slidesSizesGrid: h,
                size: f,
                activeIndex: m
            } = s;
        let p = 1;
        if (typeof l.slidesPerView == "number") return l.slidesPerView;
        if (l.centeredSlides) {
            let v = o[m] ? Math.ceil(o[m].swiperSlideSize) : 0,
                b;
            for (let y = m + 1; y < o.length; y += 1) o[y] && !b && (v += Math.ceil(o[y].swiperSlideSize), p += 1, v > f && (b = !0));
            for (let y = m - 1; y >= 0; y -= 1) o[y] && !b && (v += o[y].swiperSlideSize, p += 1, v > f && (b = !0))
        } else if (e === "current")
            for (let v = m + 1; v < o.length; v += 1)(a ? c[v] + h[v] - c[m] < f : c[v] - c[m] < f) && (p += 1);
        else
            for (let v = m - 1; v >= 0; v -= 1) c[m] - c[v] < f && (p += 1);
        return p
    }
    update() {
        const e = this;
        if (!e || e.destroyed) return;
        const {
            snapGrid: a,
            params: s
        } = e;
        s.breakpoints && e.setBreakpoint(), [...e.el.querySelectorAll('[loading="lazy"]')].forEach(c => {
            c.complete && $o(e, c)
        }), e.updateSize(), e.updateSlides(), e.updateProgress(), e.updateSlidesClasses();

        function l() {
            const c = e.rtlTranslate ? e.translate * -1 : e.translate,
                h = Math.min(Math.max(c, e.maxTranslate()), e.minTranslate());
            e.setTranslate(h), e.updateActiveIndex(), e.updateSlidesClasses()
        }
        let o;
        if (s.freeMode && s.freeMode.enabled && !s.cssMode) l(), s.autoHeight && e.updateAutoHeight();
        else {
            if ((s.slidesPerView === "auto" || s.slidesPerView > 1) && e.isEnd && !s.centeredSlides) {
                const c = e.virtual && s.virtual.enabled ? e.virtual.slides : e.slides;
                o = e.slideTo(c.length - 1, 0, !1, !0)
            } else o = e.slideTo(e.activeIndex, 0, !1, !0);
            o || l()
        }
        s.watchOverflow && a !== e.snapGrid && e.checkOverflow(), e.emit("update")
    }
    changeDirection(e, a = !0) {
        const s = this,
            l = s.params.direction;
        return e || (e = l === "horizontal" ? "vertical" : "horizontal"), e === l || e !== "horizontal" && e !== "vertical" || (s.el.classList.remove(`${s.params.containerModifierClass}${l}`), s.el.classList.add(`${s.params.containerModifierClass}${e}`), s.emitContainerClasses(), s.params.direction = e, s.slides.forEach(o => {
            e === "vertical" ? o.style.width = "" : o.style.height = ""
        }), s.emit("changeDirection"), a && s.update()), s
    }
    changeLanguageDirection(e) {
        const a = this;
        a.rtl && e === "rtl" || !a.rtl && e === "ltr" || (a.rtl = e === "rtl", a.rtlTranslate = a.params.direction === "horizontal" && a.rtl, a.rtl ? (a.el.classList.add(`${a.params.containerModifierClass}rtl`), a.el.dir = "rtl") : (a.el.classList.remove(`${a.params.containerModifierClass}rtl`), a.el.dir = "ltr"), a.update())
    }
    mount(e) {
        const a = this;
        if (a.mounted) return !0;
        let s = e || a.params.el;
        if (typeof s == "string" && (s = document.querySelector(s)), !s) return !1;
        s.swiper = a, s.parentNode && s.parentNode.host && s.parentNode.host.nodeName === a.params.swiperElementNodeName.toUpperCase() && (a.isElement = !0);
        const l = () => `.${(a.params.wrapperClass||"").trim().split(" ").join(".")}`;
        let c = s && s.shadowRoot && s.shadowRoot.querySelector ? s.shadowRoot.querySelector(l()) : Ln(s, l())[0];
        return !c && a.params.createElements && (c = ml("div", a.params.wrapperClass), s.append(c), Ln(s, `.${a.params.slideClass}`).forEach(h => {
            c.append(h)
        })), Object.assign(a, {
            el: s,
            wrapperEl: c,
            slidesEl: a.isElement && !s.parentNode.host.slideSlots ? s.parentNode.host : c,
            hostEl: a.isElement ? s.parentNode.host : s,
            mounted: !0,
            rtl: s.dir.toLowerCase() === "rtl" || Ni(s, "direction") === "rtl",
            rtlTranslate: a.params.direction === "horizontal" && (s.dir.toLowerCase() === "rtl" || Ni(s, "direction") === "rtl"),
            wrongRTL: Ni(c, "display") === "-webkit-box"
        }), !0
    }
    init(e) {
        const a = this;
        if (a.initialized || a.mount(e) === !1) return a;
        a.emit("beforeInit"), a.params.breakpoints && a.setBreakpoint(), a.addClasses(), a.updateSize(), a.updateSlides(), a.params.watchOverflow && a.checkOverflow(), a.params.grabCursor && a.enabled && a.setGrabCursor(), a.params.loop && a.virtual && a.params.virtual.enabled ? a.slideTo(a.params.initialSlide + a.virtual.slidesBefore, 0, a.params.runCallbacksOnInit, !1, !0) : a.slideTo(a.params.initialSlide, 0, a.params.runCallbacksOnInit, !1, !0), a.params.loop && a.loopCreate(void 0, !0), a.attachEvents();
        const l = [...a.el.querySelectorAll('[loading="lazy"]')];
        return a.isElement && l.push(...a.hostEl.querySelectorAll('[loading="lazy"]')), l.forEach(o => {
            o.complete ? $o(a, o) : o.addEventListener("load", c => {
                $o(a, c.target)
            })
        }), fh(a), a.initialized = !0, fh(a), a.emit("init"), a.emit("afterInit"), a
    }
    destroy(e = !0, a = !0) {
        const s = this,
            {
                params: l,
                el: o,
                wrapperEl: c,
                slides: h
            } = s;
        return typeof s.params > "u" || s.destroyed || (s.emit("beforeDestroy"), s.initialized = !1, s.detachEvents(), l.loop && s.loopDestroy(), a && (s.removeClasses(), o && typeof o != "string" && o.removeAttribute("style"), c && c.removeAttribute("style"), h && h.length && h.forEach(f => {
            f.classList.remove(l.slideVisibleClass, l.slideFullyVisibleClass, l.slideActiveClass, l.slideNextClass, l.slidePrevClass), f.removeAttribute("style"), f.removeAttribute("data-swiper-slide-index")
        })), s.emit("destroy"), Object.keys(s.eventsListeners).forEach(f => {
            s.off(f)
        }), e !== !1 && (s.el && typeof s.el != "string" && (s.el.swiper = null), ZE(s)), s.destroyed = !0), null
    }
    static extendDefaults(e) {
        Zt(Td, e)
    }
    static get extendedDefaults() {
        return Td
    }
    static get defaults() {
        return dh
    }
    static installModule(e) {
        Jn.prototype.__modules__ || (Jn.prototype.__modules__ = []);
        const a = Jn.prototype.__modules__;
        typeof e == "function" && a.indexOf(e) < 0 && a.push(e)
    }
    static use(e) {
        return Array.isArray(e) ? (e.forEach(a => Jn.installModule(a)), Jn) : (Jn.installModule(e), Jn)
    }
};
Object.keys(Sd).forEach(n => {
    Object.keys(Sd[n]).forEach(e => {
        bm.prototype[e] = Sd[n][e]
    })
});
bm.use([rw, lw]);
const cx = ["eventsPrefix", "injectStyles", "injectStylesUrls", "modules", "init", "_direction", "oneWayMovement", "swiperElementNodeName", "touchEventsTarget", "initialSlide", "_speed", "cssMode", "updateOnWindowResize", "resizeObserver", "nested", "focusableElements", "_enabled", "_width", "_height", "preventInteractionOnTransition", "userAgent", "url", "_edgeSwipeDetection", "_edgeSwipeThreshold", "_freeMode", "_autoHeight", "setWrapperSize", "virtualTranslate", "_effect", "breakpoints", "breakpointsBase", "_spaceBetween", "_slidesPerView", "maxBackfaceHiddenSlides", "_grid", "_slidesPerGroup", "_slidesPerGroupSkip", "_slidesPerGroupAuto", "_centeredSlides", "_centeredSlidesBounds", "_slidesOffsetBefore", "_slidesOffsetAfter", "normalizeSlideIndex", "_centerInsufficientSlides", "_snapToSlideEdge", "_watchOverflow", "roundLengths", "touchRatio", "touchAngle", "simulateTouch", "_shortSwipes", "_longSwipes", "longSwipesRatio", "longSwipesMs", "_followFinger", "allowTouchMove", "_threshold", "touchMoveStopPropagation", "touchStartPreventDefault", "touchStartForcePreventDefault", "touchReleaseOnEdges", "uniqueNavElements", "_resistance", "_resistanceRatio", "_watchSlidesProgress", "_grabCursor", "preventClicks", "preventClicksPropagation", "_slideToClickedSlide", "_loop", "loopAdditionalSlides", "loopAddBlankSlides", "loopPreventsSliding", "_rewind", "_allowSlidePrev", "_allowSlideNext", "_swipeHandler", "_noSwiping", "noSwipingClass", "noSwipingSelector", "passiveListeners", "containerModifierClass", "slideClass", "slideActiveClass", "slideVisibleClass", "slideFullyVisibleClass", "slideNextClass", "slidePrevClass", "slideBlankClass", "wrapperClass", "lazyPreloaderClass", "lazyPreloadPrevNext", "runCallbacksOnInit", "observer", "observeParents", "observeSlideChildren", "a11y", "_autoplay", "_controller", "coverflowEffect", "cubeEffect", "fadeEffect", "flipEffect", "creativeEffect", "cardsEffect", "hashNavigation", "history", "keyboard", "mousewheel", "_navigation", "_pagination", "parallax", "_scrollbar", "_thumbs", "virtual", "zoom", "control"];

function _a(n) {
    return typeof n == "object" && n !== null && n.constructor && Object.prototype.toString.call(n).slice(8, -1) === "Object" && !n.__swiper__
}

function Es(n, e) {
    const a = ["__proto__", "constructor", "prototype"];
    Object.keys(e).filter(s => a.indexOf(s) < 0).forEach(s => {
        typeof n[s] > "u" ? n[s] = e[s] : _a(e[s]) && _a(n[s]) && Object.keys(e[s]).length > 0 ? e[s].__swiper__ ? n[s] = e[s] : Es(n[s], e[s]) : n[s] = e[s]
    })
}

function fx(n = {}) {
    return n.navigation && typeof n.navigation.nextEl > "u" && typeof n.navigation.prevEl > "u"
}

function dx(n = {}) {
    return n.pagination && typeof n.pagination.el > "u"
}

function hx(n = {}) {
    return n.scrollbar && typeof n.scrollbar.el > "u"
}

function mx(n = "") {
    const e = n.split(" ").map(s => s.trim()).filter(s => !!s),
        a = [];
    return e.forEach(s => {
        a.indexOf(s) < 0 && a.push(s)
    }), a.join(" ")
}

function dM(n = "") {
    return n ? n.includes("swiper-wrapper") ? n : `swiper-wrapper ${n}` : "swiper-wrapper"
}

function hM({
    swiper: n,
    slides: e,
    passedParams: a,
    changedParams: s,
    nextEl: l,
    prevEl: o,
    scrollbarEl: c,
    paginationEl: h
}) {
    const f = s.filter(D => D !== "children" && D !== "direction" && D !== "wrapperClass"),
        {
            params: m,
            pagination: p,
            navigation: v,
            scrollbar: b,
            virtual: y,
            thumbs: T
        } = n;
    let S, M, _, w, C, L, O, V;
    s.includes("thumbs") && a.thumbs && a.thumbs.swiper && !a.thumbs.swiper.destroyed && m.thumbs && (!m.thumbs.swiper || m.thumbs.swiper.destroyed) && (S = !0), s.includes("controller") && a.controller && a.controller.control && m.controller && !m.controller.control && (M = !0), s.includes("pagination") && a.pagination && (a.pagination.el || h) && (m.pagination || m.pagination === !1) && p && !p.el && (_ = !0), s.includes("scrollbar") && a.scrollbar && (a.scrollbar.el || c) && (m.scrollbar || m.scrollbar === !1) && b && !b.el && (w = !0), s.includes("navigation") && a.navigation && (a.navigation.prevEl || o) && (a.navigation.nextEl || l) && (m.navigation || m.navigation === !1) && v && !v.prevEl && !v.nextEl && (C = !0);
    const k = D => {
        n[D] && (n[D].destroy(), D === "navigation" ? (n.isElement && (n[D].prevEl.remove(), n[D].nextEl.remove()), m[D].prevEl = void 0, m[D].nextEl = void 0, n[D].prevEl = void 0, n[D].nextEl = void 0) : (n.isElement && n[D].el.remove(), m[D].el = void 0, n[D].el = void 0))
    };
    s.includes("loop") && n.isElement && (m.loop && !a.loop ? L = !0 : !m.loop && a.loop ? O = !0 : V = !0), f.forEach(D => {
        if (_a(m[D]) && _a(a[D])) Object.assign(m[D], a[D]), (D === "navigation" || D === "pagination" || D === "scrollbar") && "enabled" in a[D] && !a[D].enabled && k(D);
        else {
            const H = a[D];
            (H === !0 || H === !1) && (D === "navigation" || D === "pagination" || D === "scrollbar") ? H === !1 && k(D): m[D] = a[D]
        }
    }), f.includes("controller") && !M && n.controller && n.controller.control && m.controller && m.controller.control && (n.controller.control = m.controller.control), s.includes("children") && e && y && m.virtual.enabled ? (y.slides = e, y.update(!0)) : s.includes("virtual") && y && m.virtual.enabled && (e && (y.slides = e), y.update(!0)), s.includes("children") && e && m.loop && (V = !0), S && T.init() && T.update(!0), M && (n.controller.control = m.controller.control), _ && (n.isElement && (!h || typeof h == "string") && (h = document.createElement("div"), h.classList.add("swiper-pagination"), h.part.add("pagination"), n.el.appendChild(h)), h && (m.pagination.el = h), p.init(), p.render(), p.update()), w && (n.isElement && (!c || typeof c == "string") && (c = document.createElement("div"), c.classList.add("swiper-scrollbar"), c.part.add("scrollbar"), n.el.appendChild(c)), c && (m.scrollbar.el = c), b.init(), b.updateSize(), b.setTranslate()), C && (n.isElement && ((!l || typeof l == "string") && (l = document.createElement("div"), l.classList.add("swiper-button-next"), pl(l, n.navigation.arrowSvg), l.part.add("button-next"), n.el.appendChild(l)), (!o || typeof o == "string") && (o = document.createElement("div"), o.classList.add("swiper-button-prev"), pl(o, n.navigation.arrowSvg), o.part.add("button-prev"), n.el.appendChild(o))), l && (m.navigation.nextEl = l), o && (m.navigation.prevEl = o), v.init(), v.update()), s.includes("allowSlideNext") && (n.allowSlideNext = a.allowSlideNext), s.includes("allowSlidePrev") && (n.allowSlidePrev = a.allowSlidePrev), s.includes("direction") && n.changeDirection(a.direction, !1), (L || V) && n.loopDestroy(), (O || V) && n.loopCreate(), n.update()
}

function mM(n = {}, e = !0) {
    const a = {
            on: {}
        },
        s = {},
        l = {};
    Es(a, dh), a._emitClasses = !0, a.init = !1;
    const o = {},
        c = cx.map(f => f.replace(/_/, "")),
        h = Object.assign({}, n);
    return Object.keys(h).forEach(f => {
        typeof n[f] > "u" || (c.indexOf(f) >= 0 ? _a(n[f]) ? (a[f] = {}, l[f] = {}, Es(a[f], n[f]), Es(l[f], n[f])) : (a[f] = n[f], l[f] = n[f]) : f.search(/on[A-Z]/) === 0 && typeof n[f] == "function" ? e ? s[`${f[2].toLowerCase()}${f.substr(3)}`] = n[f] : a.on[`${f[2].toLowerCase()}${f.substr(3)}`] = n[f] : o[f] = n[f])
    }), ["navigation", "pagination", "scrollbar"].forEach(f => {
        a[f] === !0 && (a[f] = {}), a[f] === !1 && delete a[f]
    }), {
        params: a,
        passedParams: l,
        rest: o,
        events: s
    }
}

function pM({
    el: n,
    nextEl: e,
    prevEl: a,
    paginationEl: s,
    scrollbarEl: l,
    swiper: o
}, c) {
    fx(c) && e && a && (o.params.navigation.nextEl = e, o.originalParams.navigation.nextEl = e, o.params.navigation.prevEl = a, o.originalParams.navigation.prevEl = a), dx(c) && s && (o.params.pagination.el = s, o.originalParams.pagination.el = s), hx(c) && l && (o.params.scrollbar.el = l, o.originalParams.scrollbar.el = l), o.init(n)
}

function gM(n, e, a, s, l) {
    const o = [];
    if (!e) return o;
    const c = f => {
        o.indexOf(f) < 0 && o.push(f)
    };
    if (a && s) {
        const f = s.map(l),
            m = a.map(l);
        f.join("") !== m.join("") && c("children"), s.length !== a.length && c("children")
    }
    return cx.filter(f => f[0] === "_").map(f => f.replace(/_/, "")).forEach(f => {
        if (f in n && f in e)
            if (_a(n[f]) && _a(e[f])) {
                const m = Object.keys(n[f]),
                    p = Object.keys(e[f]);
                m.length !== p.length ? c(f) : (m.forEach(v => {
                    n[f][v] !== e[f][v] && c(f)
                }), p.forEach(v => {
                    n[f][v] !== e[f][v] && c(f)
                }))
            } else n[f] !== e[f] && c(f)
    }), o
}
const vM = n => {
    !n || n.destroyed || !n.params.virtual || n.params.virtual && !n.params.virtual.enabled || (n.updateSlides(), n.updateProgress(), n.updateSlidesClasses(), n.emit("_virtualUpdated"), n.parallax && n.params.parallax && n.params.parallax.enabled && n.parallax.setTranslate())
};

function gu() {
    return gu = Object.assign ? Object.assign.bind() : function(n) {
        for (var e = 1; e < arguments.length; e++) {
            var a = arguments[e];
            for (var s in a) Object.prototype.hasOwnProperty.call(a, s) && (n[s] = a[s])
        }
        return n
    }, gu.apply(this, arguments)
}

function px(n) {
    return n.type && n.type.displayName && n.type.displayName.includes("SwiperSlide")
}

function gx(n) {
    const e = [];
    return xe.Children.toArray(n).forEach(a => {
        px(a) ? e.push(a) : a.props && a.props.children && gx(a.props.children).forEach(s => e.push(s))
    }), e
}

function yM(n) {
    const e = [],
        a = {
            "container-start": [],
            "container-end": [],
            "wrapper-start": [],
            "wrapper-end": []
        };
    return xe.Children.toArray(n).forEach(s => {
        if (px(s)) e.push(s);
        else if (s.props && s.props.slot && a[s.props.slot]) a[s.props.slot].push(s);
        else if (s.props && s.props.children) {
            const l = gx(s.props.children);
            l.length > 0 ? l.forEach(o => e.push(o)) : a["container-end"].push(s)
        } else a["container-end"].push(s)
    }), {
        slides: e,
        slots: a
    }
}

function bM(n, e, a) {
    if (!a) return null;
    const s = p => {
            let v = p;
            return p < 0 ? v = e.length + p : v >= e.length && (v = v - e.length), v
        },
        l = n.isHorizontal() ? {
            [n.rtlTranslate ? "right" : "left"]: `${a.offset}px`
        } : {
            top: `${a.offset}px`
        },
        {
            from: o,
            to: c
        } = a,
        h = n.params.loop ? -e.length : 0,
        f = n.params.loop ? e.length * 2 : e.length,
        m = [];
    for (let p = h; p < f; p += 1) p >= o && p <= c && m.push(e[s(p)]);
    return m.map((p, v) => xe.cloneElement(p, {
        swiper: n,
        style: l,
        key: p.props.virtualIndex || p.key || `slide-${v}`
    }))
}

function Jr(n, e) {
    return typeof window > "u" ? J.useEffect(n, e) : J.useLayoutEffect(n, e)
}
const oy = J.createContext(null),
    xM = J.createContext(null),
    vx = J.forwardRef(({
        className: n,
        tag: e = "div",
        wrapperTag: a = "div",
        children: s,
        onSwiper: l,
        ...o
    } = {}, c) => {
        let h = !1;
        const [f, m] = J.useState("swiper"), [p, v] = J.useState(null), [b, y] = J.useState(!1), T = J.useRef(!1), S = J.useRef(null), M = J.useRef(null), _ = J.useRef(null), w = J.useRef(null), C = J.useRef(null), L = J.useRef(null), O = J.useRef(null), V = J.useRef(null), {
            params: k,
            passedParams: D,
            rest: H,
            events: F
        } = mM(o), {
            slides: I,
            slots: W
        } = yM(s), ee = () => {
            y(!b)
        };
        Object.assign(k.on, {
            _containerClasses(X, te) {
                m(te)
            }
        });
        const ae = () => {
            Object.assign(k.on, F), h = !0;
            const X = { ...k
            };
            if (delete X.wrapperClass, M.current = new bm(X), M.current.virtual && M.current.params.virtual.enabled) {
                M.current.virtual.slides = I;
                const te = {
                    cache: !1,
                    slides: I,
                    renderExternal: v,
                    renderExternalUpdate: !1
                };
                Es(M.current.params.virtual, te), Es(M.current.originalParams.virtual, te)
            }
        };
        S.current || ae(), M.current && M.current.on("_beforeBreakpoint", ee);
        const se = () => {
                h || !F || !M.current || Object.keys(F).forEach(X => {
                    M.current.on(X, F[X])
                })
            },
            P = () => {
                !F || !M.current || Object.keys(F).forEach(X => {
                    M.current.off(X, F[X])
                })
            };
        J.useEffect(() => () => {
            M.current && M.current.off("_beforeBreakpoint", ee)
        }), J.useEffect(() => {
            !T.current && M.current && (M.current.emitSlidesClasses(), T.current = !0)
        }), Jr(() => {
            if (c && (c.current = S.current), !!S.current) return M.current.destroyed && ae(), pM({
                el: S.current,
                nextEl: C.current,
                prevEl: L.current,
                paginationEl: O.current,
                scrollbarEl: V.current,
                swiper: M.current
            }, k), l && !M.current.destroyed && l(M.current), () => {
                M.current && !M.current.destroyed && M.current.destroy(!0, !1)
            }
        }, []), Jr(() => {
            se();
            const X = gM(D, _.current, I, w.current, te => te.key);
            return _.current = D, w.current = I, X.length && M.current && !M.current.destroyed && hM({
                swiper: M.current,
                slides: I,
                passedParams: D,
                changedParams: X,
                nextEl: C.current,
                prevEl: L.current,
                scrollbarEl: V.current,
                paginationEl: O.current
            }), () => {
                P()
            }
        }), Jr(() => {
            vM(M.current)
        }, [p]);

        function G() {
            return k.virtual ? bM(M.current, I, p) : I.map((X, te) => xe.cloneElement(X, {
                swiper: M.current,
                swiperSlideIndex: te
            }))
        }
        return xe.createElement(e, gu({
            ref: S,
            className: mx(`${f}${n?` ${n}`:""}`)
        }, H), xe.createElement(xM.Provider, {
            value: M.current
        }, W["container-start"], xe.createElement(a, {
            className: dM(k.wrapperClass)
        }, W["wrapper-start"], G(), W["wrapper-end"]), fx(k) && xe.createElement(xe.Fragment, null, xe.createElement("div", {
            ref: L,
            className: "swiper-button-prev"
        }), xe.createElement("div", {
            ref: C,
            className: "swiper-button-next"
        })), hx(k) && xe.createElement("div", {
            ref: V,
            className: "swiper-scrollbar"
        }), dx(k) && xe.createElement("div", {
            ref: O,
            className: "swiper-pagination"
        }), W["container-end"]))
    });
vx.displayName = "Swiper";
const yx = J.forwardRef(({
    tag: n = "div",
    children: e,
    className: a = "",
    swiper: s,
    zoom: l,
    lazy: o,
    virtualIndex: c,
    swiperSlideIndex: h,
    ...f
} = {}, m) => {
    const p = J.useRef(null),
        [v, b] = J.useState("swiper-slide"),
        [y, T] = J.useState(!1);

    function S(C, L, O) {
        L === p.current && b(O)
    }
    Jr(() => {
        if (typeof h < "u" && (p.current.swiperSlideIndex = h), m && (m.current = p.current), !(!p.current || !s)) {
            if (s.destroyed) {
                v !== "swiper-slide" && b("swiper-slide");
                return
            }
            return s.on("_slideClass", S), () => {
                s && s.off("_slideClass", S)
            }
        }
    }), Jr(() => {
        s && p.current && !s.destroyed && b(s.getSlideClasses(p.current))
    }, [s]);
    const M = {
            isActive: v.indexOf("swiper-slide-active") >= 0,
            isVisible: v.indexOf("swiper-slide-visible") >= 0,
            isPrev: v.indexOf("swiper-slide-prev") >= 0,
            isNext: v.indexOf("swiper-slide-next") >= 0
        },
        _ = () => typeof e == "function" ? e(M) : e,
        w = () => {
            T(!0)
        };
    return xe.createElement(n, gu({
        ref: p,
        className: mx(`${v}${a?` ${a}`:""}`),
        "data-swiper-slide-index": c,
        onLoad: w
    }, f), l && xe.createElement(oy.Provider, {
        value: M
    }, xe.createElement("div", {
        className: "swiper-zoom-container",
        "data-swiper-zoom": typeof l == "number" ? l : void 0
    }, _(), o && !y && xe.createElement("div", {
        className: "swiper-lazy-preloader",
        ref: C => {
            C && (C.lazyPreloaderManaged = !0)
        }
    }))), !l && xe.createElement(oy.Provider, {
        value: M
    }, _(), o && !y && xe.createElement("div", {
        className: "swiper-lazy-preloader",
        ref: C => {
            C && (C.lazyPreloaderManaged = !0)
        }
    })))
});
yx.displayName = "SwiperSlide";

function bx(n, e, a, s) {
    return n.params.createElements && Object.keys(s).forEach(l => {
        if (!a[l] && a.auto === !0) {
            let o = Ln(n.el, `.${s[l]}`)[0];
            o || (o = ml("div", s[l]), o.className = s[l], n.el.append(o)), a[l] = o, e[l] = o
        }
    }), a
}
const uy = '<svg class="swiper-navigation-icon" width="11" height="20" viewBox="0 0 11 20" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M0.38296 20.0762C0.111788 19.805 0.111788 19.3654 0.38296 19.0942L9.19758 10.2796L0.38296 1.46497C0.111788 1.19379 0.111788 0.754138 0.38296 0.482966C0.654131 0.211794 1.09379 0.211794 1.36496 0.482966L10.4341 9.55214C10.8359 9.9539 10.8359 10.6053 10.4341 11.007L1.36496 20.0762C1.09379 20.3474 0.654131 20.3474 0.38296 20.0762Z" fill="currentColor"/></svg>';

function SM({
    swiper: n,
    extendParams: e,
    on: a,
    emit: s
}) {
    e({
        navigation: {
            nextEl: null,
            prevEl: null,
            addIcons: !0,
            hideOnClick: !1,
            disabledClass: "swiper-button-disabled",
            hiddenClass: "swiper-button-hidden",
            lockClass: "swiper-button-lock",
            navigationDisabledClass: "swiper-navigation-disabled"
        }
    }), n.navigation = {
        nextEl: null,
        prevEl: null,
        arrowSvg: uy
    };

    function l(y) {
        let T;
        return y && typeof y == "string" && n.isElement && (T = n.el.querySelector(y) || n.hostEl.querySelector(y), T) ? T : (y && (typeof y == "string" && (T = [...document.querySelectorAll(y)]), n.params.uniqueNavElements && typeof y == "string" && T && T.length > 1 && n.el.querySelectorAll(y).length === 1 ? T = n.el.querySelector(y) : T && T.length === 1 && (T = T[0])), y && !T ? y : T)
    }

    function o(y, T) {
        const S = n.params.navigation;
        y = ut(y), y.forEach(M => {
            M && (M.classList[T ? "add" : "remove"](...S.disabledClass.split(" ")), M.tagName === "BUTTON" && (M.disabled = T), n.params.watchOverflow && n.enabled && M.classList[n.isLocked ? "add" : "remove"](S.lockClass))
        })
    }

    function c() {
        const {
            nextEl: y,
            prevEl: T
        } = n.navigation;
        if (n.params.loop) {
            o(T, !1), o(y, !1);
            return
        }
        o(T, n.isBeginning && !n.params.rewind), o(y, n.isEnd && !n.params.rewind)
    }

    function h(y) {
        y.preventDefault(), !(n.isBeginning && !n.params.loop && !n.params.rewind) && (n.slidePrev(), s("navigationPrev"))
    }

    function f(y) {
        y.preventDefault(), !(n.isEnd && !n.params.loop && !n.params.rewind) && (n.slideNext(), s("navigationNext"))
    }

    function m() {
        const y = n.params.navigation;
        if (n.params.navigation = bx(n, n.originalParams.navigation, n.params.navigation, {
                nextEl: "swiper-button-next",
                prevEl: "swiper-button-prev"
            }), !(y.nextEl || y.prevEl)) return;
        let T = l(y.nextEl),
            S = l(y.prevEl);
        Object.assign(n.navigation, {
            nextEl: T,
            prevEl: S
        }), T = ut(T), S = ut(S);
        const M = (_, w) => {
            if (_) {
                if (y.addIcons && _.matches(".swiper-button-next,.swiper-button-prev") && !_.querySelector("svg")) {
                    const C = document.createElement("div");
                    pl(C, uy), _.appendChild(C.querySelector("svg")), C.remove()
                }
                _.addEventListener("click", w === "next" ? f : h)
            }!n.enabled && _ && _.classList.add(...y.lockClass.split(" "))
        };
        T.forEach(_ => M(_, "next")), S.forEach(_ => M(_, "prev"))
    }

    function p() {
        let {
            nextEl: y,
            prevEl: T
        } = n.navigation;
        y = ut(y), T = ut(T);
        const S = (M, _) => {
            M.removeEventListener("click", _ === "next" ? f : h), M.classList.remove(...n.params.navigation.disabledClass.split(" "))
        };
        y.forEach(M => S(M, "next")), T.forEach(M => S(M, "prev"))
    }
    a("init", () => {
        n.params.navigation.enabled === !1 ? b() : (m(), c())
    }), a("toEdge fromEdge lock unlock", () => {
        c()
    }), a("destroy", () => {
        p()
    }), a("enable disable", () => {
        let {
            nextEl: y,
            prevEl: T
        } = n.navigation;
        if (y = ut(y), T = ut(T), n.enabled) {
            c();
            return
        }[...y, ...T].filter(S => !!S).forEach(S => S.classList.add(n.params.navigation.lockClass))
    }), a("click", (y, T) => {
        let {
            nextEl: S,
            prevEl: M
        } = n.navigation;
        S = ut(S), M = ut(M);
        const _ = T.target;
        let w = M.includes(_) || S.includes(_);
        if (n.isElement && !w) {
            const C = T.path || T.composedPath && T.composedPath();
            C && (w = C.find(L => S.includes(L) || M.includes(L)))
        }
        if (n.params.navigation.hideOnClick && !w) {
            if (n.pagination && n.params.pagination && n.params.pagination.clickable && (n.pagination.el === _ || n.pagination.el.contains(_))) return;
            let C;
            S.length ? C = S[0].classList.contains(n.params.navigation.hiddenClass) : M.length && (C = M[0].classList.contains(n.params.navigation.hiddenClass)), s(C === !0 ? "navigationShow" : "navigationHide"), [...S, ...M].filter(L => !!L).forEach(L => L.classList.toggle(n.params.navigation.hiddenClass))
        }
    });
    const v = () => {
            n.el.classList.remove(...n.params.navigation.navigationDisabledClass.split(" ")), m(), c()
        },
        b = () => {
            n.el.classList.add(...n.params.navigation.navigationDisabledClass.split(" ")), p()
        };
    Object.assign(n.navigation, {
        enable: v,
        disable: b,
        update: c,
        init: m,
        destroy: p
    })
}

function Pr(n = "") {
    return `.${n.trim().replace(/([\.:!+\/()[\]#>~*^$|=,'"@{}\\])/g,"\\$1").replace(/ /g,".")}`
}

function TM({
    swiper: n,
    extendParams: e,
    on: a,
    emit: s
}) {
    const l = "swiper-pagination";
    e({
        pagination: {
            el: null,
            bulletElement: "span",
            clickable: !1,
            hideOnClick: !1,
            renderBullet: null,
            renderProgressbar: null,
            renderFraction: null,
            renderCustom: null,
            progressbarOpposite: !1,
            type: "bullets",
            dynamicBullets: !1,
            dynamicMainBullets: 1,
            formatFractionCurrent: _ => _,
            formatFractionTotal: _ => _,
            bulletClass: `${l}-bullet`,
            bulletActiveClass: `${l}-bullet-active`,
            modifierClass: `${l}-`,
            currentClass: `${l}-current`,
            totalClass: `${l}-total`,
            hiddenClass: `${l}-hidden`,
            progressbarFillClass: `${l}-progressbar-fill`,
            progressbarOppositeClass: `${l}-progressbar-opposite`,
            clickableClass: `${l}-clickable`,
            lockClass: `${l}-lock`,
            horizontalClass: `${l}-horizontal`,
            verticalClass: `${l}-vertical`,
            paginationDisabledClass: `${l}-disabled`
        }
    }), n.pagination = {
        el: null,
        bullets: []
    };
    let o, c = 0;

    function h() {
        return !n.params.pagination.el || !n.pagination.el || Array.isArray(n.pagination.el) && n.pagination.el.length === 0
    }

    function f(_, w) {
        const {
            bulletActiveClass: C
        } = n.params.pagination;
        _ && (_ = _[`${w==="prev"?"previous":"next"}ElementSibling`], _ && (_.classList.add(`${C}-${w}`), _ = _[`${w==="prev"?"previous":"next"}ElementSibling`], _ && _.classList.add(`${C}-${w}-${w}`)))
    }

    function m(_, w, C) {
        if (_ = _ % C, w = w % C, w === _ + 1) return "next";
        if (w === _ - 1) return "previous"
    }

    function p(_) {
        const w = _.target.closest(Pr(n.params.pagination.bulletClass));
        if (!w) return;
        _.preventDefault();
        const C = pu(w) * n.params.slidesPerGroup;
        if (n.params.loop) {
            if (n.realIndex === C) return;
            const L = m(n.realIndex, C, n.slides.length);
            L === "next" ? n.slideNext() : L === "previous" ? n.slidePrev() : n.slideToLoop(C)
        } else n.slideTo(C)
    }

    function v() {
        const _ = n.rtl,
            w = n.params.pagination;
        if (h()) return;
        let C = n.pagination.el;
        C = ut(C);
        let L, O;
        const V = n.virtual && n.params.virtual.enabled ? n.virtual.slides.length : n.slides.length,
            k = n.params.loop ? Math.ceil(V / n.params.slidesPerGroup) : n.snapGrid.length;
        if (n.params.loop ? (O = n.previousRealIndex || 0, L = n.params.slidesPerGroup > 1 ? Math.floor(n.realIndex / n.params.slidesPerGroup) : n.realIndex) : typeof n.snapIndex < "u" ? (L = n.snapIndex, O = n.previousSnapIndex) : (O = n.previousIndex || 0, L = n.activeIndex || 0), w.type === "bullets" && n.pagination.bullets && n.pagination.bullets.length > 0) {
            const D = n.pagination.bullets;
            let H, F, I;
            if (w.dynamicBullets && (o = ch(D[0], n.isHorizontal() ? "width" : "height"), C.forEach(W => {
                    W.style[n.isHorizontal() ? "width" : "height"] = `${o*(w.dynamicMainBullets+4)}px`
                }), w.dynamicMainBullets > 1 && O !== void 0 && (c += L - (O || 0), c > w.dynamicMainBullets - 1 ? c = w.dynamicMainBullets - 1 : c < 0 && (c = 0)), H = Math.max(L - c, 0), F = H + (Math.min(D.length, w.dynamicMainBullets) - 1), I = (F + H) / 2), D.forEach(W => {
                    const ee = [...["", "-next", "-next-next", "-prev", "-prev-prev", "-main"].map(ae => `${w.bulletActiveClass}${ae}`)].map(ae => typeof ae == "string" && ae.includes(" ") ? ae.split(" ") : ae).flat();
                    W.classList.remove(...ee)
                }), C.length > 1) D.forEach(W => {
                const ee = pu(W);
                ee === L ? W.classList.add(...w.bulletActiveClass.split(" ")) : n.isElement && W.setAttribute("part", "bullet"), w.dynamicBullets && (ee >= H && ee <= F && W.classList.add(...`${w.bulletActiveClass}-main`.split(" ")), ee === H && f(W, "prev"), ee === F && f(W, "next"))
            });
            else {
                const W = D[L];
                if (W && W.classList.add(...w.bulletActiveClass.split(" ")), n.isElement && D.forEach((ee, ae) => {
                        ee.setAttribute("part", ae === L ? "bullet-active" : "bullet")
                    }), w.dynamicBullets) {
                    const ee = D[H],
                        ae = D[F];
                    for (let se = H; se <= F; se += 1) D[se] && D[se].classList.add(...`${w.bulletActiveClass}-main`.split(" "));
                    f(ee, "prev"), f(ae, "next")
                }
            }
            if (w.dynamicBullets) {
                const W = Math.min(D.length, w.dynamicMainBullets + 4),
                    ee = (o * W - o) / 2 - I * o,
                    ae = _ ? "right" : "left";
                D.forEach(se => {
                    se.style[n.isHorizontal() ? ae : "top"] = `${ee}px`
                })
            }
        }
        C.forEach((D, H) => {
            if (w.type === "fraction" && (D.querySelectorAll(Pr(w.currentClass)).forEach(F => {
                    F.textContent = w.formatFractionCurrent(L + 1)
                }), D.querySelectorAll(Pr(w.totalClass)).forEach(F => {
                    F.textContent = w.formatFractionTotal(k)
                })), w.type === "progressbar") {
                let F;
                w.progressbarOpposite ? F = n.isHorizontal() ? "vertical" : "horizontal" : F = n.isHorizontal() ? "horizontal" : "vertical";
                const I = (L + 1) / k;
                let W = 1,
                    ee = 1;
                F === "horizontal" ? W = I : ee = I, D.querySelectorAll(Pr(w.progressbarFillClass)).forEach(ae => {
                    ae.style.transform = `translate3d(0,0,0) scaleX(${W}) scaleY(${ee})`, ae.style.transitionDuration = `${n.params.speed}ms`
                })
            }
            w.type === "custom" && w.renderCustom ? (pl(D, w.renderCustom(n, L + 1, k)), H === 0 && s("paginationRender", D)) : (H === 0 && s("paginationRender", D), s("paginationUpdate", D)), n.params.watchOverflow && n.enabled && D.classList[n.isLocked ? "add" : "remove"](w.lockClass)
        })
    }

    function b() {
        const _ = n.params.pagination;
        if (h()) return;
        const w = n.virtual && n.params.virtual.enabled ? n.virtual.slides.length : n.grid && n.params.grid.rows > 1 ? n.slides.length / Math.ceil(n.params.grid.rows) : n.slides.length;
        let C = n.pagination.el;
        C = ut(C);
        let L = "";
        if (_.type === "bullets") {
            let O = n.params.loop ? Math.ceil(w / n.params.slidesPerGroup) : n.snapGrid.length;
            n.params.freeMode && n.params.freeMode.enabled && O > w && (O = w);
            for (let V = 0; V < O; V += 1) _.renderBullet ? L += _.renderBullet.call(n, V, _.bulletClass) : L += `<${_.bulletElement} ${n.isElement?'part="bullet"':""} class="${_.bulletClass}"></${_.bulletElement}>`
        }
        _.type === "fraction" && (_.renderFraction ? L = _.renderFraction.call(n, _.currentClass, _.totalClass) : L = `<span class="${_.currentClass}"></span> / <span class="${_.totalClass}"></span>`), _.type === "progressbar" && (_.renderProgressbar ? L = _.renderProgressbar.call(n, _.progressbarFillClass) : L = `<span class="${_.progressbarFillClass}"></span>`), n.pagination.bullets = [], C.forEach(O => {
            _.type !== "custom" && pl(O, L || ""), _.type === "bullets" && n.pagination.bullets.push(...O.querySelectorAll(Pr(_.bulletClass)))
        }), _.type !== "custom" && s("paginationRender", C[0])
    }

    function y() {
        n.params.pagination = bx(n, n.originalParams.pagination, n.params.pagination, {
            el: "swiper-pagination"
        });
        const _ = n.params.pagination;
        if (!_.el) return;
        let w;
        typeof _.el == "string" && n.isElement && (w = n.el.querySelector(_.el)), !w && typeof _.el == "string" && (w = [...document.querySelectorAll(_.el)]), w || (w = _.el), !(!w || w.length === 0) && (n.params.uniqueNavElements && typeof _.el == "string" && Array.isArray(w) && w.length > 1 && (w = [...n.el.querySelectorAll(_.el)], w.length > 1 && (w = w.find(C => ax(C, ".swiper")[0] === n.el))), Array.isArray(w) && w.length === 1 && (w = w[0]), Object.assign(n.pagination, {
            el: w
        }), w = ut(w), w.forEach(C => {
            _.type === "bullets" && _.clickable && C.classList.add(...(_.clickableClass || "").split(" ")), C.classList.add(_.modifierClass + _.type), C.classList.add(n.isHorizontal() ? _.horizontalClass : _.verticalClass), _.type === "bullets" && _.dynamicBullets && (C.classList.add(`${_.modifierClass}${_.type}-dynamic`), c = 0, _.dynamicMainBullets < 1 && (_.dynamicMainBullets = 1)), _.type === "progressbar" && _.progressbarOpposite && C.classList.add(_.progressbarOppositeClass), _.clickable && C.addEventListener("click", p), n.enabled || C.classList.add(_.lockClass)
        }))
    }

    function T() {
        const _ = n.params.pagination;
        if (h()) return;
        let w = n.pagination.el;
        w && (w = ut(w), w.forEach(C => {
            C.classList.remove(_.hiddenClass), C.classList.remove(_.modifierClass + _.type), C.classList.remove(n.isHorizontal() ? _.horizontalClass : _.verticalClass), _.clickable && (C.classList.remove(...(_.clickableClass || "").split(" ")), C.removeEventListener("click", p))
        })), n.pagination.bullets && n.pagination.bullets.forEach(C => C.classList.remove(..._.bulletActiveClass.split(" ")))
    }
    a("changeDirection", () => {
        if (!n.pagination || !n.pagination.el) return;
        const _ = n.params.pagination;
        let {
            el: w
        } = n.pagination;
        w = ut(w), w.forEach(C => {
            C.classList.remove(_.horizontalClass, _.verticalClass), C.classList.add(n.isHorizontal() ? _.horizontalClass : _.verticalClass)
        })
    }), a("init", () => {
        n.params.pagination.enabled === !1 ? M() : (y(), b(), v())
    }), a("activeIndexChange", () => {
        typeof n.snapIndex > "u" && v()
    }), a("snapIndexChange", () => {
        v()
    }), a("snapGridLengthChange", () => {
        b(), v()
    }), a("destroy", () => {
        T()
    }), a("enable disable", () => {
        let {
            el: _
        } = n.pagination;
        _ && (_ = ut(_), _.forEach(w => w.classList[n.enabled ? "remove" : "add"](n.params.pagination.lockClass)))
    }), a("lock unlock", () => {
        v()
    }), a("click", (_, w) => {
        const C = w.target,
            L = ut(n.pagination.el);
        if (n.params.pagination.el && n.params.pagination.hideOnClick && L && L.length > 0 && !C.classList.contains(n.params.pagination.bulletClass)) {
            if (n.navigation && (n.navigation.nextEl && C === n.navigation.nextEl || n.navigation.prevEl && C === n.navigation.prevEl)) return;
            const O = L[0].classList.contains(n.params.pagination.hiddenClass);
            s(O === !0 ? "paginationShow" : "paginationHide"), L.forEach(V => V.classList.toggle(n.params.pagination.hiddenClass))
        }
    });
    const S = () => {
            n.el.classList.remove(n.params.pagination.paginationDisabledClass);
            let {
                el: _
            } = n.pagination;
            _ && (_ = ut(_), _.forEach(w => w.classList.remove(n.params.pagination.paginationDisabledClass))), y(), b(), v()
        },
        M = () => {
            n.el.classList.add(n.params.pagination.paginationDisabledClass);
            let {
                el: _
            } = n.pagination;
            _ && (_ = ut(_), _.forEach(w => w.classList.add(n.params.pagination.paginationDisabledClass))), T()
        };
    Object.assign(n.pagination, {
        enable: S,
        disable: M,
        render: b,
        update: v,
        init: y,
        destroy: T
    })
}

function _M({
    swiper: n,
    extendParams: e,
    on: a,
    emit: s,
    params: l
}) {
    n.autoplay = {
        running: !1,
        paused: !1,
        timeLeft: 0
    }, e({
        autoplay: {
            enabled: !1,
            delay: 3e3,
            waitForTransition: !0,
            disableOnInteraction: !1,
            stopOnLastSlide: !1,
            reverseDirection: !1,
            pauseOnMouseEnter: !1
        }
    });
    let o, c, h = l && l.autoplay ? l.autoplay.delay : 3e3,
        f = l && l.autoplay ? l.autoplay.delay : 3e3,
        m, p = new Date().getTime(),
        v, b, y, T, S, M;

    function _(G) {
        !n || n.destroyed || !n.wrapperEl || G.target === n.wrapperEl && (n.wrapperEl.removeEventListener("transitionend", _), !(M || G.detail && G.detail.bySwiperTouchMove) && H())
    }
    const w = () => {
            if (n.destroyed || !n.autoplay.running) return;
            n.autoplay.paused ? v = !0 : v && (f = m, v = !1);
            const G = n.autoplay.paused ? m : p + f - new Date().getTime();
            n.autoplay.timeLeft = G, s("autoplayTimeLeft", G, G / h), c = requestAnimationFrame(() => {
                w()
            })
        },
        C = () => {
            let G;
            return n.virtual && n.params.virtual.enabled ? G = n.slides.find(te => te.classList.contains("swiper-slide-active")) : G = n.slides[n.activeIndex], G ? parseInt(G.getAttribute("data-swiper-autoplay"), 10) : void 0
        },
        L = () => {
            let G = n.params.autoplay.delay;
            const X = C();
            return !Number.isNaN(X) && X > 0 && (G = X), G
        },
        O = G => {
            if (n.destroyed || !n.autoplay.running) return;
            cancelAnimationFrame(c), w();
            let X = G;
            typeof X > "u" && (X = L(), h = X, f = X), m = X;
            const te = n.params.speed,
                z = () => {
                    !n || n.destroyed || (n.params.autoplay.reverseDirection ? !n.isBeginning || n.params.loop || n.params.rewind ? (n.slidePrev(te, !0, !0), s("autoplay")) : n.params.autoplay.stopOnLastSlide || (n.slideTo(n.slides.length - 1, te, !0, !0), s("autoplay")) : !n.isEnd || n.params.loop || n.params.rewind ? (n.slideNext(te, !0, !0), s("autoplay")) : n.params.autoplay.stopOnLastSlide || (n.slideTo(0, te, !0, !0), s("autoplay")), n.params.cssMode && (p = new Date().getTime(), requestAnimationFrame(() => {
                        O()
                    })))
                };
            return X > 0 ? (clearTimeout(o), o = setTimeout(() => {
                z()
            }, X)) : requestAnimationFrame(() => {
                z()
            }), X
        },
        V = () => {
            p = new Date().getTime(), n.autoplay.running = !0, O(), s("autoplayStart")
        },
        k = () => {
            n.autoplay.running = !1, clearTimeout(o), cancelAnimationFrame(c), s("autoplayStop")
        },
        D = (G, X) => {
            if (n.destroyed || !n.autoplay.running) return;
            clearTimeout(o), G || (S = !0);
            const te = () => {
                s("autoplayPause"), n.params.autoplay.waitForTransition ? n.wrapperEl.addEventListener("transitionend", _) : H()
            };
            if (n.autoplay.paused = !0, X) {
                te();
                return
            }
            m = (m || n.params.autoplay.delay) - (new Date().getTime() - p), !(n.isEnd && m < 0 && !n.params.loop) && (m < 0 && (m = 0), te())
        },
        H = () => {
            n.isEnd && m < 0 && !n.params.loop || n.destroyed || !n.autoplay.running || (p = new Date().getTime(), S ? (S = !1, O(m)) : O(), n.autoplay.paused = !1, s("autoplayResume"))
        },
        F = () => {
            if (n.destroyed || !n.autoplay.running) return;
            const G = Vn();
            G.visibilityState === "hidden" && (S = !0, D(!0)), G.visibilityState === "visible" && H()
        },
        I = G => {
            G.pointerType === "mouse" && (S = !0, M = !0, !(n.animating || n.autoplay.paused) && D(!0))
        },
        W = G => {
            G.pointerType === "mouse" && (M = !1, n.autoplay.paused && H())
        },
        ee = () => {
            n.params.autoplay.pauseOnMouseEnter && (n.el.addEventListener("pointerenter", I), n.el.addEventListener("pointerleave", W))
        },
        ae = () => {
            n.el && typeof n.el != "string" && (n.el.removeEventListener("pointerenter", I), n.el.removeEventListener("pointerleave", W))
        },
        se = () => {
            Vn().addEventListener("visibilitychange", F)
        },
        P = () => {
            Vn().removeEventListener("visibilitychange", F)
        };
    a("init", () => {
        n.params.autoplay.enabled && (ee(), se(), V())
    }), a("destroy", () => {
        ae(), P(), n.autoplay.running && k()
    }), a("_freeModeStaticRelease", () => {
        (y || S) && H()
    }), a("_freeModeNoMomentumRelease", () => {
        n.params.autoplay.disableOnInteraction ? k() : D(!0, !0)
    }), a("beforeTransitionStart", (G, X, te) => {
        n.destroyed || !n.autoplay.running || (te || !n.params.autoplay.disableOnInteraction ? D(!0, !0) : k())
    }), a("sliderFirstMove", () => {
        if (!(n.destroyed || !n.autoplay.running)) {
            if (n.params.autoplay.disableOnInteraction) {
                k();
                return
            }
            b = !0, y = !1, S = !1, T = setTimeout(() => {
                S = !0, y = !0, D(!0)
            }, 200)
        }
    }), a("touchEnd", () => {
        if (!(n.destroyed || !n.autoplay.running || !b)) {
            if (clearTimeout(T), clearTimeout(o), n.params.autoplay.disableOnInteraction) {
                y = !1, b = !1;
                return
            }
            y && n.params.cssMode && H(), y = !1, b = !1
        }
    }), a("slideChange", () => {
        n.destroyed || !n.autoplay.running || n.autoplay.paused && (m = L(), h = L())
    }), Object.assign(n.autoplay, {
        start: V,
        stop: k,
        pause: D,
        resume: H
    })
}

function EM(n) {
    const {
        effect: e,
        swiper: a,
        on: s,
        setTranslate: l,
        setTransition: o,
        overwriteParams: c,
        perspective: h,
        recreateShadows: f,
        getEffectParams: m
    } = n;
    s("beforeInit", () => {
        if (a.params.effect !== e) return;
        a.classNames.push(`${a.params.containerModifierClass}${e}`), h && h() && a.classNames.push(`${a.params.containerModifierClass}3d`);
        const v = c ? c() : {};
        Object.assign(a.params, v), Object.assign(a.originalParams, v)
    }), s("setTranslate _virtualUpdated", () => {
        a.params.effect === e && l()
    }), s("setTransition", (v, b) => {
        a.params.effect === e && o(b)
    }), s("transitionEnd", () => {
        if (a.params.effect === e && f) {
            if (!m || !m().slideShadows) return;
            a.slides.forEach(v => {
                v.querySelectorAll(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").forEach(b => b.remove())
            }), f()
        }
    });
    let p;
    s("virtualUpdate", () => {
        a.params.effect === e && (a.slides.length || (p = !0), requestAnimationFrame(() => {
            p && a.slides && a.slides.length && (l(), p = !1)
        }))
    })
}

function wM(n, e) {
    const a = ym(e);
    return a !== e && (a.style.backfaceVisibility = "hidden", a.style["-webkit-backface-visibility"] = "hidden"), a
}

function cy(n, e, a) {
    const s = `swiper-slide-shadow${a?`-${a}`:""}${` swiper-slide-shadow-${n}`}`,
        l = ym(e);
    let o = l.querySelector(`.${s.split(" ").join(".")}`);
    return o || (o = ml("div", s.split(" ")), l.append(o)), o
}

function MM({
    swiper: n,
    extendParams: e,
    on: a
}) {
    e({
        coverflowEffect: {
            rotate: 50,
            stretch: 0,
            depth: 100,
            scale: 1,
            modifier: 1,
            slideShadows: !0
        }
    }), EM({
        effect: "coverflow",
        swiper: n,
        on: a,
        setTranslate: () => {
            const {
                width: o,
                height: c,
                slides: h,
                slidesSizesGrid: f
            } = n, m = n.params.coverflowEffect, p = n.isHorizontal(), v = n.translate, b = p ? -v + o / 2 : -v + c / 2, y = p ? m.rotate : -m.rotate, T = m.depth, S = nw(n);
            for (let M = 0, _ = h.length; M < _; M += 1) {
                const w = h[M],
                    C = f[M],
                    L = w.swiperSlideOffset,
                    O = (b - L - C / 2) / C,
                    V = typeof m.modifier == "function" ? m.modifier(O) : O * m.modifier;
                let k = p ? y * V : 0,
                    D = p ? 0 : y * V,
                    H = -T * Math.abs(V),
                    F = m.stretch;
                typeof F == "string" && F.indexOf("%") !== -1 && (F = parseFloat(m.stretch) / 100 * C);
                let I = p ? 0 : F * V,
                    W = p ? F * V : 0,
                    ee = 1 - (1 - m.scale) * Math.abs(V);
                Math.abs(W) < .001 && (W = 0), Math.abs(I) < .001 && (I = 0), Math.abs(H) < .001 && (H = 0), Math.abs(k) < .001 && (k = 0), Math.abs(D) < .001 && (D = 0), Math.abs(ee) < .001 && (ee = 0);
                const ae = `translate3d(${W}px,${I}px,${H}px)  rotateX(${S(D)}deg) rotateY(${S(k)}deg) scale(${ee})`,
                    se = wM(m, w);
                if (se.style.transform = ae, w.style.zIndex = -Math.abs(Math.round(V)) + 1, m.slideShadows) {
                    let P = p ? w.querySelector(".swiper-slide-shadow-left") : w.querySelector(".swiper-slide-shadow-top"),
                        G = p ? w.querySelector(".swiper-slide-shadow-right") : w.querySelector(".swiper-slide-shadow-bottom");
                    P || (P = cy("coverflow", w, p ? "left" : "top")), G || (G = cy("coverflow", w, p ? "right" : "bottom")), P && (P.style.opacity = V > 0 ? V : 0), G && (G.style.opacity = -V > 0 ? -V : 0)
                }
            }
        },
        setTransition: o => {
            n.slides.map(h => ym(h)).forEach(h => {
                h.style.transitionDuration = `${o}ms`, h.querySelectorAll(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").forEach(f => {
                    f.style.transitionDuration = `${o}ms`
                })
            })
        },
        perspective: () => !0,
        overwriteParams: () => ({
            watchSlidesProgress: !0
        })
    })
}
const AM = () => {
    const n = [{
        title: "Im Pflegeheim",
        category: "Erfahrung",
        img: "/gallery/1.png"
    }, {
        title: "In Bildungseinrichtung",
        category: "Bildung",
        img: "/gallery/6.jfif"
    }, {
        title: "In  Krankenhaus",
        category: "Erfahrung",
        img: "/gallery/2.jpg"
    }, {
        title: "In  Krankenhaus",
        category: "Erfahrung",
        img: "/gallery/8.jfif"
    }, {
        title: "In  Krankenhaus",
        category: "Erfahrung",
        img: "/gallery/3.png"
    }, {
        title: " Krankenhaus",
        category: "Erfahrung",
        img: "/gallery/7.jpg"
    }, {
        title: " Bildungseinrichtung",
        category: "Bildung",
        img: "/gallery/4.jpg"
    }, {
        title: "In  Krankenhaus",
        category: "Erfahrung",
        img: "/gallery/5.jpg"
    }, {
        title: "In  Krankenhaus",
        category: "Bildung",
        img: "/gallery/9.jpg"
    }];
    return A.jsxs("section", {
        id: "nachweise",
        className: "py-24 bg-[#f8fafc] dark:bg-[#0f172a] overflow-hidden",
        children: [A.jsxs("div", {
            className: "container mx-auto px-6",
            children: [A.jsxs("div", {
                className: "text-left mb-16 max-w-2xl",
                children: [A.jsx("div", {
                    className: "flex items-center gap-3 mb-4",
                    children: A.jsxs("div", {
                        className: "flex items-center gap-3 mb-4",
                        children: [A.jsx("span", {
                            className: "flex items-center justify-center w-8 h-8 rounded-lg bg-emerald-600 text-white text-xs font-bold shadow-lg shadow-emerald-500/30",
                            children: "02"
                        }), A.jsx("h2", {
                            className: "text-xs font-black uppercase tracking-[0.4em] text-emerald-600/80",
                            children: "Erfahrungen"
                        })]
                    })
                }), A.jsxs("h3", {
                    className: "text-4xl font-bold text-slate-900 dark:text-white mb-4",
                    children: ["Nachweise & ", A.jsx("span", {
                        className: "text-emerald-600",
                        children: "Erfahrungen."
                    })]
                })]
            }), A.jsx(vx, {
                modules: [SM, TM, _M, MM],
                effect: "coverflow",
                grabCursor: !0,
                centeredSlides: !0,
                slidesPerView: "auto",
                coverflowEffect: {
                    rotate: 5,
                    stretch: 0,
                    depth: 100,
                    modifier: 2.5,
                    slideShadows: !1
                },
                autoplay: {
                    delay: 3e3
                },
                pagination: {
                    clickable: !0
                },
                className: "certificate-swiper !pb-20",
                breakpoints: {
                    320: {
                        slidesPerView: 1.1,
                        spaceBetween: 20
                    },
                    768: {
                        slidesPerView: 2,
                        spaceBetween: 30
                    },
                    1024: {
                        slidesPerView: 3,
                        spaceBetween: 40
                    }
                },
                children: n.map((e, a) => A.jsx(yx, {
                    className: "max-w-[380px]",
                    children: A.jsxs("div", {
                        className: "group relative bg-white dark:bg-slate-800 rounded-[2.5rem] overflow-hidden border border-slate-200 dark:border-slate-700 shadow-2xl transition-all duration-500 hover:-translate-y-2",
                        children: [A.jsx("div", {
                            className: "aspect-[4/5] overflow-hidden",
                            children: A.jsx("img", {
                                src: e.img,
                                alt: e.title,
                                className: "w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                            })
                        }), A.jsx("div", {
                            className: "absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent"
                        }), A.jsxs("div", {
                            className: "absolute bottom-0 left-0 w-full p-8",
                            children: [A.jsx("span", {
                                className: "inline-block px-3 py-1 bg-emerald-500 text-[10px] font-black text-white uppercase tracking-widest rounded-md mb-3",
                                children: e.category
                            }), A.jsx("h4", {
                                className: "text-xl font-bold text-white mb-3",
                                children: e.title
                            }), A.jsxs("div", {
                                className: "flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity",
                                children: [A.jsx(A_, {}), " Dokument öffnen"]
                            })]
                        })]
                    })
                }, a))
            })]
        }), A.jsx("style", {
            jsx: "true",
            children: `
        .certificate-swiper .swiper-pagination-bullet {
          background: #10b981;
          opacity: 0.3;
        }
        .certificate-swiper .swiper-pagination-bullet-active {
          width: 25px;
          border-radius: 4px;
          opacity: 1;
        }
      `
        })]
    })
};
var _d, fy;

function CM() {
    if (fy) return _d;
    fy = 1;
    var n = typeof Element < "u",
        e = typeof Map == "function",
        a = typeof Set == "function",
        s = typeof ArrayBuffer == "function" && !!ArrayBuffer.isView;

    function l(o, c) {
        if (o === c) return !0;
        if (o && c && typeof o == "object" && typeof c == "object") {
            if (o.constructor !== c.constructor) return !1;
            var h, f, m;
            if (Array.isArray(o)) {
                if (h = o.length, h != c.length) return !1;
                for (f = h; f-- !== 0;)
                    if (!l(o[f], c[f])) return !1;
                return !0
            }
            var p;
            if (e && o instanceof Map && c instanceof Map) {
                if (o.size !== c.size) return !1;
                for (p = o.entries(); !(f = p.next()).done;)
                    if (!c.has(f.value[0])) return !1;
                for (p = o.entries(); !(f = p.next()).done;)
                    if (!l(f.value[1], c.get(f.value[0]))) return !1;
                return !0
            }
            if (a && o instanceof Set && c instanceof Set) {
                if (o.size !== c.size) return !1;
                for (p = o.entries(); !(f = p.next()).done;)
                    if (!c.has(f.value[0])) return !1;
                return !0
            }
            if (s && ArrayBuffer.isView(o) && ArrayBuffer.isView(c)) {
                if (h = o.length, h != c.length) return !1;
                for (f = h; f-- !== 0;)
                    if (o[f] !== c[f]) return !1;
                return !0
            }
            if (o.constructor === RegExp) return o.source === c.source && o.flags === c.flags;
            if (o.valueOf !== Object.prototype.valueOf && typeof o.valueOf == "function" && typeof c.valueOf == "function") return o.valueOf() === c.valueOf();
            if (o.toString !== Object.prototype.toString && typeof o.toString == "function" && typeof c.toString == "function") return o.toString() === c.toString();
            if (m = Object.keys(o), h = m.length, h !== Object.keys(c).length) return !1;
            for (f = h; f-- !== 0;)
                if (!Object.prototype.hasOwnProperty.call(c, m[f])) return !1;
            if (n && o instanceof Element) return !1;
            for (f = h; f-- !== 0;)
                if (!((m[f] === "_owner" || m[f] === "__v" || m[f] === "__o") && o.$$typeof) && !l(o[m[f]], c[m[f]])) return !1;
            return !0
        }
        return o !== o && c !== c
    }
    return _d = function(c, h) {
        try {
            return l(c, h)
        } catch (f) {
            if ((f.message || "").match(/stack|recursion/i)) return console.warn("react-fast-compare cannot handle circular refs"), !1;
            throw f
        }
    }, _d
}
var OM = CM();
const DM = vu(OM);
var Ed, dy;

function zM() {
    if (dy) return Ed;
    dy = 1;
    var n = function(e, a, s, l, o, c, h, f) {
        if (!e) {
            var m;
            if (a === void 0) m = new Error("Minified exception occurred; use the non-minified dev environment for the full error message and additional helpful warnings.");
            else {
                var p = [s, l, o, c, h, f],
                    v = 0;
                m = new Error(a.replace(/%s/g, function() {
                    return p[v++]
                })), m.name = "Invariant Violation"
            }
            throw m.framesToPop = 1, m
        }
    };
    return Ed = n, Ed
}
var RM = zM();
const hy = vu(RM);
var wd, my;

function LM() {
    return my || (my = 1, wd = function(e, a, s, l) {
        var o = s ? s.call(l, e, a) : void 0;
        if (o !== void 0) return !!o;
        if (e === a) return !0;
        if (typeof e != "object" || !e || typeof a != "object" || !a) return !1;
        var c = Object.keys(e),
            h = Object.keys(a);
        if (c.length !== h.length) return !1;
        for (var f = Object.prototype.hasOwnProperty.bind(a), m = 0; m < c.length; m++) {
            var p = c[m];
            if (!f(p)) return !1;
            var v = e[p],
                b = a[p];
            if (o = s ? s.call(l, v, b, p) : void 0, o === !1 || o === void 0 && v !== b) return !1
        }
        return !0
    }), wd
}
var jM = LM();
const NM = vu(jM);
var xx = (n => (n.BASE = "base", n.BODY = "body", n.HEAD = "head", n.HTML = "html", n.LINK = "link", n.META = "meta", n.NOSCRIPT = "noscript", n.SCRIPT = "script", n.STYLE = "style", n.TITLE = "title", n.FRAGMENT = "Symbol(react.fragment)", n))(xx || {}),
    Md = {
        link: {
            rel: ["amphtml", "canonical", "alternate"]
        },
        script: {
            type: ["application/ld+json"]
        },
        meta: {
            charset: "",
            name: ["generator", "robots", "description"],
            property: ["og:type", "og:title", "og:url", "og:image", "og:image:alt", "og:description", "twitter:url", "twitter:title", "twitter:description", "twitter:image", "twitter:image:alt", "twitter:card", "twitter:site"]
        }
    },
    py = Object.values(xx),
    xm = {
        accesskey: "accessKey",
        charset: "charSet",
        class: "className",
        contenteditable: "contentEditable",
        contextmenu: "contextMenu",
        "http-equiv": "httpEquiv",
        itemprop: "itemProp",
        tabindex: "tabIndex"
    },
    VM = Object.entries(xm).reduce((n, [e, a]) => (n[a] = e, n), {}),
    _n = "data-rh",
    ws = {
        DEFAULT_TITLE: "defaultTitle",
        DEFER: "defer",
        ENCODE_SPECIAL_CHARACTERS: "encodeSpecialCharacters",
        ON_CHANGE_CLIENT_STATE: "onChangeClientState",
        TITLE_TEMPLATE: "titleTemplate",
        PRIORITIZE_SEO_TAGS: "prioritizeSeoTags"
    },
    Ms = (n, e) => {
        for (let a = n.length - 1; a >= 0; a -= 1) {
            const s = n[a];
            if (Object.prototype.hasOwnProperty.call(s, e)) return s[e]
        }
        return null
    },
    kM = n => {
        let e = Ms(n, "title");
        const a = Ms(n, ws.TITLE_TEMPLATE);
        if (Array.isArray(e) && (e = e.join("")), a && e) return a.replace(/%s/g, () => e);
        const s = Ms(n, ws.DEFAULT_TITLE);
        return e || s || void 0
    },
    BM = n => Ms(n, ws.ON_CHANGE_CLIENT_STATE) || (() => {}),
    Ad = (n, e) => e.filter(a => typeof a[n] < "u").map(a => a[n]).reduce((a, s) => ({ ...a,
        ...s
    }), {}),
    PM = (n, e) => e.filter(a => typeof a.base < "u").map(a => a.base).reverse().reduce((a, s) => {
        if (!a.length) {
            const l = Object.keys(s);
            for (let o = 0; o < l.length; o += 1) {
                const h = l[o].toLowerCase();
                if (n.indexOf(h) !== -1 && s[h]) return a.concat(s)
            }
        }
        return a
    }, []),
    UM = n => console && typeof console.warn == "function" && console.warn(n),
    Ur = (n, e, a) => {
        const s = {};
        return a.filter(l => Array.isArray(l[n]) ? !0 : (typeof l[n] < "u" && UM(`Helmet: ${n} should be of type "Array". Instead found type "${typeof l[n]}"`), !1)).map(l => l[n]).reverse().reduce((l, o) => {
            const c = {};
            o.filter(f => {
                let m;
                const p = Object.keys(f);
                for (let b = 0; b < p.length; b += 1) {
                    const y = p[b],
                        T = y.toLowerCase();
                    e.indexOf(T) !== -1 && !(m === "rel" && f[m].toLowerCase() === "canonical") && !(T === "rel" && f[T].toLowerCase() === "stylesheet") && (m = T), e.indexOf(y) !== -1 && (y === "innerHTML" || y === "cssText" || y === "itemprop") && (m = y)
                }
                if (!m || !f[m]) return !1;
                const v = f[m].toLowerCase();
                return s[m] || (s[m] = {}), c[m] || (c[m] = {}), s[m][v] ? !1 : (c[m][v] = !0, !0)
            }).reverse().forEach(f => l.push(f));
            const h = Object.keys(c);
            for (let f = 0; f < h.length; f += 1) {
                const m = h[f],
                    p = { ...s[m],
                        ...c[m]
                    };
                s[m] = p
            }
            return l
        }, []).reverse()
    },
    HM = (n, e) => {
        if (Array.isArray(n) && n.length) {
            for (let a = 0; a < n.length; a += 1)
                if (n[a][e]) return !0
        }
        return !1
    },
    GM = n => ({
        baseTag: PM(["href"], n),
        bodyAttributes: Ad("bodyAttributes", n),
        defer: Ms(n, ws.DEFER),
        encode: Ms(n, ws.ENCODE_SPECIAL_CHARACTERS),
        htmlAttributes: Ad("htmlAttributes", n),
        linkTags: Ur("link", ["rel", "href"], n),
        metaTags: Ur("meta", ["name", "charset", "http-equiv", "property", "itemprop"], n),
        noscriptTags: Ur("noscript", ["innerHTML"], n),
        onChangeClientState: BM(n),
        scriptTags: Ur("script", ["src", "innerHTML"], n),
        styleTags: Ur("style", ["cssText"], n),
        title: kM(n),
        titleAttributes: Ad("titleAttributes", n),
        prioritizeSeoTags: HM(n, ws.PRIORITIZE_SEO_TAGS)
    }),
    Sx = n => Array.isArray(n) ? n.join("") : n,
    qM = (n, e) => {
        const a = Object.keys(n);
        for (let s = 0; s < a.length; s += 1)
            if (e[a[s]] && e[a[s]].includes(n[a[s]])) return !0;
        return !1
    },
    Cd = (n, e) => Array.isArray(n) ? n.reduce((a, s) => (qM(s, e) ? a.priority.push(s) : a.default.push(s), a), {
        priority: [],
        default: []
    }) : {
        default: n,
        priority: []
    },
    gy = (n, e) => ({ ...n,
        [e]: void 0
    }),
    YM = ["noscript", "script", "style"],
    hh = (n, e = !0) => e === !1 ? String(n) : String(n).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;"),
    Tx = n => Object.keys(n).reduce((e, a) => {
        const s = typeof n[a] < "u" ? `${a}="${n[a]}"` : `${a}`;
        return e ? `${e} ${s}` : s
    }, ""),
    XM = (n, e, a, s) => {
        const l = Tx(a),
            o = Sx(e);
        return l ? `<${n} ${_n}="true" ${l}>${hh(o,s)}</${n}>` : `<${n} ${_n}="true">${hh(o,s)}</${n}>`
    },
    FM = (n, e, a = !0) => e.reduce((s, l) => {
        const o = l,
            c = Object.keys(o).filter(m => !(m === "innerHTML" || m === "cssText")).reduce((m, p) => {
                const v = typeof o[p] > "u" ? p : `${p}="${hh(o[p],a)}"`;
                return m ? `${m} ${v}` : v
            }, ""),
            h = o.innerHTML || o.cssText || "",
            f = YM.indexOf(n) === -1;
        return `${s}<${n} ${_n}="true" ${c}${f?"/>":`>${h}</${n}>`}`
    }, ""),
    _x = (n, e = {}) => Object.keys(n).reduce((a, s) => {
        const l = xm[s];
        return a[l || s] = n[s], a
    }, e),
    KM = (n, e, a) => {
        const s = {
                key: e,
                [_n]: !0
            },
            l = _x(a, s);
        return [xe.createElement("title", l, e)]
    },
    Wo = (n, e) => e.map((a, s) => {
        const l = {
            key: s,
            [_n]: !0
        };
        return Object.keys(a).forEach(o => {
            const h = xm[o] || o;
            if (h === "innerHTML" || h === "cssText") {
                const f = a.innerHTML || a.cssText;
                l.dangerouslySetInnerHTML = {
                    __html: f
                }
            } else l[h] = a[o]
        }), xe.createElement(n, l)
    }),
    mn = (n, e, a = !0) => {
        switch (n) {
            case "title":
                return {
                    toComponent: () => KM(n, e.title, e.titleAttributes),
                    toString: () => XM(n, e.title, e.titleAttributes, a)
                };
            case "bodyAttributes":
            case "htmlAttributes":
                return {
                    toComponent: () => _x(e),
                    toString: () => Tx(e)
                };
            default:
                return {
                    toComponent: () => Wo(n, e),
                    toString: () => FM(n, e, a)
                }
        }
    },
    ZM = ({
        metaTags: n,
        linkTags: e,
        scriptTags: a,
        encode: s
    }) => {
        const l = Cd(n, Md.meta),
            o = Cd(e, Md.link),
            c = Cd(a, Md.script);
        return {
            priorityMethods: {
                toComponent: () => [...Wo("meta", l.priority), ...Wo("link", o.priority), ...Wo("script", c.priority)],
                toString: () => `${mn("meta",l.priority,s)} ${mn("link",o.priority,s)} ${mn("script",c.priority,s)}`
            },
            metaTags: l.default,
            linkTags: o.default,
            scriptTags: c.default
        }
    },
    QM = n => {
        const {
            baseTag: e,
            bodyAttributes: a,
            encode: s = !0,
            htmlAttributes: l,
            noscriptTags: o,
            styleTags: c,
            title: h = "",
            titleAttributes: f,
            prioritizeSeoTags: m
        } = n;
        let {
            linkTags: p,
            metaTags: v,
            scriptTags: b
        } = n, y = {
            toComponent: () => {},
            toString: () => ""
        };
        return m && ({
            priorityMethods: y,
            linkTags: p,
            metaTags: v,
            scriptTags: b
        } = ZM(n)), {
            priority: y,
            base: mn("base", e, s),
            bodyAttributes: mn("bodyAttributes", a, s),
            htmlAttributes: mn("htmlAttributes", l, s),
            link: mn("link", p, s),
            meta: mn("meta", v, s),
            noscript: mn("noscript", o, s),
            script: mn("script", b, s),
            style: mn("style", c, s),
            title: mn("title", {
                title: h,
                titleAttributes: f
            }, s)
        }
    },
    mh = QM,
    Go = [],
    Ex = !!(typeof window < "u" && window.document && window.document.createElement),
    ph = class {
        instances = [];
        canUseDOM = Ex;
        context;
        value = {
            setHelmet: n => {
                this.context.helmet = n
            },
            helmetInstances: {
                get: () => this.canUseDOM ? Go : this.instances,
                add: n => {
                    (this.canUseDOM ? Go : this.instances).push(n)
                },
                remove: n => {
                    const e = (this.canUseDOM ? Go : this.instances).indexOf(n);
                    (this.canUseDOM ? Go : this.instances).splice(e, 1)
                }
            }
        };
        constructor(n, e) {
            this.context = n, this.canUseDOM = e || !1, e || (n.helmet = mh({
                baseTag: [],
                bodyAttributes: {},
                htmlAttributes: {},
                linkTags: [],
                metaTags: [],
                noscriptTags: [],
                scriptTags: [],
                styleTags: [],
                title: "",
                titleAttributes: {}
            }))
        }
    },
    IM = {},
    wx = xe.createContext(IM),
    Mx = class Ax extends J.Component {
        static canUseDOM = Ex;
        helmetData;
        constructor(e) {
            super(e), this.helmetData = new ph(this.props.context || {}, Ax.canUseDOM)
        }
        render() {
            return xe.createElement(wx.Provider, {
                value: this.helmetData.value
            }, this.props.children)
        }
    },
    ds = (n, e) => {
        const a = document.head || document.querySelector("head"),
            s = a.querySelectorAll(`${n}[${_n}]`),
            l = [].slice.call(s),
            o = [];
        let c;
        return e && e.length && e.forEach(h => {
            const f = document.createElement(n);
            for (const m in h)
                if (Object.prototype.hasOwnProperty.call(h, m))
                    if (m === "innerHTML") f.innerHTML = h.innerHTML;
                    else if (m === "cssText") f.styleSheet ? f.styleSheet.cssText = h.cssText : f.appendChild(document.createTextNode(h.cssText));
            else {
                const p = m,
                    v = typeof h[p] > "u" ? "" : h[p];
                f.setAttribute(m, v)
            }
            f.setAttribute(_n, "true"), l.some((m, p) => (c = p, f.isEqualNode(m))) ? l.splice(c, 1) : o.push(f)
        }), l.forEach(h => h.parentNode ? .removeChild(h)), o.forEach(h => a.appendChild(h)), {
            oldTags: l,
            newTags: o
        }
    },
    gh = (n, e) => {
        const a = document.getElementsByTagName(n)[0];
        if (!a) return;
        const s = a.getAttribute(_n),
            l = s ? s.split(",") : [],
            o = [...l],
            c = Object.keys(e);
        for (const h of c) {
            const f = e[h] || "";
            a.getAttribute(h) !== f && a.setAttribute(h, f), l.indexOf(h) === -1 && l.push(h);
            const m = o.indexOf(h);
            m !== -1 && o.splice(m, 1)
        }
        for (let h = o.length - 1; h >= 0; h -= 1) a.removeAttribute(o[h]);
        l.length === o.length ? a.removeAttribute(_n) : a.getAttribute(_n) !== c.join(",") && a.setAttribute(_n, c.join(","))
    },
    $M = (n, e) => {
        typeof n < "u" && document.title !== n && (document.title = Sx(n)), gh("title", e)
    },
    vy = (n, e) => {
        const {
            baseTag: a,
            bodyAttributes: s,
            htmlAttributes: l,
            linkTags: o,
            metaTags: c,
            noscriptTags: h,
            onChangeClientState: f,
            scriptTags: m,
            styleTags: p,
            title: v,
            titleAttributes: b
        } = n;
        gh("body", s), gh("html", l), $M(v, b);
        const y = {
                baseTag: ds("base", a),
                linkTags: ds("link", o),
                metaTags: ds("meta", c),
                noscriptTags: ds("noscript", h),
                scriptTags: ds("script", m),
                styleTags: ds("style", p)
            },
            T = {},
            S = {};
        Object.keys(y).forEach(M => {
            const {
                newTags: _,
                oldTags: w
            } = y[M];
            _.length && (T[M] = _), w.length && (S[M] = y[M].oldTags)
        }), e && e(), f(n, T, S)
    },
    Hr = null,
    WM = n => {
        Hr && cancelAnimationFrame(Hr), n.defer ? Hr = requestAnimationFrame(() => {
            vy(n, () => {
                Hr = null
            })
        }) : (vy(n), Hr = null)
    },
    JM = WM,
    yy = class extends J.Component {
        rendered = !1;
        shouldComponentUpdate(n) {
            return !NM(n, this.props)
        }
        componentDidUpdate() {
            this.emitChange()
        }
        componentWillUnmount() {
            const {
                helmetInstances: n
            } = this.props.context;
            n.remove(this), this.emitChange()
        }
        emitChange() {
            const {
                helmetInstances: n,
                setHelmet: e
            } = this.props.context;
            let a = null;
            const s = GM(n.get().map(l => {
                const o = { ...l.props
                };
                return delete o.context, o
            }));
            Mx.canUseDOM ? JM(s) : mh && (a = mh(s)), e(a)
        }
        init() {
            if (this.rendered) return;
            this.rendered = !0;
            const {
                helmetInstances: n
            } = this.props.context;
            n.add(this), this.emitChange()
        }
        render() {
            return this.init(), null
        }
    },
    eA = class extends J.Component {
        static defaultProps = {
            defer: !0,
            encodeSpecialCharacters: !0,
            prioritizeSeoTags: !1
        };
        shouldComponentUpdate(n) {
            return !DM(gy(this.props, "helmetData"), gy(n, "helmetData"))
        }
        mapNestedChildrenToProps(n, e) {
            if (!e) return null;
            switch (n.type) {
                case "script":
                case "noscript":
                    return {
                        innerHTML: e
                    };
                case "style":
                    return {
                        cssText: e
                    };
                default:
                    throw new Error(`<${n.type} /> elements are self-closing and can not contain children. Refer to our API for more information.`)
            }
        }
        flattenArrayTypeChildren(n, e, a, s) {
            return { ...e,
                [n.type]: [...e[n.type] || [], { ...a,
                    ...this.mapNestedChildrenToProps(n, s)
                }]
            }
        }
        mapObjectTypeChildren(n, e, a, s) {
            switch (n.type) {
                case "title":
                    return { ...e,
                        [n.type]: s,
                        titleAttributes: { ...a
                        }
                    };
                case "body":
                    return { ...e,
                        bodyAttributes: { ...a
                        }
                    };
                case "html":
                    return { ...e,
                        htmlAttributes: { ...a
                        }
                    };
                default:
                    return { ...e,
                        [n.type]: { ...a
                        }
                    }
            }
        }
        mapArrayTypeChildrenToProps(n, e) {
            let a = { ...e
            };
            return Object.keys(n).forEach(s => {
                a = { ...a,
                    [s]: n[s]
                }
            }), a
        }
        warnOnInvalidChildren(n, e) {
            return hy(py.some(a => n.type === a), typeof n.type == "function" ? "You may be attempting to nest <Helmet> components within each other, which is not allowed. Refer to our API for more information." : `Only elements types ${py.join(", ")} are allowed. Helmet does not support rendering <${n.type}> elements. Refer to our API for more information.`), hy(!e || typeof e == "string" || Array.isArray(e) && !e.some(a => typeof a != "string"), `Helmet expects a string as a child of <${n.type}>. Did you forget to wrap your children in braces? ( <${n.type}>{\`\`}</${n.type}> ) Refer to our API for more information.`), !0
        }
        mapChildrenToProps(n, e) {
            let a = {};
            return xe.Children.forEach(n, s => {
                if (!s || !s.props) return;
                const {
                    children: l,
                    ...o
                } = s.props, c = Object.keys(o).reduce((f, m) => (f[VM[m] || m] = o[m], f), {});
                let {
                    type: h
                } = s;
                switch (typeof h == "symbol" ? h = h.toString() : this.warnOnInvalidChildren(s, l), h) {
                    case "Symbol(react.fragment)":
                        e = this.mapChildrenToProps(l, e);
                        break;
                    case "link":
                    case "meta":
                    case "noscript":
                    case "script":
                    case "style":
                        a = this.flattenArrayTypeChildren(s, a, c, l);
                        break;
                    default:
                        e = this.mapObjectTypeChildren(s, e, c, l);
                        break
                }
            }), this.mapArrayTypeChildrenToProps(a, e)
        }
        render() {
            const {
                children: n,
                ...e
            } = this.props;
            let a = { ...e
                },
                {
                    helmetData: s
                } = e;
            if (n && (a = this.mapChildrenToProps(n, a)), s && !(s instanceof ph)) {
                const l = s;
                s = new ph(l.context, !0), delete a.helmetData
            }
            return s ? xe.createElement(yy, { ...a,
                context: s.value
            }) : xe.createElement(wx.Consumer, null, l => xe.createElement(yy, { ...a,
                context: l
            }))
        }
    };
const tA = () => {
    const {
        t: n,
        lang: e
    } = yu(), a = we.siteUrl, s = n.site.description || "Portafolio personal de un desarrollador con experiencia en React, Node.js y DevOps.", l = `${n.site.name} - ${n.site.title}`, o = n.site.name, c = we.icon.startsWith("http") ? we.icon : `${a}${we.icon}`;
    return A.jsxs(eA, {
        children: [A.jsx("title", {
            children: l
        }), A.jsx("meta", {
            name: "description",
            content: s
        }), A.jsx("meta", {
            name: "robots",
            content: "index, follow"
        }), A.jsx("meta", {
            property: "og:title",
            content: l
        }), A.jsx("meta", {
            property: "og:description",
            content: s
        }), A.jsx("meta", {
            property: "og:image",
            content: c
        }), A.jsx("meta", {
            property: "og:url",
            content: a
        }), A.jsx("meta", {
            property: "og:type",
            content: "website"
        }), A.jsx("meta", {
            property: "og:locale",
            content: e === "es" ? "es_ES" : "en_US"
        }), A.jsx("meta", {
            property: "og:site_name",
            content: o
        }), A.jsx("meta", {
            name: "twitter:card",
            content: "summary_large_image"
        }), A.jsx("meta", {
            name: "twitter:title",
            content: l
        }), A.jsx("meta", {
            name: "twitter:description",
            content: s
        }), A.jsx("meta", {
            name: "twitter:image",
            content: c
        }), A.jsx("link", {
            rel: "alternate",
            hrefLang: "es",
            href: a
        }), A.jsx("link", {
            rel: "alternate",
            hrefLang: "en",
            href: a
        }), A.jsx("link", {
            rel: "alternate",
            hrefLang: "x-default",
            href: a
        }), A.jsx("html", {
            lang: e
        }), A.jsx("link", {
            rel: "icon",
            type: "image/webp",
            href: we.icon
        }), A.jsx("script", {
            type: "application/ld+json",
            children: JSON.stringify({
                "@context": "https://schema.org",
                "@type": "Person",
                name: n.site.name,
                url: a,
                jobTitle: n.site.title,
                description: n.site.description,
                image: c,
                email: `mailto:${we.email}`,
                sameAs: [we.social.github, we.social.linkedin, we.social.twitter, we.social.discord].filter(Boolean)
            })
        })]
    })
};

function nA() {
    return A.jsxs("div", {
        className: "min-h-screen font-sans antialiased transition-colors duration-300",
        children: [A.jsx(tA, {}), A.jsx(f_, {}), A.jsx(e3, {}), A.jsx(VE, {}), A.jsx(AM, {}), A.jsx(qE, {}), A.jsx(BE, {}), A.jsx(UE, {}), A.jsx(YE, {}), A.jsx(XE, {})]
    })
}
s_.createRoot(document.getElementById("root")).render(A.jsx(J.StrictMode, {
    children: A.jsx(Mx, {
        children: A.jsx(c_, {
            children: A.jsx(nA, {})
        })
    })
}));